<?php

/**
 * Runs when the plugin is deleted in Plugins (not on deactivation).
 *
 * Always removes what only lives for the running plugin: cron events, the
 * report cache, daily salts, the migration lock. The collected data
 * (events, sessions, settings, unfinished migrations) goes only with the setting
 * "Beim Löschen des Plugins alle Daten entfernen"; a client who deletes and
 * reinstalls the plugin should not lose two years of statistics by accident.
 *
 * Self-contained: the plugin's classes are not loaded here.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

function analyticswp_uninstall_site(): void
{
    global $wpdb;

    foreach (['analyticswp_daily', 'analyticswp_scrub_personal_data', 'analyticswp_backfill_paths', 'analyticswp_retention', 'analyticswp_trigger_email_reports'] as $hook) {
        wp_clear_scheduled_hook($hook);
    }

    $like = function (string $prefix) use ($wpdb): string {
        return $wpdb->esc_like($prefix) . '%';
    };

    // Runtime state: report cache (awp_r_*), salts, migration lock. Migration cursors
    // stay, so that a reinstall finishes a backfill that was cut short.
    foreach (['_transient_analyticswp_', '_transient_timeout_analyticswp_', '_transient_awp_r_', '_transient_timeout_awp_r_', 'analyticswp_salt_', 'analyticswp_migration_lock'] as $prefix) {
        $wpdb->query($wpdb->prepare("DELETE FROM `{$wpdb->options}` WHERE option_name LIKE %s", $like($prefix)));
    }

    // The tables stay as they are: the schema version in the options decides
    // whether a reinstall creates them, so they go only together with it.
    if (!get_option('analyticswp_delete_data_on_uninstall')) {
        return;
    }

    $wpdb->query("DROP TABLE IF EXISTS `{$wpdb->prefix}analytics_wp_events`");
    $wpdb->query("DROP TABLE IF EXISTS `{$wpdb->prefix}analytics_wp_sessions`");
    $wpdb->query("DROP TABLE IF EXISTS `{$wpdb->prefix}analytics_wp_rate_limit`");
    $wpdb->query($wpdb->prepare("DELETE FROM `{$wpdb->options}` WHERE option_name LIKE %s", $like('analyticswp_')));
    delete_option('analyticswp_version_create_table');
    // Saved filter combinations of the users (Admin\FilterDialog).
    delete_metadata('user', 0, 'analyticswp_saved_filters', '', true);
    wp_cache_flush();
}

// The must-use plugin "schneller Messpunkt" (FastEndpoint), only if it is ours.
$analyticswp_mu = WPMU_PLUGIN_DIR . '/analyticswp-fast-endpoint.php';
if (is_file($analyticswp_mu) && strpos((string)file_get_contents($analyticswp_mu), 'analyticswp-fast-endpoint (managed by the plugin') !== false) {
    @unlink($analyticswp_mu);
}

if (is_multisite()) {
    $site_ids = get_sites(['fields' => 'ids', 'number' => 0]);
    foreach ($site_ids as $site_id) {
        switch_to_blog((int)$site_id);
        analyticswp_uninstall_site();
        restore_current_blog();
    }
} else {
    analyticswp_uninstall_site();
}
