<?php

defined('ABSPATH') || exit;

// The plugin's own classes only. Composer's autoloader also loaded the YAML
// parser Spyc on every request; DeviceDetector and Mustache are no longer
// used at runtime (the bot list is precompiled into Lib/BotPattern.php), so
// vendor/ stays out of release builds.
spl_autoload_register(function ($class) {
	$prefix = 'AnalyticsWP\\Lib\\';
	if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
		return;
	}
	$file = __DIR__ . '/Lib/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
	if (is_file($file)) {
		require $file;
	}
});

define('ANALYTICSWP_VERSION', '2.5.0');

use AnalyticsWP\Lib\Core;
use AnalyticsWP\Lib\Integrations;
use AnalyticsWP\Lib\Settings;
use AnalyticsWP\Lib\SuperSimpleWP;
use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\DashboardWidget;

/**
 * Plugin Name: AnalyticsWP
 * Description: Cookielose Analytics für WordPress mit UTM-Attribution. Fork von AnalyticsWP 2.3.0 (Solid Plugins).
 * Version: 2.5.0
 * Author: Dominik Seitz, basierend auf AnalyticsWP von Solid Plugins
 * License: GPL2
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Tested up to: 7.1
 * Update URI: https://raw.githubusercontent.com/Seitzdominik/analytics-upate
 */
class AnalyticsWP_Plugin
{
	public static function init(): void
	{
		SuperSimpleWP::register_plugin(
			array(
				'slug' => 'analyticswp',
				'settings' => Settings::settings_description(),
				'on_plugins_loaded' => function () {
					Core::init();
					App::init();
					\AnalyticsWP\Lib\Privacy::init();
					\AnalyticsWP\Lib\Updater::init();
					\AnalyticsWP\Lib\Abilities::init();
					\AnalyticsWP\Lib\FastEndpoint::init();
					\AnalyticsWP\Lib\Admin\ExportTab::init();
					\AnalyticsWP\Lib\Admin\FilterDialog::init();
					Integrations::init();
					DashboardWidget::init();

					add_action('admin_init', [App::class, 'redirect_after_activation']);

				}
			)
		);
	}
}

register_activation_hook(__FILE__, function () {
	set_transient('analyticswp_redirect_to_welcome_page', true, 30);
	\AnalyticsWP\Lib\FastEndpoint::sync();
});

register_deactivation_hook(__FILE__, function () {
	\AnalyticsWP\Lib\Migrations::unschedule();
	\AnalyticsWP\Lib\FastEndpoint::remove();
});

AnalyticsWP_Plugin::init();
