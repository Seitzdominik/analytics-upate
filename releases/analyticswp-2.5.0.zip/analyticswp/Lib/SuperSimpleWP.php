<?php

namespace AnalyticsWP\Lib;

/**
 * What is left of upstream's small plugin framework: the settings list
 * (Settings::settings_description()), their registration with a sanitizer
 * per type, reading a setting with its default, and the role check for the
 * admin screens. Menu and settings screen are the fork's own (Admin\App).
 */
class SuperSimpleWP
{
	/** @var array<string, mixed> */
	private static $plugin_registration_args = [
		'slug' => '',
		'settings' => [],
		'on_plugins_loaded' => '__return_null',
	];

	/**
	 * @param array<string, mixed> $args slug, settings, on_plugins_loaded
	 */
	public static function register_plugin($args): void
	{
		self::$plugin_registration_args = $args;

		add_action('admin_init', function () use ($args) {
			self::register_settings((string)$args['slug'], (array)$args['settings']);
		});

		add_action('plugins_loaded', function () use ($args) {
			$args['on_plugins_loaded']();
		});
	}

	/**
	 * Register each setting for options.php, with a sanitizer that only
	 * lets through what its type allows. The settings form posts all of
	 * them at once (Admin\Tabs\Settings::render()).
	 *
	 * @param array<string, array<string, mixed>> $settings
	 */
	private static function register_settings(string $slug, array $settings): void
	{
		foreach ($settings as $setting_slug => $setting) {
			register_setting($slug, $slug . '_' . $setting_slug, [
				'default' => $setting['default'] ?? false,
				'sanitize_callback' => function ($value) use ($setting) {
					return self::sanitize($value, $setting);
				},
			]);
		}
	}

	/**
	 * @param mixed                $value
	 * @param array<string, mixed> $setting
	 * @return mixed
	 */
	private static function sanitize($value, array $setting)
	{
		switch ($setting['type']) {
			case 'checkbox':
				return !empty($value) && $value !== '0' ? '1' : '';
			case 'select':
			case 'radio':
				$value = is_scalar($value) ? (string)$value : '';
				return array_key_exists($value, (array)($setting['options'] ?? [])) ? $value : (string)($setting['default'] ?? '');
			case 'wp-user-roles':
			case 'wp-user-roles-without-subscriber':
				$roles = function_exists('wp_roles') ? wp_roles()->get_names() : [];
				$out = [];
				foreach (is_array($value) ? $value : [] as $role => $on) {
					if (is_string($role) && isset($roles[$role]) && !empty($on)) {
						$out[$role] = '1';
					}
				}
				return $out;
			case 'hidden':
				// Amounts per form; App::sanitize_amounts_option() checks them.
				return is_array($value) ? $value : [];
			default:
				return is_scalar($value) ? sanitize_text_field((string)$value) : '';
		}
	}

	/**
	 * @return mixed The stored value or the setting's default.
	 */
	public static function get_setting($plugin_slug, $setting_slug)
	{
		/** @var mixed */
		$default = self::$plugin_registration_args['settings'][$setting_slug]['default'] ?? false;

		return get_option($plugin_slug . '_' . $setting_slug, $default);
	}

	/**
	 * Is the current user in one of $allowed_roles (role => '1')? Super
	 * admins always are.
	 *
	 * @param array<string, string> $allowed_roles
	 */
	public static function does_current_user_have_admin_access($allowed_roles = []): bool
	{
		static $has_admin_access = null;

		if ($has_admin_access !== null) {
			return $has_admin_access;
		}

		if (is_super_admin()) {
			return $has_admin_access = true;
		}

		foreach (wp_get_current_user()->roles as $role) {
			if (isset($allowed_roles[$role])) {
				return $has_admin_access = true;
			}
		}

		return $has_admin_access = false;
	}
}
