<?php

namespace AnalyticsWP\Lib\Admin;

use AnalyticsWP\Lib\Reports;

/**
 * The filter dialog in the head of every report page: "Wonach?" on the
 * left, the values of the period on the right (search, visits, a light
 * bar), saved combinations at the foot. A value sets its filter for the
 * whole page, one value per dimension; a set value removes it again.
 *
 * The values come per admin-ajax after the page is shown, so the page
 * itself does not get slower. Without JS the dialog is a <details> with
 * links (`fd` = dimension, `fq` = search, both only in the dialog's own
 * links).
 *
 * Saved combinations are user meta (SAVED_META), at most MAX_SAVED.
 */
class FilterDialog
{
    /** Dimension => [label, icon, plural for "Weitere"]. */
    const DIMENSIONS = [
        'channel' => ['Kanal', 'signpost', 'Kanäle'],
        'source' => ['Quelle', 'browser', 'Quellen'],
        'campaign' => ['Kampagne', 'megaphone', 'Kampagnen'],
        'page' => ['Seite', 'file', 'Seiten'],
        'device' => ['Gerät', 'desktop', 'Geräte'],
        'result' => ['Ergebnis', 'target', 'Ergebnisse'],
    ];

    /** Values shown at once; the search narrows the rest. */
    const MAX_VALUES = 8;

    /** Values read per dimension before the search filters them. */
    const READ_VALUES = 500;

    const NONCE = 'analyticswp_filter';
    const SAVED_META = 'analyticswp_saved_filters';
    const MAX_SAVED = 10;

    public static function init(): void
    {
        add_action('wp_ajax_analyticswp_filter_values', [self::class, 'ajax_values']);
        add_action('admin_post_analyticswp_saved_filter', [self::class, 'handle_saved']);
    }

    /**
     * The "Filter" button with the number of active filters, and its panel.
     */
    public static function render(): void
    {
        $filters = App::filters();
        $dim = self::requested_dimension();
        $query = self::requested_search();
        // Without JS the dialog stays open on its own links.
        $open = isset($_GET['fd']) || isset($_GET['fq']);

        echo '<details class="awp-filter"' . ($open ? ' open' : '') . ' data-awp-filter data-nonce="' . esc_attr(wp_create_nonce(self::NONCE)) . '">';
        echo '<summary class="awp-filter-button" aria-haspopup="dialog">' . Icons::svg('funnel') . '<span>Filter</span>'
            . (!empty($filters) ? '<span class="awp-filter-count" aria-label="' . esc_attr(count($filters) === 1 ? '1 Filter aktiv' : count($filters) . ' Filter aktiv') . '">' . count($filters) . '</span>' : '')
            . '</summary>';

        echo '<div class="awp-filter-panel" role="dialog" aria-label="Filter hinzufügen">';
        echo '<div class="awp-filter-head"><div><p class="awp-filter-title">Filter hinzufügen</p><p class="awp-filter-sub">Gilt für alle Zahlen auf dieser Seite. Mehrere Filter gelten zusammen.</p></div>'
            . '<a class="awp-filter-close" href="' . esc_url(App::url()) . '" aria-label="Schließen" data-awp-filter-close>' . Icons::svg('x') . '</a></div>';

        echo '<div class="awp-filter-grid"><div class="awp-filter-dims"><p class="awp-filter-label">Wonach?</p>';
        foreach (self::DIMENSIONS as $key => [$label, $icon]) {
            $on = $key === $dim;
            echo '<a class="awp-filter-dim' . ($on ? ' is-active' : '') . '" href="' . esc_url(App::url(['fd' => $key])) . '" data-awp-fdim="' . esc_attr($key) . '"' . ($on ? ' aria-current="true"' : '') . '>'
                . Icons::svg($icon) . '<span>' . esc_html($label) . '</span>'
                . (isset($filters[$key]) ? '<span class="awp-filter-dot" title="Filter aktiv"><span class="awp-sr">, aktiv</span></span>' : '') . '</a>';
        }
        echo '</div>';

        echo '<div class="awp-filter-values">';
        echo '<form method="get" action="' . esc_url(admin_url('admin.php')) . '" class="awp-filter-search" data-awp-fsearch>';
        foreach (self::state_fields() as $name => $value) {
            echo '<input type="hidden" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '">';
        }
        echo '<input type="hidden" name="fd" value="' . esc_attr($dim) . '">';
        echo '<label>' . Icons::svg('magnifying-glass') . '<input type="search" name="fq" value="' . esc_attr($query) . '" placeholder="' . esc_attr(self::DIMENSIONS[$dim][0] . ' suchen') . '" aria-label="' . esc_attr(self::DIMENSIONS[$dim][0] . ' suchen') . '" autocomplete="off"></label></form>';
        // The values only on the dialog's own links; with JS they load
        // when the dialog opens.
        echo '<div class="awp-filter-list" data-awp-flist aria-live="polite">' . ($open ? self::values_html($dim, $query) : '') . '</div>';
        echo '</div></div>';

        self::saved_foot($filters);
        echo '</div></details>';
    }

    /**
     * The values of one dimension as links, for the dialog and admin-ajax.
     */
    public static function values_html(string $dim, string $query): string
    {
        [$label] = self::DIMENSIONS[$dim];
        [$rows, $more] = self::values($dim, $query);

        if (empty($rows)) {
            $text = $query !== '' ? 'Nichts gefunden für „' . $query . '“.' : 'Noch keine Werte in diesem Zeitraum.';
            return '<p class="awp-filter-empty">' . esc_html($text) . '</p>';
        }

        $max = max(array_column($rows, 'count')) ?: 1;
        $html = '<div class="awp-fval-head"><span>' . esc_html($label) . '</span><span>Besuche</span></div>';
        foreach ($rows as $row) {
            $width = round(max(1.5, $row['count'] / $max * 100), 1);
            $html .= '<a class="awp-fval' . ($row['active'] ? ' is-on' : '') . '" href="' . esc_url($row['url']) . '"' . ($row['active'] ? ' aria-current="true" title="Filter entfernen"' : '') . '>'
                . '<span class="awp-fval-label"><span class="awp-fval-bar" style="width:' . $width . '%"></span><span class="awp-fval-text">'
                . ($row['active'] ? Icons::svg('check') : '')
                . '<span class="awp-fval-name">' . esc_html($row['label']) . '</span>'
                . ($row['meta'] !== '' ? '<span class="awp-fval-meta">' . esc_html($row['meta']) . '</span>' : '')
                . ($row['active'] ? '<span class="awp-sr">, aktiv, ein Klick entfernt den Filter</span>' : '')
                . '</span></span>'
                . '<span class="awp-fval-count' . ($row['count'] < \AnalyticsWP\Lib\Insights::MIN_RATE_BASE ? ' is-few' : '') . '">' . esc_html(Format::number($row['count'])) . '</span></a>';
        }
        if ($more > 0) {
            $html .= '<p class="awp-filter-more">Weitere ' . esc_html(Format::number($more)) . ' – Suche eingrenzen</p>';
        }

        return $html;
    }

    /**
     * Values of a dimension in the period with all other active filters,
     * not the dimension's own (so the other values stay visible). The most
     * visited first, at most MAX_VALUES, matching the search.
     *
     * @return array{0: list<array{label: string, meta: string, count: int, active: bool, url: string}>, 1: int}
     */
    public static function values(string $dim, string $query): array
    {
        $period = App::period();
        $filters = App::filters();
        $own = $filters[$dim] ?? null;
        unset($filters[$dim]);

        $raw = [];
        if ($dim === 'result') {
            foreach (Reports::result_counts($period, $filters) as $value => $count) {
                $raw[] = [$value, Reports::RESULT_LABELS[$value], '', $count];
            }
        } elseif ($dim === 'page') {
            foreach (Reports::pages($period, $filters, self::READ_VALUES) as $row) {
                $raw[] = [$row['path'], Format::path($row['path']), '', $row['sessions']];
            }
            usort($raw, function ($a, $b) {
                return $b[3] <=> $a[3] ?: strcmp($a[0], $b[0]);
            });
        } else {
            $currency = Reports::main_currency($period);
            $channel_of = in_array($dim, ['source', 'campaign'], true) ? Reports::breakdown_channels($dim, $period, $filters) : [];
            foreach (Reports::breakdown($dim, $period, $filters, $currency, self::READ_VALUES) as $row) {
                if ($dim === 'campaign' && $row['value'] === null) {
                    continue;
                }
                $value = $row['value'] === null ? Reports::NONE : (string)$row['value'];
                $meta = isset($channel_of[$value]) ? Format::channel($channel_of[$value]) : '';
                $raw[] = [$value, Ui::dimension_label($dim, $row['value']), $meta, (int)$row['sessions']];
            }
        }

        if ($query !== '') {
            $raw = array_values(array_filter($raw, function ($row) use ($query) {
                return mb_stripos($row[1] . ' ' . $row[2] . ' ' . $row[0], $query) !== false;
            }));
        }

        $rows = [];
        foreach (array_slice($raw, 0, self::MAX_VALUES) as [$value, $label, $meta, $count]) {
            $active = $own !== null && $own === $value;
            $rows[] = [
                'label' => $label,
                'meta' => $meta,
                'count' => (int)$count,
                'active' => $active,
                // One value per dimension: a new one replaces the old.
                'url' => App::url(['f_' . $dim => $active ? null : $value]),
            ];
        }

        return [$rows, max(0, count($raw) - self::MAX_VALUES)];
    }

    /**
     * admin-ajax: the value list of one dimension for the current view (the
     * request carries the view's parameters). Read only.
     */
    public static function ajax_values(): void
    {
        if (!App::can_view() || !check_ajax_referer(self::NONCE, 'nonce', false)) {
            status_header(403);
            exit;
        }

        $html = self::values_html(self::requested_dimension(), self::requested_search());

        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('X-Robots-Tag: noindex');
        echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in values_html()
        exit;
    }

    /** `fd`, else "Kanal". (`dim` and `q` belong to the tabs.) */
    private static function requested_dimension(): string
    {
        $dim = isset($_GET['fd']) && is_string($_GET['fd']) ? sanitize_key($_GET['fd']) : '';

        return isset(self::DIMENSIONS[$dim]) ? $dim : 'channel';
    }

    private static function requested_search(): string
    {
        return isset($_GET['fq']) && is_string($_GET['fq']) ? mb_substr(trim(sanitize_text_field(wp_unslash($_GET['fq']))), 0, 100) : '';
    }

    /**
     * The view's state as hidden fields of the search form (no JS).
     *
     * @return array<string, string>
     */
    private static function state_fields(): array
    {
        $fields = ['page' => App::SLUG];
        $params = array_merge(['tab', 'range', 'from', 'to', 'metric', 'dim', 'model', 'ct'], array_map(function ($key) {
            return 'f_' . $key;
        }, Reports::filter_keys()));
        foreach ($params as $param) {
            if (isset($_GET[$param]) && is_string($_GET[$param]) && $_GET[$param] !== '') {
                $fields[$param] = sanitize_text_field(wp_unslash($_GET[$param]));
            }
        }

        return $fields;
    }

    // Saved combinations ------------------------------------------------------

    /**
     * The current user's saved combinations.
     *
     * @return list<array{name: string, filters: array<string, string>}>
     */
    public static function saved(): array
    {
        $saved = get_user_meta(get_current_user_id(), self::SAVED_META, true);
        $out = [];
        foreach (is_array($saved) ? $saved : [] as $item) {
            if (!is_array($item) || !isset($item['name'], $item['filters']) || !is_array($item['filters'])) {
                continue;
            }
            $filters = self::clean_filters($item['filters']);
            if (!empty($filters)) {
                $out[] = ['name' => (string)$item['name'], 'filters' => $filters];
            }
        }

        return array_slice($out, 0, self::MAX_SAVED);
    }

    /**
     * Only known filter keys and plain values, in the order of filter_keys().
     *
     * @param array<mixed> $filters
     * @return array<string, string>
     */
    private static function clean_filters(array $filters): array
    {
        $query = [];
        foreach ($filters as $key => $value) {
            if (is_string($key) && is_string($value)) {
                $query['f_' . $key] = wp_slash($value);
            }
        }

        return Reports::filters_from($query);
    }

    /**
     * "Organische Suche · Smartphone": the values of a combination.
     *
     * @param array<string, string> $filters
     */
    public static function auto_name(array $filters): string
    {
        $parts = [];
        foreach ($filters as $key => $value) {
            $parts[] = Ui::dimension_label($key, $value === Reports::NONE ? null : $value);
        }
        $name = implode(' · ', $parts);

        return mb_strlen($name) > 60 ? mb_substr($name, 0, 59) . '…' : $name;
    }

    /**
     * "Gespeichert:" with the combinations as pills (a click sets exactly
     * these filters, × deletes), "Aktuelle Filter speichern" and renaming.
     *
     * @param array<string, string> $filters
     */
    private static function saved_foot(array $filters): void
    {
        $saved = self::saved();
        $redirect = App::url();
        $hidden = function (string $op) use ($redirect) {
            return '<input type="hidden" name="action" value="analyticswp_saved_filter"><input type="hidden" name="op" value="' . esc_attr($op) . '">'
                . '<input type="hidden" name="redirect" value="' . esc_attr($redirect) . '">' . wp_nonce_field('analyticswp_saved_filter', '_wpnonce', false, false);
        };
        $post = esc_url(admin_url('admin-post.php'));

        echo '<div class="awp-filter-foot">' . Icons::svg('bookmark-simple') . '<span class="awp-filter-saved-label">Gespeichert:</span>';
        if (empty($saved)) {
            echo '<span class="awp-filter-saved-none">noch nichts</span>';
        }
        foreach ($saved as $i => $item) {
            $chips = [];
            foreach ($item['filters'] as $key => $value) {
                $chips[] = (App::FILTER_NAMES[$key] ?? $key) . ': ' . Ui::dimension_label($key, $value === Reports::NONE ? null : $value);
            }
            $args = ['f_*' => null];
            foreach ($item['filters'] as $key => $value) {
                $args['f_' . $key] = $value;
            }
            echo '<span class="awp-saved-pill"><a href="' . esc_url(App::url($args)) . '" title="' . esc_attr(implode(' · ', $chips)) . '">' . esc_html($item['name']) . '</a>'
                . '<form method="post" action="' . $post . '">' . $hidden('delete') . '<input type="hidden" name="index" value="' . (int)$i . '">'
                . '<button type="submit" aria-label="' . esc_attr('„' . $item['name'] . '“ löschen') . '" title="Löschen">' . Icons::svg('x') . '</button></form></span>';
        }

        $exists = false;
        foreach ($saved as $item) {
            $exists = $exists || $item['filters'] == $filters;
        }
        if (empty($filters)) {
            $why = 'Erst einen Filter setzen';
        } elseif ($exists) {
            $why = 'Diese Filter sind schon gespeichert';
        } elseif (count($saved) >= self::MAX_SAVED) {
            $why = 'Höchstens ' . self::MAX_SAVED . ' gespeichert. Lösche erst eine.';
        } else {
            $why = '';
        }
        echo '<form method="post" action="' . $post . '" class="awp-filter-save">' . $hidden('save');
        foreach ($filters as $key => $value) {
            echo '<input type="hidden" name="f_' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
        }
        echo '<button type="submit" class="awp-filter-save-button"' . ($why !== '' ? ' disabled title="' . esc_attr($why) . '"' : '') . '>Aktuelle Filter speichern</button></form>';

        if (!empty($saved)) {
            echo '<details class="awp-filter-rename"><summary>Umbenennen</summary><form method="post" action="' . $post . '">' . $hidden('rename');
            foreach ($saved as $i => $item) {
                echo '<label><span class="awp-sr">Name ' . ($i + 1) . '</span><input type="text" name="names[' . (int)$i . ']" value="' . esc_attr($item['name']) . '" maxlength="60"></label>';
            }
            echo '<button type="submit" class="button">Namen speichern</button></form></details>';
        }
        echo '</div>';
    }

    /**
     * admin-post: save, delete or rename a combination of the current user,
     * then back to the view.
     */
    public static function handle_saved(): void
    {
        if (!App::can_view()) {
            wp_die('Keine Berechtigung.', 403);
        }
        check_admin_referer('analyticswp_saved_filter');

        $saved = self::saved();
        $op = isset($_POST['op']) && is_string($_POST['op']) ? sanitize_key($_POST['op']) : '';

        if ($op === 'save') {
            $filters = Reports::filters_from($_POST);
            $exists = false;
            foreach ($saved as $item) {
                $exists = $exists || $item['filters'] == $filters;
            }
            if (!empty($filters) && !$exists && count($saved) < self::MAX_SAVED) {
                $saved[] = ['name' => self::auto_name($filters), 'filters' => $filters];
            }
        } elseif ($op === 'delete') {
            $index = isset($_POST['index']) ? absint($_POST['index']) : -1;
            if (isset($saved[$index])) {
                array_splice($saved, $index, 1);
            }
        } elseif ($op === 'rename' && isset($_POST['names']) && is_array($_POST['names'])) {
            foreach ($_POST['names'] as $index => $name) {
                if (isset($saved[(int)$index]) && is_string($name)) {
                    $name = mb_substr(trim(sanitize_text_field(wp_unslash($name))), 0, 60);
                    $saved[(int)$index]['name'] = $name !== '' ? $name : self::auto_name($saved[(int)$index]['filters']);
                }
            }
        }
        update_user_meta(get_current_user_id(), self::SAVED_META, array_values($saved));

        $redirect = isset($_POST['redirect']) && is_string($_POST['redirect']) ? wp_unslash($_POST['redirect']) : '';
        $redirect = wp_validate_redirect($redirect, admin_url('admin.php?page=' . App::SLUG));
        if (strpos($redirect, admin_url('admin.php')) !== 0) {
            $redirect = admin_url('admin.php?page=' . App::SLUG);
        }
        wp_safe_redirect($redirect);
        exit;
    }
}
