<?php

namespace AnalyticsWP\Lib\Admin;

/**
 * What the admin tabs (Admin\Tabs\*) share: the change badge of a key
 * figure, value formats, rows of visit cards, page grouping and the
 * device icons. Each tab
 * reads period and filters from the URL (App::period(), App::filters())
 * and renders cards; App::render_tab() picks the tab.
 */
abstract class Tab
{
    /**
     * "▲ +14,7 %" in petrol when better, amber when worse; the direction is
     * in the text for screen readers.
     *
     * @param int|float $value
     * @param int|float $previous
     */
    protected static function kpi_delta($value, $previous, bool $higher_is_better): string
    {
        $text = \AnalyticsWP\Lib\Insights::signed_change($value, $previous);
        // Nothing before, something now: "neu" instead of a percentage.
        if ($text === null && (float)$previous == 0 && (float)$value > 0) {
            return '<span class="awp-delta ' . ($higher_is_better ? 'is-good' : 'is-bad') . '">neu<span class="awp-sr"> (vorher keine)</span></span>';
        }
        if ($text === null || $text === '± 0 %') {
            return '<span class="awp-delta">' . esc_html($text ?? '–') . ($text === null ? '<span class="awp-sr"> kein Vergleichswert</span>' : '') . '</span>';
        }

        $up = (float)$value > (float)$previous;
        $good = $up === $higher_is_better;

        return '<span class="awp-delta ' . ($good ? 'is-good' : 'is-bad') . '">' . Icons::svg($up ? 'arrow-up' : 'arrow-down')
            . esc_html($text) . '<span class="awp-sr">' . ($good ? ' (besser)' : ' (schlechter)') . '</span></span>';
    }

    /**
     * @param int|float $value
     */
    protected static function format_value($value, string $format, string $currency): string
    {
        switch ($format) {
            case 'percent':
                return Format::percent($value);
            case 'money':
                return Format::money($value, $currency, 0);
            case 'duration':
                return Format::duration($value);
            default:
                return Format::number($value);
        }
    }

    /**
     * Merge rows whose paths differ only by numbers (Format::page_group()).
     *
     * @param list<array<string, mixed>> $rows
     * @param list<string> $sums Columns to add up.
     * @param list<string> $averages Columns averaged, weighted by $weight.
     * @return list<array<string, mixed>>
     */
    public static function group_pages(array $rows, string $key, array $sums, array $averages, string $weight): array
    {
        $out = [];
        foreach ($rows as $row) {
            if ($row[$key] === null) {
                continue;
            }
            [$group, $meta] = Format::page_group((string)$row[$key]);
            if (!isset($out[$group])) {
                $out[$group] = $row;
                $out[$group][$key] = $group;
                $out[$group]['path'] = $group;
                $out[$group]['meta'] = $meta;
                $out[$group]['grouped'] = $group !== (string)$row[$key];
                continue;
            }
            $merged = &$out[$group];
            $w_old = (float)$merged[$weight];
            $w_new = (float)$row[$weight];
            foreach ($averages as $column) {
                if ($row[$column] === null) {
                    continue;
                }
                $merged[$column] = $merged[$column] === null || $w_old + $w_new <= 0
                    ? $row[$column]
                    : ((float)$merged[$column] * $w_old + (float)$row[$column] * $w_new) / ($w_old + $w_new);
            }
            foreach ($sums as $column) {
                $merged[$column] = ($merged[$column] ?? 0) + ($row[$column] ?? 0);
            }
            $merged['grouped'] = true;
            unset($merged);
        }

        return array_values($out);
    }

    /** Columns of a card row about visits; the panel shows them all. */
    const VISIT_HEADS = ['Besuche', 'Anteil', 'Absprung', 'Conv.', 'Conv.-Rate', 'Umsatz'];

    /** In a half-width card: visits, conversions, revenue. */
    const VISIT_COLS_HALF = [0, 3, 5];

    /**
     * Rows of a card tab from a breakdown (Reports::breakdown()): the
     * value with its filter link, VISIT_HEADS as cells. Shares are of
     * $total visits. $extra filters narrow the tab (e.g. channel = ai);
     * when the page is filtered to another value of the same key, the tab
     * has no rows.
     *
     * @param array<string, string> $filters
     * @param array<string, string> $extra
     * @return callable(int): list<array<string, mixed>>
     */
    public static function breakdown_rows(string $dimension, array $period, array $filters, string $currency, float $total, array $extra = [], bool $with_channel = false, bool $skip_none = false): callable
    {
        return function (int $limit) use ($dimension, $period, $filters, $currency, $total, $extra, $with_channel, $skip_none) {
            foreach ($extra as $key => $value) {
                if (isset($filters[$key]) && $filters[$key] !== $value) {
                    return [];
                }
            }
            $filters = $extra + $filters;
            $channel_of = $with_channel ? \AnalyticsWP\Lib\Reports::breakdown_channels($dimension, $period, $filters) : [];

            $rows = [];
            foreach (\AnalyticsWP\Lib\Reports::breakdown($dimension, $period, $filters, $currency, $limit + 1) as $row) {
                if ($skip_none && ($row['value'] === null || $row['value'] === '')) {
                    continue;
                }
                // An exit page filters the visits that viewed it.
                $filter = $dimension === 'exit'
                    ? ($row['value'] !== null ? ['f_page' => (string)$row['value']] : [])
                    : Ui::dimension_filter($dimension, $row['value']);
                $channel = $channel_of[(string)$row['value']] ?? null;
                $rows[] = [
                    'label' => Ui::dimension_label($dimension, $row['value']),
                    'meta' => $channel !== null ? Format::channel($channel) : '',
                    'icon' => $dimension === 'channel' ? Channels::icon($row['value']) : ($dimension === 'device' ? (self::DEVICE_ICONS[(string)$row['value']] ?? 'desktop') : ''),
                    'value' => (int)$row['sessions'],
                    'url' => $filter ? App::url($filter) : '',
                    'cells' => [
                        Ui::cell_number((int)$row['sessions']),
                        Ui::cell_share((int)$row['sessions'], $total),
                        Ui::cell_rate((float)$row['bounce_rate'], (int)$row['sessions']),
                        Ui::cell_number((int)$row['conversions']),
                        Ui::cell_rate((float)$row['conversion_rate'], (int)$row['sessions']),
                        Ui::cell_money((float)$row['revenue'], $currency),
                    ],
                ];
            }

            return array_slice($rows, 0, $limit);
        };
    }

    const DEVICE_ICONS = ['desktop' => 'desktop', 'mobile' => 'device-mobile', 'tablet' => 'device-tablet'];

    /**
     * A label with a petrol bar behind it, for the compact lists.
     */
    protected static function bar_label(string $text, int $value, int $max, string $url = ''): string
    {
        $width = max(1.5, round($value / max(1, $max) * 100, 1));
        $label = $url !== '' ? '<a href="' . esc_url($url) . '">' . esc_html($text) . '</a>' : esc_html($text);

        return '<span class="awp-barlabel"><span class="awp-cell-bar" style="width:' . $width . '%;background:' . esc_attr(Channels::bar_color(null)) . '"></span>'
            . '<span class="awp-cell-text" title="' . esc_attr($text) . '">' . $label . '</span></span>';
    }
}
