<?php

namespace AnalyticsWP\Lib\Admin\Tabs;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Channels;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Icons;
use AnalyticsWP\Lib\Admin\Tab;
use AnalyticsWP\Lib\Admin\Ui;
use AnalyticsWP\Lib\Insights;
use AnalyticsWP\Lib\Reports;

/**
 * Tab "Live": what is happening right now. The heart is the number of
 * visitors with a pulse and the visitors per minute of the last 30
 * minutes; then today against yesterday until the same time, and cards for
 * the visitors on the site, the last 30 minutes and where they come from.
 * Reloads itself every 30 seconds (admin.js).
 */
class Live extends Tab
{
    /** Feed icon per event type; conversions use their kind's icon. */
    const FEED_ICONS = [
        'pageview' => 'file',
        'outbound' => 'arrow-square-out',
        'download' => 'download-simple',
        'contact' => 'phone',
        'form_submission' => 'textbox',
        'checkout_confirmed' => 'shopping-cart',
    ];

    const FEED_LABELS = [
        'pageview' => 'Seitenaufruf',
        'outbound' => 'Link nach außen',
        'download' => 'Download',
        'contact' => 'Kontakt-Klick',
        'form_submission' => 'Formular',
        'checkout_confirmed' => 'Bestellung bestätigt',
    ];

    public static function render(): void
    {
        $live = Reports::live();

        App::page_head(['live' => true]);

        echo '<div class="awp-layout" data-awp-refresh="30">';
        echo self::insight($live);
        self::heart($live);
        self::kpis($live['today'], $live['yesterday_so_far']);
        self::cards($live);
        echo '</div>';
    }

    /**
     * Who is reading what right now, and the latest conversion of the
     * last 30 minutes. Nobody there: pending, with yesterday at this time.
     *
     * @param array<string, mixed> $live
     */
    private static function insight(array $live): string
    {
        $latest = null;
        foreach ($live['events'] as $row) {
            if (!empty($row['conversion_type'])) {
                $latest = $row;
                break;
            }
        }
        $then = $latest !== null
            ? ucfirst(Format::ago((string)$latest['timestamp'])) . ': ' . Format::conversion_type((string)$latest['conversion_type']) . ' über ' . Format::channel($latest['channel']) . '.'
            : 'Heute bisher ' . Format::number($live['today']['sessions']) . ($live['today']['sessions'] === 1 ? ' Besuch.' : ' Besuche.');

        if ((int)$live['visitors'] === 0 || empty($live['visits'])) {
            $yesterday = (int)$live['yesterday'];
            return Ui::insight_line('pending', 'Gerade ist niemand da.', $yesterday > 0
                ? 'Gestern um diese Zeit ' . ($yesterday === 1 ? 'war 1 Besucher' : 'waren ' . Format::number($yesterday) . ' Besucher') . ' online. ' . $then
                : $then);
        }

        $visit = $live['visits'][0];
        $title = $visit['path'] !== null
            ? 'Gerade liest jemand ' . $visit['path'] . ', über ' . Format::channel($visit['channel']) . '.'
            : 'Gerade ist jemand über ' . Format::channel($visit['channel']) . ' auf deiner Website.';

        return Ui::insight_line('good', $title, $then);
    }

    /**
     * The large number with a pulse and the visitors per minute of the last
     * 30 minutes. Nobody there: a grey dot, and the bars show yesterday at
     * the same time in grey.
     *
     * @param array<string, mixed> $live
     */
    private static function heart(array $live): void
    {
        $count = (int)$live['visitors'];
        $sub = $count === 0 ? 'gerade auf deiner Website · gestern um diese Zeit: ' . Format::number((int)$live['yesterday']) : 'gerade auf deiner Website';

        echo '<section class="awp-card awp-span-all awp-live2' . ($count > 0 ? ' is-active' : '') . '" aria-label="Gerade auf der Website">';
        echo '<div class="awp-live2-now"><span class="awp-live-dot" aria-hidden="true"></span><span class="awp-live2-number">' . esc_html(Format::number($count)) . '</span>'
            . '<span class="awp-live2-sub">' . esc_html($sub) . '</span></div>';
        // Nobody there in the last 30 minutes: yesterday at the same time, grey.
        $quiet = $count === 0 && max($live['per_minute']) === 0;
        echo self::minute_bars($quiet ? $live['per_minute_yesterday'] : $live['per_minute'], $quiet);
        echo '</section>';
    }

    /**
     * "Besucher pro Minute": the last 30 minutes, "jetzt" on the right.
     *
     * @param list<int> $per_minute oldest first
     */
    private static function minute_bars(array $per_minute, bool $yesterday = false): string
    {
        $max = max(1, max($per_minute));
        $last = count($per_minute) - 1;
        $caption = $yesterday ? 'Besucher gestern zur selben Zeit, pro Minute' : 'Besucher pro Minute';
        $html = '<figure class="awp-live2-chart' . ($yesterday ? ' is-yesterday' : '') . '"><figcaption>' . esc_html($caption) . '</figcaption><div class="awp-live2-bars" role="img" aria-label="'
            . esc_attr($caption . ' in den letzten 30 Minuten, zuletzt ' . end($per_minute)) . '">';
        foreach ($per_minute as $i => $value) {
            $ago = $last - $i;
            $title = ($ago === 0 ? 'Diese Minute' : 'Vor ' . $ago . ' Min.') . ': ' . $value . ($value === 1 ? ' Besucher' : ' Besucher');
            $html .= '<span title="' . esc_attr($title) . '"' . ($i === $last ? ' class="is-now"' : '') . '><i style="height:' . ($value > 0 ? max(4, round($value / $max * 100)) : 0) . '%"></i></span>';
        }
        $html .= '</div><div class="awp-live2-ticks" aria-hidden="true">';
        foreach ([29 => '−29 Min.', 20 => '−20 Min.', 10 => '−10 Min.', 0 => 'jetzt'] as $ago => $label) {
            $html .= '<span style="left:' . round(($last - $ago + 0.5) / ($last + 1) * 100, 2) . '%">' . esc_html($label) . '</span>';
        }

        return $html . '</div></figure>';
    }

    /**
     * Today so far against yesterday until the same time.
     *
     * @param array{sessions: int, pageviews: int, conversions: int} $today
     * @param array{sessions: int, pageviews: int, conversions: int} $yesterday
     */
    private static function kpis(array $today, array $yesterday): void
    {
        $tiles = [];
        foreach (['sessions' => 'Besuche heute', 'pageviews' => 'Seitenaufrufe heute', 'conversions' => 'Conversions heute'] as $key => $label) {
            $delta = $today[$key] === 0
                ? '<span class="awp-delta">gestern bis jetzt: ' . esc_html(Format::number($yesterday[$key])) . '</span>'
                : self::kpi_delta($today[$key], $yesterday[$key], true);
            $tiles[] = [
                'key' => $key,
                'label' => $label,
                'help' => 'Seit Mitternacht, verglichen mit gestern bis zur selben Uhrzeit (' . Format::number($yesterday[$key]) . ').',
                'value' => Format::number($today[$key]),
                'delta' => strpos($delta, 'gestern') !== false ? $delta : (string)preg_replace('#</span>$#', ' ggü. gestern</span>', $delta),
            ];
        }

        echo '<section class="awp-card awp-span-all" aria-label="Heute">' . Ui::kpi_bar($tiles) . '</section>';
    }

    /**
     * Visitors and pages right now, the last 30 minutes (all, conversions),
     * and the channels of the last 30 minutes.
     *
     * @param array<string, mixed> $live
     */
    private static function cards(array $live): void
    {
        $nobody = 'Gerade ist niemand da. Gestern um diese Zeit: ' . Format::number((int)$live['yesterday']) . ' Besucher.';
        $quiet = 'In der letzten halben Stunde ist nichts passiert.';

        $visitors = function (int $limit) use ($live) {
            $rows = [];
            foreach (array_slice($live['visits'], 0, $limit) as $visit) {
                $device = (string)$visit['device'];
                $rows[] = [
                    'label' => $visit['path'] ?? '–',
                    'meta' => Format::channel($visit['channel']) . ((int)$visit['conversions'] > 0 ? ' · Conversion' : ''),
                    'icon' => Channels::icon($visit['channel']),
                    'value' => (int)$visit['pageviews'],
                    'cells' => [
                        Ui::cell_number((int)$visit['pageviews']),
                        ['<span title="' . esc_attr(Format::device($device)) . '">' . Icons::svg(self::DEVICE_ICONS[$device] ?? 'desktop') . '<span class="awp-sr">' . esc_html(Format::device($device)) . '</span></span>', Format::device($device)],
                        [esc_html(self::since((string)$visit['started_at'])), (string)$visit['started_at']],
                    ],
                ];
            }
            return $rows;
        };
        $pages = function (int $limit) use ($live) {
            $rows = [];
            foreach (array_slice($live['pages'], 0, $limit) as $row) {
                $rows[] = ['label' => (string)$row['path'], 'value' => (int)$row['visitors'], 'cells' => [Ui::cell_number((int)$row['visitors']), Ui::cell_number((int)$row['views'])]];
            }
            return $rows;
        };
        $feed = function (bool $only_conversions) use ($live) {
            return function (int $limit) use ($live, $only_conversions) {
                $rows = [];
                foreach ($live['events'] as $row) {
                    $type = (string)$row['event_type'];
                    $conversion = (string)($row['conversion_type'] ?? '');
                    if ($only_conversions && $conversion === '') {
                        continue;
                    }
                    if ($conversion !== '') {
                        $icon = Format::CONVERSION_KINDS[Format::conversion_kind($conversion)][1];
                        $what = Format::conversion_type($conversion);
                    } elseif ($type === 'pageview' && !empty($row['search'])) {
                        $icon = 'magnifying-glass';
                        $what = 'Suche „' . mb_substr((string)$row['search'], 0, 60) . '“';
                    } else {
                        $icon = self::FEED_ICONS[$type] ?? 'cursor-click';
                        $what = (self::FEED_LABELS[$type] ?? $type) . ($row['path'] !== null && $row['path'] !== '' ? ' ' . $row['path'] : '');
                    }
                    $value = $conversion !== '' && $row['revenue'] !== null && (float)$row['revenue'] > 0 ? ' · ' . Format::money((float)$row['revenue'], (string)$row['currency']) : '';
                    $rows[] = [
                        'label' => $what,
                        'meta' => Format::channel($row['channel']) . ($conversion !== '' ? ' · Conversion' : '') . $value,
                        'icon' => $icon,
                        'value' => 1,
                        'cells' => [[esc_html(self::since((string)$row['timestamp'])), (string)$row['timestamp']]],
                    ];
                    if (count($rows) >= $limit) {
                        break;
                    }
                }
                return $rows;
            };
        };
        $channels = function (int $limit) use ($live) {
            $rows = [];
            foreach (array_slice($live['channels'], 0, $limit) as $row) {
                $rows[] = ['label' => Format::channel($row['channel']), 'icon' => Channels::icon($row['channel']), 'value' => (int)$row['visits'], 'cells' => [Ui::cell_number((int)$row['visits'])]];
            }
            return $rows;
        };

        Ui::card_row([[
            'key' => 'now',
            'title' => 'Gerade auf der Website',
            'tabs' => [
                'visitors' => ['label' => 'Besucher', 'col' => 'Aktuelle Seite', 'heads' => ['Seiten', 'Gerät', 'Seit'], 'rows' => $visitors, 'empty' => $nobody],
                'pages' => ['label' => 'Seiten', 'col' => 'Seite', 'heads' => ['Besucher', 'Aufrufe'], 'rows' => $pages, 'empty' => $quiet],
            ],
        ]]);
        Ui::card_row([
            [
                'key' => 'feed',
                'title' => 'Letzte 30 Minuten',
                'tabs' => [
                    'all' => ['label' => 'Alles', 'col' => 'Ereignis', 'heads' => ['Vor'], 'rows' => $feed(false), 'empty' => $quiet],
                    'conv' => ['label' => 'Conversions', 'col' => 'Conversion', 'heads' => ['Vor'], 'rows' => $feed(true), 'empty' => 'Keine Conversion in der letzten halben Stunde.'],
                ],
            ],
            [
                'key' => 'sources',
                'title' => 'Woher sie gerade kommen',
                'tabs' => [
                    'channel' => ['label' => 'Kanal', 'col' => 'Kanal', 'heads' => ['Besuche'], 'rows' => $channels, 'empty' => 'Noch keine Besuche in den letzten 30 Minuten.'],
                ],
            ],
        ]);
    }

    /**
     * "3 Min." since a UTC time.
     */
    private static function since(string $utc): string
    {
        $time = strtotime($utc . ' UTC');
        $minutes = $time ? max(0, intdiv(time() - $time, 60)) : 0;
        if ($minutes < 1) {
            return '< 1 Min.';
        }

        return $minutes < 60 ? $minutes . ' Min.' : intdiv($minutes, 60) . ' Std. ' . ($minutes % 60) . ' Min.';
    }
}
