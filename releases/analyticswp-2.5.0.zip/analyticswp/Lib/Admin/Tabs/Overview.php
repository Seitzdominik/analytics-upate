<?php

namespace AnalyticsWP\Lib\Admin\Tabs;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Channels;
use AnalyticsWP\Lib\Admin\Chart;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Icons;
use AnalyticsWP\Lib\Admin\Tab;
use AnalyticsWP\Lib\Admin\Ui;
use AnalyticsWP\Lib\Reports;

/**
 * Tab "Übersicht": one insight line, six key figures with the chart, and
 * four cards with tabs: sources, pages, conversions, events.
 */
class Overview extends Tab
{
    /**
     * Key figures of the overview: metric => [label, chart title, format,
     * higher is better, explanation]. Every tile switches the chart.
     */
    const OVERVIEW_KPIS = [
        'visitors' => ['Besucher', 'Besucher', 'number', true, 'visitors'],
        'pageviews' => ['Seitenaufrufe', 'Seitenaufrufe', 'number', true, 'pageviews'],
        'bounce_rate' => ['Absprungrate', 'Absprungrate', 'percent', false, 'bounce'],
        'duration' => ['Ø Besuchsdauer', 'Ø Besuchsdauer', 'duration', true, 'duration'],
        'conversions' => ['Conversions', 'Conversions', 'number', true, 'conversions'],
        'revenue' => ['Umsatz', 'Umsatz', 'money', true, 'revenue'],
    ];

    public static function render(): void
    {
        $period = App::period();
        $filters = App::filters();

        if (!Reports::has_data()) {
            App::page_head(['since' => null]);
            self::first_start();
            return;
        }

        // Measurement start: before it there is nothing to compare with,
        // and the chart starts there instead of at zero.
        $since = Reports::first_seen_day();
        $compare = $since === null || $since <= $period['prev_end'];
        $since_in_period = $since !== null && $since > $period['start'] && $since <= $period['end'];

        App::page_head(['since' => $since]);

        $currency = Reports::main_currency($period);
        $totals = Reports::totals($period, $filters, $currency);
        $series = Reports::timeseries($period, $filters, $currency);
        $channels = Reports::breakdown('channel', $period, $filters, $currency, 20);

        echo '<div class="awp-layout">';
        echo self::insight($totals, $period, $currency, $channels, $compare, $since);
        self::kpi_chart($totals, $series, $period, $currency, $compare, $since_in_period ? $since : null);
        self::cards($period, $filters, $currency, $totals);

        echo '</div>';
    }

    private static function first_start(): void
    {
        echo '<div class="awp-layout">';
        Ui::card_open('lightning', 'Noch keine Besuche', 'Das Tracking ist aktiv. Die ersten Zahlen erscheinen nach dem nächsten Besuch.', '', 'awp-span-all');
        echo '<div class="awp-card-body">';
        echo '<p>Öffne deine Website in einem privaten Fenster: Eingeloggte Besuche zählen nur, wenn deine Rolle nicht ausgeschlossen ist.</p>';
        echo Ui::info('Es werden keine Cookies gesetzt und keine IP-Adressen gespeichert. Ein Cookie-Banner braucht die Messung deshalb nicht.');
        echo '</div>';
        Ui::card_close('<a class="awp-linkline" href="' . esc_url(home_url('/')) . '" target="_blank" rel="noopener">Website öffnen' . Icons::svg('arrow-square-out') . '<span class="awp-sr"> (öffnet in einem neuen Tab)</span></a>');
        echo '</div>';
    }

    /**
     * The one line: how the period went against the one before (arrow up or
     * down), with the channel that brings more than its share of revenue or
     * conversions, else the figures. Pending under Insights::MIN_VISITS.
     *
     * @param array{current: array<string, float|int>, previous: array<string, float|int>} $totals
     * @param list<array<string, mixed>> $channels
     */
    private static function insight(array $totals, array $period, string $currency, array $channels, bool $compare, ?string $since): string
    {
        $sessions = (int)$totals['current']['sessions'];
        if ($sessions < \AnalyticsWP\Lib\Insights::MIN_VISITS) {
            $text = 'Bisher ' . Format::number($sessions) . ($sessions === 1 ? ' Besuch' : ' Besuche')
                . ($since !== null && $since >= $period['start'] ? ' seit dem ' . Format::day($since) : ' in diesem Zeitraum') . '.';
            if (!$compare) {
                $text .= ' Vergleiche mit dem Zeitraum davor gibt es nach ' . $period['days'] . ($period['days'] === 1 ? ' Tag.' : ' Tagen.');
            }
            return Ui::insight_line('pending', 'Erkenntnisse ab ' . \AnalyticsWP\Lib\Insights::MIN_VISITS . ' Besuchen.', $text);
        }

        $sources = App::url(['tab' => 'sources'] + array_fill_keys(App::VIEW_PARAMS, null));
        $gap = \AnalyticsWP\Lib\Insights::value_gap($channels, 'revenue') ?? \AnalyticsWP\Lib\Insights::value_gap($channels, 'conversions');
        $figures = \AnalyticsWP\Lib\Insights::summary($totals['current'], $compare ? $totals['previous'] : [], (int)$period['days'], $currency);
        $text = $gap !== null ? $gap['text'] : $figures['text'];

        if (!$compare) {
            return Ui::insight_line('good', 'Noch kein Vergleichszeitraum.', $text, $sources, 'Quellen');
        }
        $icon = ['good' => 'arrow-up', 'bad' => 'arrow-down', 'neutral' => ''][$figures['tone']];

        return Ui::insight_line($figures['tone'] === 'bad' ? 'bad' : 'good', $figures['title'], $text, $sources, 'Quellen', $icon);
    }

    /**
     * Six key figures with the value before, and the chart they switch.
     *
     * @param array{current: array<string, float|int>, previous: array<string, float|int>, other_currencies: array<string, float>} $totals
     * @param array{labels: list<string>, series: array<string, list<float|int>>, previous: array<string, list<float|int>>} $series
     */
    private static function kpi_chart(array $totals, array $series, array $period, string $currency, bool $compare, ?string $since): void
    {
        $metric = self::requested_metric();
        $per = $period['hourly'] ? ' pro Stunde' : ' pro Tag';

        echo '<section class="awp-card awp-span-all" aria-label="Kennzahlen und Verlauf">';
        $tiles = [];
        foreach (self::OVERVIEW_KPIS as $key => [$label, , $format, $higher_is_better, $term]) {
            $value = $totals['current'][$key] ?? 0;
            $pending = $key === 'bounce_rate' && !\AnalyticsWP\Lib\Insights::rate_is_meaningful((int)$totals['current']['sessions']);
            $tiles[] = [
                'key' => $key,
                'label' => $label,
                'help' => $key === 'revenue' ? 'Summe der Käufe aus WooCommerce und SureCart in ' . $currency . '.' : Ui::TERMS[$term],
                'value' => $pending ? 'Ausstehend' : self::format_value($value, $format, $currency),
                'delta' => $pending
                    ? '<span class="awp-delta">ab ' . \AnalyticsWP\Lib\Insights::MIN_RATE_BASE . ' Besuchen</span>'
                    : ($compare ? self::kpi_delta($value, $totals['previous'][$key] ?? 0, $higher_is_better) : '<span class="awp-delta">Noch kein Vergleich</span>'),
                'switch' => true,
            ];
        }
        echo Ui::kpi_bar($tiles, $metric);

        $metrics = [];
        foreach (self::OVERVIEW_KPIS as $key => [$label, $title, $format, $higher_is_better]) {
            $metrics[$key] = ['label' => $label, 'title' => $title . $per, 'format' => $format, 'better' => $higher_is_better];
        }

        $count = count($series['labels']);
        $today = wp_date('Y-m-d');
        $open = $period['end'] === $today;
        $end = $open && $period['hourly'] ? (int)wp_date('G') : $count - 1;
        $start = 0;
        if ($since !== null && !$period['hourly']) {
            $start = (int)floor((strtotime($since) - strtotime($period['start'])) / DAY_IN_SECONDS);
        }

        echo Chart::render($series['labels'], $series['series'], $series['previous'], $metrics, $metric, $period['hourly'], $currency, [
            'start' => $start,
            'end' => $end,
            'open' => $open,
            'compare' => $compare,
            'strip' => $series['series']['conversions'] ?? [],
            'strip_off' => ['conversions', 'revenue'],
            'since' => $since !== null ? 'Messbeginn ' . Format::day($since) : '',
        ]);

        if (!empty($totals['other_currencies'])) {
            $parts = [];
            foreach ($totals['other_currencies'] as $code => $amount) {
                $parts[] = Format::money($amount, $code);
            }
            echo '<div class="awp-card-foot">Umsatz in ' . esc_html($currency) . '. Nicht eingerechnet: ' . esc_html(implode(', ', $parts)) . '.</div>';
        }
        echo '</section>';
    }

    /**
     * Four cards with tabs, 2 × 2: sources, pages, conversions, events.
     * Each row shows a value and its share; ⤢ shows all columns.
     *
     * @param array{current: array<string, float|int>} $totals
     */
    private static function cards(array $period, array $filters, string $currency, array $totals): void
    {
        $sessions = (float)$totals['current']['sessions'];
        $pageviews = (float)$totals['current']['pageviews'];
        $conversions = (float)$totals['current']['conversions'];

        $visit_heads = self::VISIT_HEADS;
        $breakdown = function (string $dimension, bool $skip_none = false) use ($period, $filters, $currency, $sessions) {
            return self::breakdown_rows($dimension, $period, $filters, $currency, $sessions, [], false, $skip_none);
        };

        $model = 'last';
        $conversions_by = function (string $dimension) use ($period, $filters, $currency, $conversions, $model) {
            return function (int $limit) use ($dimension, $period, $filters, $currency, $conversions, $model) {
                $rows = [];
                foreach (Reports::conversions_by($dimension, $model, $period, $filters, $currency, $limit + 1) as $row) {
                    if ($dimension === 'campaign' && $row['value'] === null) {
                        continue;
                    }
                    $filter = Ui::dimension_filter($dimension, $row['value']);
                    $rows[] = [
                        'label' => Ui::dimension_label($dimension, $row['value']),
                        'icon' => $dimension === 'channel' ? Channels::icon($row['value']) : '',
                        'value' => (int)$row['conversions'],
                        'url' => $filter ? App::url($filter) : '',
                        'cells' => [
                            Ui::cell_number((int)$row['conversions']),
                            Ui::cell_share((int)$row['conversions'], $conversions),
                            Ui::cell_money((float)$row['revenue'], $currency),
                        ],
                    ];
                }
                return array_slice($rows, 0, $limit);
            };
        };

        $events = function (string $kind) use ($period, $filters) {
            return function (int $limit) use ($kind, $period, $filters) {
                $rows = [];
                foreach (Reports::events_by($kind, $period, $filters, $limit) as $row) {
                    $rows[] = [
                        'label' => $kind === 'contact' ? (Events::CONTACT_NAMES[$row['value']] ?? $row['value']) : $row['value'],
                        'value' => $row['count'],
                        'warn' => $kind === 'search' && !empty($row['empty']) ? '<span class="awp-chip-warn" title="' . esc_attr(Format::number($row['empty']) . ' von ' . Format::number($row['count']) . ' Suchen ohne Treffer') . '">ohne Ergebnis</span>' : '',
                        'cells' => [Ui::cell_number($row['count']), Ui::cell_number($row['sessions'])],
                    ];
                }
                return $rows;
            };
        };

        Ui::card_row([
            [
                'key' => 'sources',
                'title' => 'Quellen',
                'tabs' => [
                    'channel' => ['label' => 'Kanäle', 'col' => 'Kanal', 'heads' => $visit_heads, 'show' => 2, 'rows' => $breakdown('channel'), 'empty' => 'Noch keine Besuche in diesem Zeitraum.'],
                    'source' => ['label' => 'Quellen', 'col' => 'Quelle / Art', 'heads' => $visit_heads, 'show' => 2, 'rows' => $breakdown('source_medium'), 'empty' => 'Noch keine Besuche in diesem Zeitraum.'],
                    'campaign' => ['label' => 'Kampagnen', 'col' => 'Kampagne', 'heads' => $visit_heads, 'show' => 2, 'rows' => $breakdown('campaign', true), 'empty' => 'Noch keine Besuche über einen UTM-Link. Baue einen unter UTM-Links.'],
                ],
            ],
            [
                'key' => 'pages',
                'title' => 'Seiten',
                'tabs' => [
                    'all' => ['label' => 'Alle', 'col' => 'Seite', 'heads' => ['Aufrufe', 'Anteil', 'Besuche', 'Einstiege', 'Ø aktiv', 'Scrolltiefe'], 'show' => 2, 'empty' => 'Noch keine Seitenaufrufe in diesem Zeitraum.',
                        'rows' => function (int $limit) use ($period, $filters, $pageviews) {
                            $rows = [];
                            foreach (Reports::pages($period, $filters, $limit) as $row) {
                                $rows[] = [
                                    'label' => Format::path($row['path']),
                                    'value' => $row['pageviews'],
                                    'url' => App::url(['f_page' => $row['path']]),
                                    'cells' => [
                                        Ui::cell_number($row['pageviews']),
                                        Ui::cell_share($row['pageviews'], $pageviews),
                                        Ui::cell_number($row['sessions']),
                                        Ui::cell_number($row['entries']),
                                        $row['engaged'] !== null ? [esc_html(Format::duration($row['engaged'])), $row['engaged']] : ['<span class="awp-none">–</span>', ''],
                                        $row['scroll'] !== null ? [esc_html(Format::percent($row['scroll'] / 100, 0)), $row['scroll']] : ['<span class="awp-none">–</span>', ''],
                                    ],
                                ];
                            }
                            return $rows;
                        }],
                    'entry' => ['label' => 'Einstieg', 'col' => 'Seite', 'heads' => ['Einstiege', 'Anteil', 'Absprung', 'Conv.', 'Conv.-Rate', 'Umsatz'], 'show' => 2, 'rows' => $breakdown('landing'), 'empty' => 'Noch keine Besuche in diesem Zeitraum.'],
                    'exit' => ['label' => 'Ausstieg', 'col' => 'Seite', 'heads' => ['Ausstiege', 'Anteil', 'Absprung', 'Conv.', 'Conv.-Rate', 'Umsatz'], 'show' => 2, 'rows' => $breakdown('exit'), 'empty' => 'Noch keine Besuche in diesem Zeitraum.'],
                ],
            ],
        ]);

        Ui::card_row([
            [
                'key' => 'conversions',
                'title' => 'Conversions',
                'tabs' => [
                    'type' => ['label' => 'Nach Art', 'col' => 'Conversion', 'heads' => ['Anzahl', 'Anteil', 'Umsatz'], 'show' => 2, 'empty' => 'Noch keine Conversions in diesem Zeitraum.',
                        'rows' => function (int $limit) use ($period, $filters, $currency, $conversions) {
                            $rows = [];
                            foreach (array_slice(Reports::conversion_types($period, $filters, $currency), 0, $limit) as $row) {
                                $rows[] = [
                                    'label' => Format::conversion_type($row['type']) . ($row['name'] !== null ? ': ' . $row['name'] : ''),
                                    'icon' => Format::CONVERSION_KINDS[Format::conversion_kind($row['type'])][1],
                                    'value' => $row['conversions'],
                                    'cells' => [Ui::cell_number($row['conversions']), Ui::cell_share($row['conversions'], $conversions), Ui::cell_money($row['revenue'], $currency)],
                                ];
                            }
                            return $rows;
                        }],
                    'channel' => ['label' => 'Nach Kanal', 'col' => 'Kanal', 'heads' => ['Conv.', 'Anteil', 'Umsatz'], 'show' => 2, 'rows' => $conversions_by('channel'), 'empty' => 'Noch keine Conversions in diesem Zeitraum.'],
                    'campaign' => ['label' => 'Nach Kampagne', 'col' => 'Kampagne', 'heads' => ['Conv.', 'Anteil', 'Umsatz'], 'show' => 2, 'rows' => $conversions_by('campaign'), 'empty' => 'Noch keine Conversion über einen UTM-Link.'],
                ],
            ],
            [
                'key' => 'events',
                'title' => 'Ereignisse',
                'tabs' => [
                    'contact' => ['label' => 'Kontakt-Klicks', 'col' => 'Art', 'heads' => ['Klicks', 'Besuche'], 'rows' => $events('contact'), 'empty' => 'Noch keine Klicks auf Telefon, E-Mail oder WhatsApp.'],
                    'download' => ['label' => 'Downloads', 'col' => 'Datei', 'heads' => ['Downloads', 'Besuche'], 'rows' => $events('download'), 'empty' => 'Noch keine Downloads.'],
                    'outbound' => ['label' => 'Links nach außen', 'col' => 'Ziel', 'heads' => ['Klicks', 'Besuche'], 'rows' => $events('outbound'), 'empty' => 'Noch keine Klicks auf fremde Websites.'],
                    'search' => ['label' => 'Suchbegriffe', 'col' => 'Begriff', 'heads' => ['Suchen', 'Besuche'], 'rows' => $events('search'), 'empty' => 'Noch keine Suchen auf deiner Website.'],
                ],
            ],
        ]);
    }

    private static function requested_metric(): string
    {
        $metric = isset($_GET['metric']) ? sanitize_key(wp_unslash($_GET['metric'])) : 'visitors';

        return isset(self::OVERVIEW_KPIS[$metric]) ? $metric : 'visitors';
    }
}
