<?php

namespace AnalyticsWP\Lib\Admin\Tabs;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Icons;
use AnalyticsWP\Lib\Admin\Tab;
use AnalyticsWP\Lib\Admin\Ui;
use AnalyticsWP\Lib\Insights;
use AnalyticsWP\Lib\Reports;

/**
 * Tab "Conversions": where visits become requests and purchases. The
 * attribution model is a dropdown in the head ("Zählen für"). The heart is
 * the funnel "Vom Besuch zum Abschluss"; then four key figures and the
 * cards completions (by kind, latest) and origin (channel, campaign, entry
 * page) under the chosen model.
 */
class Conversions extends Tab
{
    /** Attribution models: id => [label, subtitle, explanation]. */
    const MODELS = [
        'last' => ['Letzter Kanal', 'Gezählt für den letzten Kanal vor der Conversion, ohne Direkt', 'Kam jemand zuletzt direkt zurück, zählt der Besuch davor, etwa die Anzeige oder der Newsletter. Empfohlen, weil Direkt sonst zu gut aussieht.'],
        'session' => ['Besuch der Conversion', 'Gezählt für den Besuch, in dem die Conversion passiert ist', 'Am einfachsten zu verstehen: Woher kam der Besuch, in dem gekauft oder angefragt wurde? Direkt bekommt dabei oft mehr, als es verdient.'],
        'first' => ['Erster Kontakt', 'Gezählt für den ersten bekannten Besuch desselben Besuchers', 'Zeigt, was Leute zuerst auf dich aufmerksam macht. Ohne Einwilligung geht das nur innerhalb eines Tages, mit Einwilligung (Must-Have Cookie) über mehrere Tage.'],
    ];

    /** Key figures: key => [label, format, explanation]. */
    const KPIS = [
        'conversions' => ['Conversions', 'number', 'Abschlüsse: Käufe, Formulare und Kontakt-Klicks.'],
        'conversion_rate' => ['Conv.-Rate', 'percent', 'Anteil der Besuche mit mindestens einem Abschluss.'],
        'revenue' => ['Umsatz', 'money', 'Summe der Käufe aus WooCommerce und SureCart.'],
        'avg_order' => ['Ø Kaufwert', 'money2', 'Umsatz geteilt durch die Zahl der Käufe.'],
    ];

    /** Option with extra pages that count as contact or checkout page. */
    const FUNNEL_OPTION = 'analyticswp_funnel_paths';

    public static function render(): void
    {
        $period = App::period();
        $filters = App::filters();
        $model = self::model();
        $since = Reports::first_seen_day();
        $compare = $since === null || $since <= $period['prev_end'];

        App::page_head(['since' => $since, 'option' => self::model_menu($model)]);
        $currency = Reports::main_currency($period);
        $totals = Reports::totals($period, $filters, $currency);
        $types = Reports::conversion_types($period, $filters, $currency);
        $types_before = Reports::conversion_types(Reports::previous_period($period), $filters, $currency);
        [$bought, $bought_revenue] = self::purchases($types);
        [$bought_before, $bought_revenue_before] = self::purchases($types_before);
        $current = $totals['current'] + ['avg_order' => $bought > 0 ? $bought_revenue / $bought : 0.0];
        $previous = $totals['previous'] + ['avg_order' => $bought_before > 0 ? $bought_revenue_before / $bought_before : 0.0];

        echo '<div class="awp-layout">';
        echo self::insight($types, (int)$current['conversions'], $bought, $bought_revenue, $currency);
        self::funnel(Reports::funnel($period, $filters, self::checkout_paths()));
        self::kpis($current, $previous, $compare, $currency, (int)$current['sessions']);
        self::cards($period, $filters, $currency, $model, $types, (float)$current['conversions']);
        echo '</div>';
    }

    private static function model(): string
    {
        $model = isset($_GET['model']) && is_string($_GET['model']) ? sanitize_key($_GET['model']) : 'last';

        return isset(self::MODELS[$model]) ? $model : 'last';
    }

    /**
     * "Zählen für Letzter Kanal ▾": the attribution model, explained.
     */
    private static function model_menu(string $active): string
    {
        $html = '<details class="awp-option"><summary title="' . esc_attr(self::MODELS[$active][2]) . '"><span class="awp-option-label">Zählen für</span><strong>' . esc_html(self::MODELS[$active][0]) . '</strong>' . Icons::svg('caret-down') . '</summary><div class="awp-option-panel">';
        foreach (self::MODELS as $key => [$label, , $explanation]) {
            $on = $key === $active;
            $html .= '<a href="' . esc_url(App::url(['model' => $key === 'last' ? null : $key])) . '"' . ($on ? ' class="is-active" aria-current="true"' : '') . '>'
                . '<span class="awp-option-name">' . esc_html($label) . ($on ? Icons::svg('check') : '') . '</span><span class="awp-option-help">' . esc_html($explanation) . '</span></a>';
        }

        return $html . '</div></details>';
    }

    /**
     * Purchases among the conversion types: count and revenue.
     *
     * @param list<array<string, mixed>> $types
     * @return array{0: int, 1: float}
     */
    private static function purchases(array $types): array
    {
        $count = 0;
        $sum = 0.0;
        foreach ($types as $row) {
            if (Format::conversion_kind($row['type']) === 'purchase') {
                $count += (int)$row['conversions'];
                $sum += (float)$row['revenue'];
            }
        }

        return [$count, $sum];
    }

    /**
     * Pages that count as contact or checkout page besides those with a
     * conversion: the checkout of WooCommerce and SureCart, and the
     * setting (FUNNEL_OPTION, paths separated by commas).
     *
     * @return list<string>
     */
    public static function checkout_paths(): array
    {
        $paths = [];
        $pages = [];
        if (class_exists('WooCommerce')) {
            $pages[] = (int)get_option('woocommerce_checkout_page_id');
        }
        if (class_exists('SureCart')) {
            $pages[] = (int)get_option('surecart_checkout_page_id');
        }
        foreach (array_filter($pages) as $id) {
            $url = get_permalink($id);
            if (is_string($url) && $url !== '') {
                $paths[] = \AnalyticsWP\Lib\URLs::path_of($url);
            }
        }
        foreach (explode(',', (string)get_option(self::FUNNEL_OPTION, '')) as $path) {
            $path = trim($path);
            if ($path !== '') {
                $paths[] = $path;
            }
        }

        return array_values(array_unique(array_filter($paths)));
    }

    /**
     * The most frequent completion, with what purchases brought.
     *
     * @param list<array<string, mixed>> $types
     */
    private static function insight(array $types, int $conversions, int $bought, float $revenue, string $currency): string
    {
        if ($conversions === 0) {
            return Ui::insight_line('pending', 'Noch kein Abschluss.', 'Sobald jemand kauft, ein Formular sendet oder anruft, steht es hier.');
        }
        if ($conversions < Insights::MIN_CONVERSIONS) {
            return Ui::insight_line('pending', 'Erkenntnisse ab ' . Insights::MIN_CONVERSIONS . ' Conversions.', 'Bisher ' . Format::number($conversions) . ($conversions === 1 ? ' Conversion.' : ' Conversions.'));
        }

        if (empty($types)) {
            return '';
        }
        $top = $types[0];
        foreach ($types as $row) {
            if ((int)$row['conversions'] > (int)$top['conversions']) {
                $top = $row;
            }
        }
        $name = Format::conversion_type($top['type']) . ($top['name'] !== null ? ': ' . $top['name'] : '');
        $text = $bought > 0
            ? 'Käufe bringen ' . Format::money($revenue, $currency, 0) . ' Umsatz aus ' . Format::number($bought) . ($bought === 1 ? ' Bestellung.' : ' Bestellungen.')
            : 'Noch kein Kauf in diesem Zeitraum.';

        return Ui::insight_line('good', $name . ' ist der häufigste Abschluss: ' . Format::number((int)$top['conversions']) . ' von ' . Format::number($conversions) . '.', $text);
    }

    /**
     * "Vom Besuch zum Abschluss": four steps, each with its number, a bar,
     * its share of all visits and in amber how many it lost.
     *
     * @param array{visits: int, more: int, reached: int, done: int, pages: list<string>} $funnel
     */
    private static function funnel(array $funnel): void
    {
        $steps = [
            ['Besuche', $funnel['visits'], ''],
            ['Mehr als eine Seite angesehen', $funnel['more'], 'springen nach einer Seite ab'],
            ['Kontakt- oder Kassenseite erreicht', $funnel['reached'], 'kommen nicht bis Kontakt oder Kasse'],
            ['Abschluss (Kauf, Formular, Anruf)', $funnel['done'], 'brechen dort ab'],
        ];
        $visits = max(1, $funnel['visits']);
        // Under MIN_VISITS the numbers, but no shares and no losses yet.
        $thin = $funnel['visits'] < Insights::MIN_VISITS;
        $pages = empty($funnel['pages']) ? 'Noch keine Seite mit Formular oder Kauf in diesem Zeitraum.' : 'Als Kontakt- oder Kassenseite zählen: ' . implode(', ', array_slice($funnel['pages'], 0, 6)) . (count($funnel['pages']) > 6 ? ' und weitere' : '') . '.';

        echo '<section class="awp-card awp-span-all awp-funnel2' . ($thin ? ' is-thin' : '') . '" aria-labelledby="awp-funnel-title">';
        echo '<div class="awp-heart-head"><h2 id="awp-funnel-title" class="awp-heart-title">Vom Besuch zum Abschluss</h2>'
            . ($thin ? '<span class="awp-pill">Ausstehend · aussagekräftig ab ' . Insights::MIN_VISITS . ' Besuchen, noch ' . Format::number(Insights::MIN_VISITS - $funnel['visits']) . '</span>' : '')
            . '<span class="awp-funnel2-pages" title="' . esc_attr($pages) . '">' . Ui::term('Welche Seiten zählen?', $pages . ' Ergänzen kannst du sie in den Einstellungen.') . '</span></div>';
        echo '<ol class="awp-funnel2-steps">';
        foreach ($steps as $i => [$label, $value, $lost]) {
            $share = $value / $visits;
            $drop = $i > 0 ? $steps[$i - 1][1] - $value : 0;
            echo '<li class="awp-funnel2-step"><span class="awp-funnel2-label">' . esc_html($label) . '</span>'
                . '<span class="awp-funnel2-value">' . esc_html(Format::number($value)) . '</span>'
                . '<span class="awp-funnel2-track"><span class="awp-funnel2-bar is-' . $i . '" style="height:' . round(max(3, $share * 100), 1) . '%"></span></span>'
                . '<span class="awp-funnel2-share">' . ($i === 0 ? ($thin ? '' : '100 %') : ($thin ? 'Anteil ab ' . Insights::MIN_VISITS . ' Besuchen' : esc_html(Format::percent($share, 0)) . ' aller Besuche')) . '</span>'
                . '<span class="awp-funnel2-drop">' . (!$thin && $i > 0 && $drop > 0 ? '−' . esc_html(Format::number($drop) . ' ' . $lost) : '') . '</span></li>';
        }
        echo '</ol></section>';
    }

    /**
     * Four key figures with the period before, display only.
     *
     * @param array<string, float|int> $current
     * @param array<string, float|int> $previous
     */
    private static function kpis(array $current, array $previous, bool $compare, string $currency, int $sessions): void
    {
        $tiles = [];
        foreach (self::KPIS as $key => [$label, $format, $help]) {
            $value = $current[$key] ?? 0;
            if ($key === 'conversion_rate' && !Insights::rate_is_meaningful($sessions)) {
                $shown = 'Ausstehend';
                $delta = '<span class="awp-delta">ab ' . Insights::MIN_RATE_BASE . ' Besuchen</span>';
            } elseif ($key === 'avg_order' && (float)$value <= 0) {
                $shown = '–';
                $delta = '<span class="awp-delta">noch kein Kauf</span>';
            } else {
                $shown = $format === 'money2' ? Format::money($value, $currency) : self::format_value($value, $format, $currency);
                $delta = $compare ? self::kpi_delta($value, $previous[$key] ?? 0, true) : '<span class="awp-delta">Noch kein Vergleich</span>';
            }
            $tiles[] = ['key' => $key, 'label' => $label, 'help' => $help, 'value' => $shown, 'delta' => $delta];
        }

        echo '<section class="awp-card awp-span-all" aria-label="Kennzahlen">' . Ui::kpi_bar($tiles) . '</section>';
    }

    /**
     * Completions (by kind with the estimated value of a request, latest)
     * and origin under the model (channel, campaign, entry page).
     *
     * @param list<array<string, mixed>> $types
     */
    private static function cards(array $period, array $filters, string $currency, string $model, array $types, float $conversions): void
    {
        $empty = 'Noch keine Conversions in diesem Zeitraum.';
        $origin = function (string $dimension) use ($period, $filters, $currency, $model, $conversions) {
            return function (int $limit) use ($dimension, $period, $filters, $currency, $model, $conversions) {
                $rows = [];
                foreach (Reports::conversions_by($dimension, $model, $period, $filters, $currency, $limit + 1) as $row) {
                    if ($dimension !== 'channel' && $row['value'] === null) {
                        continue;
                    }
                    $filter = Ui::dimension_filter($dimension, $row['value']);
                    $rows[] = [
                        'label' => Ui::dimension_label($dimension, $row['value']),
                        'icon' => $dimension === 'channel' ? \AnalyticsWP\Lib\Admin\Channels::icon($row['value']) : '',
                        'value' => (int)$row['conversions'],
                        'url' => $filter ? App::url($filter) : '',
                        'cells' => [Ui::cell_number((int)$row['conversions']), Ui::cell_share((int)$row['conversions'], $conversions), Ui::cell_money((float)$row['revenue'], $currency)],
                    ];
                }
                return array_slice($rows, 0, $limit);
            };
        };

        Ui::card_row([
            [
                'key' => 'done',
                'title' => 'Abschlüsse',
                'tabs' => [
                    'type' => ['label' => 'Nach Art', 'col' => 'Conversion', 'heads' => ['Anzahl', 'Anteil', 'Umsatz'], 'cols' => [0, 2], 'empty' => $empty,
                        'rows' => function (int $limit) use ($types, $currency, $conversions) {
                            $rows = [];
                            foreach (array_slice($types, 0, $limit) as $row) {
                                $kind = Format::conversion_kind($row['type']);
                                // Forms and contact clicks: the value from the
                                // settings, marked "≈", never part of revenue.
                                $estimate = (int)$row['conversions'] * \AnalyticsWP\Lib\ConversionValue::of($row['type'], $row['name']);
                                $money = (float)$row['revenue'] > 0 || $estimate <= 0
                                    ? Ui::cell_money((float)$row['revenue'], $currency)
                                    : ['<span class="awp-estimate" title="Geschätzter Wert aus den Einstellungen, nicht im Umsatz">≈ ' . esc_html(Format::money($estimate, 'EUR', 0)) . '</span>', $estimate];
                                $rows[] = [
                                    'label' => Format::conversion_type($row['type']) . ($row['name'] !== null ? ': ' . $row['name'] : ''),
                                    'meta' => Format::CONVERSION_KINDS[$kind][0],
                                    'icon' => Format::CONVERSION_KINDS[$kind][1],
                                    'value' => (int)$row['conversions'],
                                    'cells' => [Ui::cell_number((int)$row['conversions']), Ui::cell_share((int)$row['conversions'], $conversions), $money],
                                ];
                            }
                            return $rows;
                        }],
                    'recent' => ['label' => 'Letzte', 'col' => 'Conversion', 'heads' => ['Wert', 'Zeit'], 'empty' => $empty,
                        'rows' => function (int $limit) use ($period, $filters, $currency, $model) {
                            $rows = [];
                            foreach (Reports::recent_conversions($period, $filters, min($limit, 100), $model) as $row) {
                                $type = (string)$row['conversion_type'];
                                $kind = Format::conversion_kind($type);
                                $name = Format::conversion_type($type) . (!empty($row['form_name']) && $row['form_name'] !== 'null' ? ': ' . $row['form_name'] : '');
                                $value = $row['revenue'] !== null && (float)$row['revenue'] > 0 ? (float)$row['revenue'] : 0.0;
                                $rows[] = [
                                    'label' => $name,
                                    'meta' => Format::channel((string)$row['channel']) . (!empty($row['earlier_visit']) ? ' · früherer Besuch' : ''),
                                    'icon' => Format::CONVERSION_KINDS[$kind][1],
                                    'value' => 1,
                                    'url' => App::url(['tab' => 'journeys', 'visitor' => (string)$row['unique_session_id'], 'f_*' => null] + array_fill_keys(['ct', 'full', 'model'], null)),
                                    'cells' => [
                                        Ui::cell_money($value, (string)($row['currency'] ?: $currency)),
                                        [esc_html(Format::datetime((string)$row['timestamp'])), (string)$row['timestamp']],
                                    ],
                                ];
                            }
                            return $rows;
                        }],
                ],
            ],
            [
                'key' => 'origin',
                'title' => 'Herkunft',
                'tabs' => [
                    'channel' => ['label' => 'Kanal', 'col' => 'Kanal', 'heads' => ['Conv.', 'Anteil', 'Umsatz'], 'cols' => [0, 2], 'rows' => $origin('channel'), 'empty' => $empty],
                    'campaign' => ['label' => 'Kampagne', 'col' => 'Kampagne', 'heads' => ['Conv.', 'Anteil', 'Umsatz'], 'cols' => [0, 2], 'rows' => $origin('campaign'), 'empty' => 'Noch keine Conversion über einen UTM-Link.'],
                    'landing' => ['label' => 'Einstiegsseite', 'col' => 'Seite', 'heads' => ['Conv.', 'Anteil', 'Umsatz'], 'cols' => [0, 2], 'rows' => $origin('landing'), 'empty' => $empty],
                ],
            ],
        ]);
    }
}
