<?php

namespace AnalyticsWP\Lib\Admin\Tabs;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Channels;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Icons;
use AnalyticsWP\Lib\Admin\Tab;
use AnalyticsWP\Lib\Admin\Ui;
use AnalyticsWP\Lib\Reports;

/**
 * Tab "Integrationen": the plugins that report to the analytics, with
 * status, last reports and switch.
 */
class Integrations extends Tab
{
    public static function render(): void
    {
        App::page_head();

        if (isset($_GET['updated'])) {
            echo '<div class="notice notice-success"><p>Gespeichert.</p></div>';
        }

        $installed = [];
        $others = [];
        foreach (\AnalyticsWP\Lib\Integrations::get_integrations() as $integration) {
            $slug = (string)$integration['slug'];
            $meta = Format::INTEGRATIONS[$slug] ?? ['builder', [], [], []];
            $row = $integration + ['group' => $meta[0], 'reports' => $meta[1], 'types' => $meta[2], 'events' => $meta[3]];
            if ($integration['isAvailable']) {
                $row['activity'] = Reports::integration_activity($meta[2], $meta[3]);
                $installed[] = $row;
            } else {
                $others[] = $row;
            }
        }
        $order = array_flip(array_keys(Format::INTEGRATION_GROUPS));
        usort($installed, function ($a, $b) use ($order) {
            return [$order[$a['group']] ?? 9, $a['name']] <=> [$order[$b['group']] ?? 9, $b['name']];
        });

        // Status: which installed plugins report, and the last report.
        $reporting = array_values(array_filter($installed, function ($row) {
            return $row['isEnabled'];
        }));
        $latest = null;
        foreach ($reporting as $row) {
            if ($row['activity']['last'] !== null && ($latest === null || $row['activity']['last'] > $latest[1])) {
                $latest = [$row, $row['activity']['last']];
            }
        }
        echo '<div class="awp-layout">';
        if (!empty($reporting)) {
            $text = implode(', ', array_column($reporting, 'name')) . '.';
            if ($latest !== null) {
                $what = self::activity_label($latest[0]['activity']['recent'][0] ?? []);
                $text .= ' Zuletzt ' . ($what !== '' ? $what . ', ' : '') . self::lower_day(Format::datetime($latest[1])) . '.';
            }
            echo '<div class="awp-span-all awp-status is-good">' . Icons::svg('check-circle') . '<div><p class="awp-glance-title">'
                . esc_html(count($reporting) . (count($reporting) === 1 ? ' Plugin meldet an die Auswertung.' : ' Plugins melden an die Auswertung.'))
                . '</p><p class="awp-glance-text">' . esc_html($text) . '</p></div></div>';
        } else {
            echo '<div class="awp-span-all awp-status is-warn">' . Icons::svg('warning') . '<div><p class="awp-glance-title">Kein Plugin meldet gerade.</p>'
                . '<p class="awp-glance-text">' . esc_html(empty($installed) ? 'Auf deiner Website ist keines der unterstützten Plugins installiert. Seitenaufrufe, Klicks und Kontakt-Klicks misst die Auswertung trotzdem.' : 'Käufe und Formulare tauchen erst wieder auf, wenn du eine Integration einschaltest.') . '</p></div></div>';
        }

        if (!empty($installed)) {
            Ui::card_open('plugs-connected', 'Auf deiner Website', 'Installiert und aktiv. Speichert automatisch.', '', 'awp-span-all');
            foreach ($installed as $row) {
                self::integration_row($row);
            }
            Ui::card_close();
        }

        if (!empty($others)) {
            echo '<details class="awp-card awp-span-all awp-more-plugins"><summary class="awp-card-head"><span class="awp-card-icon">' . Icons::svg('plugs-connected') . '</span>'
                . '<div class="awp-card-heading"><h2 class="awp-card-title">Weitere unterstützte Plugins <span class="awp-row-meta">· ' . count($others) . '</span></h2>'
                . '<p class="awp-card-sub">Nicht installiert. Sobald du eines installierst, meldet es automatisch.</p></div>' . Icons::svg('caret-down', 'awp-icon awp-details-caret') . '</summary>'
                . '<div class="awp-card-body">';
            foreach (Format::INTEGRATION_GROUPS as $group => [$label, , $icon]) {
                $items = array_values(array_filter($others, function ($row) use ($group) {
                    return $row['group'] === $group;
                }));
                if (empty($items)) {
                    continue;
                }
                echo '<div class="awp-plugin-group"><span class="awp-group-title">' . Icons::svg($icon) . esc_html($label) . '</span><div class="awp-plugin-grid">';
                foreach ($items as $row) {
                    echo '<div class="awp-plugin"><strong>' . esc_html((string)$row['name']) . '</strong><span>' . esc_html(Format::integration_description((string)$row['slug'], (string)$row['description'])) . '</span></div>';
                }
                echo '</div></div>';
            }
            echo '</div></details>';
        }

        echo '<div class="awp-span-all">' . Ui::info('Dein Plugin fehlt? Jeder Button und jeder Link kann ein eigenes Ereignis melden: Gib ihm das Attribut data-awp-event mit einem Namen, zum Beispiel data-awp-event="angebot-angefragt". Die Ereignisse stehen unter Ereignisse › Eigene Events.', 'code') . '</div>';
        echo '</div>';
    }

    /**
     * "Heute, 12:09" inside a sentence: "heute, 12:09".
     */
    private static function lower_day(string $datetime): string
    {
        return preg_match('/^(Heute|Gestern)\b/', $datetime) ? lcfirst($datetime) : $datetime;
    }

    /**
     * "WooCommerce-Bestellung Nr. 219", "SureForms: Kontakt".
     *
     * @param array<string, mixed> $event
     */
    private static function activity_label(array $event): string
    {
        if (empty($event)) {
            return '';
        }
        $props = json_decode((string)($event['event_properties_json'] ?? ''), true);
        $props = is_array($props) ? $props : [];
        if (!empty($event['conversion_type'])) {
            $label = Format::conversion_type((string)$event['conversion_type']);
            if (!empty($props['form_name'])) {
                return $label . ': ' . $props['form_name'];
            }
            if (!empty($props['order_number'])) {
                return $label . ' Nr. ' . $props['order_number'];
            }
            return $label . (!empty($event['conversion_id']) && Format::conversion_kind((string)$event['conversion_type']) === 'purchase' ? ' Nr. ' . $event['conversion_id'] : '');
        }

        return (string)$event['event_type'];
    }

    /**
     * One installed integration: what it reports, when last, a switch, and
     * its latest reports to unfold.
     *
     * @param array<string, mixed> $row
     */
    private static function integration_row(array $row): void
    {
        $enabled = (bool)$row['isEnabled'];
        [, $kind, $icon] = Format::INTEGRATION_GROUPS[$row['group']] ?? Format::INTEGRATION_GROUPS['builder'];
        $activity = $row['activity'];
        $noun = $row['group'] === 'shop' ? ['Bestellung', 'Bestellungen'] : ($row['group'] === 'form' ? ['Absendung', 'Absendungen'] : ['Meldung', 'Meldungen']);

        if (!$enabled) {
            $last = '<span class="awp-warnline">' . esc_html('Ausgeschaltet: meldet nichts mehr. Bisherige Zahlen bleiben.') . '</span>';
        } elseif ($activity['last'] !== null) {
            $last = '<span class="awp-row-meta">' . esc_html('Zuletzt ' . self::lower_day(Format::datetime($activity['last'])) . ' · ' . Format::number($activity['count']) . ' ' . ($activity['count'] === 1 ? $noun[0] : $noun[1]) . ' in 30 Tagen') . '</span>';
        } elseif (empty($row['types']) && empty($row['events'])) {
            $last = '<span class="awp-row-meta">Meldet Klicks als eigene Ereignisse (unter Ereignisse).</span>';
        } else {
            $last = '<span class="awp-row-meta">In den letzten 30 Tagen nichts gemeldet.</span>';
        }

        echo '<div class="awp-integration"><div class="awp-integration-main"><span class="awp-tile awp-tile--large">' . Icons::svg($icon) . '</span>'
            . '<div class="awp-integration-text"><div class="awp-integration-name"><strong>' . esc_html((string)$row['name']) . '</strong><span class="awp-row-meta">' . esc_html($kind) . '</span></div>'
            . '<span class="awp-field-desc">' . esc_html(Format::integration_description((string)$row['slug'], (string)$row['description'])) . '</span>';
        if (!empty($row['reports'])) {
            echo '<div class="awp-tags">';
            foreach ($row['reports'] as $report) {
                echo '<span>' . esc_html($report) . '</span>';
            }
            echo '</div>';
        }
        echo $last;
        if ($enabled && !empty($activity['recent'])) {
            echo '<details class="awp-integration-recent"><summary>Letzte Meldungen' . Icons::svg('caret-down') . '</summary><div class="awp-recent-list">';
            foreach ($activity['recent'] as $event) {
                $channel = (string)($event['channel'] ?? '');
                $origin = implode(' · ', array_filter([$channel !== '' ? Format::channel($channel) : '', (string)($event['source'] ?? ''), (string)($event['campaign'] ?? '')]));
                $value = $event['revenue'] !== null && (float)$event['revenue'] > 0 ? Format::money((float)$event['revenue'], (string)($event['currency'] ?: 'EUR')) : '–';
                echo '<div class="awp-recent-row"><span>' . esc_html(self::activity_label($event)) . '</span>'
                    . '<span class="awp-feed-origin">' . ($channel !== '' ? Channels::dot($channel) : '') . '<span>' . esc_html($origin !== '' ? $origin : '–') . '</span></span>'
                    . '<span class="awp-num">' . esc_html($value) . '</span><span class="awp-num is-muted">' . esc_html(Format::datetime((string)$event['timestamp'])) . '</span></div>';
            }
            echo '</div></details>';
        }
        echo '</div></div>';

        if (current_user_can('manage_options')) {
            $id = 'awp-int-' . sanitize_html_class((string)$row['slug']);
            echo '<form class="awp-integration-switch" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-awp-form-autosave>';
            wp_nonce_field('analyticswp_integration');
            echo '<input type="hidden" name="action" value="analyticswp_integration"><input type="hidden" name="slug" value="' . esc_attr((string)$row['slug']) . '"><input type="hidden" name="enabled" value="0">'
                . '<input type="checkbox" class="awp-switch" role="switch" id="' . esc_attr($id) . '" name="enabled" value="1"' . checked($enabled, true, false) . ' aria-label="' . esc_attr($row['name'] . ' melden') . '">'
                . '<noscript><button type="submit" class="button">Speichern</button></noscript></form>';
        }
        echo '</div>';

    }

    public static function handle_integration_toggle(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Keine Berechtigung.', 403);
        }
        check_admin_referer('analyticswp_integration');

        $slug = isset($_POST['slug']) ? sanitize_key(wp_unslash($_POST['slug'])) : '';
        $enabled = isset($_POST['enabled']) && $_POST['enabled'] === '1';

        $known = array_column(\AnalyticsWP\Lib\Integrations::get_integrations(), 'slug');
        if (in_array($slug, $known, true)) {
            \AnalyticsWP\Lib\Integrations::update_integration_is_enabled($slug, $enabled);
            Reports::flush_cache();
        }

        wp_safe_redirect(add_query_arg(['page' => App::SLUG, 'tab' => 'integrations', 'updated' => 1], admin_url('admin.php')));
        exit;
    }
}
