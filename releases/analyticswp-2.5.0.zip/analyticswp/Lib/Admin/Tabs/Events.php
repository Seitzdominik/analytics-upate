<?php

namespace AnalyticsWP\Lib\Admin\Tabs;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Icons;
use AnalyticsWP\Lib\Admin\Tab;
use AnalyticsWP\Lib\Admin\Ui;
use AnalyticsWP\Lib\Insights;
use AnalyticsWP\Lib\Reports;

/**
 * Tab "Ereignisse": what visitors click, download and search. The heart is
 * a wall of five tiles (contact clicks, downloads, outbound links,
 * searches, own events), then a card per kind, each with its own sentence
 * while it is empty.
 */
class Events extends Tab
{
    const CONTACT_NAMES = ['tel' => 'Telefon', 'mailto' => 'E-Mail', 'whatsapp' => 'WhatsApp'];

    /** Tiles: engagement_totals() key => [label, icon, card, what is counted]. */
    const TILES = [
        'contacts' => ['Kontakt-Klicks', 'phone', 'contact', 'Klicks auf Telefon, E-Mail, WhatsApp'],
        'downloads' => ['Downloads', 'download-simple', 'downloads', 'PDFs und andere Dateien'],
        'outbound' => ['Links nach außen', 'arrow-square-out', 'outbound', 'Klicks auf fremde Websites'],
        'searches' => ['Suchbegriffe', 'magnifying-glass', 'search', 'Suche auf deiner Website'],
        'custom' => ['Eigene Events', 'sparkle', 'custom', 'mit data-awp-event am Button'],
    ];

    public static function render(): void
    {
        $period = App::period();
        $filters = App::filters();

        App::page_head();

        if (!\AnalyticsWP\Lib\Core::engagement_enabled()) {
            echo '<div class="awp-layout"><div class="awp-span-all">' . Ui::info('Die Messung von Klicks, Downloads und Suchen ist ausgeschaltet. Du kannst sie unter Einstellungen einschalten.') . '</div></div>';
            return;
        }

        $since = Reports::first_seen_day();
        $compare = $since === null || $since <= $period['prev_end'];
        $totals = Reports::engagement_totals($period, $filters);
        $before = Reports::engagement_totals(Reports::previous_period($period), $filters);
        $searches = Reports::events_by('search', $period, $filters, 50);

        echo '<div class="awp-layout">';
        $insight = self::insight($totals, $searches);
        if ($insight !== '') {
            echo $insight;
        }
        self::tiles($totals, $before, $compare);
        self::cards($period, $filters);
        echo '</div>';
    }

    /**
     * Searches without a hit are the problem worth a line; else the most
     * searched term, else the most used contact. All with a minimum
     * (Insights::MIN_EVENTS). Nothing counted at all: pending.
     *
     * @param array<string, float|int|null> $totals
     * @param list<array{value: string, count: int, sessions: int, empty: int|null}> $searches
     */
    private static function insight(array $totals, array $searches): string
    {
        $finding = Insights::events_finding($totals, $searches);
        if ($finding === null) {
            return '';
        }

        return Ui::insight_line($finding['tone'], $finding['title'], $finding['text']);
    }

    /**
     * Five large tiles: icon, number, name and the change (or, while there
     * is nothing, what is counted). Each leads to its card.
     *
     * @param array<string, float|int|null> $totals
     * @param array<string, float|int|null> $before
     */
    private static function tiles(array $totals, array $before, bool $compare): void
    {
        echo '<div class="awp-tiles awp-span-all">';
        foreach (self::TILES as $key => [$label, $icon, $card, $what]) {
            $value = (int)($totals[$key] ?? 0);
            if ($value === 0 && (int)($before[$key] ?? 0) === 0) {
                $foot = '<span class="awp-bigtile-what">' . esc_html($what) . '</span>';
            } elseif ($compare) {
                $foot = self::kpi_delta($value, (int)($before[$key] ?? 0), true);
                $foot = $foot !== '' ? $foot : '<span class="awp-delta">± 0 %</span>';
            } else {
                $foot = '<span class="awp-delta">Noch kein Vergleich</span>';
            }
            echo '<a class="awp-bigtile' . ($value === 0 ? ' is-zero' : '') . '" href="#awp-c-' . esc_attr($card) . '-t">'
                . '<span class="awp-head-icon">' . Icons::svg($icon) . '</span>'
                . '<span class="awp-bigtile-value">' . esc_html(Format::number($value)) . '</span>'
                . '<span class="awp-bigtile-label">' . esc_html($label) . '</span>' . $foot . '</a>';
        }
        echo '</div>';
    }

    /**
     * A card per kind: contact clicks (by kind | by page), downloads,
     * searches (with "ohne Ergebnis"), outbound links, own events.
     *
     * @param array<string, string> $filters
     */
    private static function cards(array $period, array $filters): void
    {
        $rows = function (string $kind) use ($period, $filters) {
            return function (int $limit) use ($kind, $period, $filters) {
                $out = [];
                foreach (Reports::events_by($kind, $period, $filters, $limit) as $row) {
                    $value = (string)$row['value'];
                    $item = ['label' => $value, 'meta' => '', 'value' => $row['count'], 'cells' => [Ui::cell_number($row['count']), Ui::cell_number($row['sessions'])]];
                    if ($kind === 'contact') {
                        $item['label'] = self::CONTACT_NAMES[$value] ?? $value;
                        $item['icon'] = ['tel' => 'phone', 'mailto' => 'envelope-simple', 'whatsapp' => 'chat-circle'][$value] ?? 'phone';
                    } elseif ($kind === 'contact_page') {
                        $item['url'] = App::url(['f_page' => $value]);
                    } elseif ($kind === 'download') {
                        // "preisliste.pdf" with the folder as meta.
                        $path = (string)\AnalyticsWP\Lib\URLs::path_of($value);
                        $item['label'] = basename($path) !== '' ? basename($path) : $value;
                        $item['meta'] = trailingslashit(dirname($path)) !== './' ? trailingslashit(dirname($path)) : '';
                    } elseif ($kind === 'outbound') {
                        $item['label'] = preg_replace('#^https?://(www\.)?#i', '', $value);
                    } elseif ($kind === 'search' && !empty($row['empty'])) {
                        $item['warn'] = '<span class="awp-chip-warn" title="' . esc_attr(Format::number($row['empty']) . ' von ' . Format::number($row['count']) . ' Suchen ohne Treffer') . '">ohne Ergebnis</span>';
                    }
                    $out[] = $item;
                }
                return $out;
            };
        };

        Ui::card_row([
            [
                'key' => 'contact',
                'title' => 'Kontakt-Klicks',
                'tabs' => [
                    'type' => ['label' => 'Art', 'col' => 'Art', 'heads' => ['Klicks', 'Besuche'], 'rows' => $rows('contact'), 'empty' => 'Noch keine Klicks auf Telefon, E-Mail oder WhatsApp.'],
                    'page' => ['label' => 'Seite', 'col' => 'Seite', 'heads' => ['Klicks', 'Besuche'], 'rows' => $rows('contact_page'), 'empty' => 'Noch keine Klicks auf Telefon, E-Mail oder WhatsApp.'],
                ],
            ],
            [
                'key' => 'downloads',
                'title' => 'Downloads',
                'tabs' => [
                    'file' => ['label' => 'Datei', 'col' => 'Datei', 'heads' => ['Downloads', 'Besuche'], 'rows' => $rows('download'), 'empty' => 'Noch keine Downloads.'],
                ],
            ],
        ]);
        Ui::card_row([
            [
                'key' => 'search',
                'title' => 'Suchbegriffe',
                'tabs' => [
                    'term' => ['label' => 'Begriff', 'col' => 'Begriff', 'heads' => ['Suchen', 'Besuche'], 'rows' => $rows('search'), 'empty' => 'Noch keine Suchen auf deiner Website.'],
                ],
            ],
            [
                'key' => 'outbound',
                'title' => 'Links nach außen',
                'tabs' => [
                    'target' => ['label' => 'Ziel', 'col' => 'Ziel', 'heads' => ['Klicks', 'Besuche'], 'rows' => $rows('outbound'), 'empty' => 'Noch keine Klicks auf fremde Websites.'],
                ],
            ],
        ]);
        Ui::card_row([[
            'key' => 'custom',
            'title' => 'Eigene Events',
            'tabs' => [
                'event' => ['label' => 'Event', 'col' => 'Event', 'heads' => ['Anzahl', 'Besuche'], 'rows' => $rows('custom'), 'empty' => 'Eigene Events meldest du mit data-awp-event am Button.'],
            ],
        ]]);
    }
}
