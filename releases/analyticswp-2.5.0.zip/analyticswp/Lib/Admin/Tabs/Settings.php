<?php

namespace AnalyticsWP\Lib\Admin\Tabs;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Icons;
use AnalyticsWP\Lib\Admin\Tab;
use AnalyticsWP\Lib\Admin\Ui;
use AnalyticsWP\Lib\Reports;
use AnalyticsWP\Lib\SuperSimpleWP;
use AnalyticsWP\Lib\Validators;

/**
 * Tab "Einstellungen": what is measured, conversions and their value,
 * consent, retention, privacy text, performance, access.
 */
class Settings extends Tab
{
    /** WordPress' own roles; every other role counts as "Shop und Plugins". */
    const CORE_ROLES = ['administrator', 'editor', 'author', 'contributor', 'subscriber'];

    public static function render(): void
    {
        if (!current_user_can('manage_options')) {
            echo Ui::info('Nur Administratoren können die Einstellungen ändern.');
            return;
        }

        App::page_head();
        if (isset($_GET['settings-updated'])) {
            echo '<div class="notice notice-success"><p>Gespeichert.</p></div>';
        }
        if (\AnalyticsWP\Lib\RequestGuard::shared_address()) {
            echo '<div class="awp-span-all" style="margin-bottom:20px">' . Ui::info('Der Server sieht alle Besucher unter derselben internen Adresse. Davor steht ein Proxy, der die Besucher-IP nicht weitergibt: Alle teilen sich dann ein Limit, und ähnliche Besucher fallen zusammen. Bitte den Hoster, die echte IP weiterzugeben, oder setze den Filter analyticswp_client_ip.', 'warning') . '</div>';
        }

        $roles = wp_roles()->get_names();
        $excluded = Validators::array_of_string_keys_and_values(SuperSimpleWP::get_setting('analyticswp', 'disabled-tracking-user-roles'));
        $access = Validators::array_of_string_keys_and_values(SuperSimpleWP::get_setting('analyticswp', 'admin-access-user-roles'));

        // Without JS the whole form saves through options.php, as before.
        echo '<form method="post" action="' . esc_url(admin_url('options.php')) . '" class="awp-settings-form"><div class="awp-layout">';
        settings_fields('analyticswp');

        // Was gemessen wird.
        Ui::card_open('eye', 'Was gemessen wird', 'Ohne Cookies, für alle Besucher', '', 'awp-span-all');
        echo Ui::toggle('engagement_tracking', (bool)SuperSimpleWP::get_setting('analyticswp', 'engagement_tracking'), 'Engagement messen', ['description' => 'Aktive Zeit und Scrolltiefe je Seite, Links nach außen, Downloads, Klicks auf Telefon, E-Mail und WhatsApp.']);
        echo '<div class="awp-field"><span class="awp-switch-label">Diese Besucher nicht zählen</span><p class="awp-field-desc">Eingeloggte Nutzer mit diesen Rollen zählen nicht, ihre Bestellungen und Formulare auch nicht.</p>';
        if (!isset($excluded['administrator'])) {
            echo '<div class="awp-tipline">' . Icons::svg('info') . '<span>Tipp: Schließ dich selbst aus, sonst zählen deine eigenen Besuche und Testbestellungen mit.</span>'
                . '<button type="button" class="button" data-awp-check="#awp-role-exclude-administrator">Administrator ausschließen</button></div>';
        }
        echo self::role_chips('exclude_role', 'analyticswp_disabled-tracking-user-roles', $roles, $excluded, 'awp-role-exclude-');
        echo '</div>';
        Ui::card_close('Im Browser wird nichts gespeichert, keine IP-Adresse und keine E-Mail-Adresse. Besucher werden über einen täglich wechselnden Hash höchstens einen Tag lang wiedererkannt.');

        // Was als Conversion zählt.
        $contact = (bool)SuperSimpleWP::get_setting('analyticswp', 'contact_clicks_as_conversion');
        Ui::card_open('target', 'Was als Conversion zählt', 'Käufe zählen immer, mit ihrem Umsatz', '', 'awp-span-all');
        echo Ui::toggle('contact_clicks_as_conversion', $contact, 'Kontakt-Klicks als Conversion zählen', ['description' => 'Ein Klick auf Telefonnummer, E-Mail-Adresse oder WhatsApp zählt wie eine Anfrage, höchstens einmal je Besucher, Tag und Art.']);
        self::value_fields();
        self::funnel_field();
        Ui::card_close('Welchem Besuch eine Conversion zählt, stellst du direkt unter ' . Ui::link(App::url(['tab' => 'conversions'] + array_fill_keys(App::VIEW_PARAMS, null)), 'Conversions') . ' um.');

        // Mit Einwilligung über mehrere Tage.
        $multi_day = (bool)SuperSimpleWP::get_setting('analyticswp', 'multi_day_with_consent');
        $mhc = \AnalyticsWP\Lib\Consent::mhc_active();
        Ui::card_open('lock-simple', 'Mit Einwilligung über mehrere Tage', 'Nur für Besucher, die zustimmen', '', 'awp-span-all');
        echo '<div class="awp-field"><p class="awp-field-desc" style="margin:0">Stimmt ein Besucher im Cookie-Banner der Statistik zu, kann ein Kauf nach einer Woche noch der Anzeige zugeordnet werden, über die er kam.</p></div>';
        if ($mhc) {
            echo Ui::toggle('multi_day_with_consent', $multi_day, 'Besucher mit Einwilligung wiedererkennen', ['description' => 'Wer in Must-Have Cookie der Kategorie „Statistik“ zustimmt (oder „Alle akzeptieren“), bekommt ein Cookie mit einer Zufalls-ID (awp_vid, 13 Monate). Widerruft er, wird es gelöscht.']);
            $share = Reports::consent_share(Reports::period('30d'));
            Ui::card_close('Trage das Cookie awp_vid in Must-Have Cookie unter „Statistik“ ein. In den letzten 30 Tagen liefen ' . esc_html(Format::percent($share, 0)) . ' der Besuche mit Einwilligung.');
        } else {
            echo '<div class="awp-card-body">' . self::info_html('Dafür braucht es das Plugin Must-Have Cookie. Ohne bleibt die Messung immer cookielos, und das ist für die meisten Websites genau richtig. ' . Ui::link(admin_url('plugin-install.php?s=Must-Have+Cookie&tab=search&type=term'), 'Must-Have Cookie ansehen'), 'lock-simple') . '</div>';
            echo '<input type="hidden" name="analyticswp_multi_day_with_consent" value="' . ($multi_day ? '1' : '') . '">';
            Ui::card_close();
        }

        // Eingeloggte Besucher.
        Ui::card_open('user-circle-dashed', 'Eingeloggte Besucher', 'Zum Beispiel Kunden mit Konto', '', 'awp-span-all');
        echo Ui::toggle('link_logged_in_users', (bool)SuperSimpleWP::get_setting('analyticswp', 'link_logged_in_users'), 'Besuche dem Konto zuordnen', [
            'description' => 'Die Journeys zeigen dann Kunden mit Namen und über mehrere Tage. Aus, zählen auch eingeloggte Besucher cookielos.',
            'warning' => 'Das sind personenbezogene Daten. Nimm sie in deine Datenschutzerklärung auf (der Text unten passt sich an). Löschanfragen erledigst du unter Werkzeuge › Personenbezogene Daten löschen.',
        ]);
        Ui::card_close();

        // Aufbewahrung.
        $months = \AnalyticsWP\Lib\Retention::months();
        Ui::card_open('hourglass-simple-medium', 'Aufbewahrung', 'Wie lange Besuche gespeichert bleiben', '', 'awp-span-all');
        echo '<div class="awp-field awp-switch-field"><div class="awp-switch-text"><span class="awp-switch-label">Besuche und Events löschen nach</span>'
            . '<p class="awp-field-desc">Einmal am Tag. Bestellungen und Formulare selbst bleiben, nur ihre gemessene Herkunft geht mit.</p></div>'
            . '<div class="awp-seg awp-seg--radio" role="radiogroup" aria-label="Aufbewahrung">';
        foreach (\AnalyticsWP\Lib\Retention::CHOICES as $value => $label) {
            $id = 'awp-keep-' . $value;
            echo '<input type="radio" id="' . esc_attr($id) . '" name="analyticswp_retention_months" value="' . esc_attr((string)$value) . '"' . checked($months, $value, false) . ' data-awp-autosave="retention_months">'
                . '<label for="' . esc_attr($id) . '">' . esc_html($value === 0 ? 'Nie' : str_replace(' Monate', ' Mon.', $label)) . '</label>';
        }
        echo '</div></div>';
        echo Ui::toggle('delete_data_on_uninstall', (bool)SuperSimpleWP::get_setting('analyticswp', 'delete_data_on_uninstall'), 'Beim Löschen des Plugins alle Daten entfernen', [
            'description' => 'Aus, bleiben die Daten für eine spätere Neuinstallation erhalten. Deaktivieren allein löscht nie etwas.',
            'warning' => 'Beim Löschen des Plugins sind alle Besuche und Einstellungen endgültig weg. Ein Backup gibt es nicht.',
        ]);
        Ui::card_close();

        // Datenschutzerklärung.
        Ui::card_open('book-open', 'Text für die Datenschutzerklärung', 'Passt sich deinen Einstellungen an. Ein Vorschlag, keine Rechtsberatung.', '<button type="button" class="button" data-awp-copy="#awp-policy-text">' . Icons::svg('copy') . ' Text kopieren</button>', 'awp-span-all');
        echo '<div class="awp-card-body"><div class="awp-policy-preview" id="awp-policy" aria-live="polite">' . self::policy_preview() . '</div>'
            . '<textarea id="awp-policy-text" class="awp-sr" readonly tabindex="-1" aria-hidden="true">' . esc_textarea(\AnalyticsWP\Lib\Privacy::policy_text()) . '</textarea></div>';
        Ui::card_close('Steht auch unter Einstellungen › Datenschutz in der Anleitung für die Datenschutzerklärung.');

        // Leistung: the must-use plugin for the tracking request.
        $fast = \AnalyticsWP\Lib\FastEndpoint::status();
        $fast_texts = [
            'active' => ['', 'Aktiv. Jeder Seitenaufruf kostet den Server nur noch einen Bruchteil.'],
            'off' => ['', 'Aus. Jede Messanfrage lädt alle Plugins der Website.'],
            'outdated' => ['', 'Wird beim nächsten Aufruf einer Admin-Seite eingerichtet.'],
            'blocked' => ['warn', 'Auf diesem Server darf WordPress keine Dateien in wp-content/mu-plugins anlegen. Die Messung läuft trotzdem, nur ohne Schnellweg.'],
            'foreign' => ['warn', 'In wp-content/mu-plugins liegt schon eine Datei analyticswp-fast-endpoint.php, die nicht von Analytics stammt. Sie bleibt unangetastet.'],
        ];
        [$fast_tone, $fast_text] = $fast_texts[$fast] ?? $fast_texts['off'];
        Ui::card_open('lightning', 'Leistung', 'Wie viel Server jeder Seitenaufruf kostet', '', 'awp-span-all');
        $description = 'Für die Messanfrage, die jeder Seitenaufruf schickt, lädt WordPress nur Analytics (und Must-Have Cookie) statt aller Plugins. Dafür legt Analytics eine kleine Datei in wp-content/mu-plugins an und entfernt sie beim Ausschalten oder Deaktivieren wieder.';
        echo Ui::toggle('fast_endpoint', \AnalyticsWP\Lib\FastEndpoint::enabled(), 'Schneller Messpunkt', $fast_tone === 'warn'
            ? ['description' => $description, 'warning' => $fast_text]
            : ['description' => $description . ' ' . $fast_text]);
        Ui::card_close('Code, der die Messung über Filter anpasst, muss dann in einem MU-Plugin oder in wp-config.php stehen. Weitere Plugins lassen sich mit ANALYTICSWP_FAST_ENDPOINT_KEEP freigeben.');

        // Zugriff.
        Ui::card_open('user-circle-dashed', 'Zugriff', 'Wer die Auswertung sehen darf', '', 'awp-span-all');
        echo '<div class="awp-field"><p class="awp-field-desc">Administratoren immer. Die Einstellungen bleiben Administratoren vorbehalten.</p>';
        $access_roles = $roles;
        unset($access_roles['subscriber']);
        echo self::role_chips('access_role', 'analyticswp_admin-access-user-roles', $access_roles, $access + ['administrator' => '1'], 'awp-role-access-', ['administrator']);
        echo '</div>';
        Ui::card_close();

        // Shop.
        if (class_exists('WooCommerce')) {
            $positions = \AnalyticsWP\Lib\Integrations\WooCommerceIntegration::get_wc_field_positions();
            $how = (string)SuperSimpleWP::get_setting('analyticswp', 'how_did_you_hear');
            Ui::card_open('shopping-cart', 'Shop', 'WooCommerce', '', 'awp-span-all');
            echo '<div class="awp-field awp-switch-field"><div class="awp-switch-text"><label class="awp-switch-label" for="awp-how">Frage „Wie hast du von uns erfahren?“ an der Kasse</label><p class="awp-field-desc">Die Antwort steht an der Bestellung, neben der gemessenen Herkunft.</p></div>';
            echo '<select id="awp-how" name="analyticswp_how_did_you_hear" data-awp-autosave="how_did_you_hear"><option value="disable"' . selected($how, 'disable', false) . '>Nicht fragen</option>';
            foreach ($positions as $key => $label) {
                echo '<option value="' . esc_attr($key) . '"' . selected($how, $key, false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select></div>';
            echo Ui::toggle('enable_woocommerce_order_notification_source_section', (bool)SuperSimpleWP::get_setting('analyticswp', 'enable_woocommerce_order_notification_source_section'), 'Herkunft in der E-Mail „Neue Bestellung“ zeigen');
            Ui::card_close();
        }

        echo '<noscript><div class="awp-span-all"><button type="submit" class="button button-primary button-large">Einstellungen speichern</button></div></noscript>';
        echo '</div></form>';
    }

    /**
     * Roles as chips: a checkbox per role (posts with the form), saved on
     * change. Grouped into WordPress' roles and the rest.
     *
     * @param array<string, string> $roles
     * @param array<string, string> $active
     * @param list<string> $locked Always on, not changeable.
     */
    private static function role_chips(string $setting, string $name, array $roles, array $active, string $id_prefix, array $locked = []): string
    {
        $groups = ['WordPress' => [], 'Shop und Plugins' => []];
        foreach ($roles as $role => $label) {
            $groups[in_array($role, self::CORE_ROLES, true) ? 'WordPress' : 'Shop und Plugins'][$role] = $label;
        }

        $html = '';
        foreach ($groups as $group => $items) {
            if (empty($items)) {
                continue;
            }
            $html .= '<div class="awp-role-group"><span class="awp-insight-label">' . esc_html($group) . '</span><div class="awp-role-chips">';
            foreach ($items as $role => $label) {
                $id = $id_prefix . sanitize_html_class((string)$role);
                $is_locked = in_array($role, $locked, true);
                $html .= '<input type="checkbox" class="awp-chip-check" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '[' . esc_attr((string)$role) . ']" value="1"'
                    . checked(isset($active[$role]) || $is_locked, true, false) . ($is_locked ? ' disabled' : '')
                    . ' data-awp-autosave="' . esc_attr($setting) . '" data-awp-autosave-key="' . esc_attr((string)$role) . '">'
                    . '<label class="awp-chip-toggle" for="' . esc_attr($id) . '">' . Icons::svg('check') . esc_html(translate_user_role($label)) . '</label>';
                if ($is_locked) {
                    $html .= '<input type="hidden" name="' . esc_attr($name) . '[' . esc_attr((string)$role) . ']" value="1">';
                }
            }
            $html .= '</div></div>';
        }

        return $html;
    }

    /**
     * Pages that count as "Kontakt- oder Kassenseite" in the funnel of the
     * conversions tab, besides those with a form or purchase and the shop
     * checkout (Conversions::checkout_paths()).
     */
    private static function funnel_field(): void
    {
        $auto = array_values(array_diff(Conversions::checkout_paths(), array_filter(array_map('trim', explode(',', (string)get_option(Conversions::FUNNEL_OPTION, ''))))));
        echo '<div class="awp-field"><label class="awp-switch-label" for="awp-funnel-paths">Weitere Kontakt- oder Kassenseiten</label>'
            . '<p class="awp-field-desc">Für den Trichter unter Conversions. Seiten mit Formular oder Kauf zählen von selbst, außer der Startseite' . (!empty($auto) ? ', die Kasse auch (' . esc_html(implode(', ', $auto)) . ')' : '') . '. Hier ergänzt du z. B. eine Terminseite. Mehrere mit Komma trennen.</p>'
            . '<input type="text" id="awp-funnel-paths" class="regular-text" value="' . esc_attr((string)get_option(Conversions::FUNNEL_OPTION, '')) . '" placeholder="/termin/, /angebot/" data-awp-autosave="funnel_paths"></div>';
    }

    /**
     * "Was ist eine Anfrage wert?": per form, per contact click, optionally
     * per form, with what that would add up to.
     */
    private static function value_fields(): void
    {
        $period = Reports::period('30d');
        $types = Reports::conversion_types($period, [], Reports::main_currency($period));
        $forms = 0;
        $clicks = 0;
        $form_rows = [];
        foreach ($types as $row) {
            $kind = Format::conversion_kind($row['type']);
            if ($kind === 'form') {
                $forms += (int)$row['conversions'];
                $form_rows[] = $row;
            } elseif ($kind === 'contact') {
                $clicks += (int)$row['conversions'];
            }
        }
        $per_form = (string)SuperSimpleWP::get_setting('analyticswp', 'value_per_form');
        $per_contact = (string)SuperSimpleWP::get_setting('analyticswp', 'value_per_contact');
        $own = \AnalyticsWP\Lib\ConversionValue::form_values();

        $input = function (string $name, string $setting, string $value, string $placeholder, string $key = '') {
            return '<span class="awp-amount"><input type="text" inputmode="decimal" name="' . esc_attr($name) . '" value="' . esc_attr(str_replace('.', ',', $value)) . '" placeholder="' . esc_attr($placeholder) . '"'
                . ' data-awp-autosave="' . esc_attr($setting) . '"' . ($key !== '' ? ' data-awp-autosave-key="' . esc_attr($key) . '"' : '') . '><span>€</span></span>';
        };

        echo '<div class="awp-field" data-awp-value-hint data-forms="' . $forms . '" data-clicks="' . $clicks . '"><span class="awp-switch-label">Was ist eine Anfrage wert?</span>'
            . '<p class="awp-field-desc">Dann sehen auch Formulare und Kontakt-Klicks einen Wert, und Kanäle lassen sich ohne Shop vergleichen. Leer lassen, wenn du das nicht brauchst.</p>'
            . '<div class="awp-amounts"><label><span class="awp-utm-label">Je Formular-Anfrage</span>' . $input('analyticswp_value_per_form', 'value_per_form', $per_form, '0') . '</label>'
            . '<label><span class="awp-utm-label">Je Kontakt-Klick</span>' . $input('analyticswp_value_per_contact', 'value_per_contact', $per_contact, '0') . '</label></div>'
            . '<p class="awp-field-desc awp-value-hint">' . esc_html(self::value_hint($forms, $clicks, (float)$per_form, (float)$per_contact)) . '</p>';

        if (!empty($form_rows)) {
            echo '<details class="awp-utm-more"><summary>Je Formular unterschiedlich · optional</summary><div class="awp-form-values">';
            foreach ($form_rows as $row) {
                $key = \AnalyticsWP\Lib\ConversionValue::form_key($row['type'], $row['name']);
                $label = Format::conversion_type($row['type']) . ($row['name'] !== null ? ': ' . $row['name'] : '');
                echo '<label><span>' . esc_html($label) . '</span>' . $input('analyticswp_form_values[' . $key . ']', 'form_value', $own[$key] ?? '', $per_form !== '' ? str_replace('.', ',', $per_form) : '0', $key) . '</label>';
            }
            echo '</div></details>';
        }
        echo '</div>';
    }

    private static function value_hint(int $forms, int $clicks, float $per_form, float $per_contact): string
    {
        if ($forms === 0 && $clicks === 0) {
            return 'In den letzten 30 Tagen gab es noch keine Anfragen. Der Wert wird getrennt vom Umsatz gezeigt.';
        }

        $parts = [];
        if ($forms > 0) {
            $parts[] = Format::number($forms) . ($forms === 1 ? ' Anfrage' : ' Anfragen');
        }
        if ($clicks > 0) {
            $parts[] = Format::number($clicks) . ($clicks === 1 ? ' Kontakt-Klick' : ' Kontakt-Klicks');
        }
        $total = $forms * $per_form + $clicks * $per_contact;

        return 'Bei ' . implode(' und ', $parts) . ' in den letzten 30 Tagen wären das zusätzlich ' . Format::money($total, 'EUR', 0) . ' Wert. Er wird getrennt vom Umsatz gezeigt.';
    }

    /**
     * The privacy text as paragraphs; the first is the heading.
     */
    private static function policy_preview(): string
    {
        $paragraphs = \AnalyticsWP\Lib\Privacy::policy_paragraphs();
        $html = '<p class="awp-policy-title">' . esc_html((string)array_shift($paragraphs)) . '</p>';
        foreach ($paragraphs as $paragraph) {
            $html .= '<p>' . esc_html($paragraph) . '</p>';
        }

        return $html;
    }

    /**
     * Ui::info() with HTML (a link) in the text, escaped by the caller.
     */
    private static function info_html(string $html, string $icon = 'info'): string
    {
        return '<div class="awp-info">' . Icons::svg($icon) . '<div>' . $html . '</div></div>';
    }
}
