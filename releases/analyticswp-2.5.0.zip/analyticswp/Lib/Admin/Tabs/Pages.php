<?php

namespace AnalyticsWP\Lib\Admin\Tabs;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Tab;
use AnalyticsWP\Lib\Admin\Ui;
use AnalyticsWP\Lib\Insights;
use AnalyticsWP\Lib\Reports;

/**
 * Tab "Seiten": what is read and where visits end. The heart is "Was nach
 * dieser Seite passiert": per page the views split into completed (the
 * visit ended here with a conversion), clicked on, and left the website.
 * Then key figures (display only) and cards for pages, not found and
 * devices. A click on a page filters the whole page view.
 */
class Pages extends Tab
{
    /** Pages in the heart. */
    const HEART_PAGES = 8;

    /** Segment shares from this size carry their percentage. */
    const LABEL_SHARE = 0.09;

    /** Key figures: key => [label, format, higher is better, explanation]. */
    const KPIS = [
        'pageviews' => ['Seitenaufrufe', 'number', true, 'Jedes Laden einer Seite, auch mehrmals im selben Besuch.'],
        'per_visit' => ['Seiten je Besuch', 'decimal', true, 'Seitenaufrufe geteilt durch Besuche.'],
        'engaged' => ['Ø aktiv je Seite', 'duration', true, 'Zeit, in der eine Seite sichtbar war und benutzt wurde, im Schnitt je Aufruf.'],
        'bounce_rate' => ['Absprungrate', 'percent', false, 'Besuche mit nur einer Seite, ohne Abschluss und unter 10 Sekunden aktiv.'],
        'not_found' => ['Nicht gefunden', 'number', false, 'Aufrufe, die auf einer 404-Seite endeten.'],
    ];

    public static function render(): void
    {
        $period = App::period();
        $filters = App::filters();
        $since = Reports::first_seen_day();
        $compare = $since === null || $since <= $period['prev_end'];

        App::page_head(['since' => $since]);
        $currency = Reports::main_currency($period);
        $totals = Reports::totals($period, $filters, $currency);
        $engagement = Reports::engagement_totals($period, $filters);
        $before = Reports::engagement_totals(Reports::previous_period($period), $filters);

        // Pages with numbers in the address (order confirmations) as one.
        $pages = self::group_pages(Reports::pages($period, $filters, 200), 'path', ['pageviews', 'sessions', 'entries'], ['engaged', 'scroll'], 'pageviews');
        $exits = self::group_pages(Reports::breakdown('exit', $period, $filters, $currency, 200), 'value', ['sessions', 'conversions', 'converting', 'revenue'], ['bounce_rate'], 'sessions');
        $not_found = [];
        foreach (Reports::events_by('404', $period, $filters, 50) as $row) {
            $path = (string)\AnalyticsWP\Lib\URLs::path_of($row['value']);
            $not_found[$path] = ($not_found[$path] ?? 0) + (int)$row['count'];
        }
        arsort($not_found);
        $skip = array_keys($not_found);

        echo '<div class="awp-layout">';
        echo self::insight($totals, $exits, $pages, $skip, $period, $filters, $currency, $since);
        self::heart($pages, $exits, (int)$totals['current']['sessions'] >= Insights::MIN_VISITS ? $skip : null);
        self::kpis($totals, $engagement, $before, $compare);
        self::cards($period, $filters, $currency, $totals, $not_found);
        echo '</div>';
    }

    /**
     * The page most visits leave without a conversion (Insights::leaky_exit()),
     * else the best entry page, else the most viewed page.
     *
     * @param list<array<string, mixed>> $exits
     * @param list<array<string, mixed>> $pages
     * @param list<string> $skip
     */
    private static function insight(array $totals, array $exits, array $pages, array $skip, array $period, array $filters, string $currency, ?string $since): string
    {
        $sessions = (int)$totals['current']['sessions'];
        if ($sessions < Insights::MIN_VISITS) {
            return Ui::insight_line('pending', 'Erkenntnisse ab ' . Insights::MIN_VISITS . ' Besuchen.',
                'Bisher ' . Format::number($sessions) . ($sessions === 1 ? ' Besuch' : ' Besuche')
                . ($since !== null && $since >= $period['start'] ? ' seit dem ' . Format::day($since) : ' in diesem Zeitraum') . '. Bis dahin zeigen wir nur, was schon da ist.');
        }

        $leaky = Insights::leaky_exit($exits, $pages, $skip);
        if ($leaky !== null) {
            $exits_here = 0;
            foreach ($exits as $row) {
                if ((string)$row['value'] === $leaky['path']) {
                    $exits_here = (int)$row['sessions'];
                }
            }
            return Ui::insight_line('bad', 'Auf ' . $leaky['path'] . ' enden ' . Format::number($exits_here) . ' Besuche ohne Abschluss.',
                'Die Seite wird oft gelesen, führt aber selten weiter.', App::url(['f_page' => $leaky['path']]), 'Seite filtern');
        }

        $entries = Reports::breakdown('landing', $period, $filters, $currency, 200);
        $best = Insights::best_entry($entries, $currency);
        if ($best['status'] === 'ok') {
            return Ui::insight_line('good', 'Bester Einstieg: ' . $best['value'] . '.', $best['detail'] . '.', App::url(['f_landing' => $best['path']]), 'Einstieg filtern');
        }
        $top = Insights::top_page($pages);

        return Ui::insight_line($top['status'] === 'ok' ? 'good' : 'pending', 'Meistbesucht: ' . $top['value'] . '.', $top['detail'] . '.');
    }

    /**
     * "Was nach dieser Seite passiert": the most viewed pages, each with a
     * bar of 100 % of its views. Completed: visits that ended on the page
     * with a conversion; clicked on: views minus exits; left: exits without
     * a conversion. Under Insights::MIN_RATE_BASE views no bar, a
     * placeholder. Amber "viele gehen" from Insights::MIN_LEAVE_SHARE left
     * and nothing completed, with the exceptions of leaky_exit(), and only
     * from Insights::MIN_VISITS visits, like every finding.
     *
     * @param list<array<string, mixed>> $pages
     * @param list<array<string, mixed>> $exits
     * @param list<string>|null $skip null: too few visits for findings (no amber yet)
     */
    private static function heart(array $pages, array $exits, ?array $skip): void
    {
        $by_exit = [];
        foreach ($exits as $row) {
            $by_exit[(string)$row['value']] = $row;
        }

        echo '<section class="awp-card awp-span-all awp-heart" aria-labelledby="awp-heart-title">';
        echo '<div class="awp-heart-head"><h2 id="awp-heart-title" class="awp-heart-title">Was nach dieser Seite passiert</h2><div class="awp-heart-legend">'
            . '<span><i class="is-done"></i>Abgeschlossen</span><span><i class="is-on"></i>Weitergeklickt</span><span><i class="is-left"></i>Website verlassen</span></div></div>';

        if (empty($pages)) {
            echo '<p class="awp-tempty">Noch keine Seitenaufrufe in diesem Zeitraum.</p></section>';
            return;
        }

        echo '<div class="awp-heart-grid" role="table" aria-label="Was nach dieser Seite passiert">';
        echo '<div class="awp-heart-row is-head" role="row"><span role="columnheader">Seite</span><span role="columnheader">Aufrufe</span><span role="columnheader">Anteil der Aufrufe</span></div>';
        foreach (array_slice($pages, 0, self::HEART_PAGES) as $page) {
            $path = (string)$page['path'];
            $views = (int)$page['pageviews'];
            $exit = $by_exit[$path] ?? null;
            $exits_here = min($views, $exit !== null ? (int)$exit['sessions'] : 0);
            $done = min($exits_here, $exit !== null ? (int)($exit['converting'] ?? 0) : 0);
            $parts = [
                ['is-done', 'Abgeschlossen', $done],
                ['is-on', 'Weitergeklickt', $views - $exits_here],
                ['is-left', 'Website verlassen', $exits_here - $done],
            ];
            $few = !Insights::rate_is_meaningful($views);
            $warn = $skip !== null && !$few && empty($page['grouped']) && Insights::many_leave($path, $views, $done, $exits_here - $done, $skip);

            $bar = '';
            $said = [];
            if ($few) {
                $bar = '<span class="awp-heart-few" title="Unter ' . Insights::MIN_RATE_BASE . ' Aufrufen sind Anteile nicht aussagekräftig">Anteile ab ' . Insights::MIN_RATE_BASE . ' Aufrufen</span>';
                $said[] = 'unter ' . Insights::MIN_RATE_BASE . ' Aufrufen';
            } else {
                foreach ($parts as [$class, $label, $value]) {
                    if ($value <= 0) {
                        continue;
                    }
                    $share = $value / $views;
                    $text = $label . ': ' . Format::number($value) . ' (' . Format::percent($share, 0) . ')';
                    $said[] = $text;
                    $bar .= '<span class="awp-heart-seg ' . $class . '" style="flex:' . $value . ' 1 0" title="' . esc_attr($text) . '">'
                        . ($share >= self::LABEL_SHARE ? esc_html(Format::percent($share, 0)) : '') . '</span>';
                }
            }

            $name = '<span class="awp-heart-path" title="' . esc_attr($path) . '">' . esc_html($path) . '</span>'
                . ($page['meta'] !== '' ? '<span class="awp-tmeta">' . esc_html((string)$page['meta']) . '</span>' : '')
                . ($warn ? '<span class="awp-heart-warn">viele gehen</span>' : '');
            $cells = '<span class="awp-heart-name" role="cell">' . $name . '</span>'
                . '<span class="awp-heart-views" role="cell">' . esc_html(Format::number($views)) . '</span>'
                . '<span class="awp-heart-bar" role="cell">' . $bar . '</span>';
            $aria = $path . ': ' . implode(', ', $said);

            if (empty($page['grouped'])) {
                echo '<a class="awp-heart-row" role="row" href="' . esc_url(App::url(['f_page' => $path])) . '" aria-label="' . esc_attr($aria . '. Nach dieser Seite filtern') . '">' . $cells . '</a>';
            } else {
                echo '<div class="awp-heart-row" role="row" aria-label="' . esc_attr($aria) . '">' . $cells . '</div>';
            }
        }
        echo '</div></section>';
    }

    /**
     * Five key figures with the period before, display only.
     *
     * @param array{current: array<string, float|int>, previous: array<string, float|int>} $totals
     * @param array<string, float|int|null> $engagement
     * @param array<string, float|int|null> $before
     */
    private static function kpis(array $totals, array $engagement, array $before, bool $compare): void
    {
        $per_visit = function (array $t) {
            return (int)$t['sessions'] > 0 ? (int)$t['pageviews'] / (int)$t['sessions'] : 0.0;
        };
        $values = [
            'pageviews' => [$totals['current']['pageviews'], $totals['previous']['pageviews']],
            'per_visit' => [$per_visit($totals['current']), $per_visit($totals['previous'])],
            'engaged' => [$engagement['engaged'], $before['engaged']],
            'bounce_rate' => [$totals['current']['bounce_rate'], $totals['previous']['bounce_rate']],
            'not_found' => [$engagement['not_found'], $before['not_found']],
        ];
        $enough = Insights::rate_is_meaningful((int)$totals['current']['sessions']);

        $tiles = [];
        foreach (self::KPIS as $key => [$label, $format, $higher_is_better, $help]) {
            [$value, $previous] = $values[$key];
            if ($value === null) {
                $shown = '–';
                $delta = '';
            } elseif (in_array($key, ['bounce_rate', 'per_visit'], true) && !$enough) {
                $shown = 'Ausstehend';
                $delta = '<span class="awp-delta">ab ' . Insights::MIN_RATE_BASE . ' Besuchen</span>';
            } else {
                $shown = $format === 'decimal' ? number_format((float)$value, 1, ',', '.') : self::format_value($value, $format, '');
                $delta = $compare && $previous !== null ? self::kpi_delta($value, $previous, $higher_is_better) : '<span class="awp-delta">Noch kein Vergleich</span>';
            }
            $tiles[] = ['key' => $key, 'label' => $label, 'help' => $help, 'value' => $shown, 'delta' => $delta];
        }

        echo '<section class="awp-card awp-span-all" aria-label="Kennzahlen">' . Ui::kpi_bar($tiles) . '</section>';
    }

    /**
     * Pages (all, entry, exit), pages not found, devices.
     *
     * @param array{current: array<string, float|int>} $totals
     * @param array<string, int> $not_found path => views
     */
    private static function cards(array $period, array $filters, string $currency, array $totals, array $not_found): void
    {
        $sessions = (float)$totals['current']['sessions'];
        $empty = 'Noch keine Besuche in diesem Zeitraum.';

        Ui::card_row([[
            'key' => 'pages',
            'title' => 'Seiten',
            'tabs' => [
                'all' => ['label' => 'Alle Seiten', 'col' => 'Seite', 'heads' => ['Aufrufe', 'Besuche', 'Einstiege', 'Ø aktiv', 'Scrolltiefe'], 'empty' => 'Noch keine Seitenaufrufe in diesem Zeitraum.',
                    'rows' => function (int $limit) use ($period, $filters) {
                        $pages = self::group_pages(Reports::pages($period, $filters, max(200, $limit)), 'path', ['pageviews', 'sessions', 'entries'], ['engaged', 'scroll'], 'pageviews');
                        $rows = [];
                        foreach (array_slice($pages, 0, $limit) as $row) {
                            $rows[] = [
                                'label' => (string)$row['path'],
                                'meta' => (string)$row['meta'],
                                'value' => (int)$row['pageviews'],
                                'url' => empty($row['grouped']) ? App::url(['f_page' => (string)$row['path']]) : '',
                                'cells' => [
                                    Ui::cell_number((int)$row['pageviews']),
                                    Ui::cell_number((int)$row['sessions']),
                                    Ui::cell_number((int)$row['entries']),
                                    $row['engaged'] !== null ? [esc_html(Format::duration($row['engaged'])), (float)$row['engaged']] : ['<span class="awp-none">–</span>', ''],
                                    $row['scroll'] !== null ? [esc_html(Format::percent((float)$row['scroll'] / 100, 0)), (float)$row['scroll']] : ['<span class="awp-none">–</span>', ''],
                                ],
                            ];
                        }
                        return $rows;
                    }],
                'entry' => ['label' => 'Einstieg', 'col' => 'Seite', 'heads' => ['Einstiege', 'Anteil', 'Absprung', 'Conv.', 'Conv.-Rate', 'Umsatz'], 'cols' => [0, 3, 4, 5],
                    'rows' => self::breakdown_rows('landing', $period, $filters, $currency, $sessions), 'empty' => $empty],
                'exit' => ['label' => 'Ausstieg', 'col' => 'Seite', 'heads' => ['Ausstiege', 'Anteil', 'Absprung', 'Conv.', 'Conv.-Rate', 'Umsatz'], 'cols' => [0, 2, 3, 4],
                    'rows' => self::breakdown_rows('exit', $period, $filters, $currency, $sessions), 'empty' => $empty],
            ],
        ]]);

        $views_404 = array_sum($not_found);
        Ui::card_row([
            [
                'key' => 'notfound',
                'title' => 'Nicht gefunden',
                'badge' => $views_404 > 0 ? Format::number($views_404) : '',
                'tabs' => [
                    '404' => ['label' => 'Fehlerseiten', 'col' => 'Adresse', 'heads' => ['Aufrufe'], 'empty' => 'Keine Fehlerseiten. Gut so.',
                        'rows' => function (int $limit) use ($not_found) {
                            $rows = [];
                            foreach (array_slice($not_found, 0, $limit, true) as $path => $count) {
                                $rows[] = ['label' => (string)$path, 'value' => $count, 'url' => App::url(['f_page' => (string)$path]), 'cells' => [Ui::cell_number($count)]];
                            }
                            return $rows;
                        }],
                ],
            ],
            [
                'key' => 'devices',
                'title' => 'Geräte',
                'tabs' => [
                    'type' => ['label' => 'Gerätetyp', 'col' => 'Gerät', 'heads' => self::VISIT_HEADS, 'cols' => [0, 2],
                        'rows' => self::breakdown_rows('device', $period, $filters, $currency, $sessions, [], false, true), 'empty' => $empty],
                ],
            ],
        ]);
    }
}
