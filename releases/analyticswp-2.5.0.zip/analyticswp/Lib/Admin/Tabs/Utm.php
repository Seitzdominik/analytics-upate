<?php

namespace AnalyticsWP\Lib\Admin\Tabs;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Icons;
use AnalyticsWP\Lib\Admin\Tab;
use AnalyticsWP\Lib\Admin\Ui;
use AnalyticsWP\Lib\Reports;

/**
 * Tab "UTM-Links": the link builder, and the campaigns that already had
 * visits in the last 90 days (suggestions in the builder; a click opens
 * Quellen filtered to the campaign).
 */
class Utm extends Tab
{
    public static function render(): void
    {
        App::page_head();

        $period = Reports::period('90d');
        $rows = array_values(array_filter(Reports::breakdown('campaign', $period, [], Reports::main_currency($period), 30), function ($row) {
            return $row['value'] !== null && $row['value'] !== '';
        }));

        echo '<div class="awp-stack">';
        echo self::builder(array_map('strval', array_column($rows, 'value')));
        self::known($rows);
        echo '</div>';
    }

    /**
     * "Kampagnen, die schon Besuche hatten": reuse a name and the numbers
     * add up in Quellen.
     *
     * @param list<array<string, mixed>> $rows Reports::breakdown('campaign', ...), last 90 days
     */
    private static function known(array $rows): void
    {
        $base = ['tab' => 'sources', 'range' => '90d', 'from' => null, 'to' => null, 'f_*' => null] + array_fill_keys(App::VIEW_PARAMS, null);
        Ui::card_open('', 'Kampagnen, die schon Besuche hatten', 'Die letzten 90 Tage', '<a class="awp-linkline" href="' . esc_url(App::url($base) . '#awp-c-campaigns-t') . '">In Quellen ansehen' . Icons::svg('caret-right') . '</a>');
        echo '<div class="awp-card-body">';
        if (empty($rows)) {
            echo '<p class="awp-tempty">Noch keine Kampagne mit Besuchen. Sobald jemand über einen UTM-Link kommt, steht sie hier.</p>';
        } else {
            echo '<div class="awp-known">';
            foreach ($rows as $row) {
                $name = (string)$row['value'];
                echo '<a class="awp-known-chip" href="' . esc_url(App::url($base + ['f_campaign' => $name])) . '" title="' . esc_attr('In Quellen nach „' . $name . '“ filtern') . '">'
                    . esc_html($name) . '<span>' . esc_html(Format::number((int)$row['sessions'])) . '</span></a>';
            }
            echo '</div>';
        }
        echo '</div>';
        Ui::card_close('<span>Gleichen Namen wiederverwenden, dann laufen die Zahlen in „Quellen“ zusammen.</span>');
    }

    /**
     * Link builder for a campaign (admin.js builds and copies the link).
     *
     * @param list<string> $campaigns Known campaign names, as suggestions.
     */
    private static function builder(array $campaigns = []): string
    {
        $presets = [
            'newsletter' => ['Newsletter', 'envelope-simple', 'newsletter', 'email'],
            'facebook' => ['Facebook-Post', 'chat-circle', 'facebook', 'social'],
            'instagram' => ['Instagram', 'chat-circle', 'instagram', 'social'],
            'google' => ['Google-Anzeige', 'magnifying-glass', 'google', 'cpc'],
            'meta' => ['Meta-Anzeige', 'megaphone', 'facebook', 'paid'],
        ];

        $html = '<section class="awp-card awp-span-all" id="awp-utm"><header class="awp-card-head"><span class="awp-card-icon">' . Icons::svg('megaphone') . '</span>'
            . '<div class="awp-card-heading"><h2 class="awp-card-title">Link für eine Kampagne bauen</h2><p class="awp-card-sub">Damit du siehst, welcher Newsletter, Post oder welche Anzeige Besucher bringt.</p></div></header>'
            . '<div class="awp-card-body awp-utm" data-awp-utm>';

        $html .= '<div class="awp-utm-presets"><span class="awp-utm-label">Wo teilst du den Link?</span><div>';
        foreach ($presets as $key => [$label, $icon, $source, $medium]) {
            $on = $key === 'newsletter';
            $html .= '<button type="button" class="awp-preset" data-awp-utm-preset data-source="' . esc_attr($source) . '" data-medium="' . esc_attr($medium) . '" aria-pressed="' . ($on ? 'true' : 'false') . '">'
                . Icons::svg($icon) . esc_html($label) . '</button>';
        }
        $html .= '</div></div>';

        $field = function (string $name, string $label, string $param, string $value, string $placeholder, string $extra = '') {
            return '<label class="awp-utm-field"><span class="awp-utm-label">' . esc_html($label) . ($param !== '' ? ' <span>· ' . esc_html($param) . '</span>' : '') . '</span>'
                . '<input type="text" data-awp-utm-field="' . esc_attr($name) . '" value="' . esc_attr($value) . '" placeholder="' . esc_attr($placeholder) . '"' . $extra . '></label>';
        };

        $html .= '<div class="awp-utm-grid">'
            . '<div class="awp-utm-wide">' . $field('url', 'Zielseite', '', home_url('/'), home_url('/')) . '</div>'
            . $field('utm_source', 'Quelle', 'utm_source', 'newsletter', 'z. B. newsletter')
            . $field('utm_medium', 'Art', 'utm_medium', 'email', 'z. B. email')
            . $field('utm_campaign', 'Kampagne', 'utm_campaign', '', 'z. B. herbst-aktion', ' list="awp-campaigns"')
            . '</div><datalist id="awp-campaigns">';
        foreach ($campaigns as $campaign) {
            $html .= '<option value="' . esc_attr($campaign) . '"></option>';
        }
        $html .= '</datalist>';

        $html .= '<details class="awp-utm-more"><summary>Inhalt unterscheiden · optional</summary>'
            . '<label class="awp-utm-field"><span class="awp-field-desc">Zum Beispiel zwei Buttons im selben Newsletter. utm_content</span>'
            . '<input type="text" data-awp-utm-field="utm_content" placeholder="z. B. button-oben"></label></details>';

        $html .= '<div class="awp-utm-result"><div class="awp-utm-link" data-awp-utm-out aria-label="Fertiger Link" aria-live="polite">' . esc_html(home_url('/')) . '</div>'
            . '<button type="button" class="button button-primary awp-utm-copy" data-awp-copy-utm>' . Icons::svg('copy') . '<span>Link kopieren</span></button></div>'
            . '<p class="awp-field-desc">Großbuchstaben und Leerzeichen passen wir automatisch an, damit gleiche Namen in der Auswertung zusammenlaufen.</p>';

        return $html . '</div></section>';
    }
}
