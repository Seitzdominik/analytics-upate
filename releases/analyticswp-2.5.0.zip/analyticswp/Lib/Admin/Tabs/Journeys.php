<?php

namespace AnalyticsWP\Lib\Admin\Tabs;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Channels;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Icons;
use AnalyticsWP\Lib\Admin\Tab;
use AnalyticsWP\Lib\Admin\Ui;
use AnalyticsWP\Lib\Reports;

/**
 * Tab "Journeys": the mosaic of the latest visits with preview and
 * timeline, and the list of visits by day with their steps.
 */
class Journeys extends Tab
{
    /** Result of a visit => [label, colour]. */
    const VISIT_RESULTS = [
        'conv' => ['Mit Conversion', '#0f6e68'],
        'multi' => ['Mehrere Seiten, ohne Conversion', '#9fcbc6'],
        'bounce' => ['Abgesprungen', '#dcdcd7'],
    ];

    const MONTHS = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

    /** Visits per page of the journeys list. */
    const VISITS_PER_PAGE = 20;

    /** Result of a visit in the mosaic => value of the `result` filter. */
    const RESULT_FILTERS = ['conv' => 'converted', 'multi' => 'browsed', 'bounce' => 'bounced'];

    public static function render(): void
    {
        $visitor = isset($_GET['visitor']) ? sanitize_text_field(wp_unslash($_GET['visitor'])) : '';
        $user_id = isset($_GET['user']) ? absint($_GET['user']) : 0;

        if ($visitor !== '' || $user_id > 0) {
            self::journey_detail($visitor, $user_id);
            return;
        }

        $period = App::period();
        $filters = App::filters();
        $with_empty = !empty($_GET['empty']);
        $page = isset($_GET['p']) ? max(1, min(50, absint($_GET['p']))) : 1;

        App::page_head();
        echo '<div class="awp-layout">';

        // Mosaic and list follow the page's filters; the legend sets them.
        $mosaic = Reports::recent_visits($filters);
        self::journey_mosaic($mosaic, $filters);

        $limit = $page * self::VISITS_PER_PAGE;
        $rows = Reports::visits_list($period, $filters, 'all', $with_empty, $limit + 1);
        $has_more = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);
        $counts = Reports::visits_counts($period, $filters, $with_empty);
        self::journey_list($rows, $counts, $with_empty, $has_more, $page, $filters);

        echo '</div>';
    }

    /**
     * Purchase, multi-page or bounce.
     *
     * @param array<string, mixed> $visit
     */
    private static function visit_result(array $visit): string
    {
        if ((int)$visit['conversions'] > 0) {
            return 'conv';
        }

        return (int)$visit['pageviews'] > 1 ? 'multi' : 'bounce';
    }

    /**
     * The path of a visit as dots: one per page (at most 10), a conversion
     * marks the page it happened on.
     *
     * @param list<array<string, mixed>> $events
     * @return list<string> 'p' page, 'c' page with conversion
     */
    private static function visit_dots(array $events, int $pageviews): array
    {
        $dots = [];
        foreach ($events as $event) {
            if ($event['event_type'] === 'pageview') {
                $dots[] = 'p';
            } elseif (!empty($event['conversion_type'])) {
                if (empty($dots)) {
                    $dots[] = 'p';
                }
                $dots[count($dots) - 1] = 'c';
            }
        }
        if (empty($dots)) {
            $dots = array_fill(0, max(0, min(10, $pageviews)), 'p');
        }

        return array_slice($dots, 0, 10);
    }

    /**
     * @param array<string, mixed> $visit
     */
    private static function visit_detail(array $visit): string
    {
        $parts = array_filter([(string)$visit['source'], (string)$visit['campaign']]);
        if (empty($parts)) {
            return $visit['channel'] === \AnalyticsWP\Lib\Attribution::DIRECT ? 'ohne Quelle' : '';
        }

        return implode(' · ', $parts);
    }

    /**
     * @param array<string, mixed> $visit
     */
    private static function visit_duration(array $visit): string
    {
        $seconds = (int)strtotime($visit['last_seen_at'] . ' UTC') - (int)strtotime($visit['started_at'] . ' UTC');

        return (int)$visit['events'] > 1 && $seconds > 0 ? Format::duration($seconds) : '–';
    }

    /**
     * "Heute", "Gestern" or "18. Oktober" for a UTC timestamp.
     */
    private static function day_label(string $utc): string
    {
        $time = (int)strtotime($utc . ' UTC');
        $day = wp_date('Y-m-d', $time);
        if ($day === wp_date('Y-m-d')) {
            return 'Heute';
        }
        if ($day === wp_date('Y-m-d', time() - DAY_IN_SECONDS)) {
            return 'Gestern';
        }

        return wp_date('j', $time) . '. ' . self::MONTHS[(int)wp_date('n', $time) - 1] . ((string)wp_date('Y', $time) !== (string)wp_date('Y') ? ' ' . wp_date('Y', $time) : '');
    }

    /**
     * The last 260 visits as squares, the time they fell in as stacked bars,
     * a preview of the visit under the pointer.
     *
     * @param list<array<string, mixed>> $visits
     */
    private static function journey_mosaic(array $visits, array $filters): void
    {
        $count = count($visits);
        $switch = '<span class="awp-seg-label">Farbe nach</span><div class="awp-seg awp-seg--buttons" role="group" aria-label="Farbe nach">'
            . '<button type="button" class="is-active" aria-pressed="true" data-awp-mosaic-mode="result">Ergebnis</button>'
            . '<button type="button" aria-pressed="false" data-awp-mosaic-mode="channel">Kanal</button></div>';

        if ($count === 0) {
            Ui::card_open('squares-four', 'Die letzten Besuche', '', '', 'awp-span-all');
            echo '<div class="awp-card-body">' . Ui::empty_state('Noch keine Besuche.') . '</div>';
            Ui::card_close();
            return;
        }

        $oldest = (string)end($visits)['started_at'];
        $newest = (string)$visits[0]['started_at'];
        $subtitle = 'Jedes Quadrat ist ein Besuch, vom ' . Format::datetime($oldest) . ' bis ' . Format::datetime($newest)
            . ($count < Reports::MOSAIC_SIZE ? ' · ' . Format::number($count) . ' von ' . Reports::MOSAIC_SIZE . ' Feldern gefüllt' : '');
        Ui::card_open('squares-four', $count >= Reports::MOSAIC_SIZE ? 'Die letzten ' . Reports::MOSAIC_SIZE . ' Besuche' : 'Die letzten ' . $count . ' Besuche', $subtitle, $switch, 'awp-span-all awp-mosaic-card');

        $steps = Reports::visit_steps(array_column($visits, 'session_id'), 8000);
        $timeline = self::visit_bins($visits);

        $data = [];
        $results = ['conv' => 0, 'multi' => 0, 'bounce' => 0];
        $channels = [];
        $pages = 0;
        $mobile = 0;
        $squares = '';
        foreach ($visits as $i => $visit) {
            $result = self::visit_result($visit);
            $channel = (string)$visit['channel'];
            $results[$result]++;
            $channels[$channel] = ($channels[$channel] ?? 0) + 1;
            $pages += (int)$visit['pageviews'];
            $mobile += $visit['device_type'] === 'mobile' ? 1 : 0;
            $conversions = (int)$visit['conversions'];
            $revenue = $visit['revenue'] !== null && (float)$visit['revenue'] > 0 ? Format::money((float)$visit['revenue'], (string)($visit['currency'] ?: 'EUR')) : '';

            $data[] = [
                'id' => (string)$visit['session_id'],
                'v' => $visit['user_id'] ? '' : (string)$visit['visitor_hash'],
                'u' => (int)$visit['user_id'],
                'k' => $channel,
                'n' => Format::channel($channel),
                'd' => self::visit_detail($visit),
                'dv' => Format::device((string)$visit['device_type']),
                'di' => self::DEVICE_ICONS[(string)$visit['device_type']] ?? 'desktop',
                'w' => Format::datetime((string)$visit['started_at']) . ' Uhr',
                'e' => (string)$visit['landing_path'],
                'p' => (int)$visit['pageviews'],
                't' => self::visit_duration($visit),
                'c' => $conversions,
                'r' => $revenue,
                'x' => self::visit_dots($steps[(string)$visit['session_id']] ?? [], (int)$visit['pageviews']),
                'b' => $timeline['of'][$i],
                's' => $result,
            ];

            $aria = Format::channel($channel) . ', ' . Format::datetime((string)$visit['started_at']) . ', '
                . ($conversions > 0 ? $conversions . ($conversions === 1 ? ' Conversion' : ' Conversions') : ((int)$visit['pageviews'] > 1 ? $visit['pageviews'] . ' Seiten' : 'abgesprungen'));
            $squares .= '<button type="button" class="awp-sq" data-i="' . $i . '" aria-label="' . esc_attr($aria) . '" aria-pressed="false"'
                . ' style="--sq-res:' . self::VISIT_RESULTS[$result][1] . ';--sq-ch:' . esc_attr(Channels::color($channel)) . '"></button>';
        }

        $channel_icons = [];
        foreach (Channels::STYLES as $channel => [, $icon]) {
            $channel_icons[$channel] = $icon;
        }
        // The visits as a JSON script: no attribute escaping for 260 entries.
        echo '<div class="awp-mosaic" data-awp-mosaic data-awp-channel-icons="' . esc_attr((string)wp_json_encode($channel_icons)) . '">'
            . '<script type="application/json" class="awp-mosaic-data">' . wp_json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) . '</script>';

        // Squares and timeline.
        // Fields not yet filled, dashed (not part of the mosaic's script).
        $squares .= str_repeat('<span class="awp-sq-empty" aria-hidden="true"></span>', max(0, Reports::MOSAIC_SIZE - $count));
        echo '<div class="awp-mosaic-left"><div class="awp-sq-grid" role="group" aria-label="Besuche als Quadrate, neueste oben links">' . $squares . '</div>'
            . '<div class="awp-sq-ends" aria-hidden="true"><span>neuester</span><span>älter</span></div>';
        echo '<div class="awp-bins-wrap"><div class="awp-bins-head"><span>Wann die Besuche waren</span><span>' . esc_html($timeline['unit']) . '</span></div>'
            . '<div class="awp-bins" role="img" aria-label="' . esc_attr('Besuche ' . $timeline['unit'] . ', neueste links') . '">';
        foreach ($timeline['bins'] as $b => $bin) {
            echo '<div class="awp-bin" data-b="' . $b . '" data-title="' . esc_attr($bin['title']) . '" data-text="' . esc_attr(Format::number($bin['n']) . ($bin['n'] === 1 ? ' Besuch' : ' Besuche') . ($bin['conv'] ? ' · ' . $bin['conv'] . ' mit Conversion' : '')) . '"' . ($bin['gap'] ? ' style="margin-right:3px"' : '') . '>'
                . '<span class="awp-bin-mark" aria-hidden="true"></span><span class="awp-bin-by-result">';
            foreach (['conv', 'multi', 'bounce'] as $key) {
                if ($bin[$key] > 0) {
                    echo '<i style="height:' . round($bin[$key] / $timeline['max'] * 48, 1) . 'px;background:' . self::VISIT_RESULTS[$key][1] . '"></i>';
                }
            }
            echo '</span><span class="awp-bin-by-channel">';
            foreach ($bin['ch'] as $channel => $n) {
                echo '<i style="height:' . round($n / $timeline['max'] * 48, 1) . 'px;background:' . esc_attr(Channels::color($channel)) . '"></i>';
            }
            echo '</span></div>';
        }
        echo '<div class="awp-bin-tip" hidden></div></div><div class="awp-bins-x" aria-hidden="true">';
        foreach ($timeline['ticks'] as [$position, $label]) {
            echo '<span style="left:' . $position . '%">' . esc_html($label) . '</span>';
        }
        echo '</div></div></div>';

        // Preview, legend, figures.
        echo '<div class="awp-mosaic-right">';
        echo '<div class="awp-preview" aria-live="polite">'
            . '<div class="awp-preview-empty">' . Icons::svg('squares-four') . '<span>Fahr über ein Quadrat oder einen Balken.<br>Hier erscheint die Vorschau des Besuchs.</span></div>'
            . '<div class="awp-preview-card" hidden><div class="awp-preview-head"><span class="awp-tile" data-slot="icon"></span>'
            . '<span class="awp-preview-origin"><strong data-slot="channel"></strong><span data-slot="detail"></span></span>'
            . '<button type="button" class="awp-preview-close" data-awp-unpin hidden aria-label="Vorschau schließen">' . Icons::svg('x') . '</button></div>'
            . '<div class="awp-preview-when"><span data-slot="device-icon"></span><span data-slot="when"></span></div>'
            . '<div class="awp-preview-path"><span class="awp-dots" data-slot="dots"></span><span><span class="awp-row-meta">Einstieg</span> <span data-slot="entry"></span></span><span class="awp-field-desc" data-slot="summary"></span></div>'
            . '<div class="awp-preview-foot"><span data-slot="result"></span><a href="#" class="awp-linkline" data-slot="open">Ganze Journey' . Icons::svg('caret-down') . '</a></div></div>'
            . '</div>';

        // Icons the preview borrows (channel and device).
        echo '<div hidden data-awp-icon-sprite>';
        foreach (array_unique(array_merge(array_column(Channels::STYLES, 1), array_values(self::DEVICE_ICONS))) as $icon) {
            echo '<span data-name="' . esc_attr($icon) . '">' . Icons::svg($icon) . '</span>';
        }
        echo '</div>';

        $percent = function (int $n) use ($count) {
            return Format::percent($n / max(1, $count), 0);
        };
        // A click on the legend filters mosaic and list (and the whole page).
        $legend_row = function (string $param, string $value, string $color, string $label, int $n) use ($filters, $percent) {
            $on = ($filters[$param] ?? null) === $value;
            return '<a class="awp-legend-row' . ($on ? ' is-on' : '') . '" href="' . esc_url(App::url(['f_' . $param => $on ? null : $value, 'p' => null])) . '"'
                . ' title="' . esc_attr($on ? 'Filter entfernen' : 'Nur diese Besuche zeigen') . '"' . ($on ? ' aria-current="true"' : '') . '>'
                . '<i style="background:' . esc_attr($color) . '"></i><span>' . esc_html($label) . '</span><strong>' . esc_html(Format::number($n)) . '</strong><span>' . esc_html($percent($n)) . '</span></a>';
        };
        echo '<div class="awp-legend"><span class="awp-legend-label">Legende</span><div class="awp-legend-by-result">';
        foreach (self::VISIT_RESULTS as $key => [$label, $color]) {
            echo $legend_row('result', self::RESULT_FILTERS[$key], $color, $label, $results[$key]);
        }
        echo '</div><div class="awp-legend-by-channel">';
        arsort($channels);
        foreach ($channels as $channel => $n) {
            echo $legend_row('channel', (string)$channel, Channels::color($channel), Format::channel($channel), $n);
        }
        echo '</div></div>';

        echo '<div class="awp-stats">'
            . '<div class="awp-stat"><span class="awp-stat-label">Ø Seiten je Besuch</span><span class="awp-stat-value">' . esc_html(number_format($pages / max(1, $count), 1, ',', '.')) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Mit Conversion</span><span class="awp-stat-value">' . esc_html($percent($results['conv'])) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Abgesprungen</span><span class="awp-stat-value">' . esc_html($percent($results['bounce'])) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Smartphone</span><span class="awp-stat-value">' . esc_html($percent($mobile)) . '</span></div>'
            . '</div><span class="awp-field-desc">Klick auf ein Quadrat hält die Vorschau fest.</span>';
        echo '</div></div>';

        Ui::card_close();
    }

    /**
     * Time windows of the mosaic's visits, newest left: 6 hours while the
     * visits span two weeks at most, else days, else weeks, so that there
     * are never more than about 60 bars.
     *
     * @param list<array<string, mixed>> $visits Newest first.
     * @return array{bins: list<array<string, mixed>>, of: list<int>, ticks: list<array{0: float, 1: string}>, unit: string, max: int}
     */
    private static function visit_bins(array $visits): array
    {
        $offset = wp_timezone()->getOffset(new \DateTime('now', new \DateTimeZone('UTC')));
        $local = array_map(function ($visit) use ($offset) {
            return (int)strtotime($visit['started_at'] . ' UTC') + $offset;
        }, $visits);
        $span = max(1, $local[0] - end($local));

        if ($span <= 14 * DAY_IN_SECONDS) {
            [$size, $unit] = [6 * HOUR_IN_SECONDS, 'je 6 Stunden'];
        } elseif ($span <= 60 * DAY_IN_SECONDS) {
            [$size, $unit] = [DAY_IN_SECONDS, 'je Tag'];
        } else {
            [$size, $unit] = [WEEK_IN_SECONDS, 'je Woche'];
        }

        $end = (int)(floor($local[0] / $size) + 1) * $size;
        $count = (int)floor(($end - end($local) - 1) / $size) + 1;
        $bins = [];
        for ($b = 0; $b < $count; $b++) {
            $start = $end - ($b + 1) * $size;
            $bins[$b] = ['n' => 0, 'conv' => 0, 'multi' => 0, 'bounce' => 0, 'ch' => [], 'start' => $start, 'gap' => false, 'title' => ''];
        }

        $of = [];
        foreach ($visits as $i => $visit) {
            $b = min($count - 1, (int)floor(($end - 1 - $local[$i]) / $size));
            $of[$i] = $b;
            $bins[$b]['n']++;
            $bins[$b][self::visit_result($visit)]++;
            $channel = (string)$visit['channel'];
            $bins[$b]['ch'][$channel] = ($bins[$b]['ch'][$channel] ?? 0) + 1;
        }

        $weekday = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
        $today = (int)floor((time() + $offset) / DAY_IN_SECONDS);
        $day_name = function (int $local_time) use ($weekday, $today) {
            $day = (int)floor($local_time / DAY_IN_SECONDS);
            if ($day === $today) {
                return 'Heute';
            }
            if ($day === $today - 1) {
                return 'Gestern';
            }
            return $weekday[(int)gmdate('w', $local_time)] . ' ' . gmdate('j.', $local_time);
        };

        $ticks = [];
        foreach ($bins as $b => &$bin) {
            $start = $bin['start'];
            if ($size === 6 * HOUR_IN_SECONDS) {
                $hour = (int)gmdate('G', $start);
                $name = $day_name($start);
                $bin['title'] = (in_array($name, ['Heute', 'Gestern'], true) ? $name : $weekday[(int)gmdate('w', $start)] . ', ' . gmdate('j.n.', $start)) . ', ' . $hour . '–' . ($hour + 6) . ' Uhr';
                if ($hour === 0 && $b < $count - 1) {
                    $bin['gap'] = true;
                }
                if ($hour === 12) {
                    $ticks[] = [round(($b + 0.5) / $count * 100, 2), $day_name($start)];
                }
            } elseif ($size === DAY_IN_SECONDS) {
                $bin['title'] = $weekday[(int)gmdate('w', $start)] . ', ' . gmdate('j.n.', $start);
                if ($b % 7 === 0) {
                    $ticks[] = [round(($b + 0.5) / $count * 100, 2), $day_name($start)];
                }
            } else {
                $bin['title'] = 'Woche ab ' . gmdate('j.n.', $start);
                if ($b % 4 === 0) {
                    $ticks[] = [round(($b + 0.5) / $count * 100, 2), gmdate('j.n.', $start)];
                }
            }
            arsort($bin['ch']);
        }
        unset($bin);

        return ['bins' => $bins, 'of' => $of, 'ticks' => $ticks, 'unit' => $unit, 'max' => max(1, max(array_column($bins, 'n')))];
    }

    /**
     * The visits of the period, by day, each with its steps to unfold.
     *
     * @param list<array<string, mixed>> $rows
     * @param array{all: int, conv: int, multi: int, empty: int} $counts
     * @param array<string, string> $filters
     */
    private static function journey_list(array $rows, array $counts, bool $with_empty, bool $has_more, int $page, array $filters): void
    {
        $total = (int)$counts['all'];
        echo '<section class="awp-card awp-span-all awp-visits" id="awp-visits" aria-label="Besuche"><header class="awp-card-head awp-visits-head">'
            . '<div class="awp-card-heading"><h2 class="awp-card-title">Besuche</h2><p class="awp-card-sub">' . esc_html(Format::number($total) . ($total === 1 ? ' Besuch' : ' Besuche') . (empty($filters) ? ' in diesem Zeitraum' : ' mit den Filtern oben')) . ', neueste zuerst</p></div></header>';

        if (empty($rows)) {
            echo '<div class="awp-card-body">' . Ui::empty_state('Keine Besuche in diesem Zeitraum' . (!empty($filters) ? ' mit diesen Filtern' : '') . '.') . '</div>';
        } else {
            $steps = Reports::visit_steps(array_column($rows, 'session_id'), 6000);
            echo '<div class="awp-visit-head" aria-hidden="true"><span>Herkunft</span><span>Weg durch die Website</span><span>Ergebnis</span><span>Dauer</span><span>Gerät</span><span>Beginn</span><span></span></div>';
            $day = '';
            foreach ($rows as $row) {
                $label = self::day_label((string)$row['started_at']);
                if ($label !== $day) {
                    echo '<div class="awp-visit-day">' . esc_html($label) . '</div>';
                    $day = $label;
                }
                self::visit_row($row, $steps[(string)$row['session_id']] ?? []);
            }
        }

        if ($has_more) {
            echo '<div class="awp-visits-more"><a class="button" href="' . esc_url(App::url(['p' => (string)($page + 1)]) . '#awp-visits') . '">Weitere ' . self::VISITS_PER_PAGE . ' Besuche laden</a></div>';
        }

        $foot = '';
        if ($counts['empty'] > 0) {
            $foot = Icons::svg('info') . '<span>' . esc_html(
                $with_empty
                    ? Format::number($counts['empty']) . ($counts['empty'] === 1 ? ' Besuch ohne Seitenaufruf wird gezeigt' : ' Besuche ohne Seitenaufruf werden gezeigt') . ' (etwa ein Kauf, den ein Zahlungsdienst bestätigt hat).'
                    : Format::number($counts['empty']) . ($counts['empty'] === 1 ? ' Besuch ohne Seitenaufruf ausgeblendet' : ' Besuche ohne Seitenaufruf ausgeblendet') . ' (etwa ein Kauf, den ein Zahlungsdienst bestätigt hat).'
            ) . '</span><a href="' . esc_url(App::url(['empty' => $with_empty ? null : '1', 'p' => null]) . '#awp-visits') . '">' . ($with_empty ? 'Ausblenden' : 'Zeigen') . '</a>';
        }
        echo $foot !== '' ? '<footer class="awp-card-foot awp-visits-foot">' . $foot . '</footer>' : '';
        echo '</section>';
    }

    /**
     * One visit: a summary row that unfolds into its steps.
     *
     * @param array<string, mixed> $row
     * @param list<array<string, mixed>> $events
     */
    private static function visit_row(array $row, array $events): void
    {
        $channel = (string)$row['channel'];
        $result = self::visit_result($row);
        $pageviews = (int)$row['pageviews'];
        $conversions = (int)$row['conversions'];
        $revenue = $row['revenue'] !== null && (float)$row['revenue'] > 0 ? Format::money((float)$row['revenue'], (string)($row['currency'] ?: 'EUR')) : '';
        $device = (string)$row['device_type'];
        $path = $pageviews === 0 ? 'Kein Seitenaufruf' : (string)$row['landing_path'] . ($pageviews > 1 ? ' + ' . ($pageviews - 1) . ($pageviews === 2 ? ' Seite' : ' Seiten') : '');

        $dots = '';
        foreach (self::visit_dots($events, $pageviews) as $i => $dot) {
            $dots .= '<i class="' . ($dot === 'c' ? 'is-conv' : ($i === 0 ? 'is-first' : '')) . '"></i>';
        }
        if ($pageviews === 0) {
            $dots .= '<i class="is-none"></i>';
        }

        if ($conversions > 0) {
            $outcome = '<span class="awp-outcome"><span class="awp-pill-conv">' . Icons::svg('target') . esc_html($conversions === 1 ? '1 Conversion' : $conversions . ' Conversions') . '</span>'
                . ($revenue !== '' ? '<span>' . esc_html($revenue) . '</span>' : '') . '</span>';
        } else {
            $outcome = '<span class="awp-none">' . ($pageviews === 1 ? 'Abgesprungen' : '–') . '</span>';
        }

        echo '<details class="awp-visit" id="awp-visit-' . esc_attr((string)$row['session_id']) . '"><summary class="awp-visit-row">'
            . '<span class="awp-visit-origin"><span class="awp-tile">' . Icons::svg(Channels::icon($channel)) . '<span class="awp-swatch" style="background:' . esc_attr(Channels::css_var($channel)) . '"></span></span>'
            . '<span class="awp-visit-text"><span>' . esc_html(Format::channel($channel)) . '</span><span class="awp-row-meta">' . esc_html(self::visit_detail($row)) . '</span></span></span>'
            . '<span class="awp-visit-path"><span class="awp-dots" aria-hidden="true">' . $dots . '</span><span class="awp-visit-pathtext">' . esc_html($path) . '</span></span>'
            . '<span>' . $outcome . '</span>'
            . '<span class="awp-num is-muted">' . esc_html(self::visit_duration($row)) . '</span>'
            . '<span class="awp-visit-device" title="' . esc_attr(Format::device($device)) . '">' . Icons::svg(self::DEVICE_ICONS[$device] ?? 'desktop') . '<span class="awp-sr">' . esc_html(Format::device($device)) . '</span></span>'
            . '<span class="awp-num is-muted">' . esc_html((string)wp_date('H:i', (int)strtotime($row['started_at'] . ' UTC'))) . '</span>'
            . '<span class="awp-visit-caret">' . Icons::svg('caret-down') . '</span>'
            . '</summary>';

        echo '<div class="awp-visit-body">' . self::visit_steps_html($row, $events);
        $journey = $row['user_id'] ? ['user' => (string)(int)$row['user_id']] : ['visitor' => (string)$row['visitor_hash']];
        echo '<div class="awp-visit-side"><div class="awp-stats">'
            . '<div class="awp-stat"><span class="awp-stat-label">Seiten</span><span class="awp-stat-value">' . esc_html(Format::number($pageviews)) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Dauer</span><span class="awp-stat-value">' . esc_html(self::visit_duration($row)) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Gerät</span><span class="awp-stat-value">' . esc_html(Format::device($device)) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Ergebnis</span><span class="awp-stat-value">' . esc_html($conversions > 0 ? $conversions . '× · ' . ($revenue !== '' ? $revenue : 'ohne Wert') : 'keine Conversion') . '</span></div>'
            . '</div><p class="awp-field-desc">Ohne Einwilligung endet ein Besuch nach 30 Minuten ohne Aktivität, spätestens um Mitternacht.</p>'
            . Ui::link(App::url($journey + ['empty' => null, 'p' => null, 'f_*' => null]), 'Alle Besuche dieses Besuchers') . '</div>';
        echo '</div></details>';
    }

    /**
     * The steps of one visit as a timeline: entry, pages, clicks,
     * conversions, end.
     *
     * @param array<string, mixed> $visit
     * @param list<array<string, mixed>> $events
     */
    private static function visit_steps_html(array $visit, array $events): string
    {
        $start = (int)strtotime($visit['started_at'] . ' UTC');
        $relative = function (string $timestamp) use ($start) {
            $seconds = max(0, (int)strtotime($timestamp . ' UTC') - $start);
            return intdiv($seconds, 60) . ':' . str_pad((string)($seconds % 60), 2, '0', STR_PAD_LEFT);
        };
        $origin = Format::channel((string)$visit['channel']) . (self::visit_detail($visit) !== '' && self::visit_detail($visit) !== 'ohne Quelle' ? ' · ' . self::visit_detail($visit) : '');

        $steps = [];
        $first_page = true;
        $last_path = '';
        foreach ($events as $event) {
            $props = json_decode((string)$event['event_properties_json'], true);
            $props = is_array($props) ? $props : [];
            $path = (string)($event['path'] ?? '') !== '' ? (string)$event['path'] : Format::path((string)$event['page_url']);

            if (!empty($event['conversion_type'])) {
                $type = (string)$event['conversion_type'];
                $label = Format::conversion_type($type) . (!empty($props['form_name']) ? ': ' . $props['form_name'] : '');
                $value = $event['revenue'] !== null && (float)$event['revenue'] > 0 ? Format::money((float)$event['revenue'], (string)($event['currency'] ?: 'EUR')) : '';
                $steps[] = [$relative($event['timestamp']), Format::CONVERSION_KINDS[Format::conversion_kind($type)][1], $label, $path !== '' ? 'Auf ' . $path : '', $value, 'conv'];
                continue;
            }

            switch ($event['event_type']) {
                case 'pageview':
                    $sub = [];
                    if ((int)($props['status'] ?? 0) === 404) {
                        $sub[] = 'Seite nicht gefunden';
                    }
                    if (!empty($props['search'])) {
                        $sub[] = 'Suche: ' . $props['search'];
                    }
                    if ($event['engaged_seconds'] !== null && (int)$event['engaged_seconds'] > 0) {
                        $sub[] = Format::duration((int)$event['engaged_seconds']) . ' aktiv';
                    }
                    if ($event['scroll_depth'] !== null && (int)$event['scroll_depth'] > 0) {
                        $sub[] = (int)$event['scroll_depth'] . ' % gescrollt';
                    }
                    if ($first_page) {
                        $steps[] = [$relative($event['timestamp']), 'sign-in', 'Einstieg auf ' . $path, implode(', ', array_merge([$origin], $sub)), '', 'entry'];
                        $first_page = false;
                    } else {
                        $steps[] = [$relative($event['timestamp']), 'file', $path, implode(', ', $sub), '', 'page'];
                    }
                    $last_path = $path;
                    break;
                case 'outbound':
                    $steps[] = [$relative($event['timestamp']), 'arrow-square-out', 'Link nach außen: ' . (string)wp_parse_url((string)($props['url'] ?? ''), PHP_URL_HOST), 'Auf ' . $path, '', 'event'];
                    break;
                case 'download':
                    $steps[] = [$relative($event['timestamp']), 'download-simple', 'Download: ' . basename((string)($props['file'] ?? '')), 'Auf ' . $path, '', 'event'];
                    break;
                case 'contact':
                    $labels = ['tel' => 'Telefonnummer', 'mailto' => 'E-Mail-Adresse', 'whatsapp' => 'WhatsApp'];
                    $steps[] = [$relative($event['timestamp']), 'phone', 'Klick auf ' . ($labels[$props['type'] ?? ''] ?? 'Kontakt'), 'Auf ' . $path, '', 'event'];
                    break;
                default:
                    $steps[] = [$relative($event['timestamp']), 'cursor-click', (string)$event['event_type'], $path !== '' ? 'Auf ' . $path : '', '', 'event'];
            }
        }

        $more = 0;
        if (count($steps) > 40) {
            $more = count($steps) - 40;
            $steps = array_slice($steps, 0, 40);
        }
        $pageviews = (int)$visit['pageviews'];
        if ($pageviews > 0) {
            $steps[] = [
                self::visit_duration($visit) !== '–' ? $relative((string)$visit['last_seen_at']) : '',
                'sign-out',
                $pageviews <= 1 ? 'Abgesprungen' : 'Ende auf ' . ((string)$visit['exit_path'] !== '' ? $visit['exit_path'] : $last_path),
                $pageviews <= 1 ? 'Nur diese eine Seite' : '',
                '',
                'end',
            ];
        }

        $html = '<ol class="awp-steps">';
        foreach ($steps as [$time, $icon, $label, $sub, $value, $kind]) {
            $html .= '<li class="awp-step is-' . $kind . '"><span class="awp-step-time">' . esc_html($time) . '</span>'
                . '<span class="awp-step-node">' . Icons::svg($icon) . '</span>'
                . '<span class="awp-step-text"><span class="awp-step-label">' . esc_html($label) . '</span>' . ($sub !== '' ? '<span class="awp-step-sub">' . esc_html($sub) . '</span>' : '') . '</span>'
                . '<span class="awp-step-value">' . esc_html($value) . '</span></li>';
        }
        if ($more > 0) {
            $html .= '<li class="awp-step is-more"><span class="awp-step-time"></span><span class="awp-step-node"></span><span class="awp-step-text"><span class="awp-step-sub">' . esc_html('… ' . $more . ' weitere Schritte') . '</span></span><span></span></li>';
        }

        return $html . '</ol>';
    }

    /**
     * Everything one visitor did (a daily hash, or a logged-in user across
     * days), visit by visit, with the same steps as the list.
     */
    private static function journey_detail(string $visitor, int $user_id): void
    {
        $journey = Reports::journey($visitor, $user_id);
        $back = Ui::link(App::url(['visitor' => null, 'user' => null]), 'Alle Besuche');

        if ($user_id > 0) {
            $user = get_userdata($user_id);
            $title = $user ? 'Journey von ' . $user->display_name : 'Journey von Nutzer ' . $user_id;
            $subtitle = 'Eingeloggt, deshalb über mehrere Tage. Neueste Besuche zuerst.';
        } else {
            $last = !empty($journey) ? $journey[count($journey) - 1]['session']['started_at'] : '';
            $title = 'Journey eines Besuchers';
            $subtitle = ($last !== '' ? 'Am ' . wp_date('j.n.Y', (int)strtotime($last . ' UTC')) . '. ' : '') . 'Ohne Einwilligung ist ein Besucher höchstens einen Tag lang erkennbar.';
        }

        App::page_head(['title' => $title, 'question' => $subtitle, 'period' => false]);
        echo '<p class="awp-back">' . $back . '</p>';

        if (empty($journey)) {
            echo Ui::info('Zu diesem Besucher gibt es keine Besuche (mehr).');
            return;
        }

        echo '<div class="awp-layout">';
        foreach ($journey as $entry) {
            $session = $entry['session'];
            $events = array_map(function ($event) {
                return $event + ['path' => null, 'engaged_seconds' => null, 'scroll_depth' => null];
            }, $entry['events']);
            $subtitle = Format::datetime((string)$session['started_at']) . ' · ' . Format::device((string)$session['device_type'])
                . ' · ' . Format::number($session['pageviews']) . ((int)$session['pageviews'] === 1 ? ' Seite' : ' Seiten')
                . (self::visit_duration($session) !== '–' ? ' · ' . self::visit_duration($session) : '');
            $detail = self::visit_detail($session);

            echo '<section class="awp-card awp-span-all"><header class="awp-card-head"><span class="awp-card-icon" style="color:' . esc_attr(Channels::css_var((string)$session['channel'])) . '">' . Icons::svg(Channels::icon((string)$session['channel'])) . '</span>'
                . '<div class="awp-card-heading"><h2 class="awp-card-title">' . esc_html(Format::channel((string)$session['channel']) . ($detail !== '' && $detail !== 'ohne Quelle' ? ' · ' . $detail : '')) . '</h2>'
                . '<p class="awp-card-sub">' . esc_html($subtitle) . '</p></div></header>'
                . '<div class="awp-card-body">' . self::visit_steps_html($session, $events) . '</div></section>';
        }
        echo '</div>';
    }
}
