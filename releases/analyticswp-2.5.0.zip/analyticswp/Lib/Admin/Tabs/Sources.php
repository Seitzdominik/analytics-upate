<?php

namespace AnalyticsWP\Lib\Admin\Tabs;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Channels;
use AnalyticsWP\Lib\Admin\Chart;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Icons;
use AnalyticsWP\Lib\Admin\Tab;
use AnalyticsWP\Lib\Admin\Ui;
use AnalyticsWP\Lib\Attribution;
use AnalyticsWP\Lib\Insights;
use AnalyticsWP\Lib\Reports;

/**
 * Tab "Quellen": where visitors come from. One insight line, five key
 * figures (visits, conversions and revenue choose what the donut counts),
 * the donut with the channel list, and cards for origin, campaigns, and
 * websites and AI assistants.
 */
class Sources extends Tab
{
    /** Key figures: metric => [label, format, higher is better, term, counts in the donut]. */
    const KPIS = [
        'sessions' => ['Besuche', 'number', true, 'sessions', true],
        'conversions' => ['Conversions', 'number', true, 'conversions', true],
        'conversion_rate' => ['Conv.-Rate', 'percent', true, 'conversion_rate', false],
        'revenue' => ['Umsatz', 'money', true, '', true],
        'bounce_rate' => ['Absprungrate', 'percent', false, 'bounce', false],
    ];

    public static function render(): void
    {
        $period = App::period();
        $filters = App::filters();
        $since = Reports::first_seen_day();
        $compare = $since === null || $since <= $period['prev_end'];

        App::page_head(['since' => $since]);
        $currency = Reports::main_currency($period);
        $totals = Reports::totals($period, $filters, $currency);
        $sessions = (float)$totals['current']['sessions'];

        // The donut always shows every channel; a channel filter marks one.
        $channel_filters = $filters;
        unset($channel_filters['channel']);
        $channels = Reports::breakdown('channel', $period, $channel_filters, $currency, 20);

        echo '<div class="awp-layout">';
        echo self::insight($channels, $sessions, $since, $period);
        self::mix($totals, $channels, $currency, $compare, $filters['channel'] ?? null);

        Ui::card_row([[
            'key' => 'origin',
            'title' => 'Herkunft',
            'tabs' => [
                'channel' => ['label' => 'Kanäle', 'col' => 'Kanal', 'heads' => self::VISIT_HEADS, 'show' => 6, 'rows' => self::breakdown_rows('channel', $period, $filters, $currency, $sessions), 'empty' => 'Noch keine Besuche in diesem Zeitraum.'],
                'source' => ['label' => 'Quellen', 'col' => 'Quelle / Art', 'heads' => self::VISIT_HEADS, 'show' => 6, 'rows' => self::breakdown_rows('source_medium', $period, $filters, $currency, $sessions, [], true), 'empty' => 'Noch keine Besuche in diesem Zeitraum.'],
                'referrer' => ['label' => 'Verweis-Domains', 'col' => 'Website', 'heads' => self::VISIT_HEADS, 'show' => 6, 'rows' => self::breakdown_rows('referrer', $period, $filters, $currency, $sessions, [], true, true), 'empty' => 'Noch keine Besuche über Links von anderen Websites.'],
            ],
        ]]);

        $half = function (string $col, string $dimension, string $empty, array $extra = []) use ($period, $filters, $currency, $sessions) {
            return ['col' => $col, 'heads' => self::VISIT_HEADS, 'cols' => self::VISIT_COLS_HALF, 'empty' => $empty,
                'rows' => self::breakdown_rows($dimension, $period, $filters, $currency, $sessions, $extra, empty($extra), true)];
        };
        Ui::card_row([
            [
                'key' => 'campaigns',
                'title' => 'Kampagnen',
                'tabs' => [
                    'campaign' => ['label' => 'Kampagne'] + $half('Kampagne', 'campaign', 'Noch keine Besuche über einen UTM-Link. Baue einen unter UTM-Links.'),
                    'content' => ['label' => 'Inhalt'] + $half('utm_content', 'content', 'Noch keine Links mit utm_content, z. B. für zwei Buttons im selben Newsletter.'),
                    'term' => ['label' => 'Begriff'] + $half('utm_term', 'term', 'Noch keine Links mit utm_term, meist das Suchwort einer Anzeige.'),
                ],
            ],
            [
                'key' => 'web',
                'title' => 'Websites und KI',
                'tabs' => [
                    'referral' => ['label' => 'Verweise'] + $half('Website', 'referrer', 'Noch keine Besuche über Links von anderen Websites.', ['channel' => Attribution::REFERRAL]),
                    'ai' => ['label' => 'KI-Assistenten'] + $half('Assistent', 'source', 'Noch keine Besuche aus ChatGPT, Perplexity, Claude oder anderen KI-Assistenten.', ['channel' => Attribution::AI]),
                    'social' => ['label' => 'Social Media'] + $half('Netzwerk', 'source', 'Noch keine Besuche aus sozialen Netzwerken.', ['channel' => Attribution::ORGANIC_SOCIAL]),
                ],
            ],
        ]);

        echo '</div>';
    }

    /**
     * The channel that brings more than its share of revenue (or
     * conversions), else the largest channel. Pending under MIN_VISITS.
     *
     * @param list<array<string, mixed>> $channels
     */
    private static function insight(array $channels, float $sessions, ?string $since, array $period): string
    {
        if ($sessions < Insights::MIN_VISITS) {
            return Ui::insight_line('pending', 'Erkenntnisse ab ' . Insights::MIN_VISITS . ' Besuchen.',
                'Bisher ' . Format::number($sessions) . ($sessions === 1.0 ? ' Besuch' : ' Besuche')
                . ($since !== null && $since >= $period['start'] ? ' seit dem ' . Format::day($since) : ' in diesem Zeitraum')
                . '. Woher sie kamen, siehst du schon unten.');
        }

        $revenue = Insights::value_gap($channels, 'revenue');
        $gap = $revenue ?? Insights::value_gap($channels, 'conversions');
        if ($gap !== null) {
            $more = $revenue !== null ? 'so viel Umsatz' : 'so viele Abschlüsse';
            return Ui::insight_line('good', $gap['text'], 'Kein anderer Kanal macht aus so wenigen Besuchen ' . $more . '.');
        }

        $largest = Insights::largest_channel($channels);

        return Ui::insight_line($largest['status'] === 'ok' ? 'good' : 'pending', 'Größter Kanal: ' . $largest['value'] . '.', $largest['detail']);
    }

    /**
     * Key figures and the donut. Visits, conversions and revenue choose
     * what the donut and the list next to it count (admin.js, `metric` in
     * the URL without JS); conversion rate and bounce rate only show.
     *
     * @param array{current: array<string, float|int>, previous: array<string, float|int>} $totals
     * @param list<array<string, mixed>> $channels
     */
    private static function mix(array $totals, array $channels, string $currency, bool $compare, ?string $active): void
    {
        $metric = isset($_GET['metric']) && is_string($_GET['metric']) ? sanitize_key($_GET['metric']) : 'sessions';
        if (empty(self::KPIS[$metric][4])) {
            $metric = 'sessions';
        }

        $tiles = [];
        foreach (self::KPIS as $key => [$label, $format, $higher_is_better, $term, $switch]) {
            $value = $totals['current'][$key] ?? 0;
            if (in_array($key, ['conversion_rate', 'bounce_rate'], true) && !Insights::rate_is_meaningful((int)$totals['current']['sessions'])) {
                $shown = 'Ausstehend';
                $delta = '<span class="awp-delta">ab ' . Insights::MIN_RATE_BASE . ' Besuchen</span>';
            } else {
                $shown = self::format_value($value, $format, $currency);
                $delta = $compare ? self::kpi_delta($value, $totals['previous'][$key] ?? 0, $higher_is_better) : '<span class="awp-delta">Noch kein Vergleich</span>';
            }
            $tiles[] = [
                'key' => $key,
                'label' => $label,
                'help' => $term !== '' ? Ui::TERMS[$term] : 'Summe der Käufe aus WooCommerce und SureCart in ' . $currency . '.',
                'value' => $shown,
                'delta' => $delta,
                'switch' => $switch,
            ];
        }

        echo '<section class="awp-card awp-span-all" aria-label="Kennzahlen und Kanäle" data-awp-donut-switch>';
        echo Ui::kpi_bar($tiles, $metric, 'data-awp-donut-metric');
        foreach (['sessions', 'conversions', 'revenue'] as $key) {
            echo '<div class="awp-mix2" data-awp-donut-view="' . esc_attr($key) . '" data-awp-hover="channels"' . ($key === $metric ? '' : ' hidden') . '>';
            echo Chart::donut($channels, $key, $currency);
            echo self::channel_list($channels, $key, $currency, $active);
            echo '</div>';
        }
        echo '</section>';
    }

    /**
     * The channels next to the donut, most first: colour, icon, value,
     * share. Hover joins row and segment; a click filters the page.
     *
     * @param list<array<string, mixed>> $channels
     */
    private static function channel_list(array $channels, string $metric, string $currency, ?string $active): string
    {
        [$label] = Chart::DONUT_METRICS[$metric];
        $rows = array_values(array_filter($channels, function ($row) use ($metric) {
            return (float)$row[$metric] > 0;
        }));
        usort($rows, function ($a, $b) use ($metric) {
            return (float)$b[$metric] <=> (float)$a[$metric] ?: strcmp((string)$a['value'], (string)$b['value']);
        });
        $total = array_sum(array_map(function ($row) use ($metric) {
            return (float)$row[$metric];
        }, $rows));

        if (empty($rows)) {
            $title = ['sessions' => 'Noch keine Besuche.', 'conversions' => 'Noch keine Conversions.', 'revenue' => 'Noch kein Umsatz.'][$metric];
            $text = $metric === 'sessions'
                ? 'Sobald jemand deine Website besucht, siehst du hier, aus welchem Kanal er kam.'
                : 'Sobald jemand kauft, ein Formular sendet oder anruft, siehst du hier, aus welchem Kanal es kam.';
            return '<div class="awp-mix2-list"><div class="awp-mix2-empty"><strong>' . esc_html($title) . '</strong><span>' . esc_html($text) . '</span></div></div>';
        }

        $html = '<div class="awp-mix2-list"><div class="awp-mix2-head"><span>Kanal</span><span>' . esc_html($label) . '</span><span>Anteil</span></div>';
        foreach ($rows as $row) {
            $channel = (string)$row['value'];
            $name = Format::channel($row['value']);
            $value = (float)$row[$metric];
            $on = $active !== null && $active === $channel;
            $url = App::url(['f_channel' => $on ? null : $channel]);
            $html .= '<a class="awp-mix2-row' . ($on ? ' is-on' : '') . '" href="' . esc_url($url) . '" data-awp-key="' . esc_attr($channel) . '"'
                . ' title="' . esc_attr($on ? 'Filter entfernen' : 'Nach „' . $name . '“ filtern') . '"' . ($on ? ' aria-current="true"' : '') . '>'
                . '<span class="awp-mix2-name"><span class="awp-mix2-dot" style="background:' . esc_attr(Channels::color($channel)) . '"></span>'
                . Icons::svg(Channels::icon($channel)) . '<span>' . esc_html($name) . '</span>' . ($on ? Icons::svg('check') : '') . '</span>'
                . '<span class="awp-mix2-value">' . esc_html($metric === 'revenue' ? Format::money($value, $currency, 0) : Format::number($value)) . '</span>'
                . '<span class="awp-mix2-share">' . esc_html(Format::percent($value / max(1, $total), 0)) . '</span></a>';
        }

        return $html . '</div>';
    }
}
