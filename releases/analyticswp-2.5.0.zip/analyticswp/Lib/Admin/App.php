<?php

namespace AnalyticsWP\Lib\Admin;

use AnalyticsWP\Lib\Reports;
use AnalyticsWP\Lib\SuperSimpleWP;
use AnalyticsWP\Lib\Validators;

/**
 * The admin app: one menu entry "Analytics" with its own sidebar, as in
 * Pixel Made Simple. Views are server-rendered; the period and filters live
 * in the URL, so every state can be bookmarked and shared.
 *
 * Upstream's journey screens are kept as hidden pages under their old slugs
 * (WooCommerce, EDD and form integrations link to them) and rendered inside
 * this frame.
 */
class App
{
    const SLUG = 'analyticswp';

    /**
     * Tab => [group, icon, title, question]. The icon is the same in the
     * sidebar and in the page head; the question stands under the title.
     */
    const TABS = [
        'overview' => ['Auswerten', 'squares-four', 'Übersicht', 'Wie deine Website gerade läuft'],
        'sources' => ['Auswerten', 'signpost', 'Quellen', 'Woher deine Besucher kommen'],
        'pages' => ['Auswerten', 'stack', 'Seiten', 'Was gelesen wird und wo Besuche enden'],
        'events' => ['Verhalten', 'cursor-click', 'Ereignisse', 'Was Besucher anklicken, herunterladen und suchen'],
        'journeys' => ['Verhalten', 'footprints', 'Journeys', 'Wie sich Besucher durch deine Website bewegen'],
        'live' => ['Verhalten', 'pulse', 'Live', 'Was gerade auf deiner Website passiert'],
        'conversions' => ['Ziele', 'target', 'Conversions', 'Wo aus Besuchen Anfragen und Käufe werden'],
        'utm' => ['Werkzeuge', 'link', 'UTM-Links', 'Links für Newsletter, Posts und Anzeigen, damit du in „Quellen“ siehst, was Besucher bringt'],
        'export' => ['Werkzeuge', 'sparkle', 'KI & Export', 'Zahlen an eine KI geben oder für Kunden exportieren'],
        'integrations' => ['System', 'plugs-connected', 'Integrationen', 'Welche Plugins Käufe, Formulare und Klicks an die Auswertung melden'],
        'settings' => ['System', 'sliders-horizontal', 'Einstellungen', 'Änderungen werden sofort gespeichert.'],
    ];

    /** Tools and system: title and one line, no filter, no period. */
    const SIMPLE_TABS = ['utm', 'export', 'integrations', 'settings'];

    /** Only for administrators. */
    const ADMIN_TABS = ['export', 'settings'];

    /** Slugs before 2.5.0 => tab now. Bookmarks are redirected. */
    const RENAMED_TABS = ['campaigns' => 'sources', 'engagement' => 'events'];

    /**
     * Upstream's journey pages. WooCommerce, EDD and form integrations
     * still link to them; they redirect to the journeys view.
     */
    const LEGACY_PAGES = ['Journeys', 'anonymous_journeys', 'user_journeys', 'event_id_journeys', 'conversion_journeys'];

    /** Parameters that make up the current view. */
    const STATE_PARAMS = ['tab', 'range', 'from', 'to', 'metric', 'dim', 'model', 'visitor', 'user', 'p', 'view', 'empty', 'ct', 'full'];

    /**
     * View parameters that belong to one tab and are dropped when switching
     * tabs. `ct` holds the open tab of each card ("pages.exit,sources.campaign"),
     * `full` the card whose ⤢ panel is open (Ui::tab_card()).
     */
    const VIEW_PARAMS = ['metric', 'dim', 'model', 'visitor', 'user', 'p', 'view', 'empty', 'ct', 'full'];

    /**
     * Settings a switch may save on its own (Ui::toggle(), admin.js), with
     * the values each accepts. Anything not listed here is refused.
     */
    const AUTOSAVE_SETTINGS = [
        'engagement_tracking' => ['', '1'],
        'contact_clicks_as_conversion' => ['', '1'],
        'multi_day_with_consent' => ['', '1'],
        'link_logged_in_users' => ['', '1'],
        'delete_data_on_uninstall' => ['', '1'],
        'enable_woocommerce_order_notification_source_section' => ['', '1'],
        'retention_months' => ['6', '13', '25', '38', '0'],
        'ai_access' => ['', '1'],
        'fast_endpoint' => ['', '1'],
        // Rules instead of a list: checked in ajax_save_setting().
        'value_per_form' => 'amount',
        'value_per_contact' => 'amount',
        'how_did_you_hear' => 'wc_position',
        'form_value' => 'amount_by_key',
        'exclude_role' => 'role',
        'access_role' => 'role',
        'funnel_paths' => 'paths',
    ];

    const AUTOSAVE_NONCE = 'analyticswp_autosave';

    /** @var array<string, string> */
    private static $hooks = [];

    public static function init(): void
    {
        add_action('admin_menu', [self::class, 'register_menu']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue']);
        add_action('admin_post_analyticswp_integration', [Tabs\Integrations::class, 'handle_integration_toggle']);
        add_action('admin_init', [self::class, 'redirect_legacy_pages']);
        add_action('wp_ajax_analyticswp_save_setting', [self::class, 'ajax_save_setting']);
        add_action('wp_ajax_analyticswp_view', [self::class, 'ajax_view']);
        add_filter('pre_update_option_analyticswp_value_per_form', [self::class, 'sanitize_amount_option']);
        add_filter('pre_update_option_analyticswp_value_per_contact', [self::class, 'sanitize_amount_option']);
        add_filter('pre_update_option_analyticswp_form_values', [self::class, 'sanitize_amounts_option']);
    }

    /**
     * Save one setting from a switch. Administrators only, with nonce, and
     * only the settings and values in AUTOSAVE_SETTINGS. Answers with the
     * privacy policy text, which follows the settings.
     */
    public static function ajax_save_setting(): void
    {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung.'], 403);
        }
        if (!check_ajax_referer(self::AUTOSAVE_NONCE, 'nonce', false)) {
            wp_send_json_error(['message' => 'Die Seite ist abgelaufen. Lade sie neu.'], 403);
        }

        $setting = isset($_POST['setting']) && is_string($_POST['setting']) ? sanitize_key(wp_unslash($_POST['setting'])) : '';
        $value = isset($_POST['value']) && is_string($_POST['value']) ? sanitize_text_field(wp_unslash($_POST['value'])) : '';
        $key = isset($_POST['key']) && is_string($_POST['key']) ? sanitize_text_field(wp_unslash($_POST['key'])) : '';
        $rule = self::AUTOSAVE_SETTINGS[$setting] ?? null;
        $refuse = function () {
            wp_send_json_error(['message' => 'Diese Einstellung lässt sich so nicht speichern.'], 400);
        };

        if (is_array($rule)) {
            if (!in_array($value, $rule, true)) {
                $refuse();
            }
            update_option('analyticswp_' . $setting, $value);
        } elseif ($rule === 'amount') {
            $amount = \AnalyticsWP\Lib\ConversionValue::sanitize($value);
            if ($amount === null) {
                wp_send_json_error(['message' => 'Bitte einen Betrag eingeben, z. B. 50 oder 49,90.'], 400);
            }
            update_option('analyticswp_' . $setting, $amount);
        } elseif ($rule === 'amount_by_key') {
            $amount = \AnalyticsWP\Lib\ConversionValue::sanitize($value);
            if ($amount === null) {
                wp_send_json_error(['message' => 'Bitte einen Betrag eingeben, z. B. 50 oder 49,90.'], 400);
            }
            if (!preg_match('/^[a-z0-9_-]{1,40}\|.{0,120}$/', $key)) {
                $refuse();
            }
            $values = \AnalyticsWP\Lib\ConversionValue::form_values();
            if ($amount === '') {
                unset($values[$key]);
            } elseif (count($values) < \AnalyticsWP\Lib\ConversionValue::MAX_FORMS || isset($values[$key])) {
                $values[$key] = $amount;
            }
            update_option('analyticswp_form_values', $values);
        } elseif ($rule === 'paths') {
            // "/termin/, /angebot/": up to 20 paths of this site.
            $paths = [];
            foreach (preg_split('/[\s,]+/', $value) as $path) {
                $path = \AnalyticsWP\Lib\URLs::path_of($path);
                if (is_string($path) && $path !== '' && strlen($path) <= 191) {
                    $paths[] = $path;
                }
            }
            update_option('analyticswp_' . $setting, implode(', ', array_slice(array_unique($paths), 0, 20)));
        } elseif ($rule === 'wc_position') {
            $positions = class_exists('WooCommerce') ? \AnalyticsWP\Lib\Integrations\WooCommerceIntegration::get_wc_field_positions() : [];
            if ($value !== 'disable' && !isset($positions[$value])) {
                $refuse();
            }
            update_option('analyticswp_how_did_you_hear', $value);
        } elseif ($rule === 'role') {
            $roles = wp_roles()->get_names();
            if (!isset($roles[$key]) || !in_array($value, ['', '1'], true)) {
                $refuse();
            }
            $option = $setting === 'exclude_role' ? 'analyticswp_disabled-tracking-user-roles' : 'analyticswp_admin-access-user-roles';
            $current = Validators::array_of_string_keys_and_values(get_option($option, $setting === 'access_role' ? ['administrator' => '1'] : []));
            if ($value === '1') {
                $current[$key] = '1';
            } elseif ($setting !== 'access_role' || $key !== 'administrator') {
                unset($current[$key]);
            }
            update_option($option, $current);
        } else {
            $refuse();
        }

        wp_send_json_success([
            'policy' => \AnalyticsWP\Lib\Privacy::policy_text(),
        ]);
    }

    /**
     * Amounts that arrive through the settings form (without JS) are
     * stored the same way as through autosave: per form, as a list.
     *
     * @param mixed $value
     * @return array<string, string>
     */
    public static function sanitize_amounts_option($value): array
    {
        $out = [];
        foreach (is_array($value) ? $value : [] as $key => $amount) {
            $amount = is_string($amount) ? \AnalyticsWP\Lib\ConversionValue::sanitize($amount) : null;
            if (is_string($key) && $amount !== null && $amount !== '' && count($out) < \AnalyticsWP\Lib\ConversionValue::MAX_FORMS) {
                $out[sanitize_text_field($key)] = $amount;
            }
        }

        return $out;
    }

    /**
     * The same for a single amount.
     *
     * @param mixed $value
     */
    public static function sanitize_amount_option($value)
    {
        $amount = is_string($value) ? \AnalyticsWP\Lib\ConversionValue::sanitize($value) : null;

        return $amount ?? '';
    }

    /**
     * After activation, once: open the app. Not for WP-CLI and bulk
     * activation; the transient is set in the activation hook.
     */
    public static function redirect_after_activation(): void
    {
        if ((defined('WP_CLI') && WP_CLI) || isset($_GET['activate-multi']) || !get_transient('analyticswp_redirect_to_welcome_page')) {
            return;
        }
        delete_transient('analyticswp_redirect_to_welcome_page');
        if (!get_option('analyticswp_dont_redirect_to_homescreen_after_install') && self::can_view()) {
            wp_safe_redirect(admin_url('admin.php?page=' . self::SLUG));
            exit;
        }
    }

    /**
     * Send upstream's journey URLs to the journeys view.
     */
    public static function redirect_legacy_pages(): void
    {
        $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';

        // Renamed tabs: the same view under the new slug.
        $tab = isset($_GET['tab']) && is_string($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : '';
        if ($page === self::SLUG && isset(self::RENAMED_TABS[$tab]) && self::can_view()) {
            wp_safe_redirect(self::url(['tab' => self::RENAMED_TABS[$tab]]));
            exit;
        }

        // Before 2.5.0 the journeys list had its own chips (`only`).
        $only = ['conv' => 'converted', 'multi' => 'multi'][isset($_GET['only']) && is_string($_GET['only']) ? $_GET['only'] : ''] ?? null;
        if ($page === self::SLUG && $tab === 'journeys' && $only !== null && self::can_view()) {
            wp_safe_redirect(self::url(['f_result' => $only]));
            exit;
        }

        // Before 2.5.0 a page had a detail panel (`sel`); now the page filter.
        if ($page === self::SLUG && $tab === 'pages' && isset($_GET['sel']) && is_string($_GET['sel']) && $_GET['sel'] !== '' && self::can_view()) {
            wp_safe_redirect(self::url(['f_page' => sanitize_text_field(wp_unslash($_GET['sel'])), 'view' => null]));
            exit;
        }

        if (!in_array($page, self::LEGACY_PAGES, true) || !self::can_view()) {
            return;
        }

        $args = ['page' => self::SLUG, 'tab' => 'journeys'];
        if (!empty($_GET['unique_session_id'])) {
            $args['visitor'] = sanitize_text_field(wp_unslash($_GET['unique_session_id']));
        } elseif (!empty($_GET['user_id'])) {
            $args['user'] = (string)absint($_GET['user_id']);
        } elseif (!empty($_GET['event_id'])) {
            $event = \AnalyticsWP\Lib\Event::find(absint($_GET['event_id']));
            if (is_array($event)) {
                if (!empty($event['user_id'])) {
                    $args['user'] = (string)(int)$event['user_id'];
                } else {
                    $args['visitor'] = (string)$event['unique_session_id'];
                }
            }
        } elseif ($page === 'conversion_journeys') {
            $args['tab'] = 'conversions';
        }

        wp_safe_redirect(add_query_arg(array_map('rawurlencode', $args), admin_url('admin.php')));
        exit;
    }

    /**
     * Roles allowed to see the screens (setting "admin-access-user-roles";
     * administrators always).
     */
    public static function can_view(): bool
    {
        $allowed_roles = Validators::array_of_string_keys_and_values(SuperSimpleWP::get_setting('analyticswp', 'admin-access-user-roles'));

        return current_user_can('manage_options') || SuperSimpleWP::does_current_user_have_admin_access($allowed_roles);
    }

    public static function register_menu(): void
    {
        if (!self::can_view()) {
            return;
        }

        self::$hooks[] = (string)add_menu_page(
            'Analytics',
            'Analytics',
            'read',
            self::SLUG,
            [self::class, 'render'],
            'dashicons-chart-area',
            3
        );

    }

    /**
     * @param string $hook_suffix
     */
    public static function enqueue($hook_suffix): void
    {
        if (!in_array($hook_suffix, self::$hooks, true)) {
            return;
        }

        $dir = dirname(__DIR__, 2);
        $base = plugin_dir_url($dir . '/analyticswp.php');
        // The file time in the version: a changed file is fetched again even
        // while ANALYTICSWP_VERSION stays the same (development builds).
        $version = function (string $file) use ($dir) {
            return ANALYTICSWP_VERSION . '.' . (string)@filemtime($dir . '/' . $file);
        };
        wp_enqueue_style('analyticswp-admin', $base . 'assets/admin.css', [], $version('assets/admin.css'));
        wp_add_inline_style('analyticswp-admin', Channels::css_tokens());
        wp_enqueue_script('analyticswp-admin', $base . 'assets/admin.js', [], $version('assets/admin.js'), ['in_footer' => true, 'strategy' => 'defer']);
        wp_add_inline_script('analyticswp-admin', 'var analyticswpAdmin = ' . wp_json_encode([
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => current_user_can('manage_options') ? wp_create_nonce(self::AUTOSAVE_NONCE) : '',
        ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';', 'before');
    }

    public static function current_tab(): string
    {
        $tab = isset($_GET['tab']) && is_string($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'overview';
        $tab = self::RENAMED_TABS[$tab] ?? $tab;

        return isset(self::TABS[$tab]) && (!in_array($tab, self::ADMIN_TABS, true) || current_user_can('manage_options')) ? $tab : 'overview';
    }

    /**
     * URL of the app with the current view's state, changed by $args
     * (null removes a parameter). Filters (f_*) are kept unless $args sets
     * them; pass ['f_*' => null] to drop them all.
     *
     * @param array<string, string|null> $args
     */
    public static function url(array $args = []): string
    {
        $query = ['page' => self::SLUG];

        foreach (self::STATE_PARAMS as $param) {
            if (isset($_GET[$param]) && is_string($_GET[$param]) && $_GET[$param] !== '') {
                $query[$param] = sanitize_text_field(wp_unslash($_GET[$param]));
            }
        }

        // The ⤢ panel stays open only where a link asks for it.
        unset($query['full']);

        $drop_filters = array_key_exists('f_*', $args);
        unset($args['f_*']);
        if (!$drop_filters) {
            foreach (Reports::filters_from($_GET) as $key => $value) {
                $query['f_' . $key] = $value;
            }
        }

        foreach ($args as $key => $value) {
            if ($value === null) {
                unset($query[$key]);
            } else {
                $query[$key] = $value;
            }
        }

        return add_query_arg(array_map('rawurlencode', $query), admin_url('admin.php'));
    }

    public static function render(): void
    {
        if (!self::can_view()) {
            echo '<div class="wrap"><h1>Analytics</h1><p>Deine Benutzerrolle hat keinen Zugriff auf diese Seite.</p></div>';
            return;
        }

        $tab = self::current_tab();
        Icons::start_sprite();
        self::render_frame($tab, function () use ($tab) {
            self::render_tab($tab);
        });
        echo Icons::sprite();
    }

    /**
     * The app without the WordPress admin around it, for admin.js: a click
     * inside the app swaps the frame instead of loading the whole admin
     * page again. Same checks and the same output as render(); read only.
     */
    public static function ajax_view(): void
    {
        if (!self::can_view()) {
            status_header(403);
            exit;
        }

        // Forms take their referer from the request (wp_referer_field()):
        // it must be the app's address, not admin-ajax.php.
        $query = wp_unslash($_GET);
        unset($query['action']);
        $_SERVER['REQUEST_URI'] = (string)wp_parse_url(admin_url('admin.php'), PHP_URL_PATH) . '?' . http_build_query($query);

        $tab = self::current_tab();
        Icons::start_sprite();
        ob_start();
        self::render_frame($tab, function () use ($tab) {
            self::render_tab($tab);
        });
        $html = (string)ob_get_clean() . Icons::sprite();

        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('X-Robots-Tag: noindex');
        echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped while rendering
        exit;
    }

    public static function render_tab(string $tab): void
    {
        switch ($tab) {
            case 'sources':
                Tabs\Sources::render();
                break;
            case 'pages':
                Tabs\Pages::render();
                break;
            case 'events':
                Tabs\Events::render();
                break;
            case 'conversions':
                Tabs\Conversions::render();
                break;
            case 'live':
                Tabs\Live::render();
                break;
            case 'journeys':
                Tabs\Journeys::render();
                break;
            case 'utm':
                Tabs\Utm::render();
                break;
            case 'integrations':
                Tabs\Integrations::render();
                break;
            case 'settings':
                Tabs\Settings::render();
                break;
            case 'export':
                ExportTab::render();
                break;
            default:
                Tabs\Overview::render();
        }
    }

    /**
     * The frame: sidebar and main column.
     */
    public static function render_frame(string $active, callable $content): void
    {
        echo '<div class="awp-app">';
        echo '<aside class="awp-side">';
        echo '<div class="awp-brand"><span class="awp-brand-mark">' . Icons::svg('chart-bar') . '</span><span>'
            . '<span class="awp-brand-name">Analytics</span>'
            . '<span class="awp-brand-meta">Cookielos · Version ' . esc_html(ANALYTICSWP_VERSION) . '</span></span></div>';

        echo '<nav class="awp-nav" aria-label="Analytics">';
        $group = '';
        foreach (self::TABS as $tab => [$tab_group, $icon, $title]) {
            if (in_array($tab, self::ADMIN_TABS, true) && !current_user_can('manage_options')) {
                continue;
            }
            if ($tab_group !== $group) {
                if ($group !== '') {
                    echo '</ul>';
                }
                echo '<p class="awp-nav-group">' . esc_html($tab_group) . '</p><ul class="awp-nav-list">';
                $group = $tab_group;
            }
            $is_active = $tab === $active;
            // Switching tabs keeps the period and filters, not the tab's own
            // view (metric, dimension). Tools and system pages have neither.
            $url = in_array($tab, self::SIMPLE_TABS, true)
                ? self::url(['tab' => $tab, 'range' => null, 'from' => null, 'to' => null, 'f_*' => null] + array_fill_keys(self::VIEW_PARAMS, null))
                : self::url(['tab' => $tab === 'overview' ? null : $tab] + array_fill_keys(self::VIEW_PARAMS, null));
            $badge = $tab === 'pages' ? self::not_found_badge() : '';
            echo '<li><a class="awp-nav-item' . ($is_active ? ' is-active' : '') . '" href="' . esc_url($url) . '"' . ($is_active ? ' aria-current="page"' : '') . '>'
                . Icons::svg($icon) . '<span class="awp-nav-label">' . esc_html($title) . '</span>' . $badge . '</a></li>';
        }
        echo '</ul></nav>';

        echo '<div class="awp-side-foot">Ohne Cookies, ohne IP-Adressen. Besucher werden höchstens einen Tag lang wiedererkannt.</div>';
        echo '</aside>';

        // WordPress moves admin notices of other plugins behind .wp-header-end
        // (common.js), so they land in this column instead of above the app.
        $simple = in_array($active, self::SIMPLE_TABS, true);
        echo '<main class="awp-main' . ($simple ? ' awp-main--simple' : '') . '"><hr class="wp-header-end">';
        $content();
        echo '</main></div>';
    }

    /**
     * Amber count at "Seiten" while pages of the period were not found.
     */
    private static function not_found_badge(): string
    {
        $count = (int)(Reports::engagement_totals(self::period(), self::filters())['not_found'] ?? 0);
        if ($count < 1) {
            return '';
        }
        $label = $count === 1 ? '1 Aufruf einer nicht gefundenen Seite' : Format::number($count) . ' Aufrufe nicht gefundener Seiten';

        return '<span class="awp-nav-badge" title="' . esc_attr($label) . '"><span aria-hidden="true">' . esc_html($count > 99 ? '99+' : Format::number($count)) . '</span><span class="awp-sr">, ' . esc_html($label) . '</span></span>';
    }

    /**
     * Page head of the current tab: icon tile, title and its question; on
     * the right the live pill, an option of the page, and the period. Under
     * it the period in words and the active filters as chips.
     *
     * Tools and system pages (SIMPLE_TABS) only get title and line.
     *
     * @param array{title?: string, question?: string, option?: string, live?: bool, period?: bool, since?: string|null} $args
     *        option: HTML of a dropdown (Conversions: "Zählen für"); live: the
     *        update time instead of pill and period; period: false for a
     *        view without period (a single journey); since: first day of
     *        measurement, read from the data when not given.
     */
    public static function page_head(array $args = []): void
    {
        $tab = self::current_tab();
        [, $icon, $title, $question] = self::TABS[$tab];
        $title = $args['title'] ?? $title;
        $question = $args['question'] ?? $question;

        if (in_array($tab, self::SIMPLE_TABS, true)) {
            echo '<header class="awp-head awp-head--simple"><div><h1 class="awp-title">' . esc_html($title) . '</h1>'
                . '<p class="awp-question">' . esc_html($question) . '</p></div></header>';
            return;
        }

        $live = !empty($args['live']);
        $with_period = ($args['period'] ?? true) && !$live;

        echo '<header class="awp-head"><div class="awp-head-title"><span class="awp-head-icon">' . Icons::svg($icon) . '</span>'
            . '<div><h1 class="awp-title">' . esc_html($title) . '</h1><p class="awp-question">' . esc_html($question) . '</p></div></div>';
        echo '<div class="awp-head-tools">';
        if ($live) {
            // "Aktualisiert vor x Sek." counts up in admin.js; without JS the time.
            echo '<span class="awp-updated"><span class="awp-live-dot" aria-hidden="true"></span><span data-awp-updated="' . esc_attr((string)time()) . '">Aktualisiert um ' . esc_html(wp_date('H:i:s')) . ' Uhr</span></span>';
        } elseif ($with_period) {
            self::live_pill();
        }
        if (!empty($args['option'])) {
            echo $args['option']; // phpcs:ignore WordPress.Security.EscapeOutput -- built by the tab, escaped there
        }
        if ($with_period) {
            FilterDialog::render();
            self::period_selector();
        }
        echo '</div></header>';

        if ($live) {
            // Live counts every visit right now; filters do not apply yet.
            self::chip_row('Letzte 30 Minuten, aktualisiert sich alle 30 Sekunden', false);
        } elseif ($with_period) {
            $since = array_key_exists('since', $args) ? $args['since'] : Reports::first_seen_day();
            self::chip_row(self::range_text(self::period(), $since));
        }
    }

    /**
     * "21.9.–20.10.2026 im Vergleich zu den 30 Tagen davor". Before there
     * is a period to compare with: "Seit Messbeginn am 27.10.2026 · noch
     * kein Vergleichszeitraum".
     *
     * @param array{start: string, end: string, prev_start: string, prev_end: string, days: int} $period
     */
    public static function range_text(array $period, ?string $since): string
    {
        if ($since !== null && $since > $period['prev_end'] && $since <= $period['end']) {
            return 'Seit Messbeginn am ' . Format::day(max($since, $period['start']), true) . ' · noch kein Vergleichszeitraum';
        }

        if ($period['days'] === 1) {
            $range = Format::day($period['start'], true);
            $compare = ' im Vergleich zum Tag davor';
        } else {
            $range = self::range_label($period);
            $compare = ' im Vergleich zu den ' . $period['days'] . ' Tagen davor';
        }
        if ($since !== null && $since > $period['prev_start'] && $since <= $period['prev_end']) {
            $compare .= ' (gemessen ab ' . Format::day($since) . ')';
        }

        return $range . $compare;
    }

    /**
     * "21.9.–20.10.2026", one day "28.10.2026".
     *
     * @param array{start: string, end: string, days: int} $period
     */
    public static function range_label(array $period): string
    {
        if ($period['days'] === 1) {
            return Format::day($period['start'], true);
        }

        return Format::day($period['start'], substr($period['start'], 0, 4) !== substr($period['end'], 0, 4)) . '–' . Format::day($period['end'], true);
    }

    /**
     * The card tab whose ⤢ panel is open ("pages.exit"), or ''.
     */
    public static function requested_full(): string
    {
        $full = isset($_GET['full']) && is_string($_GET['full']) ? sanitize_text_field(wp_unslash($_GET['full'])) : '';

        return preg_match('/^[a-z0-9_-]+\.[a-z0-9_-]+$/', $full) ? $full : '';
    }

    /**
     * "● 3 online", a link to the live view. Grey dot at 0, petrol with a
     * pulse from 1.
     */
    private static function live_pill(): void
    {
        $count = Reports::online_count();
        $label = $count === 1 ? '1 Besucher gerade online, Live öffnen' : Format::number($count) . ' Besucher gerade online, Live öffnen';

        echo '<a class="awp-live-pill' . ($count > 0 ? ' is-active' : '') . '" href="' . esc_url(self::url(['tab' => 'live', 'f_*' => null] + array_fill_keys(self::VIEW_PARAMS, null))) . '" aria-label="' . esc_attr($label) . '" title="In den letzten 5 Minuten aktiv">'
            . '<span class="awp-live-dot" aria-hidden="true"></span>'
            . '<span><strong>' . esc_html(Format::number($count)) . '</strong> online</span></a>';
    }

    /**
     * @return array{key: string, start: string, end: string, prev_start: string, prev_end: string, days: int, hourly: bool}
     */
    public static function period(): array
    {
        $range = isset($_GET['range']) ? sanitize_key(wp_unslash($_GET['range'])) : '30d';
        $from = isset($_GET['from']) ? sanitize_text_field(wp_unslash($_GET['from'])) : '';
        $to = isset($_GET['to']) ? sanitize_text_field(wp_unslash($_GET['to'])) : '';

        return Reports::period($range, $from, $to);
    }

    /**
     * @return array<string, string>
     */
    public static function filters(): array
    {
        return Reports::filters_from($_GET);
    }

    /** Period presets of the dropdown, in this order. */
    const PERIODS = [
        'today' => 'Heute',
        'yesterday' => 'Gestern',
        '7d' => 'Letzte 7 Tage',
        '30d' => 'Letzte 30 Tage',
        '90d' => 'Letzte 90 Tage',
        'month' => 'Dieser Monat',
        'last_month' => 'Letzter Monat',
        '12m' => 'Letzte 12 Monate',
    ];

    /** Length in days of the presets that end today, for › back to them. */
    const ROLLING = [1 => 'today', 7 => '7d', 30 => '30d', 90 => '90d', 365 => '12m'];

    /**
     * Period dropdown between ‹ and ›: the period before and after of the
     * same length; whole months step by month. › is greyed while the period
     * reaches today.
     */
    private static function period_selector(): void
    {
        $period = self::period();
        $label = self::PERIODS[$period['key']] ?? self::range_label($period);

        echo '<div class="awp-period">';
        $prev = self::shifted_period($period, -1);
        echo '<a class="awp-period-step" href="' . esc_url(self::url($prev)) . '" aria-label="Vorheriger Zeitraum" title="Vorheriger Zeitraum">' . Icons::svg('caret-left') . '</a>';

        echo '<details class="awp-period-menu"><summary>' . Icons::svg('calendar-blank') . '<span>' . esc_html($label) . '</span>' . Icons::svg('caret-down') . '</summary><div class="awp-period-panel">';
        foreach (self::PERIODS as $key => $text) {
            $is = $period['key'] === $key;
            echo '<a href="' . esc_url(self::url(['range' => $key, 'from' => null, 'to' => null])) . '"' . ($is ? ' class="is-active" aria-current="true"' : '') . '>' . esc_html($text) . ($is ? Icons::svg('check') : '') . '</a>';
        }

        // Custom range: a GET form that carries the current state along.
        echo '<form method="get" action="' . esc_url(admin_url('admin.php')) . '">';
        echo '<input type="hidden" name="page" value="' . esc_attr(self::SLUG) . '"><input type="hidden" name="range" value="custom">';
        foreach (array_merge(['tab', 'metric', 'dim', 'model', 'ct'], array_map(function ($k) {
            return 'f_' . $k;
        }, Reports::filter_keys())) as $param) {
            if (isset($_GET[$param]) && is_string($_GET[$param]) && $_GET[$param] !== '') {
                echo '<input type="hidden" name="' . esc_attr($param) . '" value="' . esc_attr(sanitize_text_field(wp_unslash($_GET[$param]))) . '">';
            }
        }
        echo '<label>Von<input type="date" name="from" value="' . esc_attr($period['start']) . '" max="' . esc_attr(wp_date('Y-m-d')) . '"></label>';
        echo '<label>Bis<input type="date" name="to" value="' . esc_attr($period['end']) . '" max="' . esc_attr(wp_date('Y-m-d')) . '"></label>';
        echo '<button type="submit" class="button">Zeitraum anzeigen</button></form>';
        echo '</div></details>';

        if ($period['end'] >= wp_date('Y-m-d')) {
            echo '<span class="awp-period-step is-disabled" aria-disabled="true" title="Der Zeitraum reicht bis heute">' . Icons::svg('caret-right') . '<span class="awp-sr">Nächster Zeitraum</span></span>';
        } else {
            echo '<a class="awp-period-step" href="' . esc_url(self::url(self::shifted_period($period, 1))) . '" aria-label="Nächster Zeitraum" title="Nächster Zeitraum">' . Icons::svg('caret-right') . '</a>';
        }
        echo '</div>';
    }

    /**
     * URL arguments of the period one step before (-1) or after (1). A
     * step that reaches today lands on the matching preset again.
     *
     * @param array{key: string, start: string, end: string, days: int} $period
     * @return array<string, string|null>
     */
    public static function shifted_period(array $period, int $step): array
    {
        $tz = wp_timezone();
        $today = new \DateTimeImmutable('today', $tz);
        $start = new \DateTimeImmutable($period['start'], $tz);
        $end = new \DateTimeImmutable($period['end'], $tz);

        // A whole month, or this month so far: step by calendar month.
        $is_month = $start->format('j') === '1' && $start->format('Y-m') === $end->format('Y-m')
            && ($end->format('Y-m-d') === $start->format('Y-m-t') || $end == $today);
        if ($is_month) {
            $start = $start->modify(($step < 0 ? '-1' : '+1') . ' month');
            $end = new \DateTimeImmutable($start->format('Y-m-t'), $tz);
            if ($start->format('Y-m') === $today->format('Y-m')) {
                return ['range' => 'month', 'from' => null, 'to' => null];
            }
            if ($start->format('Y-m') === $today->modify('first day of last month')->format('Y-m')) {
                return ['range' => 'last_month', 'from' => null, 'to' => null];
            }
        } else {
            $days = (int)$period['days'];
            $start = $start->modify(($step * $days > 0 ? '+' : '') . ($step * $days) . ' days');
            $end = $end->modify(($step * $days > 0 ? '+' : '') . ($step * $days) . ' days');
            if ($end >= $today) {
                if (isset(self::ROLLING[$days])) {
                    return ['range' => self::ROLLING[$days], 'from' => null, 'to' => null];
                }
                $end = $today;
            }
        }

        return ['range' => 'custom', 'from' => $start->format('Y-m-d'), 'to' => $end->format('Y-m-d')];
    }

    /** Filter name in the chips: "Kanal: E-Mail". */
    const FILTER_NAMES = [
        'channel' => 'Kanal',
        'source' => 'Quelle',
        'medium' => 'Medium',
        'campaign' => 'Kampagne',
        'term' => 'Begriff',
        'content' => 'Inhalt',
        'landing' => 'Einstieg',
        'referrer' => 'Verweis',
        'device' => 'Gerät',
        'page' => 'Seite',
        'result' => 'Ergebnis',
    ];

    /**
     * Period in words, then the active filters as chips with ×, then
     * "Alle entfernen". Each × removes its filter. Where the page cannot
     * apply the filters, each chip says so instead of showing numbers that
     * only look filtered.
     */
    private static function chip_row(string $range, bool $applies = true): void
    {
        echo '<div class="awp-chiprow"><span class="awp-range">' . esc_html($range) . '</span>';
        $filters = self::filters();
        foreach ($filters as $key => $value) {
            $label = (self::FILTER_NAMES[$key] ?? $key) . ': ' . Ui::dimension_label($key, $value === Reports::NONE ? null : $value);
            echo '<span class="awp-chip' . ($applies ? '' : ' is-inactive') . '">' . esc_html($label)
                . ($applies ? '' : '<span class="awp-chip-note">gilt hier nicht</span>')
                . '<a class="awp-chip-x" href="' . esc_url(self::url(['f_' . $key => null])) . '" aria-label="' . esc_attr('Filter ' . $label . ' entfernen') . '" title="Filter entfernen">' . Icons::svg('x') . '</a></span>';
        }
        if (!empty($filters)) {
            echo '<a class="awp-chips-clear" href="' . esc_url(self::url(['f_*' => null])) . '">Alle entfernen</a>';
        }
        echo '</div>';
    }

    /**
     * The open tab of a card: from `ct` ("pages.exit,sources.campaign"),
     * else the first.
     *
     * @param list<string> $tabs
     */
    public static function card_tab(string $card, array $tabs): string
    {
        $state = isset($_GET['ct']) && is_string($_GET['ct']) ? sanitize_text_field(wp_unslash($_GET['ct'])) : '';
        foreach (explode(',', $state) as $pair) {
            [$key, $tab] = array_pad(explode('.', $pair, 2), 2, '');
            if ($key === $card && in_array($tab, $tabs, true)) {
                return $tab;
            }
        }

        return $tabs[0] ?? '';
    }

    /**
     * `ct` with the tab of one card set (the first tab is not stored).
     */
    public static function card_tab_state(string $card, string $tab, bool $is_first): string
    {
        $state = isset($_GET['ct']) && is_string($_GET['ct']) ? sanitize_text_field(wp_unslash($_GET['ct'])) : '';
        $pairs = [];
        foreach (array_filter(explode(',', $state)) as $pair) {
            if (strpos($pair, $card . '.') !== 0 && preg_match('/^[a-z0-9_-]+\.[a-z0-9_-]+$/', $pair)) {
                $pairs[] = $pair;
            }
        }
        if (!$is_first) {
            $pairs[] = $card . '.' . $tab;
        }

        return implode(',', $pairs);
    }
}
