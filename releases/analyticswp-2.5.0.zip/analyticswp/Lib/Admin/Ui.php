<?php

namespace AnalyticsWP\Lib\Admin;

use AnalyticsWP\Lib\Insights;
use AnalyticsWP\Lib\Reports;

/**
 * Building blocks of the admin screens, after Pixel Made Simple's
 * PXMS_Admin_UI: cards with head and foot, key figure tiles, tables whose
 * rows filter the page, hints, switches, term tooltips. All output is
 * escaped here.
 */
class Ui
{
    /** Explanations of technical terms, for Ui::term(). One wording everywhere. */
    const TERMS = [
        'visitors' => 'Verschiedene Menschen im Zeitraum. Ohne Einwilligung wird ein Besucher höchstens einen Tag lang wiedererkannt.',
        'sessions' => 'Ein Besuch endet nach 30 Minuten ohne neuen Seitenaufruf.',
        'bounce' => 'Besuche mit nur einer Seite, ohne Abschluss und unter 10 Sekunden aktiv.',
        'conversion_rate' => 'Anteil der Besuche mit mindestens einem Abschluss.',
        'conversions' => 'Abschlüsse: Käufe, Formular-Anfragen und, wenn eingestellt, Klicks auf Telefon, E-Mail oder WhatsApp.',
        'duration' => 'Zeit vom ersten bis zum letzten Seitenaufruf eines Besuchs.',
        'engaged' => 'Zeit, in der die Seite sichtbar war und benutzt wurde, je Seitenaufruf. Nicht dasselbe wie die Besuchsdauer.',
        'pageviews' => 'Jedes Laden einer Seite, auch mehrmals im selben Besuch.',
    ];

    /**
     * Open a card. $actions is HTML for the right of the head (already
     * escaped by the caller), as is $subtitle with $subtitle_is_html.
     */
    public static function card_open(string $icon, string $title, string $subtitle = '', string $actions = '', string $class = '', bool $subtitle_is_html = false): void
    {
        echo '<section class="awp-card ' . esc_attr($class) . '">';
        echo '<header class="awp-card-head">';
        if ($icon !== '') {
            echo '<span class="awp-card-icon">' . Icons::svg($icon) . '</span>';
        }
        echo '<div class="awp-card-heading"><h2 class="awp-card-title">' . esc_html($title) . '</h2>';
        if ($subtitle !== '') {
            echo '<p class="awp-card-sub">' . ($subtitle_is_html ? $subtitle : esc_html($subtitle)) . '</p>';
        }
        echo '</div>';
        if ($actions !== '') {
            echo '<div class="awp-card-actions">' . $actions . '</div>';
        }
        echo '</header>';
    }

    /**
     * Close a card, with an optional foot (HTML, escaped by the caller).
     */
    public static function card_close(string $foot = ''): void
    {
        if ($foot !== '') {
            echo '<footer class="awp-card-foot">' . $foot . '</footer>';
        }
        echo '</section>';
    }

    public static function info(string $text, string $icon = 'info'): string
    {
        return '<div class="awp-info">' . Icons::svg($icon) . '<div>' . esc_html($text) . '</div></div>';
    }

    public static function empty_state(string $text): string
    {
        return '<p class="awp-empty">' . esc_html($text) . '</p>';
    }

    /**
     * A link to another view, with caret.
     */
    public static function link(string $url, string $text): string
    {
        return '<a class="awp-linkline" href="' . esc_url($url) . '">' . esc_html($text) . Icons::svg('caret-right') . '</a>';
    }

    /**
     * A technical term with its explanation: dotted underline, the
     * explanation on hover and keyboard focus (admin.js). Without JS the
     * browser shows the title.
     */
    public static function term(string $label, string $help): string
    {
        return '<span class="awp-term" tabindex="0" title="' . esc_attr($help) . '">' . esc_html($label) . '</span>';
    }

    /**
     * A rate, or "zu wenig" while fewer than Insights::MIN_RATE_BASE visits
     * stand behind it: 1 of 2 visits converting is no 50 % rate.
     *
     * @param float|int $rate 0..1
     */
    public static function rate($rate, int $base, int $decimals = 1): string
    {
        if (!Insights::rate_is_meaningful($base)) {
            return '<span class="awp-few" tabindex="0" title="Unter ' . Insights::MIN_RATE_BASE . ' Besuchen ist eine Rate nicht aussagekräftig">zu wenig</span>';
        }

        return esc_html(Format::percent($rate, $decimals));
    }

    /**
     * An on/off switch (44 × 26), as a native checkbox with role="switch":
     * it posts with its form as before, and with JS it saves on change
     * (data-awp-autosave, see App::ajax_save_setting()).
     *
     * @param array{description?: string, disabled?: bool, autosave?: bool, warning?: string} $options warning: amber line while on
     */
    public static function toggle(string $setting, bool $checked, string $label, array $options = []): string
    {
        $id = 'awp-sw-' . sanitize_html_class($setting);
        $autosave = ($options['autosave'] ?? true) && isset(App::AUTOSAVE_SETTINGS[$setting]);

        $html = '<div class="awp-field awp-switch-field"><div class="awp-switch-text">'
            . '<label for="' . esc_attr($id) . '" class="awp-switch-label">' . esc_html($label) . '</label>';
        if (!empty($options['description'])) {
            $html .= '<p class="awp-field-desc">' . esc_html($options['description']) . '</p>';
        }
        if (!empty($options['warning'])) {
            // Amber line at the decision, shown while the switch is on.
            $html .= '<p class="awp-warnline" data-awp-when-on' . ($checked ? '' : ' hidden') . '><span class="awp-warn-dot" aria-hidden="true"></span><span>' . esc_html($options['warning']) . '</span></p>';
        }
        $html .= '</div><input type="checkbox" class="awp-switch" role="switch" id="' . esc_attr($id) . '" name="analyticswp_' . esc_attr($setting) . '" value="1"'
            . checked($checked, true, false)
            . (!empty($options['disabled']) ? ' disabled' : '')
            . ($autosave ? ' data-awp-autosave="' . esc_attr($setting) . '"' : '')
            . '></div>';

        return $html;
    }

    /**
     * Change badge: "+12,3 %" with an arrow, petrol when the change is an
     * improvement, amber when it is not. The direction is in the text too.
     */
    public static function change(?float $change, bool $higher_is_better = true): string
    {
        if ($change === null) {
            return '<span class="awp-change">–<span class="awp-sr"> kein Vergleichswert</span></span>';
        }

        $rounded = round($change * 100, 1);
        if ($rounded == 0.0) {
            return '<span class="awp-change">± 0 %</span>';
        }

        $up = $rounded > 0;
        $good = $up === $higher_is_better;
        $text = ($up ? '▲ +' : '▼ ') . number_format($rounded, 1, ',', '.') . ' %';

        return '<span class="awp-change ' . ($good ? 'is-good' : 'is-bad') . '" title="im Vergleich zum Zeitraum davor">'
            . esc_html($text) . '<span class="awp-sr"> zum Zeitraum davor</span></span>';
    }

    /**
     * Label of a breakdown value.
     */
    public static function dimension_label(string $dimension, ?string $value): string
    {
        if ($dimension === 'source_medium') {
            [$source, $medium] = array_pad(explode("\x1f", (string)$value, 2), 2, '');
            if ($source === '' && $medium === '') {
                return 'Direkt (ohne Quelle)';
            }
            return ($source !== '' ? $source : '(keine Quelle)') . ' / ' . ($medium !== '' ? $medium : '(kein Medium)');
        }

        if ($value === null) {
            switch ($dimension) {
                case 'campaign':
                    return '(keine Kampagne)';
                case 'referrer':
                    return '(kein Verweis)';
                case 'source':
                    return '(keine Quelle)';
                case 'medium':
                    return '(kein Medium)';
                default:
                    return '(nicht gesetzt)';
            }
        }

        switch ($dimension) {
            case 'channel':
                return Format::channel($value);
            case 'device':
                return Format::device($value);
            case 'landing':
            case 'exit':
            case 'page':
                return Format::path($value);
            case 'result':
                return Reports::RESULT_LABELS[$value] ?? $value;
            default:
                return $value;
        }
    }

    /**
     * Filter parameters that select a breakdown value, or [] when the
     * dimension cannot be filtered on.
     *
     * @return array<string, string>
     */
    public static function dimension_filter(string $dimension, ?string $value): array
    {
        if ($dimension === 'source_medium') {
            [$source, $medium] = array_pad(explode("\x1f", (string)$value, 2), 2, '');
            return [
                'f_source' => $source !== '' ? $source : Reports::NONE,
                'f_medium' => $medium !== '' ? $medium : Reports::NONE,
            ];
        }

        if (!in_array($dimension, Reports::filter_keys(), true)) {
            return [];
        }

        return ['f_' . $dimension => $value === null ? Reports::NONE : $value];
    }

    /**
     * A breakdown as table: label with a bar for its share of sessions,
     * then sessions, conversions, conversion rate and revenue.
     *
     * @param list<array{value: string|null, sessions: int, visitors: int, bounce_rate: float, conversions: int, conversion_rate: float, revenue: float}> $rows
     * @param array{revenue?: bool, bounce?: bool, visitors?: bool} $columns
     */
    public static function breakdown_table(string $dimension, string $label, array $rows, string $currency, array $columns = []): string
    {
        if (empty($rows)) {
            return self::empty_state('Für diesen Zeitraum gibt es noch keine Daten.');
        }

        $show_revenue = $columns['revenue'] ?? true;
        $show_bounce = $columns['bounce'] ?? false;
        $show_visitors = $columns['visitors'] ?? false;
        $max = max(array_column($rows, 'sessions')) ?: 1;

        $is_channel = $dimension === 'channel';

        $html = '<table class="awp-table" data-awp-hover="' . esc_attr($dimension) . '"><thead><tr>';
        $html .= '<th scope="col">' . esc_html($label) . '</th>';
        if ($show_visitors) {
            $html .= '<th scope="col" class="is-optional">' . self::term('Besucher', self::TERMS['visitors']) . '</th>';
        }
        $html .= '<th scope="col">' . self::term('Besuche', self::TERMS['sessions']) . '</th>';
        if ($show_bounce) {
            $html .= '<th scope="col" class="is-optional">' . self::term('Absprung', self::TERMS['bounce']) . '</th>';
        }
        $html .= '<th scope="col">Conv.</th>';
        $html .= '<th scope="col" class="is-optional">' . self::term('Conv.-Rate', self::TERMS['conversion_rate']) . '</th>';
        if ($show_revenue) {
            $html .= '<th scope="col">Umsatz</th>';
        }
        $html .= '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $text = self::dimension_label($dimension, $row['value']);
            $filter = self::dimension_filter($dimension, $row['value']);
            $width = max(1.5, round($row['sessions'] / $max * 100, 1));
            $bar = Channels::bar_color($is_channel ? (string)$row['value'] : null);

            $label_html = $filter
                ? '<a href="' . esc_url(App::url($filter)) . '" title="Nach „' . esc_attr($text) . '“ filtern">' . esc_html($text) . '</a>'
                : esc_html($text);
            if ($row['value'] === null) {
                $label_html = '<span class="awp-none">' . $label_html . '</span>';
            }
            if ($is_channel) {
                $label_html = Channels::icon_html((string)$row['value']) . $label_html;
            }

            $html .= '<tr data-awp-key="' . esc_attr((string)$row['value']) . '"><td class="awp-cell-label"><span class="awp-cell-bar" style="width:calc(' . $width . '% - 14px);background:' . esc_attr($bar) . '"></span>'
                . '<span class="awp-cell-text">' . $label_html . '</span></td>';
            if ($show_visitors) {
                $html .= '<td class="is-optional">' . esc_html(Format::number($row['visitors'])) . '</td>';
            }
            $html .= '<td>' . esc_html(Format::number($row['sessions'])) . '</td>';
            if ($show_bounce) {
                $html .= '<td class="is-optional">' . self::rate($row['bounce_rate'], (int)$row['sessions'], 0) . '</td>';
            }
            $html .= '<td>' . esc_html(Format::number($row['conversions'])) . '</td>';
            $html .= '<td class="is-optional">' . self::rate($row['conversion_rate'], (int)$row['sessions']) . '</td>';
            if ($show_revenue) {
                $html .= '<td>' . ($row['revenue'] > 0 ? esc_html(Format::money($row['revenue'], $currency, 0)) : '<span class="awp-none">–</span>') . '</td>';
            }
            $html .= '</tr>';
        }

        return $html . '</tbody></table>';
    }

    /**
     * Pills to switch a card between dimensions, as links.
     *
     * @param array<string, string> $options value => label
     */
    public static function pills(string $param, array $options, string $active): string
    {
        $html = '<nav class="awp-pills" aria-label="Ansicht">';
        foreach ($options as $value => $text) {
            $is = $value === $active;
            $html .= '<a href="' . esc_url(App::url([$param => $value])) . '"' . ($is ? ' class="is-active" aria-current="true"' : '') . '>' . esc_html($text) . '</a>';
        }

        return $html . '</nav>';
    }

    /**
     * Sort report rows by a key; null values (and rates over too few
     * visits, passed as null) last.
     *
     * @param list<array<string, mixed>> $rows
     * @param callable(array<string, mixed>): (int|float|null) $value
     * @return list<array<string, mixed>>
     */
    public static function sort_rows(array $rows, callable $value, string $dir): array
    {
        // Stable on PHP 7 too (usort is stable only from PHP 8): equal
        // values keep the order they came in, so a table does not reshuffle.
        $keyed = [];
        foreach (array_values($rows) as $i => $row) {
            $keyed[] = [$i, $value($row), $row];
        }
        usort($keyed, function ($a, $b) use ($dir) {
            [$i, $x] = $a;
            [$j, $y] = $b;
            if ($x === null || $y === null) {
                $order = $x === $y ? 0 : ($x === null ? 1 : -1);
            } else {
                $order = $dir === 'asc' ? $x <=> $y : $y <=> $x;
            }
            return $order ?: $i <=> $j;
        });

        return array_column($keyed, 2);
    }

    /**
     * The one finding of a page, in one line: petrol sparkle for a finding,
     * amber dot and title for a problem, grey ring while it is pending. An
     * optional action on the right, usually a filter.
     *
     * @param 'good'|'bad'|'pending' $tone
     */
    public static function insight_line(string $tone, string $title, string $text = '', string $action_url = '', string $action_label = '', string $icon = ''): string
    {
        if ($icon !== '') {
            $mark = Icons::svg($icon);
        } else {
            $mark = $tone === 'good' ? Icons::svg('sparkle') : '<span class="awp-insight-mark" aria-hidden="true"></span>';
        }
        $sr = ['good' => 'Erkenntnis: ', 'bad' => 'Problem: ', 'pending' => 'Ausstehend: '][$tone] ?? '';

        return '<div class="awp-insight-line is-' . esc_attr($tone) . ($icon !== '' ? ' has-icon' : '') . '">' . $mark
            . '<p><span class="awp-sr">' . esc_html($sr) . '</span><strong>' . esc_html($title) . '</strong>' . ($text !== '' ? ' <span>' . esc_html($text) . '</span>' : '') . '</p>'
            . ($action_url !== '' ? '<a class="awp-insight-action" href="' . esc_url($action_url) . '">' . esc_html($action_label) . Icons::svg('caret-right') . '</a>' : '')
            . '</div>';
    }

    /**
     * Key figure tiles side by side, the change as a pill. Tiles with
     * `switch` choose what the chart (or donut) below counts: buttons with
     * $attr="key", the chosen one underlined. The others only show.
     *
     * @param list<array{key: string, label: string, help?: string, value: string, delta: string, switch?: bool}> $tiles delta: HTML (Tab::kpi_delta())
     */
    public static function kpi_bar(array $tiles, string $active = '', string $attr = 'data-awp-metric'): string
    {
        $switches = count(array_filter($tiles, function ($tile) {
            return !empty($tile['switch']);
        }));
        $html = '<div class="awp-kpis"' . ($switches ? ' role="tablist" aria-label="Was das Diagramm zählt"' : '') . ' style="--awp-kpi-count:' . count($tiles) . '">';
        foreach ($tiles as $tile) {
            $label = !empty($tile['help']) ? self::term($tile['label'], $tile['help']) : esc_html($tile['label']);
            $inner = '<span class="awp-kpi-label">' . $label . '</span><span class="awp-kpi-value">' . esc_html($tile['value']) . '</span>' . $tile['delta'];
            if (!empty($tile['switch'])) {
                $html .= '<button type="button" class="awp-kpi" role="tab" ' . $attr . '="' . esc_attr($tile['key']) . '" aria-selected="' . ($tile['key'] === $active ? 'true' : 'false') . '">' . $inner . '</button>';
            } else {
                $html .= '<div class="awp-kpi is-static">' . $inner . '</div>';
            }
        }

        return $html . '</div>';
    }

    /** Rows of a card; the ⤢ panel shows up to DRAWER_ROWS. */
    const CARD_ROWS = 8;
    const DRAWER_ROWS = 500;

    /**
     * Cards side by side, equally high: one card takes the full width.
     *
     * @param list<array<string, mixed>> $cards See tab_card().
     */
    public static function card_row(array $cards): void
    {
        echo '<div class="awp-card-row' . (count($cards) === 1 ? ' is-single' : '') . '">';
        foreach ($cards as $card) {
            self::tab_card($card + ['wide' => count($cards) === 1]);
        }
        echo '</div>';
    }

    /**
     * A card with tabs: what it lists is chosen in the card (underlined
     * tabs, kept in `ct`), at most CARD_ROWS rows with a bar behind the
     * label and 1–5 numbers. A row with a link sets a filter for the whole
     * page. ⤢ opens the panel with all entries and all columns of the open
     * tab (`full`, admin.js loads it in place).
     *
     * Only the rows of the tabs are computed, through their callbacks; the
     * panel asks for more rows than the card.
     *
     * @param array{key: string, title: string, badge?: string, wide?: bool, tabs: array<string, array{label: string, col: string, heads: list<string>, show?: int, cols?: list<int>, rows: callable(int): list<array<string, mixed>>, empty?: string}>} $card
     *        heads: all columns (the panel shows them all); the card shows
     *        `cols` (indexes) or the first `show` (default 5).
     *        Row: label, meta (grey, optional), icon (name or icon_html),
     *        value (length of the bar), url (filter link, optional), warn
     *        (HTML after the label, optional), cells: list of
     *        [HTML, sort value], one per head.
     */
    public static function tab_card(array $card): void
    {
        $key = $card['key'];
        $tabs = $card['tabs'];
        // Keys as strings: PHP turns a key like '404' into an integer.
        $keys = array_map('strval', array_keys($tabs));
        $active = App::card_tab($key, $keys);
        $id = 'awp-c-' . $key;

        echo '<section class="awp-tcard' . (!empty($card['wide']) ? ' is-wide' : '') . '" aria-labelledby="' . esc_attr($id) . '-t" data-awp-tcard>';
        echo '<header class="awp-tcard-head"><h2 class="awp-tcard-title" id="' . esc_attr($id) . '-t">' . esc_html($card['title'])
            . (!empty($card['badge']) ? '<span class="awp-count-badge">' . esc_html($card['badge']) . '</span>' : '') . '</h2>'
            . '<a class="awp-expand" href="' . esc_url(App::url(['full' => $key . '.' . $active])) . '" data-awp-full aria-label="' . esc_attr($card['title'] . ': alle anzeigen') . '" title="Alle anzeigen">' . Icons::svg('arrows-out-simple') . '</a></header>';

        echo '<div class="awp-ctabs" role="tablist" aria-label="' . esc_attr($card['title']) . '">';
        foreach ($tabs as $tab => $info) {
            $tab = (string)$tab;
            $on = $tab === $active;
            echo '<a class="awp-ctab" role="tab" id="' . esc_attr($id . '-tab-' . $tab) . '" aria-controls="' . esc_attr($id . '-p-' . $tab) . '" aria-selected="' . ($on ? 'true' : 'false') . '"'
                . ' tabindex="' . ($on ? '0' : '-1') . '" data-awp-ctab="' . esc_attr($key . '.' . $tab) . '" data-awp-full-href="' . esc_url(App::url(['full' => $key . '.' . $tab])) . '"'
                . ' href="' . esc_url(App::url(['ct' => App::card_tab_state($key, $tab, $tab === $keys[0])])) . '">' . esc_html($info['label']) . '</a>';
        }
        echo '</div>';

        foreach ($tabs as $tab => $info) {
            $rows = ($info['rows'])(self::CARD_ROWS);
            echo '<div class="awp-cpanel" role="tabpanel" id="' . esc_attr($id . '-p-' . $tab) . '" aria-labelledby="' . esc_attr($id . '-tab-' . $tab) . '"' . ((string)$tab === $active ? '' : ' hidden') . '>';
            echo empty($rows)
                ? '<p class="awp-tempty">' . esc_html($info['empty'] ?? 'In diesem Zeitraum noch nichts.') . '</p>'
                : self::rows_table($info, array_slice($rows, 0, self::CARD_ROWS), $info['cols'] ?? range(0, min(count($info['heads']), $info['show'] ?? 5) - 1), false);
            echo '</div>';
        }
        echo '</section>';

        $full = App::requested_full();
        if ($full !== '' && strpos($full, $key . '.') === 0 && isset($tabs[substr($full, strlen($key) + 1)])) {
            $tab = substr($full, strlen($key) + 1);
            self::drawer($card['title'] . ' · ' . $tabs[$tab]['label'], $tabs[$tab]);
        }
    }

    /**
     * The ⤢ panel: all entries and all columns of one tab, sortable and
     * searchable with JS. Without JS a page of its own over the view, with a
     * link back.
     *
     * @param array{label: string, col: string, heads: list<string>, rows: callable(int): list<array<string, mixed>>, empty?: string} $tab
     */
    private static function drawer(string $title, array $tab): void
    {
        $rows = ($tab['rows'])(self::DRAWER_ROWS);
        $close = App::url();

        echo '<div class="awp-drawer" data-awp-drawer>';
        echo '<a class="awp-drawer-backdrop" href="' . esc_url($close) . '" tabindex="-1" aria-hidden="true" data-awp-drawer-close></a>';
        echo '<aside class="awp-drawer-panel" role="dialog" aria-modal="true" aria-labelledby="awp-drawer-title" style="--awp-tcols:' . count($tab['heads']) . '">';
        echo '<header class="awp-drawer-head"><div><h2 id="awp-drawer-title">' . esc_html($title) . '</h2>'
            . '<p>Alle Einträge · ' . esc_html(App::range_label(App::period())) . (count($rows) >= self::DRAWER_ROWS ? ' · die ersten ' . self::DRAWER_ROWS : '') . '</p></div>'
            . '<a class="awp-drawer-close" href="' . esc_url($close) . '" aria-label="Schließen" data-awp-drawer-close>' . Icons::svg('x') . '</a></header>';
        if (count($rows) > self::CARD_ROWS) {
            echo '<label class="awp-drawer-search" hidden data-awp-drawer-search>' . Icons::svg('magnifying-glass')
                . '<input type="search" placeholder="' . esc_attr('In ' . Format::number(count($rows)) . ' Einträgen suchen') . '" aria-label="Einträge durchsuchen"></label>';
        }
        echo '<div class="awp-drawer-body">';
        echo empty($rows)
            ? '<p class="awp-tempty">' . esc_html($tab['empty'] ?? 'In diesem Zeitraum noch nichts.') . '</p>'
            : self::rows_table($tab, $rows, array_keys($tab['heads']), true);
        echo '</div></aside></div>';
    }

    /**
     * Rows of a card or of the panel. In the panel the heads sort (admin.js,
     * by the cells' data-v).
     *
     * @param array{col: string, heads: list<string>} $tab
     * @param list<array<string, mixed>> $rows
     * @param list<int> $columns Indexes into heads and cells, in this order.
     */
    private static function rows_table(array $tab, array $rows, array $columns, bool $sortable): string
    {
        $max = 0.0;
        foreach ($rows as $row) {
            $max = max($max, (float)($row['value'] ?? 0));
        }
        $max = $max > 0 ? $max : 1.0;

        $head = function (string $label, int $i, bool $first) use ($sortable) {
            $class = $first ? ' class="awp-tlabel"' : '';
            if (!$sortable) {
                return '<th scope="col"' . $class . '>' . esc_html($label) . '</th>';
            }
            return '<th scope="col"' . $class . ' aria-sort="none"><button type="button" data-awp-sort="' . $i . '" disabled>' . esc_html($label) . Icons::svg('caret-up-down') . '</button></th>';
        };

        $html = '<table class="awp-ttable' . ($sortable ? ' is-full' : '') . '" style="--awp-tcols:' . count($columns) . '"><thead><tr>' . $head($tab['col'], 0, true);
        foreach ($columns as $i => $column) {
            $html .= $head($tab['heads'][$column], $i + 1, false);
        }
        $html .= '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $label = (string)$row['label'];
            $icon = $row['icon_html'] ?? (!empty($row['icon']) ? Icons::svg((string)$row['icon']) : '');
            $text = !empty($row['url'])
                ? '<a class="awp-filter-link" href="' . esc_url((string)$row['url']) . '" title="' . esc_attr('Nach „' . $label . '“ filtern') . '">' . esc_html($label) . '</a>'
                : '<span class="awp-tname" title="' . esc_attr($label) . '">' . esc_html($label) . '</span>';
            $width = round(max(1.5, (float)($row['value'] ?? 0) / $max * 100), 1);

            $html .= '<tr><td class="awp-tlabel" data-v="' . esc_attr(strtolower($label . ' ' . ($row['meta'] ?? ''))) . '">'
                . '<span class="awp-tbar" style="width:' . $width . '%"></span><span class="awp-ttext">' . $icon . $text
                . (!empty($row['meta']) ? '<span class="awp-tmeta">' . esc_html((string)$row['meta']) . '</span>' : '')
                . ($row['warn'] ?? '')
                . (!empty($row['url']) ? Icons::svg('funnel') : '') . '</span></td>';
            foreach ($columns as $i => $column) {
                [$cell, $sort] = $row['cells'][$column];
                $html .= '<td' . ($i === 0 ? ' class="is-strong"' : '') . ' data-v="' . esc_attr((string)$sort) . '">' . $cell . '</td>';
            }
            $html .= '</tr>';
        }

        return $html . '</tbody></table>';
    }

    /**
     * Cells of a card row: a number, a share, a rate (or "zu wenig"), an
     * amount. Each [HTML, sort value]; rates over too few visits sort last.
     *
     * @return array{0: string, 1: float|int|string}
     */
    public static function cell_number($n): array
    {
        return [esc_html(Format::number($n)), (float)$n];
    }

    /** @return array{0: string, 1: float|string} */
    public static function cell_share(float $part, float $total): array
    {
        return $total > 0 ? [esc_html(Format::percent($part / $total)), $part / $total] : ['<span class="awp-none">–</span>', ''];
    }

    /** @return array{0: string, 1: float|string} */
    public static function cell_rate(float $rate, int $base): array
    {
        if (!Insights::rate_is_meaningful($base)) {
            return ['<span class="awp-few" title="Unter ' . Insights::MIN_RATE_BASE . ' nicht aussagekräftig">zu wenig</span>', ''];
        }

        return [esc_html(Format::percent($rate)), $rate];
    }

    /** @return array{0: string, 1: float} */
    public static function cell_money(float $amount, string $currency): array
    {
        return [$amount > 0 ? esc_html(Format::money($amount, $currency, 0)) : '<span class="awp-none">–</span>', $amount];
    }
}
