<?php

namespace AnalyticsWP\Lib;

/**
 * The numbers behind the dashboard.
 *
 * Everything counts sessions that started in the selected period (by their
 * local start day, Sessions::started_day). Page views, conversions and
 * revenue are reached through the session they belong to, so that one
 * filter (a channel, a campaign, a landing page) narrows every number on
 * the page the same way.
 *
 * "Visitors" are distinct daily visitor hashes. The hash changes every day
 * (Visitor), so over several days a returning person counts once per day.
 * Cookieless analytics cannot do better; the dashboard says so.
 *
 * SQL targets MySQL/MariaDB (TIMESTAMPDIFF, JSON_EXTRACT). WordPress
 * Playground's SQLite does not run all of it; test reports on MariaDB.
 *
 * @psalm-type Period = array{
 *   key: string,
 *   start: string,
 *   end: string,
 *   prev_start: string,
 *   prev_end: string,
 *   days: int,
 *   hourly: bool,
 * }
 */
class Reports
{
    /** Filter parameter => sessions column. */
    const FILTERS = [
        'channel' => 'channel',
        'source' => 'source',
        'medium' => 'medium',
        'campaign' => 'campaign',
        'term' => 'term',
        'content' => 'content',
        'landing' => 'landing_path',
        'referrer' => 'referrer_domain',
        'device' => 'device_type',
    ];

    /**
     * Filters that are not a column: `page` keeps visits that viewed the
     * page (path), `result` visits by outcome (RESULTS).
     */
    const SPECIAL_FILTERS = ['page', 'result'];

    /**
     * Values of the `result` filter => condition on sessions (%1$s = alias).
     * The last two are the colours of the journeys mosaic (its legend sets
     * them); the filter dialog offers DIALOG_RESULTS.
     */
    const RESULTS = [
        'converted' => '%1$s.conversions > 0',
        'not_converted' => '%1$s.conversions = 0',
        'multi' => '%1$s.pageviews > 1',
        'single' => '%1$s.pageviews <= 1',
        'browsed' => '(%1$s.pageviews > 1 AND %1$s.conversions = 0)',
        'bounced' => '(%1$s.pageviews <= 1 AND %1$s.conversions = 0)',
    ];

    const RESULT_LABELS = [
        'converted' => 'Mit Conversion',
        'not_converted' => 'Ohne Conversion',
        'multi' => 'Mehr als eine Seite',
        'single' => 'Nur eine Seite',
        'browsed' => 'Mehrere Seiten, ohne Conversion',
        'bounced' => 'Abgesprungen',
    ];

    const DIALOG_RESULTS = ['converted', 'not_converted', 'multi', 'single'];

    /** Value of a filter that matches sessions without the attribute. */
    const NONE = '(none)';

    /** Breakdown dimension => SQL expression on sessions `s`. */
    const DIMENSIONS = [
        'channel' => 's.channel',
        'source' => 's.source',
        'medium' => 's.medium',
        'source_medium' => "CONCAT(COALESCE(s.source, ''), '\x1f', COALESCE(s.medium, ''))",
        'campaign' => 's.campaign',
        'term' => 's.term',
        'content' => 's.content',
        'landing' => 's.landing_path',
        'exit' => 's.exit_path',
        'referrer' => 's.referrer_domain',
        'device' => 's.device_type',
    ];

    const RANGES = ['today', 'yesterday', '7d', '30d', '90d', 'month', 'last_month', '12m', 'custom'];

    /** Off in tests and measurements: every call queries the database. */
    public static $cache_enabled = true;

    /** Bumped by flush_cache(); part of every cache key. */
    const CACHE_GENERATION_OPTION = 'analyticswp_report_cache_generation';

    /**
     * Run a report through the cache. A period that ends before today
     * cannot change any more (apart from late engagement reports) and is
     * kept for 12 hours; one that includes today for two minutes. With a
     * persistent object cache the transients live there, otherwise in
     * wp_options (expired ones are removed by WordPress' daily cron).
     *
     * @template T
     * @param array<string, mixed> $period
     * @param array<mixed>         $key_parts
     * @param callable(): T        $compute
     * @return T
     */
    private static function remember(string $name, array $period, array $key_parts, callable $compute)
    {
        if (!self::$cache_enabled) {
            return $compute();
        }

        $generation = (int)get_option(self::CACHE_GENERATION_OPTION, 1);
        $key = 'awp_r_' . md5($name . '|' . $generation . '|' . wp_json_encode($period) . '|' . wp_json_encode($key_parts));

        $cached = get_transient($key);
        if ($cached !== false && is_array($cached) && array_key_exists('v', $cached)) {
            return $cached['v'];
        }

        $value = $compute();
        $finished = isset($period['end']) && $period['end'] < wp_date('Y-m-d');
        $long = isset($period['days']) && (int)$period['days'] >= 28;
        set_transient($key, ['v' => $value], $finished ? 12 * HOUR_IN_SECONDS : ($long ? 15 * MINUTE_IN_SECONDS : 2 * MINUTE_IN_SECONDS));

        return $value;
    }

    /**
     * Make every cached report stale (after deleting data, a migration).
     */
    public static function flush_cache(): void
    {
        update_option(self::CACHE_GENERATION_OPTION, (int)get_option(self::CACHE_GENERATION_OPTION, 1) + 1, false);
    }

    /**
     * The selected period and the one before it, as local days.
     *
     * @return Period
     */
    public static function period(string $key, string $from = '', string $to = ''): array
    {
        $tz = wp_timezone();
        $today = new \DateTimeImmutable('today', $tz);

        switch ($key) {
            case 'today':
                $start = $end = $today;
                break;
            case 'yesterday':
                $start = $end = $today->modify('-1 day');
                break;
            case '7d':
                $start = $today->modify('-6 days');
                $end = $today;
                break;
            case '90d':
                $start = $today->modify('-89 days');
                $end = $today;
                break;
            case 'month':
                $start = $today->modify('first day of this month');
                $end = $today;
                break;
            case 'last_month':
                $start = $today->modify('first day of last month');
                $end = $today->modify('last day of last month');
                break;
            case '12m':
                $start = $today->modify('-364 days');
                $end = $today;
                break;
            case 'custom':
                $start = self::parse_day($from, $tz) ?? $today->modify('-29 days');
                $end = self::parse_day($to, $tz) ?? $today;
                if ($end < $start) {
                    [$start, $end] = [$end, $start];
                }
                break;
            default:
                $key = '30d';
                $start = $today->modify('-29 days');
                $end = $today;
        }

        $days = (int)$start->diff($end)->days + 1;
        $prev_end = $start->modify('-1 day');
        $prev_start = $prev_end->modify('-' . ($days - 1) . ' days');

        return [
            'key' => $key,
            'start' => $start->format('Y-m-d'),
            'end' => $end->format('Y-m-d'),
            'prev_start' => $prev_start->format('Y-m-d'),
            'prev_end' => $prev_end->format('Y-m-d'),
            'days' => $days,
            'hourly' => $days === 1,
        ];
    }

    private static function parse_day(string $value, \DateTimeZone $tz): ?\DateTimeImmutable
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return null;
        }

        $day = \DateTimeImmutable::createFromFormat('!Y-m-d', $value, $tz);
        return $day instanceof \DateTimeImmutable ? $day : null;
    }

    /**
     * All filter keys: the session columns, then page and result.
     *
     * @return list<string>
     */
    public static function filter_keys(): array
    {
        return array_merge(array_keys(self::FILTERS), self::SPECIAL_FILTERS);
    }

    /**
     * Filters from request parameters (f_channel=..., f_campaign=...).
     * Unknown result values are dropped.
     *
     * @param array<string, mixed> $query
     * @return array<string, string>
     */
    public static function filters_from(array $query): array
    {
        $filters = [];
        foreach (self::filter_keys() as $key) {
            if (isset($query['f_' . $key]) && is_string($query['f_' . $key]) && $query['f_' . $key] !== '') {
                $value = sanitize_text_field(wp_unslash($query['f_' . $key]));
                if ($key === 'result' && !isset(self::RESULTS[$value])) {
                    continue;
                }
                $filters[$key] = substr($value, 0, 191);
            }
        }

        return $filters;
    }

    /**
     * WHERE clause on sessions `s` for a period and filters.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return string Prepared SQL, without the WHERE keyword.
     */
    private static function where(array $period, array $filters, bool $previous = false): string
    {
        return self::period_sql($period, $previous, 's') . self::filters_sql($filters, 's');
    }

    /**
     * @param Period $period
     */
    private static function period_sql(array $period, bool $previous, string $alias): string
    {
        global $wpdb;

        return (string)$wpdb->prepare(
            "$alias.started_day BETWEEN %s AND %s",
            $previous ? $period['prev_start'] : $period['start'],
            $previous ? $period['prev_end'] : $period['end']
        );
    }

    /**
     * " AND ..." for each filter on sessions with the given alias.
     *
     * @param array<string, string> $filters
     */
    private static function filters_sql(array $filters, string $alias): string
    {
        global $wpdb;

        $sql = '';
        foreach ($filters as $key => $value) {
            if ($key === 'page') {
                // Visits with a view of the page: per visit a look-up in
                // idx_session_id, a handful of rows each.
                $events = Event::table_name();
                $sql .= (string)$wpdb->prepare(
                    " AND EXISTS (SELECT 1 FROM `$events` fe WHERE fe.session_id = $alias.session_id AND fe.event_type = 'pageview' AND fe.path = %s)",
                    $value
                );
                continue;
            }
            if ($key === 'result') {
                if (isset(self::RESULTS[$value])) {
                    $sql .= ' AND ' . sprintf(self::RESULTS[$value], $alias);
                }
                continue;
            }
            if (!isset(self::FILTERS[$key])) {
                continue;
            }
            $column = $alias . '.' . self::FILTERS[$key];
            $sql .= $value === self::NONE
                ? " AND ($column IS NULL OR $column = '')"
                : (string)$wpdb->prepare(" AND $column = %s", $value);
        }

        return $sql;
    }

    /**
     * Cached; see main_currency_uncached().
     */
    public static function main_currency(array $period): string
    {
        return self::remember('main_currency', $period, [], function () use ($period) {
            return self::main_currency_uncached($period);
        });
    }

    /**
     * Currency that most conversions in the period were made in, or the
     * shop's currency, or EUR. Revenue is only summed in this one.
     *
     * @param Period $period
     */
    private static function main_currency_uncached(array $period): string
    {
        global $wpdb;
        $events = Event::table_name();
        $sessions = Sessions::table_name();

        $currency = $wpdb->get_var(
            "SELECT e.currency FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id
             WHERE " . self::where($period, []) . " AND e.conversion_type IS NOT NULL AND e.currency IS NOT NULL
             GROUP BY e.currency ORDER BY COUNT(*) DESC, e.currency LIMIT 1"
        );

        if (is_string($currency) && $currency !== '') {
            return $currency;
        }
        if (function_exists('get_woocommerce_currency')) {
            return (string)get_woocommerce_currency();
        }

        return 'EUR';
    }

    /**
     * Cached; see totals_uncached().
     */
    public static function totals(array $period, array $filters, string $currency): array
    {
        return self::remember('totals', $period, [$filters, $currency], function () use ($period, $filters, $currency) {
            return self::totals_uncached($period, $filters, $currency);
        });
    }

    /**
     * Key figures for the period and the one before it.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return array{current: array<string, float|int>, previous: array<string, float|int>, other_currencies: array<string, float>}
     */
    private static function totals_uncached(array $period, array $filters, string $currency): array
    {
        $current = self::totals_for(self::where($period, $filters), $currency);
        $previous = self::totals_for(self::where($period, $filters, true), $currency);

        return [
            'current' => $current,
            'previous' => $previous,
            'other_currencies' => self::other_currencies(self::where($period, $filters), $currency),
        ];
    }

    /**
     * @return array<string, float|int>
     */
    private static function totals_for(string $where, string $currency): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();

        $row = $wpdb->get_row(
            "SELECT COUNT(*) AS sessions,
                    COUNT(DISTINCT s.visitor_hash) AS visitors,
                    COALESCE(SUM(s.pageviews), 0) AS pageviews,
                    COALESCE(SUM(CASE WHEN s.pageviews <= 1 AND s.conversions = 0 AND s.engaged_seconds < 10 THEN 1 ELSE 0 END), 0) AS bounces,
                    COALESCE(SUM(CASE WHEN s.conversions > 0 THEN 1 ELSE 0 END), 0) AS converting,
                    COALESCE(SUM(s.conversions), 0) AS conversions,
                    COALESCE(SUM(CASE WHEN s.events > 1 OR s.engaged_seconds > 0 THEN TIMESTAMPDIFF(SECOND, s.started_at, s.last_seen_at) ELSE 0 END), 0) AS duration_sum,
                    COALESCE(SUM(CASE WHEN s.events > 1 OR s.engaged_seconds > 0 THEN 1 ELSE 0 END), 0) AS duration_n
             FROM `$sessions` s WHERE $where",
            'ARRAY_A'
        );

        $revenue = (float)$wpdb->get_var((string)$wpdb->prepare(
            "SELECT COALESCE(SUM(e.revenue), 0) FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id
             WHERE $where AND e.conversion_type IS NOT NULL AND e.currency = %s",
            $currency
        ));

        $row = is_array($row) ? $row : [];
        $sessions_count = (int)($row['sessions'] ?? 0);

        return [
            'visitors' => (int)($row['visitors'] ?? 0),
            'sessions' => $sessions_count,
            'pageviews' => (int)($row['pageviews'] ?? 0),
            'bounce_rate' => $sessions_count > 0 ? (int)$row['bounces'] / $sessions_count : 0.0,
            'duration' => (int)($row['duration_n'] ?? 0) > 0 ? (int)$row['duration_sum'] / (int)$row['duration_n'] : 0.0,
            'conversions' => (int)($row['conversions'] ?? 0),
            'conversion_rate' => $sessions_count > 0 ? (int)$row['converting'] / $sessions_count : 0.0,
            'revenue' => $revenue,
        ];
    }

    /**
     * Revenue in currencies other than the main one, so the page can say it
     * is not included.
     *
     * @return array<string, float>
     */
    private static function other_currencies(string $where, string $currency): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();

        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT e.currency, SUM(e.revenue) AS revenue FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id
             WHERE $where AND e.conversion_type IS NOT NULL AND e.currency IS NOT NULL AND e.currency <> %s
             GROUP BY e.currency",
            $currency
        ), 'ARRAY_A');

        $out = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            $out[(string)$row['currency']] = (float)$row['revenue'];
        }

        return $out;
    }

    /**
     * Cached; see timeseries_uncached().
     */
    public static function timeseries(array $period, array $filters, string $currency): array
    {
        return self::remember('timeseries', $period, [$filters, $currency], function () use ($period, $filters, $currency) {
            return self::timeseries_uncached($period, $filters, $currency);
        });
    }

    /**
     * Per day (or per hour for a single day): the series behind the chart,
     * with every bucket present.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return array{labels: list<string>, series: array<string, list<float|int>>, previous: array<string, list<float|int>>}
     */
    private static function timeseries_uncached(array $period, array $filters, string $currency): array
    {
        $buckets = self::buckets($period, false);
        $prev_buckets = self::buckets($period, true);

        return [
            'labels' => $buckets,
            'series' => self::series_for(self::where($period, $filters), $period['hourly'], $buckets, $currency),
            'previous' => self::series_for(self::where($period, $filters, true), $period['hourly'], $prev_buckets, $currency),
        ];
    }

    /**
     * @param Period $period
     * @return list<string> Y-m-d per day, or "H" per hour.
     */
    private static function buckets(array $period, bool $previous): array
    {
        if ($period['hourly']) {
            return array_map(function ($h) {
                return sprintf('%02d', $h);
            }, range(0, 23));
        }

        $out = [];
        $day = new \DateTimeImmutable($previous ? $period['prev_start'] : $period['start']);
        for ($i = 0; $i < $period['days']; $i++) {
            $out[] = $day->modify("+$i days")->format('Y-m-d');
        }

        return $out;
    }

    /**
     * @param list<string> $buckets
     * @return array<string, list<float|int>>
     */
    private static function series_for(string $where, bool $hourly, array $buckets, string $currency): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();

        // An hour of the site's day. The offset is today's; a single-day
        // view only straddles a daylight saving change twice a year.
        $offset = wp_timezone()->getOffset(new \DateTime('now', new \DateTimeZone('UTC')));
        $bucket_sql = $hourly
            ? (string)$wpdb->prepare("LPAD(HOUR(DATE_ADD(s.started_at, INTERVAL %d SECOND)), 2, '0')", $offset)
            : 's.started_day';

        $rows = $wpdb->get_results(
            "SELECT $bucket_sql AS bucket,
                    COUNT(*) AS sessions,
                    COUNT(DISTINCT s.visitor_hash) AS visitors,
                    COALESCE(SUM(s.pageviews), 0) AS pageviews,
                    COALESCE(SUM(s.conversions), 0) AS conversions,
                    COALESCE(SUM(CASE WHEN s.pageviews <= 1 AND s.conversions = 0 AND s.engaged_seconds < 10 THEN 1 ELSE 0 END), 0) AS bounces,
                    COALESCE(SUM(CASE WHEN s.events > 1 OR s.engaged_seconds > 0 THEN TIMESTAMPDIFF(SECOND, s.started_at, s.last_seen_at) ELSE 0 END), 0) AS duration_sum,
                    COALESCE(SUM(CASE WHEN s.events > 1 OR s.engaged_seconds > 0 THEN 1 ELSE 0 END), 0) AS duration_n,
                    COALESCE(SUM(CASE WHEN s.conversions > 0 THEN 1 ELSE 0 END), 0) AS converting
             FROM `$sessions` s WHERE $where GROUP BY bucket",
            'ARRAY_A'
        );

        $revenue_rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT $bucket_sql AS bucket, SUM(e.revenue) AS revenue FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id
             WHERE $where AND e.conversion_type IS NOT NULL AND e.currency = %s GROUP BY bucket",
            $currency
        ), 'ARRAY_A');

        $by_bucket = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            $by_bucket[(string)$row['bucket']] = $row;
        }
        $revenue = [];
        foreach (is_array($revenue_rows) ? $revenue_rows : [] as $row) {
            $revenue[(string)$row['bucket']] = (float)$row['revenue'];
        }

        $series = ['visitors' => [], 'sessions' => [], 'pageviews' => [], 'conversions' => [], 'bounce_rate' => [], 'duration' => [], 'conversion_rate' => [], 'revenue' => []];
        foreach ($buckets as $bucket) {
            $row = $by_bucket[$bucket] ?? null;
            $sessions_count = $row ? (int)$row['sessions'] : 0;
            $series['visitors'][] = $row ? (int)$row['visitors'] : 0;
            $series['sessions'][] = $sessions_count;
            $series['pageviews'][] = $row ? (int)$row['pageviews'] : 0;
            $series['conversions'][] = $row ? (int)$row['conversions'] : 0;
            $series['bounce_rate'][] = $sessions_count > 0 ? (int)$row['bounces'] / $sessions_count : 0;
            // Same definition as totals(): visits with more than one event.
            $series['conversion_rate'][] = $sessions_count > 0 ? (int)$row['converting'] / $sessions_count : 0;
            $series['duration'][] = $row && (int)$row['duration_n'] > 0 ? round((int)$row['duration_sum'] / (int)$row['duration_n']) : 0;
            $series['revenue'][] = $revenue[$bucket] ?? 0.0;
        }

        return $series;
    }

    /**
     * Cached; see breakdown_uncached().
     */
    public static function breakdown(string $dimension, array $period, array $filters, string $currency, int $limit = 10, bool $with_visitors = false): array
    {
        return self::remember('breakdown', $period, [$dimension, $filters, $currency, $limit, $with_visitors], function () use ($dimension, $period, $filters, $currency, $limit, $with_visitors) {
            return self::breakdown_uncached($dimension, $period, $filters, $currency, $limit, $with_visitors);
        });
    }

    /**
     * Sessions grouped by one attribute, with conversions and revenue.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return list<array{value: string|null, sessions: int, visitors: int, bounce_rate: float, conversions: int, conversion_rate: float, revenue: float}>
     */
    private static function breakdown_uncached(string $dimension, array $period, array $filters, string $currency, int $limit = 10, bool $with_visitors = false): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();

        $expression = self::DIMENSIONS[$dimension] ?? self::DIMENSIONS['channel'];
        $where = self::where($period, $filters);

        // Distinct visitors per row cost most of the query; only where the
        // table shows them.
        $visitors_sql = $with_visitors ? 'COUNT(DISTINCT s.visitor_hash)' : '0';

        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT $expression AS value,
                    COUNT(*) AS sessions,
                    $visitors_sql AS visitors,
                    SUM(CASE WHEN s.pageviews <= 1 AND s.conversions = 0 AND s.engaged_seconds < 10 THEN 1 ELSE 0 END) AS bounces,
                    SUM(CASE WHEN s.conversions > 0 THEN 1 ELSE 0 END) AS converting,
                    SUM(s.conversions) AS conversions
             FROM `$sessions` s
             WHERE $where
             GROUP BY value
             ORDER BY sessions DESC, value
             LIMIT %d",
            $limit
        ), 'ARRAY_A');

        // Revenue by the same attribute, starting from the conversions
        // (few rows, on idx_conversion_revenue) instead of joining every
        // session of the period to them.
        $revenue_rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT $expression AS value, SUM(e.revenue) AS revenue
             FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id
             WHERE e.conversion_type IS NOT NULL AND e.currency = %s AND $where
             GROUP BY value",
            $currency
        ), 'ARRAY_A');
        $revenue = [];
        foreach (is_array($revenue_rows) ? $revenue_rows : [] as $row) {
            $revenue[(string)$row['value']] = (float)$row['revenue'];
        }
        foreach (is_array($rows) ? $rows : [] as $k => $row) {
            $rows[$k]['revenue'] = $revenue[(string)$row['value']] ?? 0.0;
        }

        $out = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            $sessions_count = (int)$row['sessions'];
            $out[] = [
                'value' => $row['value'] === null || $row['value'] === '' ? null : (string)$row['value'],
                'sessions' => $sessions_count,
                'visitors' => (int)$row['visitors'],
                'bounce_rate' => $sessions_count > 0 ? (int)$row['bounces'] / $sessions_count : 0.0,
                'conversions' => (int)$row['conversions'],
                'converting' => (int)$row['converting'],
                'conversion_rate' => $sessions_count > 0 ? (int)$row['converting'] / $sessions_count : 0.0,
                'revenue' => (float)$row['revenue'],
            ];
        }

        return $out;
    }

    /**
     * Cached; see pages_uncached().
     */
    public static function pages(array $period, array $filters, int $limit = 10): array
    {
        return self::remember('pages', $period, [$filters, $limit], function () use ($period, $filters, $limit) {
            return self::pages_uncached($period, $filters, $limit);
        });
    }

    /**
     * Most viewed pages (without query string).
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return list<array{path: string, pageviews: int, sessions: int, entries: int, engaged: float|null, scroll: float|null}>
     */
    private static function pages_uncached(array $period, array $filters, int $limit = 10): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();

        // Without filters: a time range of page views on
        // (event_type, timestamp, path), no join. With filters: through the
        // sessions they belong to, as every other report.
        if (empty($filters)) {
            [$from, $to] = self::utc_bounds($period);
            $rows = $wpdb->get_results((string)$wpdb->prepare(
                "SELECT e.path AS path, COUNT(*) AS pageviews, COUNT(DISTINCT e.session_id) AS sessions,
                        AVG(e.engaged_seconds) AS engaged, AVG(e.scroll_depth) AS scroll
                 FROM `$events` e
                 WHERE e.event_type = 'pageview' AND e.timestamp >= %s AND e.timestamp < %s AND e.path IS NOT NULL
                 GROUP BY e.path ORDER BY pageviews DESC, path LIMIT %d",
                $from,
                $to,
                $limit
            ), 'ARRAY_A');
        } else {
            $where = self::where($period, $filters);
            $rows = $wpdb->get_results((string)$wpdb->prepare(
                "SELECT e.path AS path, COUNT(*) AS pageviews, COUNT(DISTINCT e.session_id) AS sessions,
                        AVG(e.engaged_seconds) AS engaged, AVG(e.scroll_depth) AS scroll
                 FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id
                 WHERE $where AND e.event_type = 'pageview' AND e.path IS NOT NULL
                 GROUP BY e.path ORDER BY pageviews DESC, path LIMIT %d",
                $limit
            ), 'ARRAY_A');
        }
        $rows = is_array($rows) ? $rows : [];

        // Entries: sessions of the period that began on these paths.
        $entries = [];
        $paths = array_values(array_filter(array_column($rows, 'path'), 'is_string'));
        if (!empty($paths)) {
            $placeholders = implode(',', array_fill(0, count($paths), '%s'));
            $entry_rows = $wpdb->get_results((string)$wpdb->prepare(
                "SELECT s.landing_path AS path, COUNT(*) AS entries FROM `$sessions` s
                 WHERE " . self::where($period, $filters) . " AND s.landing_path IN ($placeholders) GROUP BY s.landing_path",
                ...$paths
            ), 'ARRAY_A');
            foreach (is_array($entry_rows) ? $entry_rows : [] as $row) {
                $entries[(string)$row['path']] = (int)$row['entries'];
            }
        }

        $out = [];
        foreach ($rows as $row) {
            $out[] = [
                'path' => (string)$row['path'],
                'pageviews' => (int)$row['pageviews'],
                'sessions' => (int)$row['sessions'],
                'entries' => $entries[(string)$row['path']] ?? 0,
                'engaged' => $row['engaged'] !== null ? (float)$row['engaged'] : null,
                'scroll' => $row['scroll'] !== null ? (float)$row['scroll'] : null,
            ];
        }

        return $out;
    }

    /**
     * The period as UTC datetimes [from, to): midnight of the first local
     * day to midnight after the last.
     *
     * @param Period $period
     * @return array{0: string, 1: string}
     */
    private static function utc_bounds(array $period): array
    {
        $tz = wp_timezone();
        $utc = new \DateTimeZone('UTC');
        $from = (new \DateTimeImmutable($period['start'] . ' 00:00:00', $tz))->setTimezone($utc);
        $to = (new \DateTimeImmutable($period['end'] . ' 00:00:00', $tz))->modify('+1 day')->setTimezone($utc);

        return [$from->format('Y-m-d H:i:s'), $to->format('Y-m-d H:i:s')];
    }

    /**
     * Cached; see conversion_types_uncached().
     */
    public static function conversion_types(array $period, array $filters, string $currency): array
    {
        return self::remember('conversion_types', $period, [$filters, $currency], function () use ($period, $filters, $currency) {
            return self::conversion_types_uncached($period, $filters, $currency);
        });
    }

    /**
     * Conversions grouped by what was converted: conversion type plus, for
     * forms, the form name.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return list<array{type: string, name: string|null, conversions: int, revenue: float, sessions: int}>
     */
    private static function conversion_types_uncached(array $period, array $filters, string $currency): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();
        $where = self::where($period, $filters);

        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT e.conversion_type AS type,
                    JSON_UNQUOTE(JSON_EXTRACT(e.event_properties_json, '$.form_name')) AS name,
                    COUNT(*) AS conversions,
                    COALESCE(SUM(CASE WHEN e.currency = %s THEN e.revenue END), 0) AS revenue,
                    COUNT(DISTINCT e.session_id) AS sessions
             FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id
             WHERE $where AND e.conversion_type IS NOT NULL
             GROUP BY type, name ORDER BY conversions DESC, type, name LIMIT 50",
            $currency
        ), 'ARRAY_A');

        $out = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            $name = $row['name'];
            $out[] = [
                'type' => (string)$row['type'],
                'name' => is_string($name) && $name !== '' && $name !== 'null' ? $name : null,
                'conversions' => (int)$row['conversions'],
                'revenue' => (float)$row['revenue'],
                'sessions' => (int)$row['sessions'],
            ];
        }

        return $out;
    }

    /** Attribution model => events column holding the session to credit. */
    const MODELS = [
        'session' => 'session_id',
        'last' => 'attributed_session_id',
        'first' => 'first_session_id',
    ];

    /**
     * Cached; see conversions_by_uncached().
     */
    public static function conversions_by(string $dimension, string $model, array $period, array $filters, string $currency, int $limit = 20): array
    {
        return self::remember('conversions_by', $period, [$dimension, $model, $filters, $currency, $limit], function () use ($dimension, $model, $period, $filters, $currency, $limit) {
            return self::conversions_by_uncached($dimension, $model, $period, $filters, $currency, $limit);
        });
    }

    /**
     * Conversions grouped by an attribute of the session they are credited
     * to under the chosen model: the converting visit itself, the latest
     * visit with an origin other than direct, or the first visit (both
     * within Sessions::LOOKBACK_DAYS). The period selects conversions by
     * the start of their converting visit; filters apply to the credited
     * visit.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return list<array{value: string|null, conversions: int, revenue: float, sessions: int}>
     */
    private static function conversions_by_uncached(string $dimension, string $model, array $period, array $filters, string $currency, int $limit = 20): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();

        $column = self::MODELS[$model] ?? 'session_id';
        $expression = str_replace('s.', 'a.', self::DIMENSIONS[$dimension] ?? self::DIMENSIONS['channel']);

        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT $expression AS value,
                    COUNT(*) AS conversions,
                    COALESCE(SUM(CASE WHEN e.currency = %s THEN e.revenue END), 0) AS revenue,
                    COUNT(DISTINCT e.session_id) AS sessions
             FROM `$events` e
             JOIN `$sessions` s ON s.session_id = e.session_id
             JOIN `$sessions` a ON a.session_id = COALESCE(e.$column, e.session_id)
             WHERE " . self::period_sql($period, false, 's') . self::filters_sql($filters, 'a') . " AND e.conversion_type IS NOT NULL
             GROUP BY value ORDER BY revenue DESC, conversions DESC, value LIMIT %d",
            $currency,
            $limit
        ), 'ARRAY_A');

        $out = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            $out[] = [
                'value' => $row['value'] === null || $row['value'] === '' ? null : (string)$row['value'],
                'conversions' => (int)$row['conversions'],
                'revenue' => (float)$row['revenue'],
                'sessions' => (int)$row['sessions'],
            ];
        }

        return $out;
    }

    /** Event types that are not custom events. */
    const BUILTIN_EVENT_TYPES = ['pageview', 'engagement', 'outbound', 'download', 'contact', 'conversion', 'form_submission', 'checkout_confirmed'];

    /**
     * Cached; see engagement_totals_uncached().
     */
    public static function engagement_totals(array $period, array $filters): array
    {
        return self::remember('engagement_totals', $period, [$filters], function () use ($period, $filters) {
            return self::engagement_totals_uncached($period, $filters);
        });
    }

    /**
     * Totals of the engagement events and of active time per page view.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return array<string, float|int|null>
     */
    private static function engagement_totals_uncached(array $period, array $filters): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();

        $select = "SELECT
                SUM(e.event_type = 'outbound') AS outbound,
                SUM(e.event_type = 'download') AS downloads,
                SUM(e.event_type = 'contact' OR e.conversion_type LIKE 'contact\\_%') AS contacts,
                AVG(CASE WHEN e.event_type = 'pageview' THEN e.engaged_seconds END) AS engaged,
                AVG(CASE WHEN e.event_type = 'pageview' THEN e.scroll_depth END) AS scroll,
                SUM(e.event_type = 'pageview' AND e.engaged_seconds IS NOT NULL) AS measured,
                SUM(e.event_type = 'pageview' AND JSON_UNQUOTE(JSON_EXTRACT(e.event_properties_json, '$.status')) = '404') AS not_found,
                SUM(e.event_type = 'pageview' AND JSON_EXTRACT(e.event_properties_json, '$.search') IS NOT NULL) AS searches,
                SUM(e.conversion_type IS NULL AND e.event_type NOT IN ('" . implode("','", self::BUILTIN_EVENT_TYPES) . "')) AS custom";

        if (empty($filters)) {
            [$from, $to] = self::utc_bounds($period);
            $row = $wpdb->get_row($select . (string)$wpdb->prepare(" FROM `$events` e WHERE e.timestamp >= %s AND e.timestamp < %s", $from, $to), 'ARRAY_A');
        } else {
            $row = $wpdb->get_row($select . " FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id WHERE " . self::where($period, $filters), 'ARRAY_A');
        }

        $row = is_array($row) ? $row : [];
        return [
            'outbound' => (int)($row['outbound'] ?? 0),
            'downloads' => (int)($row['downloads'] ?? 0),
            'contacts' => (int)($row['contacts'] ?? 0),
            'engaged' => isset($row['engaged']) ? (float)$row['engaged'] : null,
            'scroll' => isset($row['scroll']) ? (float)$row['scroll'] : null,
            'measured' => (int)($row['measured'] ?? 0),
            'not_found' => (int)($row['not_found'] ?? 0),
            'searches' => (int)($row['searches'] ?? 0),
            'custom' => (int)($row['custom'] ?? 0),
        ];
    }

    /** Pages where conversions happened, read for the funnel. */
    const FUNNEL_PAGES = 50;

    /**
     * "Vom Besuch zum Abschluss" in four nested steps:
     *  1. visits;
     *  2. more than one page viewed (or completed);
     *  3. a contact or checkout page reached after the first page (or
     *     completed). Those pages are where forms were sent and purchases
     *     made in the period (contact clicks happen anywhere, so they do not
     *     count; nor does the start page, where nearly every visit passes
     *     even with a form on it), plus $extra (the shop's checkout pages,
     *     the setting);
     *  4. completed: at least one conversion.
     * Each step contains the next, so the funnel never grows.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @param list<string>          $extra   Paths that count as step 3 as well.
     * @return array{visits: int, more: int, reached: int, done: int, pages: list<string>}
     */
    public static function funnel(array $period, array $filters, array $extra = []): array
    {
        return self::remember('funnel', $period, [$filters, $extra], function () use ($period, $filters, $extra) {
            global $wpdb;
            $sessions = Sessions::table_name();
            $events = Event::table_name();
            $where = self::where($period, $filters);

            $found = $wpdb->get_col((string)$wpdb->prepare(
                "SELECT e.path FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id
                 WHERE $where AND e.conversion_type IS NOT NULL AND e.conversion_type NOT LIKE 'contact\\_%%' AND e.path IS NOT NULL AND e.path NOT IN ('', '/')
                 GROUP BY e.path ORDER BY COUNT(*) DESC, e.path LIMIT %d",
                self::FUNNEL_PAGES
            ));
            $pages = array_values(array_unique(array_merge(is_array($found) ? array_map('strval', $found) : [], $extra)));

            $reached = '0';
            if (!empty($pages)) {
                $placeholders = implode(',', array_fill(0, count($pages), '%s'));
                $reached = (string)$wpdb->prepare(
                    "s.pageviews > 1 AND EXISTS (SELECT 1 FROM `$events` fp WHERE fp.session_id = s.session_id AND fp.event_type = 'pageview' AND fp.path IN ($placeholders))",
                    ...$pages
                );
            }

            $row = $wpdb->get_row(
                "SELECT COUNT(*) AS visits,
                        COALESCE(SUM(s.pageviews > 1 OR s.conversions > 0), 0) AS more,
                        COALESCE(SUM(($reached) OR s.conversions > 0), 0) AS reached,
                        COALESCE(SUM(s.conversions > 0), 0) AS done
                 FROM `$sessions` s WHERE $where",
                'ARRAY_A'
            );

            return [
                'visits' => (int)($row['visits'] ?? 0),
                'more' => (int)($row['more'] ?? 0),
                'reached' => (int)($row['reached'] ?? 0),
                'done' => (int)($row['done'] ?? 0),
                'pages' => $pages,
            ];
        });
    }

    /**
     * Visits per value of the `result` filter (for the filter dialog).
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return array<string, int> RESULTS key => visits
     */
    public static function result_counts(array $period, array $filters): array
    {
        return self::remember('result_counts', $period, [$filters], function () use ($period, $filters) {
            global $wpdb;
            $sessions = Sessions::table_name();
            $row = $wpdb->get_row(
                "SELECT COALESCE(SUM(s.conversions > 0), 0) AS converted, COALESCE(SUM(s.conversions = 0), 0) AS not_converted,
                        COALESCE(SUM(s.pageviews > 1), 0) AS multi, COALESCE(SUM(s.pageviews <= 1), 0) AS single
                 FROM `$sessions` s WHERE " . self::where($period, $filters),
                'ARRAY_A'
            );
            $out = [];
            foreach (self::DIALOG_RESULTS as $key) {
                $out[$key] = (int)($row[$key] ?? 0);
            }
            return $out;
        });
    }

    /**
     * Cached; see events_by_uncached().
     */
    public static function events_by(string $kind, array $period, array $filters, int $limit = 20): array
    {
        return self::remember('events_by', $period, [$kind, $filters, $limit], function () use ($kind, $period, $filters, $limit) {
            return self::events_by_uncached($kind, $period, $filters, $limit);
        });
    }

    /**
     * Events of one kind grouped by a value: a property of the event
     * ("$.url"), or the event type itself for custom events.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @param 'outbound'|'download'|'contact'|'contact_page'|'custom'|'404'|'search' $kind
     * @return list<array{value: string, count: int, sessions: int, empty: int|null}> empty: searches without a hit
     */
    private static function events_by_uncached(string $kind, array $period, array $filters, int $limit = 20): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();
        $where = self::where($period, $filters);
        $json = function (string $path) {
            return "JSON_UNQUOTE(JSON_EXTRACT(e.event_properties_json, '$.$path'))";
        };

        switch ($kind) {
            case 'outbound':
                $value = $json('url');
                $condition = "e.event_type = 'outbound'";
                break;
            case 'download':
                $value = $json('file');
                $condition = "e.event_type = 'download'";
                break;
            case 'contact':
            case 'contact_page':
                // By kind (tel, mailto, whatsapp) or by the page it happened on.
                $value = $kind === 'contact' ? "COALESCE(" . $json('type') . ", REPLACE(e.conversion_type, 'contact_', ''))" : 'e.path';
                // Runs through prepare(): a literal % is written %%.
                $condition = "(e.event_type = 'contact' OR e.conversion_type LIKE 'contact\\_%%')";
                break;
            case '404':
                $value = "SUBSTRING_INDEX(e.page_url, '?', 1)";
                $condition = "e.event_type = 'pageview' AND " . $json('status') . " = '404'";
                break;
            case 'search':
                $value = $json('search');
                $condition = "e.event_type = 'pageview' AND " . $json('search') . " IS NOT NULL";
                break;
            default:
                $value = 'e.event_type';
                $condition = "e.conversion_type IS NULL AND e.event_type NOT IN ('" . implode("','", self::BUILTIN_EVENT_TYPES) . "')";
        }

        // Searches since 2.4 carry the number of hits; older ones count as unknown.
        $empty = $kind === 'search' ? ", SUM(JSON_EXTRACT(e.event_properties_json, '$.results') = 0) AS empty" : '';

        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT $value AS value, COUNT(*) AS count, COUNT(DISTINCT e.session_id) AS sessions$empty
             FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id
             WHERE $where AND $condition
             GROUP BY value ORDER BY count DESC, value LIMIT %d",
            $limit
        ), 'ARRAY_A');

        $out = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            if ($row['value'] === null || $row['value'] === '') {
                continue;
            }
            $out[] = ['value' => (string)$row['value'], 'count' => (int)$row['count'], 'sessions' => (int)$row['sessions'], 'empty' => isset($row['empty']) ? (int)$row['empty'] : null];
        }

        return $out;
    }

    /**
     * Share of sessions in the period recorded with consent (multi-day ID).
     *
     * @param Period $period
     */
    public static function consent_share(array $period): float
    {
        global $wpdb;
        $sessions = Sessions::table_name();

        $row = $wpdb->get_row("SELECT COUNT(*) AS n, SUM(s.consented) AS c FROM `$sessions` s WHERE " . self::period_sql($period, false, 's'), 'ARRAY_A');

        return is_array($row) && (int)$row['n'] > 0 ? (int)$row['c'] / (int)$row['n'] : 0.0;
    }

    /**
     * The latest conversions with the session that brought them.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return list<array<string, mixed>>
     */
    public static function recent_conversions(array $period, array $filters, int $limit = 25, string $model = 'session'): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();
        $column = self::MODELS[$model] ?? 'session_id';
        $where = self::period_sql($period, false, 'cs') . self::filters_sql($filters, 's');

        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT e.id, e.timestamp, e.event_type, e.conversion_type, e.conversion_id, e.revenue, e.currency,
                    e.page_url, e.unique_session_id,
                    JSON_UNQUOTE(JSON_EXTRACT(e.event_properties_json, '$.form_name')) AS form_name,
                    JSON_UNQUOTE(JSON_EXTRACT(e.event_properties_json, '$.order_number')) AS order_number,
                    s.channel, s.source, s.medium, s.campaign, s.landing_page, s.device_type, s.pageviews,
                    TIMESTAMPDIFF(SECOND, s.started_at, e.timestamp) AS seconds_to_convert,
                    (e.$column IS NOT NULL AND e.$column <> e.session_id) AS earlier_visit
             FROM `$events` e
             JOIN `$sessions` cs ON cs.session_id = e.session_id
             JOIN `$sessions` s ON s.session_id = COALESCE(e.$column, e.session_id)
             WHERE $where AND e.conversion_type IS NOT NULL
             ORDER BY e.timestamp DESC, e.id DESC LIMIT %d",
            $limit
        ), 'ARRAY_A');

        return is_array($rows) ? $rows : [];
    }

    /**
     * Visitors active in the last five minutes, for the live pill in every
     * page head. A range on idx_timestamp, so cheap on any table size.
     */
    public static function online_count(): int
    {
        global $wpdb;

        return (int)$wpdb->get_var((string)$wpdb->prepare(
            "SELECT COUNT(DISTINCT unique_session_id) FROM `" . Event::table_name() . "` WHERE timestamp >= %s",
            gmdate('Y-m-d H:i:s', time() - 5 * MINUTE_IN_SECONDS)
        ));
    }

    /** Visits in the live list. */
    const LIVE_VISITS = 50;

    /**
     * Right now: the visitors of the live pill (online_count()), the visits
     * active in the last five minutes with the page they are on, visitors
     * per minute over the last 30 minutes, the same moment yesterday and
     * the latest events. Every query is a range on idx_timestamp or a
     * lookup by primary key, so it stays cheap on any table size; not
     * cached, the view reloads every 30 seconds.
     *
     * @return array{visitors: int, visits: list<array<string, mixed>>, per_minute: list<int>, yesterday: int, events: list<array<string, mixed>>, sessions_today: int}
     */
    public static function live(): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();
        $now = time();
        $utc = function (int $time) {
            return gmdate('Y-m-d H:i:s', $time);
        };
        $since = $utc($now - 5 * MINUTE_IN_SECONDS);

        // Active visits, newest activity first, with the latest page.
        $active = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT e.session_id, MAX(e.timestamp) AS seen,
                    SUBSTRING_INDEX(MAX(CASE WHEN e.event_type = 'pageview' THEN CONCAT(e.timestamp, '|', e.path) END), '|', -1) AS path
             FROM `$events` e WHERE e.timestamp >= %s AND e.session_id IS NOT NULL
             GROUP BY e.session_id ORDER BY seen DESC, e.session_id LIMIT %d",
            $since,
            self::LIVE_VISITS
        ), 'ARRAY_A');
        $active = is_array($active) ? $active : [];

        $visits = [];
        if (!empty($active)) {
            $ids = array_column($active, 'session_id');
            $placeholders = implode(',', array_fill(0, count($ids), '%s'));
            $rows = $wpdb->get_results((string)$wpdb->prepare(
                "SELECT session_id, channel, device_type, started_at, pageviews, conversions FROM `$sessions` WHERE session_id IN ($placeholders)",
                $ids
            ), 'ARRAY_A');
            $by_id = [];
            foreach (is_array($rows) ? $rows : [] as $row) {
                $by_id[(string)$row['session_id']] = $row;
            }
            foreach ($active as $row) {
                $session = $by_id[(string)$row['session_id']] ?? null;
                if ($session === null) {
                    continue;
                }
                $visits[] = [
                    'path' => $row['path'] !== null && $row['path'] !== '' ? (string)$row['path'] : null,
                    'channel' => $session['channel'],
                    'device' => $session['device_type'],
                    'started_at' => (string)$session['started_at'],
                    'pageviews' => (int)$session['pageviews'],
                    'conversions' => (int)$session['conversions'],
                ];
            }
        }

        // Visitors per minute, oldest first: index 29 is the current minute.
        $minutes = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT TIMESTAMPDIFF(MINUTE, e.timestamp, %s) AS ago, COUNT(DISTINCT e.unique_session_id) AS visitors
             FROM `$events` e WHERE e.timestamp >= %s GROUP BY ago",
            $utc($now),
            $utc($now - 30 * MINUTE_IN_SECONDS)
        ), 'ARRAY_A');
        $per_minute = array_fill(0, 30, 0);
        foreach (is_array($minutes) ? $minutes : [] as $row) {
            $ago = (int)$row['ago'];
            if ($ago >= 0 && $ago < 30) {
                $per_minute[29 - $ago] = (int)$row['visitors'];
            }
        }

        // The same 30 minutes yesterday, for the empty live view.
        $minutes_yesterday = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT TIMESTAMPDIFF(MINUTE, e.timestamp, %s) AS ago, COUNT(DISTINCT e.unique_session_id) AS visitors
             FROM `$events` e WHERE e.timestamp >= %s AND e.timestamp < %s GROUP BY ago",
            $utc($now - DAY_IN_SECONDS),
            $utc($now - DAY_IN_SECONDS - 30 * MINUTE_IN_SECONDS),
            $utc($now - DAY_IN_SECONDS)
        ), 'ARRAY_A');
        $per_minute_yesterday = array_fill(0, 30, 0);
        foreach (is_array($minutes_yesterday) ? $minutes_yesterday : [] as $row) {
            $ago = (int)$row['ago'];
            if ($ago >= 0 && $ago < 30) {
                $per_minute_yesterday[29 - $ago] = (int)$row['visitors'];
            }
        }

        $yesterday = (int)$wpdb->get_var((string)$wpdb->prepare(
            "SELECT COUNT(DISTINCT unique_session_id) FROM `$events` WHERE timestamp >= %s AND timestamp < %s",
            $utc($now - DAY_IN_SECONDS - 5 * MINUTE_IN_SECONDS),
            $utc($now - DAY_IN_SECONDS)
        ));

        // The feed without engagement pings (active time, scroll depth).
        $recent = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT e.timestamp, e.event_type, e.conversion_type, e.revenue, e.currency, e.path, s.channel, s.device_type,
                    JSON_UNQUOTE(JSON_EXTRACT(e.event_properties_json, '$.search')) AS search
             FROM `$events` e LEFT JOIN `$sessions` s ON s.session_id = e.session_id
             WHERE e.timestamp >= %s AND e.event_type <> 'engagement' ORDER BY e.timestamp DESC, e.id DESC LIMIT 30",
            $utc($now - 30 * MINUTE_IN_SECONDS)
        ), 'ARRAY_A');

        $sessions_today = (int)$wpdb->get_var((string)$wpdb->prepare("SELECT COUNT(*) FROM `$sessions` WHERE started_day = %s", wp_date('Y-m-d')));

        // Today so far against yesterday until the same time of day.
        [$midnight] = self::utc_bounds(['start' => wp_date('Y-m-d'), 'end' => wp_date('Y-m-d')]);
        $midnight = (int)strtotime($midnight . ' UTC');
        $span = function (int $from, int $to) use ($wpdb, $events, $sessions, $utc) {
            $row = $wpdb->get_row((string)$wpdb->prepare(
                "SELECT SUM(event_type = 'pageview') AS pageviews, SUM(conversion_type IS NOT NULL) AS conversions FROM `$events` WHERE timestamp >= %s AND timestamp < %s",
                $utc($from),
                $utc($to)
            ), 'ARRAY_A');
            $visits = (int)$wpdb->get_var((string)$wpdb->prepare(
                "SELECT COUNT(*) FROM `$sessions` WHERE started_at >= %s AND started_at < %s",
                $utc($from),
                $utc($to)
            ));
            return ['sessions' => $visits, 'pageviews' => (int)($row['pageviews'] ?? 0), 'conversions' => (int)($row['conversions'] ?? 0)];
        };
        $today = $span($midnight, $now + 1);
        $yesterday_so_far = $span($midnight - DAY_IN_SECONDS, $now - DAY_IN_SECONDS + 1);

        // Pages and channels of the last 30 minutes.
        $pages = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT path, COUNT(DISTINCT session_id) AS visitors, COUNT(*) AS views FROM `$events`
             WHERE timestamp >= %s AND event_type = 'pageview' AND path IS NOT NULL
             GROUP BY path ORDER BY visitors DESC, views DESC, path LIMIT 50",
            $utc($now - 30 * MINUTE_IN_SECONDS)
        ), 'ARRAY_A');
        $channels = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT s.channel, COUNT(DISTINCT e.session_id) AS visits FROM `$events` e JOIN `$sessions` s ON s.session_id = e.session_id
             WHERE e.timestamp >= %s GROUP BY s.channel ORDER BY visits DESC, s.channel",
            $utc($now - 30 * MINUTE_IN_SECONDS)
        ), 'ARRAY_A');

        return [
            'visitors' => self::online_count(),
            'visits' => $visits,
            'per_minute' => $per_minute,
            'per_minute_yesterday' => $per_minute_yesterday,
            'yesterday' => $yesterday,
            'events' => is_array($recent) ? $recent : [],
            'sessions_today' => $sessions_today,
            'today' => $today,
            'yesterday_so_far' => $yesterday_so_far,
            'pages' => is_array($pages) ? $pages : [],
            'channels' => is_array($channels) ? $channels : [],
        ];
    }

    /**
     * The latest sessions of the period, for the journeys list.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return list<array<string, mixed>>
     */
    public static function sessions_list(array $period, array $filters, int $limit = 100, int $offset = 0): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();
        $where = self::where($period, $filters);

        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT s.*, TIMESTAMPDIFF(SECOND, s.started_at, s.last_seen_at) AS duration,
                    (SELECT SUM(e.revenue) FROM `$events` e WHERE e.session_id = s.session_id AND e.conversion_type IS NOT NULL) AS revenue,
                    (SELECT e.currency FROM `$events` e WHERE e.session_id = s.session_id AND e.currency IS NOT NULL LIMIT 1) AS currency
             FROM `$sessions` s WHERE $where
             ORDER BY s.started_at DESC, s.session_id DESC LIMIT %d OFFSET %d",
            $limit,
            $offset
        ), 'ARRAY_A');

        return is_array($rows) ? $rows : [];
    }

    /** Visits in the journeys mosaic. */
    const MOSAIC_SIZE = 260;

    /**
     * The newest visits with at least one page view, whatever the period
     * (the mosaic shows the last 260). Filters apply. Cached briefly.
     *
     * @param array<string, string> $filters
     * @return list<array<string, mixed>>
     */
    public static function recent_visits(array $filters, int $limit = self::MOSAIC_SIZE): array
    {
        $today = wp_date('Y-m-d');

        return self::remember('recent_visits', ['start' => $today, 'end' => $today, 'days' => 1], [$filters, $limit], function () use ($filters, $limit) {
            global $wpdb;
            $sessions = Sessions::table_name();
            $events = Event::table_name();

            $rows = $wpdb->get_results((string)$wpdb->prepare(
                "SELECT s.session_id, s.visitor_hash, s.user_id, s.started_at, s.last_seen_at, s.channel, s.source, s.medium, s.campaign,
                        s.landing_path, s.exit_path, s.pageviews, s.events, s.conversions, s.device_type,
                        (SELECT SUM(e.revenue) FROM `$events` e WHERE e.session_id = s.session_id AND e.conversion_type IS NOT NULL) AS revenue,
                        (SELECT e.currency FROM `$events` e WHERE e.session_id = s.session_id AND e.currency IS NOT NULL LIMIT 1) AS currency
                 FROM `$sessions` s WHERE s.pageviews > 0" . self::filters_sql($filters, 's') . "
                 ORDER BY s.started_at DESC, s.session_id DESC LIMIT %d",
                $limit
            ), 'ARRAY_A');

            return is_array($rows) ? $rows : [];
        });
    }

    /**
     * Visits of the period for the journeys list, newest first.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @param 'all'|'conv'|'multi' $only
     * @return list<array<string, mixed>>
     */
    public static function visits_list(array $period, array $filters, string $only, bool $with_empty, int $limit, int $offset = 0): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();

        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT s.session_id, s.visitor_hash, s.user_id, s.started_at, s.last_seen_at, s.channel, s.source, s.medium, s.campaign,
                    s.landing_path, s.exit_path, s.pageviews, s.events, s.conversions, s.device_type, s.engaged_seconds,
                    (SELECT SUM(e.revenue) FROM `$events` e WHERE e.session_id = s.session_id AND e.conversion_type IS NOT NULL) AS revenue,
                    (SELECT e.currency FROM `$events` e WHERE e.session_id = s.session_id AND e.currency IS NOT NULL LIMIT 1) AS currency
             FROM `$sessions` s WHERE " . self::where($period, $filters) . self::visits_condition($only, $with_empty) . "
             ORDER BY s.started_at DESC, s.session_id DESC LIMIT %d OFFSET %d",
            $limit,
            $offset
        ), 'ARRAY_A');

        return is_array($rows) ? $rows : [];
    }

    /**
     * Counts for the list's filter chips, and the visits without a page
     * view (a purchase confirmed by webhook, a form sent from an app).
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return array{all: int, conv: int, multi: int, empty: int}
     */
    public static function visits_counts(array $period, array $filters, bool $with_empty): array
    {
        return self::remember('visits_counts', $period, [$filters, $with_empty], function () use ($period, $filters, $with_empty) {
            global $wpdb;
            $base = $with_empty ? '1' : 's.pageviews > 0';
            $row = $wpdb->get_row(
                "SELECT SUM($base) AS n_all,
                        SUM(($base) AND s.conversions > 0) AS n_conv,
                        SUM(s.pageviews > 1) AS n_multi,
                        SUM(s.pageviews = 0) AS n_empty
                 FROM `" . Sessions::table_name() . "` s WHERE " . self::where($period, $filters),
                'ARRAY_A'
            );
            $row = is_array($row) ? $row : [];

            return [
                'all' => (int)($row['n_all'] ?? 0),
                'conv' => (int)($row['n_conv'] ?? 0),
                'multi' => (int)($row['n_multi'] ?? 0),
                'empty' => (int)($row['n_empty'] ?? 0),
            ];
        });
    }

    private static function visits_condition(string $only, bool $with_empty): string
    {
        $sql = $with_empty ? '' : ' AND s.pageviews > 0';
        if ($only === 'conv') {
            $sql .= ' AND s.conversions > 0';
        } elseif ($only === 'multi') {
            $sql .= ' AND s.pageviews > 1';
        }

        return $sql;
    }

    /**
     * The events of several visits in one query, grouped by visit, in
     * order. For the steps of the journeys list and the dots of the mosaic.
     *
     * @param list<string> $session_ids
     * @return array<string, list<array<string, mixed>>>
     */
    public static function visit_steps(array $session_ids, int $limit = 5000): array
    {
        global $wpdb;
        $session_ids = array_values(array_unique(array_filter(array_map('strval', $session_ids))));
        if (empty($session_ids)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($session_ids), '%s'));
        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT session_id, timestamp, event_type, conversion_type, conversion_id, revenue, currency, path, page_url, referrer,
                    engaged_seconds, scroll_depth, event_properties_json
             FROM `" . Event::table_name() . "` WHERE session_id IN ($placeholders)
             ORDER BY session_id, timestamp, id LIMIT %d",
            ...array_merge($session_ids, [$limit])
        ), 'ARRAY_A');

        $out = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            $out[(string)$row['session_id']][] = $row;
        }

        return $out;
    }

    /**
     * What an integration reported in the last 30 days: how often, when
     * last, and the latest few with their origin. Cached.
     *
     * @param list<string> $conversion_types
     * @param list<string> $event_types
     * @return array{count: int, last: string|null, recent: list<array<string, mixed>>}
     */
    public static function integration_activity(array $conversion_types, array $event_types, int $recent = 5): array
    {
        $period = self::period('30d');

        return self::remember('integration_activity', $period, [$conversion_types, $event_types, $recent], function () use ($conversion_types, $event_types, $recent, $period) {
            global $wpdb;
            if (empty($conversion_types) && empty($event_types)) {
                return ['count' => 0, 'last' => null, 'recent' => []];
            }

            $conditions = [];
            $values = [];
            if (!empty($conversion_types)) {
                $conditions[] = 'e.conversion_type IN (' . implode(',', array_fill(0, count($conversion_types), '%s')) . ')';
                $values = array_merge($values, $conversion_types);
            }
            if (!empty($event_types)) {
                $conditions[] = '(e.conversion_type IS NULL AND e.event_type IN (' . implode(',', array_fill(0, count($event_types), '%s')) . '))';
                $values = array_merge($values, $event_types);
            }
            [$from, $to] = self::utc_bounds($period);
            $where = (string)$wpdb->prepare('e.timestamp >= %s AND e.timestamp < %s AND (' . implode(' OR ', $conditions) . ')', ...array_merge([$from, $to], $values));
            $events = Event::table_name();
            $sessions = Sessions::table_name();

            $count = (int)$wpdb->get_var("SELECT COUNT(*) FROM `$events` e WHERE $where");
            $rows = $wpdb->get_results((string)$wpdb->prepare(
                "SELECT e.timestamp, e.event_type, e.conversion_type, e.conversion_id, e.revenue, e.currency, e.event_properties_json,
                        s.channel, s.source, s.campaign
                 FROM `$events` e LEFT JOIN `$sessions` s ON s.session_id = COALESCE(e.attributed_session_id, e.session_id)
                 WHERE $where ORDER BY e.timestamp DESC, e.id DESC LIMIT %d",
                $recent
            ), 'ARRAY_A');
            $rows = is_array($rows) ? $rows : [];

            return ['count' => $count, 'last' => $rows[0]['timestamp'] ?? null, 'recent' => $rows];
        });
    }

    /**
     * Everything a visitor did: their sessions with attribution, each with
     * its events in order. A visitor is one daily hash, or one logged-in
     * user across days.
     *
     * @return list<array{session: array<string, mixed>, events: list<array<string, mixed>>}>
     */
    public static function journey(string $visitor_hash = '', int $user_id = 0, int $limit = 300): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();

        if ($user_id > 0) {
            $session_rows = $wpdb->get_results((string)$wpdb->prepare(
                "SELECT * FROM `$sessions` WHERE user_id = %d ORDER BY started_at DESC, session_id DESC LIMIT 50",
                $user_id
            ), 'ARRAY_A');
        } else {
            $session_rows = $wpdb->get_results((string)$wpdb->prepare(
                "SELECT * FROM `$sessions` WHERE visitor_hash = %s ORDER BY started_at DESC, session_id DESC LIMIT 50",
                $visitor_hash
            ), 'ARRAY_A');
        }

        $out = [];
        $remaining = $limit;
        foreach (is_array($session_rows) ? $session_rows : [] as $session) {
            if ($remaining <= 0) {
                break;
            }
            $event_rows = $wpdb->get_results((string)$wpdb->prepare(
                "SELECT id, timestamp, event_type, conversion_type, conversion_id, revenue, currency, path, page_url, referrer,
                        engaged_seconds, scroll_depth, event_properties_json
                 FROM `$events` WHERE session_id = %s ORDER BY timestamp ASC, id ASC LIMIT %d",
                (string)$session['session_id'],
                $remaining
            ), 'ARRAY_A');
            $event_rows = is_array($event_rows) ? $event_rows : [];
            $remaining -= count($event_rows);
            $out[] = ['session' => $session, 'events' => $event_rows];
        }

        return $out;
    }

    /**
     * The period before $period as a period of its own (for reports that
     * have no "previous" built in).
     *
     * @param Period $period
     * @return Period
     */
    public static function previous_period(array $period): array
    {
        return self::period('custom', $period['prev_start'], $period['prev_end']);
    }

    /**
     * Cached; see breakdown_channels_uncached().
     *
     * @return array<string, string>
     */
    public static function breakdown_channels(string $dimension, array $period, array $filters): array
    {
        return self::remember('breakdown_channels', $period, [$dimension, $filters], function () use ($dimension, $period, $filters) {
            return self::breakdown_channels_uncached($dimension, $period, $filters);
        });
    }

    /**
     * The channel most visits of each value came through, for the grey
     * channel name behind a source or campaign.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return array<string, string> value => channel
     */
    private static function breakdown_channels_uncached(string $dimension, array $period, array $filters): array
    {
        global $wpdb;
        if (!isset(self::DIMENSIONS[$dimension]) || $dimension === 'channel') {
            return [];
        }

        $expression = self::DIMENSIONS[$dimension];
        $rows = $wpdb->get_results(
            "SELECT $expression AS value, s.channel AS channel, COUNT(*) AS n
             FROM `" . Sessions::table_name() . "` s WHERE " . self::where($period, $filters) . "
             GROUP BY value, channel ORDER BY n DESC, value, channel LIMIT 2000",
            'ARRAY_A'
        );

        $out = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            $value = (string)$row['value'];
            if (!isset($out[$value])) {
                $out[$value] = (string)$row['channel'];
            }
        }

        return $out;
    }

    /**
     * The first day with a visit (site time, Y-m-d), or null. A MIN over
     * the started_day index, so a lookup, not a scan.
     */
    public static function first_seen_day(): ?string
    {
        global $wpdb;
        $day = $wpdb->get_var("SELECT MIN(started_day) FROM `" . Sessions::table_name() . "`");

        return is_string($day) && $day !== '' ? $day : null;
    }

    /**
     * Does any session exist yet? The dashboard shows its first-start state
     * until one does.
     */
    public static function has_data(): bool
    {
        global $wpdb;
        $sessions = Sessions::table_name();

        return (bool)$wpdb->get_var("SELECT 1 FROM `$sessions` LIMIT 1");
    }

    /** Visits read for the common paths, newest first. */
    const PATHS_SAMPLE = 2000;

    /** Steps of a path before the rest is cut off as "…". */
    const PATH_STEPS = 4;

    /**
     * Cached; see common_paths_uncached().
     *
     * @return array{paths: list<array{steps: list<string>, more: bool, visits: int, converting: int}>, visits: int, converting: int, sampled: bool}
     */
    public static function common_paths(array $period, array $filters, int $limit = 10): array
    {
        return self::remember('common_paths', $period, [$filters, $limit], function () use ($period, $filters, $limit) {
            return self::common_paths_uncached($period, $filters, $limit);
        });
    }

    /**
     * The most frequent ways through the site: the first PATH_STEPS pages
     * of each visit with at least two pages (reloads and numbered pages
     * folded), counted over the newest PATHS_SAMPLE visits with a page
     * view. Summarised, no single visit is returned.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return array{paths: list<array{steps: list<string>, more: bool, visits: int, converting: int}>, visits: int, converting: int, sampled: bool}
     */
    private static function common_paths_uncached(array $period, array $filters, int $limit): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $events = Event::table_name();
        $where = self::where($period, $filters);

        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT e.session_id, e.path, v.conversions
             FROM `$events` e
             JOIN (
                SELECT s.session_id, s.conversions FROM `$sessions` s
                WHERE $where AND s.pageviews > 0
                ORDER BY s.started_at DESC, s.session_id DESC LIMIT %d
             ) v ON v.session_id = e.session_id
             WHERE e.event_type = 'pageview'
             ORDER BY e.session_id, e.timestamp, e.id",
            self::PATHS_SAMPLE
        ), 'ARRAY_A');

        $visits = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            $id = (string)$row['session_id'];
            if (!isset($visits[$id])) {
                $visits[$id] = ['steps' => [], 'converting' => (int)$row['conversions'] > 0];
            }
            [$path] = \AnalyticsWP\Lib\Admin\Format::page_group((string)$row['path']);
            $steps = &$visits[$id]['steps'];
            if (end($steps) !== $path) {
                $steps[] = $path;
            }
            unset($steps);
        }

        $paths = [];
        $converting = 0;
        foreach ($visits as $visit) {
            if ($visit['converting']) {
                $converting++;
            }
            // One page is no way through the site; visit_depth() counts those.
            if (count($visit['steps']) < 2) {
                continue;
            }
            $more = count($visit['steps']) > self::PATH_STEPS;
            $steps = array_slice($visit['steps'], 0, self::PATH_STEPS);
            $key = implode("\x1f", $steps) . ($more ? "\x1f…" : '');
            if (!isset($paths[$key])) {
                $paths[$key] = ['steps' => $steps, 'more' => $more, 'visits' => 0, 'converting' => 0];
            }
            $paths[$key]['visits']++;
            if ($visit['converting']) {
                $paths[$key]['converting']++;
            }
        }
        usort($paths, function ($a, $b) {
            return $b['visits'] <=> $a['visits'] ?: count($b['steps']) <=> count($a['steps']) ?: strcmp(implode(' ', $a['steps']), implode(' ', $b['steps']));
        });

        return [
            'paths' => array_slice($paths, 0, $limit),
            'visits' => count($visits),
            'converting' => $converting,
            'sampled' => count($visits) >= self::PATHS_SAMPLE,
        ];
    }

    /**
     * Cached; see visit_depth_uncached().
     *
     * @return array{one: int, two: int, three_four: int, five_plus: int, average: float}
     */
    public static function visit_depth(array $period, array $filters): array
    {
        return self::remember('visit_depth', $period, [$filters], function () use ($period, $filters) {
            return self::visit_depth_uncached($period, $filters);
        });
    }

    /**
     * How many pages a visit sees: visits with 1, 2, 3–4 and 5+ page
     * views, and the average over visits with at least one.
     *
     * @param Period                $period
     * @param array<string, string> $filters
     * @return array{one: int, two: int, three_four: int, five_plus: int, average: float}
     */
    private static function visit_depth_uncached(array $period, array $filters): array
    {
        global $wpdb;
        $sessions = Sessions::table_name();
        $where = self::where($period, $filters);

        $row = $wpdb->get_row(
            "SELECT COALESCE(SUM(s.pageviews = 1), 0) AS one,
                    COALESCE(SUM(s.pageviews = 2), 0) AS two,
                    COALESCE(SUM(s.pageviews BETWEEN 3 AND 4), 0) AS three_four,
                    COALESCE(SUM(s.pageviews >= 5), 0) AS five_plus,
                    AVG(CASE WHEN s.pageviews > 0 THEN s.pageviews END) AS average
             FROM `$sessions` s WHERE $where",
            'ARRAY_A'
        );
        $row = is_array($row) ? $row : [];

        return [
            'one' => (int)($row['one'] ?? 0),
            'two' => (int)($row['two'] ?? 0),
            'three_four' => (int)($row['three_four'] ?? 0),
            'five_plus' => (int)($row['five_plus'] ?? 0),
            'average' => round((float)($row['average'] ?? 0), 1),
        ];
    }
}
