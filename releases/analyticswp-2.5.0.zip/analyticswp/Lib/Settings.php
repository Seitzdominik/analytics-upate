<?php

namespace AnalyticsWP\Lib;

/**
 * @psalm-import-type SettingsArgs from \AnalyticsWP\Lib\SuperSimpleWP
 */
class Settings
{
    /**
     * @return SettingsArgs
     */
    public static function settings_description()
    {
        $settings = array(
            // Fork settings, rendered by Admin\Tabs\Settings::render().
            'multi_day_with_consent' => array(
                'type' => 'checkbox',
                'label' => 'Recognise visitors across days with consent (Must-Have Cookie).',
                'default' => '1',
                'tab' => 'General'
            ),
            'engagement_tracking' => array(
                'type' => 'checkbox',
                'label' => 'Measure active time, scroll depth, outbound links, downloads and contact clicks.',
                'default' => '1',
                'tab' => 'General'
            ),
            'link_logged_in_users' => array(
                'type' => 'checkbox',
                'label' => 'Link visits of logged-in users to their account.',
                'default' => '0',
                'tab' => 'General'
            ),
            'contact_clicks_as_conversion' => array(
                'type' => 'checkbox',
                'label' => 'Count phone, e-mail and WhatsApp clicks as conversions.',
                'default' => '1',
                'tab' => 'General'
            ),
            'value_per_form' => array(
                'type' => 'text',
                'label' => 'Estimated value of one form submission.',
                'default' => '',
                'tab' => 'General'
            ),
            'value_per_contact' => array(
                'type' => 'text',
                'label' => 'Estimated value of one contact click.',
                'default' => '',
                'tab' => 'General'
            ),
            'form_values' => array(
                'type' => 'hidden',
                'label' => 'Estimated value per form.',
                'default' => array(),
                'tab' => 'General'
            ),
            'retention_months' => array(
                'type' => 'select',
                'label' => 'Delete visits and events after this many months (0 = never).',
                'options' => array('6' => '6', '13' => '13', '25' => '25', '38' => '38', '0' => '0'),
                'default' => '25',
                'tab' => 'General'
            ),
            'fast_endpoint' => array(
                'type' => 'checkbox',
                'label' => 'Load only this plugin for tracking requests (must-use plugin).',
                'default' => '1',
                'tab' => 'General'
            ),
            'delete_data_on_uninstall' => array(
                'type' => 'checkbox',
                'label' => 'Delete all analytics data when the plugin is deleted.',
                'default' => '0',
                'tab' => 'General'
            ),
            'disabled-tracking-user-roles' => array(
                'type' => 'wp-user-roles',
                'label' => 'Disable tracking for these user roles.',
                'description' => 'Exclude certain user roles from being tracked. Select the user roles you want to exclude from tracking.',
                'tab' => 'General'
            ),
            'admin-access-user-roles' => array(
                'type' => 'wp-user-roles-without-subscriber',
                'label' => 'Give these user roles access to the AnalyticsWP admin pages.',
                'description' => 'Select the user roles that should have access to the AnalyticsWP admin pages. Only administrators will have access to this settings page.',
                'default' => ['administrator' => '1'],
                'tab' => 'General'
            ),
            'how_did_you_hear' => array(
                'type' => 'radio',
                'label' => 'Add a "How did you hear about us?" question to the checkout page.',
                'description' => 'This will add a field to your WooCommerce checkout form, and track the value in AnalyticsWP.',
                'options' => array_merge(['disable' => 'Disable'], Integrations\WooCommerceIntegration::get_wc_field_positions()),
                'tab' => 'General'
            ),
            'enable_woocommerce_order_notification_source_section' => array(
                'type' => 'checkbox',
                'label' => 'Enable WooCommerce Email Order Notification Source Section',
                'description' => 'This will add a section to the WooCommerce order notification email that shows the source of the order.',
                'default' => '1',
                'tab' => 'General'
            ),
        );

        return $settings;
    }
}
