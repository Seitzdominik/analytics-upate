<?php

namespace AnalyticsWP\Lib;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Format;

/**
 * Where an order (or any conversion) came from, for the screens of the shop
 * plugins: WooCommerce's order list, order screen and "Neue Bestellung"
 * e-mail.
 *
 * Reads the attribution stored with the conversion (Sessions):
 * - last: the latest visit with a source within 30 days, which gets the
 *   credit (the visit of the order itself when that one had a source);
 * - first: the visitor's first known visit, when it is a different one.
 * A handful of primary-key lookups, so no cache.
 *
 * @psalm-type Origin = array{
 *   last: array<string, mixed>,
 *   first: array<string, mixed>|null,
 *   order_session: array<string, mixed>,
 *   timestamp: string,
 *   journey_url: string
 * }
 */
class OrderOrigin
{
    /**
     * @param list<string> $conversion_types
     * @return Origin|null
     */
    public static function find(array $conversion_types, string $conversion_id): ?array
    {
        global $wpdb;

        if ($conversion_id === '' || $conversion_id === '0' || empty($conversion_types)) {
            return null;
        }

        $placeholders = implode(', ', array_fill(0, count($conversion_types), '%s'));
        $event = $wpdb->get_row((string)$wpdb->prepare(
            "SELECT session_id, attributed_session_id, first_session_id, timestamp, unique_session_id, user_id
             FROM `" . Event::table_name() . "`
             WHERE conversion_id = %s AND conversion_type IN ($placeholders)
             ORDER BY id ASC LIMIT 1",
            $conversion_id,
            ...$conversion_types
        ), 'ARRAY_A');

        if (!is_array($event) || empty($event['session_id'])) {
            return null;
        }

        $order_session = Sessions::find((string)$event['session_id']);
        if ($order_session === null) {
            return null;
        }

        $last = $order_session;
        if (!empty($event['attributed_session_id']) && $event['attributed_session_id'] !== $event['session_id']) {
            $last = Sessions::find((string)$event['attributed_session_id']) ?? $order_session;
        }

        $first = null;
        if (!empty($event['first_session_id']) && $event['first_session_id'] !== $last['session_id']) {
            $first = Sessions::find((string)$event['first_session_id']);
        }

        $journey_args = !empty($event['user_id'])
            ? ['tab' => 'journeys', 'user' => (string)(int)$event['user_id']]
            : ['tab' => 'journeys', 'visitor' => (string)$event['unique_session_id']];

        return [
            'last' => $last,
            'first' => $first,
            'order_session' => $order_session,
            'timestamp' => (string)$event['timestamp'],
            'journey_url' => App::url($journey_args + ['f_*' => null]),
        ];
    }

    /**
     * "Bezahlte Suche" + "google / cpc · Kampagne „herbst“".
     *
     * @param array<string, mixed> $session
     * @return array{0: string, 1: string}
     */
    public static function describe(array $session): array
    {
        $parts = [];
        $source = trim((string)($session['source'] ?? ''));
        $medium = trim((string)($session['medium'] ?? ''));
        if ($source !== '' || $medium !== '') {
            $parts[] = trim($source . ($medium !== '' ? ' / ' . $medium : ''), ' /');
        } elseif (!empty($session['referrer_domain'])) {
            $parts[] = (string)$session['referrer_domain'];
        }
        if (!empty($session['campaign'])) {
            $parts[] = 'Kampagne „' . (string)$session['campaign'] . '“';
        }

        return [Format::channel((string)($session['channel'] ?? '')), implode(' · ', $parts)];
    }

    /**
     * Days between a visit and the order, as "am selben Tag" / "3 Tage vorher".
     *
     * @param array<string, mixed> $session
     */
    public static function days_before(array $session, string $order_timestamp): string
    {
        $visit = strtotime((string)$session['started_at'] . ' UTC');
        $order = strtotime($order_timestamp . ' UTC');
        if (!$visit || !$order) {
            return '';
        }

        $days = (int)floor(max(0, $order - $visit) / DAY_IN_SECONDS);

        return $days === 0 ? 'am selben Tag' : ($days === 1 ? '1 Tag vorher' : $days . ' Tage vorher');
    }

    /**
     * The origin as HTML. Compact for a list column: channel and source
     * only. Otherwise with landing page, first contact and journey link.
     *
     * @param Origin|null $origin
     */
    public static function render(?array $origin, bool $compact = false, bool $with_link = true): string
    {
        if ($origin === null) {
            return '<span style="color:#646970">Nicht erfasst</span>';
        }

        [$channel, $detail] = self::describe($origin['last']);
        $html = '<strong>' . esc_html($channel) . '</strong>';
        if ($detail !== '') {
            $html .= '<br><span style="color:#646970">' . esc_html($detail) . '</span>';
        }

        if ($compact) {
            return $html;
        }

        $rows = [];
        if ($origin['last']['session_id'] !== $origin['order_session']['session_id']) {
            $rows[] = ['Besuch über diese Quelle', self::days_before($origin['last'], $origin['timestamp'])];
        }
        if (!empty($origin['last']['landing_path'])) {
            $rows[] = ['Einstieg', (string)$origin['last']['landing_path']];
        }
        if (!empty($origin['order_session']['device_type'])) {
            $rows[] = ['Gerät', Format::device((string)$origin['order_session']['device_type'])];
        }
        if ($origin['first'] !== null) {
            [$first_channel, $first_detail] = self::describe($origin['first']);
            $rows[] = ['Erster Kontakt', $first_channel . ($first_detail !== '' ? ' · ' . $first_detail : '') . ', ' . self::days_before($origin['first'], $origin['timestamp'])];
        }

        foreach ($rows as [$label, $value]) {
            $html .= '<br>' . esc_html($label) . ': ' . esc_html($value);
        }

        if ($with_link) {
            $html .= '<br><a href="' . esc_url($origin['journey_url']) . '">Journey ansehen</a>';
        }

        return $html;
    }
}
