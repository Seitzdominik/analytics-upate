<?php

namespace AnalyticsWP\Lib;

/**
 * The consent tier: visitors who agree to statistics in Must-Have Cookie
 * get a first-party ID (cookie awp_vid) and are recognised across days.
 * Everyone else stays cookieless (Visitor's daily hash).
 *
 * Must-Have Cookie (MHC) is detected by its own constants and functions,
 * never by its cookie: a leftover cookie proves nothing (Pixel Made Simple,
 * DECISIONS.md §2). Its consent cookie, `mhcookie` unless the filter
 * `mhcookie/first_party_cookie_name` renames it, holds Base64-encoded JSON:
 *
 *   {"groups":["all"],"services":{...},"iab_vendors":["all"],...}
 *
 * "Accept all" stores "all"; the statistics category is "analytics". Group
 * slugs taken from MHC 1.0.4 (templates/consent.tpl.json).
 *
 * The browser decides when to set or delete awp_vid (assets: analyticswp.js,
 * on MHC's events mhcookie/store_consent and mhcookie/save_consent, which
 * fire without a reload). The server checks the consent cookie again on every
 * request before it uses the ID, so a visitor without consent is never
 * recognised across days, whatever their browser sends.
 */
class Consent
{
    /** First-party cookie with the visitor ID; only set with consent. */
    const VISITOR_COOKIE = 'awp_vid';

    /** Groups in the MHC cookie that mean consent to statistics. */
    const STATISTICS_GROUPS = ['all', 'analytics', 'statistics'];

    /** Consent cookies longer than this are not parsed. */
    const MAX_COOKIE_LENGTH = 8192;

    public static function mhc_active(): bool
    {
        return defined('MH_COOKIE_PLUGIN_FILE') || function_exists('mhcookie_get_option');
    }

    public static function mhc_cookie_name(): string
    {
        $name = apply_filters('mhcookie/first_party_cookie_name', 'mhcookie');

        return is_string($name) && $name !== '' ? $name : 'mhcookie';
    }

    /**
     * Is the multi-day tier switched on and possible on this site?
     */
    public static function multi_day_enabled(): bool
    {
        $enabled = self::mhc_active() && (bool)SuperSimpleWP::get_setting('analyticswp', 'multi_day_with_consent');

        /**
         * Switch the consent tier on or off, e.g. for another consent tool
         * (then also filter analyticswp_has_statistics_consent).
         *
         * @param bool $enabled
         */
        return (bool)apply_filters('analyticswp_multi_day_enabled', $enabled);
    }

    /**
     * Has the visitor of the current request agreed to statistics?
     */
    public static function has_statistics_consent(): bool
    {
        $consent = false;
        $name = self::mhc_cookie_name();

        if (self::mhc_active() && !empty($_COOKIE[$name]) && is_string($_COOKIE[$name])) {
            $consent = self::groups_allow_statistics(self::parse_mhc_cookie((string)wp_unslash($_COOKIE[$name])));
        }

        /**
         * Consent to statistics for the current request.
         *
         * @param bool $consent
         */
        return (bool)apply_filters('analyticswp_has_statistics_consent', $consent);
    }

    /**
     * @return list<string> Consent groups from an MHC cookie value, [] if unreadable.
     */
    public static function parse_mhc_cookie(string $raw): array
    {
        $raw = trim(rawurldecode($raw));
        if ($raw === '' || strlen($raw) > self::MAX_COOKIE_LENGTH) {
            return [];
        }

        $json = base64_decode($raw, true);
        $data = is_string($json) ? json_decode($json, true) : null;
        if (!is_array($data) || !isset($data['groups']) || !is_array($data['groups'])) {
            return [];
        }

        return array_values(array_filter($data['groups'], 'is_string'));
    }

    /**
     * @param list<string> $groups
     */
    public static function groups_allow_statistics(array $groups): bool
    {
        return (bool)array_intersect($groups, self::STATISTICS_GROUPS);
    }

    /**
     * The visitor ID from the awp_vid cookie, if the tier is on, the visitor
     * has consented and the value is a well-formed random ID. '' otherwise.
     */
    public static function visitor_id(): string
    {
        if (empty($_COOKIE[self::VISITOR_COOKIE]) || !is_string($_COOKIE[self::VISITOR_COOKIE])) {
            return '';
        }

        $id = strtolower(trim((string)wp_unslash($_COOKIE[self::VISITOR_COOKIE])));
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', $id)) {
            return '';
        }

        if (!self::multi_day_enabled() || !self::has_statistics_consent()) {
            return '';
        }

        return $id;
    }

    /**
     * Settings for the tracker script.
     *
     * @return array{multiDay: bool, mhcCookie: string, cookie: string}
     */
    public static function script_vars(): array
    {
        return [
            'multiDay' => self::multi_day_enabled(),
            'mhcCookie' => self::mhc_cookie_name(),
            'cookie' => self::VISITOR_COOKIE,
        ];
    }
}
