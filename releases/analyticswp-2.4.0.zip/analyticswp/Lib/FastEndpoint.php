<?php

namespace AnalyticsWP\Lib;

/**
 * "Schneller Messpunkt": keeps the must-use plugin mu/analyticswp-fast-
 * endpoint.php in wp-content/mu-plugins in step with the setting. That file
 * lets the tracking request load only this plugin (and Must-Have Cookie)
 * instead of every active plugin; see the file for what it changes.
 *
 * Written only where WordPress may write files directly (no FTP
 * credentials), atomically, and only our own file: a file of that name
 * without our marker is left alone.
 */
class FastEndpoint
{
    const FILE = 'analyticswp-fast-endpoint.php';

    const OPTION = 'analyticswp_fast_endpoint';

    /** Hash of the installed file, to notice a plugin update cheaply. */
    const HASH_OPTION = 'analyticswp_fast_endpoint_hash';

    const MARKER = 'analyticswp-fast-endpoint (managed by the plugin';

    public static function init(): void
    {
        add_action('admin_init', [self::class, 'maybe_sync']);
        add_action('add_option_' . self::OPTION, [self::class, 'sync']);
        add_action('update_option_' . self::OPTION, [self::class, 'sync']);
    }

    public static function enabled(): bool
    {
        return (bool)SuperSimpleWP::get_setting('analyticswp', 'fast_endpoint');
    }

    public static function target(): string
    {
        return WPMU_PLUGIN_DIR . '/' . self::FILE;
    }

    /**
     * The file as it should be on this site.
     */
    public static function contents(): string
    {
        $template = (string)@file_get_contents(dirname(__DIR__) . '/mu/' . self::FILE);
        $basename = plugin_basename(dirname(__DIR__) . '/analyticswp.php');
        if ($template === '' || !preg_match('#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+\.php$#', $basename)) {
            return '';
        }

        return str_replace(['{{BASENAME}}', '{{VERSION}}'], [$basename, ANALYTICSWP_VERSION], $template);
    }

    /**
     * After a plugin update or a changed setting: only when something is
     * off, so admin pages do not touch the disk.
     */
    public static function maybe_sync(): void
    {
        if (!current_user_can('activate_plugins')) {
            return;
        }
        $want = self::enabled() ? md5(self::contents()) : '';
        if (get_option(self::HASH_OPTION, '') !== $want || ($want !== '') !== is_file(self::target())) {
            self::sync();
        }
    }

    /**
     * Install, update or remove the file to match the setting.
     */
    public static function sync(): void
    {
        if (self::enabled()) {
            self::install();
        } else {
            self::remove();
        }
    }

    public static function install(): bool
    {
        $contents = self::contents();
        if ($contents === '' || !self::can_write()) {
            return false;
        }
        $target = self::target();
        if (is_file($target)) {
            $current = (string)@file_get_contents($target);
            if ($current === $contents) {
                update_option(self::HASH_OPTION, md5($contents), false);
                return true;
            }
            if (strpos($current, self::MARKER) === false) {
                return false;
            }
        }
        if (!is_dir(WPMU_PLUGIN_DIR) && !wp_mkdir_p(WPMU_PLUGIN_DIR)) {
            return false;
        }

        $tmp = $target . '.' . wp_generate_password(8, false) . '.tmp';
        if (@file_put_contents($tmp, $contents) !== strlen($contents) || !@rename($tmp, $target)) {
            @unlink($tmp);
            return false;
        }
        update_option(self::HASH_OPTION, md5($contents), false);

        return true;
    }

    public static function remove(): void
    {
        $target = self::target();
        if (is_file($target) && strpos((string)@file_get_contents($target), self::MARKER) !== false) {
            @unlink($target);
        }
        delete_option(self::HASH_OPTION);
    }

    /**
     * active, off, blocked (cannot write), foreign (a file of that name that
     * is not ours) or outdated.
     */
    public static function status(): string
    {
        $target = self::target();
        $exists = is_file($target);
        if (!self::enabled()) {
            return 'off';
        }
        if ($exists) {
            $current = (string)@file_get_contents($target);
            if (strpos($current, self::MARKER) === false) {
                return 'foreign';
            }
            return $current === self::contents() ? 'active' : 'outdated';
        }

        return self::can_write() ? 'outdated' : 'blocked';
    }

    private static function can_write(): bool
    {
        if (!function_exists('get_filesystem_method')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $dir = is_dir(WPMU_PLUGIN_DIR) ? WPMU_PLUGIN_DIR : WP_CONTENT_DIR;

        return get_filesystem_method([], $dir) === 'direct' && wp_is_writable($dir);
    }
}
