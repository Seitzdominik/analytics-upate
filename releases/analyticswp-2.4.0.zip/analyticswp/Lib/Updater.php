<?php

namespace AnalyticsWP\Lib;

/**
 * Updates from the public repository Seitzdominik/analytics-upate, signed
 * with ed25519.
 *
 * - update.json in the repository names the newest version, its ZIP under
 *   releases/, the ZIP's SHA-256, a SHA-256 over the unpacked files ("tree")
 *   and a signature over "analyticswp\n<version>\n<zip sha256>\n<tree
 *   sha256>" (dev-tools/release-key.js).
 * - WordPress asks through the "Update URI" header
 *   (update_plugins_raw.githubusercontent.com), so wordpress.org never
 *   offers a plugin of the same name in its place.
 * - Two checks against the public key below, both fail closed:
 *   1. upgrader_pre_download: the ZIP, before WordPress unpacks it.
 *   2. upgrader_source_selection: the unpacked files, before they replace
 *      the plugin. This one also holds when the ZIP came past WordPress'
 *      download filter (WP-CLI fetches and caches packages itself).
 *   A ZIP that does not match, or an old ZIP relabelled as a new version,
 *   is refused.
 *
 * The repository can be public: it holds only ZIPs and the manifest, no
 * token is needed on client sites, and whoever takes over the repository
 * still cannot sign.
 *
 * @psalm-type Manifest = array{version: string, package: string, sha256: string, tree_sha256: string, signature: string, requires: string, requires_php: string, tested: string, published: string, changelog: string}
 */
class Updater
{
    /** Public half of the release key (base64, 32 bytes). */
    const PUBLIC_KEY = '82WXxUaFKKkXj4ej94VscVX2rbv3d8ZPsJMW6wzy7Kc=';

    const MANIFEST_URL = 'https://raw.githubusercontent.com/Seitzdominik/analytics-upate/main/update.json';

    /** Packages are accepted only from here. */
    const PACKAGE_PREFIX = 'https://raw.githubusercontent.com/Seitzdominik/analytics-upate/main/releases/';

    /** Host of the plugin's Update URI header. */
    const UPDATE_HOST = 'raw.githubusercontent.com';

    const CACHE_KEY = 'analyticswp_update_manifest';
    const CACHE_TTL = 12 * HOUR_IN_SECONDS;
    const CACHE_TTL_ERROR = HOUR_IN_SECONDS;

    const REFUSED = 'Das Update-Paket von AnalyticsWP ist nicht korrekt signiert und wurde nicht installiert.';

    public static function init(): void
    {
        add_filter('update_plugins_' . self::UPDATE_HOST, [self::class, 'check'], 10, 3);
        add_filter('plugins_api', [self::class, 'info'], 10, 3);
        // Last in line: another filter (a backup plugin, a cache) may
        // already have fetched the file; it is checked all the same.
        add_filter('upgrader_pre_download', [self::class, 'download'], PHP_INT_MAX, 3);
        add_filter('upgrader_source_selection', [self::class, 'verify_source'], PHP_INT_MAX, 4);
        add_action('upgrader_process_complete', function () {
            delete_site_transient(self::CACHE_KEY);
        });
    }

    public static function basename(): string
    {
        return plugin_basename(dirname(__DIR__) . '/analyticswp.php');
    }

    /**
     * @param mixed                $update
     * @param array<string, mixed> $plugin_data
     * @param string               $plugin_file
     * @return mixed
     */
    public static function check($update, $plugin_data, $plugin_file)
    {
        if ($plugin_file !== self::basename()) {
            return $update;
        }

        $manifest = self::manifest();
        if ($manifest === null) {
            return $update;
        }

        return [
            'id' => self::MANIFEST_URL,
            'slug' => dirname(self::basename()),
            'version' => $manifest['version'],
            'url' => 'https://github.com/Seitzdominik/analytics-upate',
            'package' => version_compare($manifest['version'], ANALYTICSWP_VERSION, '>') ? $manifest['package'] : '',
            'requires' => $manifest['requires'],
            'requires_php' => $manifest['requires_php'],
            'tested' => $manifest['tested'],
        ];
    }

    /**
     * "View details" in the plugin list.
     *
     * @param mixed  $result
     * @param string $action
     * @param object $args
     * @return mixed
     */
    public static function info($result, $action, $args)
    {
        if ($action !== 'plugin_information' || !is_object($args) || ($args->slug ?? '') !== dirname(self::basename())) {
            return $result;
        }

        $manifest = self::manifest();
        if ($manifest === null) {
            return $result;
        }

        return (object)[
            'name' => 'AnalyticsWP',
            'slug' => dirname(self::basename()),
            'version' => $manifest['version'],
            'author' => 'Dominik Seitz',
            'homepage' => 'https://github.com/Seitzdominik/analytics-upate',
            'requires' => $manifest['requires'],
            'requires_php' => $manifest['requires_php'],
            'tested' => $manifest['tested'],
            'last_updated' => $manifest['published'],
            'download_link' => $manifest['package'],
            'sections' => [
                'description' => 'Cookielose Analytics für WordPress mit UTM-Attribution. Fork von AnalyticsWP 2.3.0 (Solid Plugins).',
                'changelog' => wp_kses_post($manifest['changelog']),
            ],
        ];
    }

    /**
     * Check 1: the ZIP, before WordPress unpacks it. Downloads it, or takes
     * the file an earlier filter fetched. Other packages pass untouched.
     *
     * @param mixed  $reply false, a local file from an earlier filter, or WP_Error
     * @param string $package
     * @param mixed  $upgrader
     * @return mixed a verified local file, or WP_Error
     */
    public static function download($reply, $package, $upgrader)
    {
        if (!is_string($package) || strpos($package, self::package_prefix()) !== 0 || is_wp_error($reply)) {
            return $reply;
        }

        $earlier_file = is_string($reply) && $reply !== '' && is_file($reply) ? $reply : '';

        // The manifest decides which package belongs to which version; ask
        // it fresh, not from a cache that may be twelve hours old.
        $manifest = self::fresh_manifest();
        if ($manifest === null || $manifest['package'] !== $package) {
            self::discard($earlier_file);
            return new \WP_Error('analyticswp_update_manifest', 'Die Update-Informationen von AnalyticsWP passen nicht zum Paket. Das Update wurde nicht installiert.');
        }

        if ($earlier_file !== '') {
            $file = $earlier_file;
        } elseif ($reply === false) {
            if (!function_exists('download_url')) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
            }
            $file = download_url($package, 60);
            if (is_wp_error($file)) {
                return $file;
            }
        } else {
            // Something claims the download is done, without a file to check.
            return new \WP_Error('analyticswp_update_signature', self::REFUSED);
        }

        $actual = hash_file('sha256', $file);
        if (!is_string($actual) || !hash_equals($manifest['sha256'], $actual) || !self::verify_signature($manifest)) {
            self::discard($file);
            return new \WP_Error('analyticswp_update_signature', self::REFUSED);
        }

        return $file;
    }

    /**
     * Check 2: the unpacked files of an update of this plugin, before they
     * replace it, whichever way the ZIP arrived.
     *
     * @param mixed                $source Unpacked folder, or WP_Error
     * @param string               $remote_source
     * @param mixed                $upgrader
     * @param array<string, mixed> $hook_extra
     * @return mixed
     */
    public static function verify_source($source, $remote_source = '', $upgrader = null, $hook_extra = [])
    {
        if (is_wp_error($source) || !is_array($hook_extra) || ($hook_extra['plugin'] ?? '') !== self::basename()) {
            return $source;
        }

        $manifest = self::fresh_manifest();
        $tree = is_string($source) ? self::tree_hash($source) : null;

        if ($manifest === null || $tree === null || !hash_equals($manifest['tree_sha256'], $tree) || !self::verify_signature($manifest)) {
            return new \WP_Error('analyticswp_update_signature', self::REFUSED);
        }

        return $source;
    }

    /**
     * SHA-256 over a plugin folder: one line "<sha256>  <relative path>\n"
     * per file, sorted by path (bytes). dev-tools/package.py --tree computes
     * the same from the ZIP.
     */
    public static function tree_hash(string $dir): ?string
    {
        $dir = rtrim(str_replace('\\', '/', $dir), '/');
        if (!is_dir($dir)) {
            return null;
        }

        $entries = [];
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
        foreach ($files as $file) {
            if (!$file->isFile()) {
                continue;
            }
            $path = str_replace('\\', '/', $file->getPathname());
            $hash = hash_file('sha256', $path);
            if (!is_string($hash)) {
                return null;
            }
            $entries[substr($path, strlen($dir) + 1)] = $hash;
        }
        uksort($entries, 'strcmp');

        $text = '';
        foreach ($entries as $relative => $hash) {
            $text .= $hash . '  ' . $relative . "\n";
        }

        return hash('sha256', $text);
    }

    /**
     * @param Manifest $manifest
     */
    public static function verify_signature(array $manifest): bool
    {
        if (!function_exists('sodium_crypto_sign_verify_detached') && is_readable(ABSPATH . WPINC . '/sodium_compat/autoload.php')) {
            require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
        }
        if (!function_exists('sodium_crypto_sign_verify_detached')) {
            return false;
        }

        $raw_signature = base64_decode($manifest['signature'], true);
        $raw_key = base64_decode(self::PUBLIC_KEY, true);
        if ($raw_signature === false || strlen($raw_signature) !== 64 || $raw_key === false || strlen($raw_key) !== 32) {
            return false;
        }

        $message = implode("\n", ['analyticswp', $manifest['version'], $manifest['sha256'], $manifest['tree_sha256']]);

        try {
            return sodium_crypto_sign_verify_detached($raw_signature, $message, $raw_key);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * The manifest, checked field by field, or null. Cached.
     *
     * @return Manifest|null
     */
    public static function manifest(): ?array
    {
        $cached = get_site_transient(self::CACHE_KEY);
        if (is_array($cached)) {
            return isset($cached['version']) ? $cached : null;
        }

        $response = wp_remote_get(self::manifest_url(), [
            'timeout' => 10,
            'headers' => ['Accept' => 'application/json'],
        ]);
        $data = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200
            ? json_decode(wp_remote_retrieve_body($response), true)
            : null;

        $manifest = is_array($data) ? self::validate($data) : null;
        set_site_transient(self::CACHE_KEY, $manifest ?? ['error' => true], $manifest !== null ? self::CACHE_TTL : self::CACHE_TTL_ERROR);

        return $manifest;
    }

    /**
     * @param array<string, mixed> $data
     * @return Manifest|null
     */
    public static function validate(array $data): ?array
    {
        $string = function (string $key) use ($data): string {
            return isset($data[$key]) && is_string($data[$key]) ? $data[$key] : '';
        };

        $version = $string('version');
        $package = $string('package');
        $sha256 = strtolower($string('sha256'));
        $tree = strtolower($string('tree_sha256'));
        $signature = $string('signature');

        if (!preg_match('/^\d+\.\d+\.\d+(-[0-9A-Za-z.]+)?$/', $version)
            || strpos($package, self::package_prefix()) !== 0
            || strpos($package, '..') !== false
            || !preg_match('/^[0-9a-f]{64}$/', $sha256)
            || !preg_match('/^[0-9a-f]{64}$/', $tree)
            || !preg_match('#^[A-Za-z0-9+/]{86}==$#', $signature)) {
            return null;
        }

        $short = function (string $key) use ($string): string {
            return preg_match('/^[0-9.]{1,10}$/', $string($key)) ? $string($key) : '';
        };

        return [
            'version' => $version,
            'package' => $package,
            'sha256' => $sha256,
            'tree_sha256' => $tree,
            'signature' => $signature,
            'requires' => $short('requires'),
            'requires_php' => $short('requires_php'),
            'tested' => $short('tested'),
            'published' => preg_match('/^\d{4}-\d{2}-\d{2}$/', $string('published')) ? $string('published') : '',
            'changelog' => $string('changelog'),
        ];
    }

    /**
     * @return Manifest|null
     */
    private static function fresh_manifest(): ?array
    {
        delete_site_transient(self::CACHE_KEY);

        return self::manifest();
    }

    private static function discard(string $file): void
    {
        if ($file !== '' && is_file($file)) {
            @unlink($file);
        }
    }

    /**
     * Overridable for a test install only (a filter needs code on the site,
     * which can do anything anyway).
     */
    private static function manifest_url(): string
    {
        return (string)apply_filters('analyticswp_update_manifest_url', self::MANIFEST_URL);
    }

    private static function package_prefix(): string
    {
        return (string)apply_filters('analyticswp_update_package_prefix', self::PACKAGE_PREFIX);
    }
}
