<?php

namespace AnalyticsWP\Lib;

/**
 * Device class from the request, decided on the server.
 *
 * Upstream let the browser report its device type. Reading it here means a
 * visitor cannot set it, and server-side events (orders, form submissions)
 * get one too. The rules are upstream's, from analyticswp.js, plus the
 * Sec-CH-UA-Mobile client hint, which Chromium sends instead of a telling
 * user agent on some Android tablets and phones.
 */
class DeviceType
{
    /**
     * @return 'tablet'|'mobile'|'desktop'
     */
    public static function from_user_agent(string $user_agent): string
    {
        $ua = strtolower($user_agent);

        if (preg_match('/tablet|ipad|playbook|silk/', $ua)) {
            return 'tablet';
        }

        if (preg_match('/mobile|iphone|ipod|android|blackberry|mini|windows\sce|palm/', $ua)) {
            return 'mobile';
        }

        if (isset($_SERVER['HTTP_SEC_CH_UA_MOBILE']) && trim((string)$_SERVER['HTTP_SEC_CH_UA_MOBILE']) === '?1') {
            return 'mobile';
        }

        return 'desktop';
    }
}
