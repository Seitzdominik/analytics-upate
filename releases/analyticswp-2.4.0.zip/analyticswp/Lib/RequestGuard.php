<?php

namespace AnalyticsWP\Lib;

/**
 * Who is asking? Visitor IP, origin check and rate limit for the tracking
 * endpoint, which every visitor reaches without logging in.
 *
 * Ported from Pixel Made Simple (PXMS_Request_Guard, 0.19.1), where the
 * approach is tested against page caches, Cloudflare and IPv6 /64 rotation.
 * Nonces are deliberately not used: a cached page serves an expired one, and
 * the tracking endpoint returns no data worth protecting with one.
 */
class RequestGuard
{
    /**
     * Rate limit window in seconds. Each caller names its own limit.
     */
    const RATE_WINDOW = 60;

    /**
     * Cloudflare's address ranges (cloudflare.com/ips-v4 and /ips-v6, as of
     * 2026-10-01). CF-Connecting-IP is only believed for requests from here:
     * any visitor can send that header, it is only genuine when Cloudflare
     * itself forwarded the request.
     */
    const CLOUDFLARE_RANGES = [
        '173.245.48.0/20',
        '103.21.244.0/22',
        '103.22.200.0/22',
        '103.31.4.0/22',
        '141.101.64.0/18',
        '108.162.192.0/18',
        '190.93.240.0/20',
        '188.114.96.0/20',
        '197.234.240.0/22',
        '198.41.128.0/17',
        '162.158.0.0/15',
        '104.16.0.0/13',
        '104.24.0.0/14',
        '172.64.0.0/13',
        '131.0.72.0/22',
        '2400:cb00::/32',
        '2606:4700::/32',
        '2803:f800::/32',
        '2405:b500::/32',
        '2405:8100::/32',
        '2a06:98c0::/29',
        '2c0f:f248::/32',
    ];

    /**
     * Cloudflare's "Pseudo IPv4" replacement addresses (class E). When one of
     * these is in CF-Connecting-IP, the real address is in CF-Connecting-IPv6.
     */
    const PSEUDO_IPV4_RANGE = '240.0.0.0/4';

    /**
     * The visitor's IP address, or '' if the server reports no valid one.
     *
     * REMOTE_ADDR, unless the request comes from Cloudflare: then REMOTE_ADDR
     * is Cloudflare's edge server, and many hosts do not restore the visitor
     * address. X-Forwarded-For is never read, since without knowing which
     * proxy set it any visitor could choose it. A proxy this class does not
     * know can be handled with the `analyticswp_client_ip` filter.
     *
     * The address is used for the rate limit and as one input to the daily
     * visitor hash (Visitor::hash()). It is never stored.
     */
    public static function client_ip(): string
    {
        $remote = self::server_ip('REMOTE_ADDR');
        $ip = $remote;

        if ($remote !== '' && self::from_cloudflare($remote)) {
            $visitor = self::server_ip('HTTP_CF_CONNECTING_IP');

            // Only read CF-Connecting-IPv6 behind a pseudo IPv4 address.
            // Without one in front of it, a visitor could send it themselves.
            if ($visitor !== '' && self::ip_in_range($visitor, self::PSEUDO_IPV4_RANGE)) {
                $real = self::server_ip('HTTP_CF_CONNECTING_IPV6');
                $visitor = ($real !== '' && strpos($real, ':') !== false) ? $real : '';
            }

            if ($visitor !== '') {
                $ip = $visitor;
            }
        }

        /**
         * Override the detected visitor IP, for a proxy in front of the site
         * that this plugin does not know. Only take a header such as
         * X-Forwarded-For when a proxy is certain to set it. An invalid value
         * is discarded.
         *
         * @param string $ip     Detected visitor IP ('' if none).
         * @param string $remote REMOTE_ADDR as the server reports it.
         */
        $filtered = apply_filters('analyticswp_client_ip', $ip, $remote);
        $filtered = is_string($filtered) ? filter_var(trim($filtered), FILTER_VALIDATE_IP) : false;

        return $filtered !== false ? $filtered : $ip;
    }

    /**
     * Does the request come from this site? A browser sends Origin with every
     * POST, so another site that makes its visitors fire events here fails
     * this check. A script outside a browser can forge the header; that is
     * what the rate limit is for.
     *
     * When both Origin and Referer are missing (some privacy extensions strip
     * them), the request passes. "www." does not count as a different host.
     */
    public static function origin_allowed(): bool
    {
        $home = self::bare_host((string)wp_parse_url(home_url(), PHP_URL_HOST));

        foreach (['HTTP_ORIGIN', 'HTTP_REFERER'] as $header) {
            if (empty($_SERVER[$header])) {
                continue;
            }

            $host = self::bare_host((string)wp_parse_url(esc_url_raw(wp_unslash((string)$_SERVER[$header])), PHP_URL_HOST));

            return $host !== '' && $host === $home;
        }

        return true;
    }

    /**
     * Is a URL on this site's host? Used to refuse events for pages that are
     * not on this site.
     */
    public static function is_own_url(string $url): bool
    {
        $home = self::bare_host((string)wp_parse_url(home_url(), PHP_URL_HOST));
        $host = self::bare_host((string)wp_parse_url($url, PHP_URL_HOST));

        return $host !== '' && $host === $home;
    }

    /**
     * @return string
     */
    public static function table_name()
    {
        global $wpdb;
        return $wpdb->prefix . 'analytics_wp_rate_limit';
    }

    /**
     * Create the rate limit table (dbDelta, idempotent). Called from
     * Event::create_table(), whose schema version is the plugin's single
     * migration path.
     *
     * rl_key is the PRIMARY KEY, which is what ON DUPLICATE KEY UPDATE
     * collides on: one bucket and one address make exactly one row.
     */
    public static function create_table(): void
    {
        global $wpdb;

        $table_name = self::table_name();
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table_name} (
            rl_key VARCHAR(64) NOT NULL,
            window_start INT UNSIGNED NOT NULL DEFAULT 0,
            hits INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY  (rl_key),
            KEY window_start (window_start)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Has this visitor IP already sent $limit requests to this bucket within
     * the current window of RATE_WINDOW seconds? This call counts either way.
     *
     * Only a hash of the address is stored (wp_hash(), keyed with the site's
     * salt). IPv6 counts per /64, since a connection practically always has a
     * whole /64 and could otherwise rotate past the limit. Without a visitor
     * IP nothing is limited: one counter for "everyone without an address"
     * would hit the wrong people.
     *
     * @param string $bucket Bucket of the endpoint, a-z, 0-9 and "_" only.
     * @param int    $limit  Maximum requests per window.
     * @return bool True when the request is to be refused.
     */
    public static function rate_limited(string $bucket, int $limit): bool
    {
        $ip = self::client_ip();

        if ($ip === '') {
            return false;
        }

        $key = sanitize_key($bucket) . ':' . substr(wp_hash(self::rate_subject($ip)), 0, 20);

        return self::count_hit($key) > $limit;
    }

    /**
     * Has the endpoint as a whole taken $limit requests in this bucket within
     * the current window? One counter for everyone; counts this call.
     */
    public static function globally_limited(string $bucket, int $limit): bool
    {
        return self::count_hit(sanitize_key($bucket) . ':all') > $limit;
    }

    /** Object cache group of the counters. */
    const CACHE_GROUP = 'analyticswp_rate';

    /**
     * Count this request under $key and return the hits in the current
     * window. With a persistent object cache (Redis, Memcached) in memory,
     * without one in the rate limit table.
     */
    private static function count_hit(string $key): int
    {
        if (wp_using_ext_object_cache()) {
            // Fixed windows: the key carries the window's number.
            $cache_key = $key . ':' . intdiv(time(), self::RATE_WINDOW);
            wp_cache_add($cache_key, 0, self::CACHE_GROUP, 2 * self::RATE_WINDOW);
            $hits = wp_cache_incr($cache_key, 1, self::CACHE_GROUP);
            if (is_int($hits)) {
                return $hits;
            }
        }

        global $wpdb;
        $now = time();
        $table = self::table_name();

        // One atomic query: count up, or start a new window when the stored
        // one began RATE_WINDOW seconds ago or earlier. Arithmetic instead of
        // IF() so that SQLite (WordPress Playground) runs it too. The
        // right-hand columns read the stored values: MySQL assigns left to
        // right, so window_start is still the old one while hits is set.
        $expired = $now - self::RATE_WINDOW;
        $wpdb->query((string)$wpdb->prepare(
            "INSERT INTO `$table` (rl_key, window_start, hits) VALUES (%s, %d, 1) ON DUPLICATE KEY UPDATE hits = (window_start > %d) * hits + 1, window_start = window_start + (window_start <= %d) * (%d - window_start)",
            $key,
            $now,
            $expired,
            $expired,
            $now
        ));

        return (int)$wpdb->get_var((string)$wpdb->prepare("SELECT hits FROM `$table` WHERE rl_key = %s", $key));
    }

    /**
     * Does the server see every visitor under the same private address (a
     * proxy in front that does not pass the visitor's IP on)? Then all
     * visitors share one rate limit and similar visitors one hash.
     */
    public static function shared_address(): bool
    {
        $remote = self::server_ip('REMOTE_ADDR');

        if ($remote === '' || filter_var($remote, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
            return false;
        }

        return self::client_ip() === $remote;
    }

    /**
     * Delete expired windows. Runs on the plugin's daily cron.
     */
    public static function cleanup(): void
    {
        global $wpdb;

        $table = self::table_name();
        $wpdb->query((string)$wpdb->prepare("DELETE FROM `$table` WHERE window_start < %d", time() - self::RATE_WINDOW));
    }

    /**
     * What the rate limit and the visitor hash count by: IPv4 per address,
     * IPv6 per /64.
     */
    public static function rate_subject(string $ip): string
    {
        if (strpos($ip, ':') === false || !function_exists('inet_pton')) {
            return $ip;
        }

        $bin = inet_pton($ip);

        if ($bin === false || strlen($bin) !== 16) {
            return $ip;
        }

        return inet_ntop(substr($bin, 0, 8) . str_repeat("\0", 8)) . '/64';
    }

    /**
     * Is an IP address within a range (CIDR)? IPv4 against an IPv6 range, and
     * the other way round, never matches.
     */
    public static function ip_in_range(string $ip, string $cidr): bool
    {
        $parts = explode('/', $cidr, 2);
        $subnet = $parts[0];

        if (!function_exists('inet_pton') || filter_var($ip, FILTER_VALIDATE_IP) === false || filter_var($subnet, FILTER_VALIDATE_IP) === false) {
            return false;
        }

        $ip_bin = inet_pton($ip);
        $subnet_bin = inet_pton($subnet);

        if ($ip_bin === false || $subnet_bin === false || strlen($ip_bin) !== strlen($subnet_bin)) {
            return false;
        }

        $max = strlen($ip_bin) * 8;
        $bits = isset($parts[1]) ? $parts[1] : (string)$max;

        if (!preg_match('/^\d{1,3}$/', $bits) || (int)$bits > $max) {
            return false;
        }

        $bits = (int)$bits;
        $bytes = intdiv($bits, 8);
        $rest = $bits % 8;

        if ($bytes > 0 && strncmp($ip_bin, $subnet_bin, $bytes) !== 0) {
            return false;
        }

        if ($rest === 0) {
            return true;
        }

        $mask = (0xFF << (8 - $rest)) & 0xFF;

        return (ord($ip_bin[$bytes]) & $mask) === (ord($subnet_bin[$bytes]) & $mask);
    }

    private static function from_cloudflare(string $ip): bool
    {
        foreach (self::CLOUDFLARE_RANGES as $range) {
            if (self::ip_in_range($ip, $range)) {
                return true;
            }
        }

        return false;
    }

    /**
     * A valid IP address from $_SERVER, or ''. IPv4 in IPv6 notation
     * (::ffff:203.0.113.5), as some servers report it, becomes plain IPv4.
     */
    private static function server_ip(string $key): string
    {
        if (empty($_SERVER[$key])) {
            return '';
        }

        $ip = filter_var(trim(sanitize_text_field(wp_unslash((string)$_SERVER[$key]))), FILTER_VALIDATE_IP);

        if ($ip === false) {
            return '';
        }

        if (stripos($ip, '::ffff:') === 0 && filter_var(substr($ip, 7), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
            return substr($ip, 7);
        }

        return $ip;
    }

    /**
     * Host in lower case, without a leading "www.".
     */
    private static function bare_host(string $host): string
    {
        $host = strtolower(trim($host));

        return strpos($host, 'www.') === 0 ? substr($host, 4) : $host;
    }
}
