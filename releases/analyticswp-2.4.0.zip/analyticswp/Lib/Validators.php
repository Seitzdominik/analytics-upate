<?php

namespace AnalyticsWP\Lib;

/**
 * Small type guards for values from options and requests. Upstream had 25
 * of them; these are the ones still in use.
 */
class Validators
{
    /**
     * @param mixed $val
     */
    public static function arr($val): array
    {
        return is_array($val) ? $val : (array)$val;
    }

    /**
     * @param mixed $val
     * @return array<array-key, string>
     */
    public static function array_of_string($val): array
    {
        return array_filter(self::arr($val), 'is_string');
    }

    /**
     * @param mixed $val
     * @return array<string, string>
     */
    public static function array_of_string_keys_and_values($val): array
    {
        $out = [];
        foreach (self::array_of_string($val) as $key => $value) {
            if (is_string($key)) {
                $out[$key] = $value;
            }
        }

        return $out;
    }

    /**
     * "1234.50" with two decimals, for amounts in e-mails and order notes.
     *
     * @param int|float $val
     */
    public static function currency_amount_string($val): string
    {
        return number_format(round((float)$val, 2), 2);
    }
}
