<?php

namespace AnalyticsWP\Lib;

/**
 * One row per session: where it came from (Attribution, decided from its
 * first event) and running totals, so that reports group sessions by channel
 * or campaign without scanning every event.
 *
 * A session ends after Visitor::SESSION_TIMEOUT seconds without a page view,
 * or earlier when a page view arrives from a different campaign, ad click or
 * external referrer (Attribution::starts_new_session()). Other events
 * (orders, forms) join the visitor's latest session of the day.
 *
 * Revenue is not summed here: conversions can be in different currencies.
 * Reports join conversion events (Event revenue/currency) on session_id.
 *
 * @psalm-import-type AttributionData from Attribution
 */
class Sessions
{
    /**
     * @return string
     */
    public static function table_name()
    {
        global $wpdb;
        return $wpdb->prefix . 'analytics_wp_sessions';
    }

    /**
     * Create the table (dbDelta, idempotent). Called from Event::create_table().
     */
    public static function create_table(): void
    {
        global $wpdb;

        $table_name = self::table_name();
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table_name} (
            session_id CHAR(32) NOT NULL,
            visitor_hash VARCHAR(255) NOT NULL,
            started_at DATETIME NOT NULL,
            started_day DATE DEFAULT NULL,
            last_seen_at DATETIME NOT NULL,
            landing_page TEXT DEFAULT NULL,
            exit_page TEXT DEFAULT NULL,
            landing_path VARCHAR(191) DEFAULT NULL,
            exit_path VARCHAR(191) DEFAULT NULL,
            referrer_domain VARCHAR(255) DEFAULT NULL,
            channel VARCHAR(32) NOT NULL DEFAULT 'direct',
            source VARCHAR(255) DEFAULT NULL,
            medium VARCHAR(255) DEFAULT NULL,
            campaign VARCHAR(255) DEFAULT NULL,
            term VARCHAR(255) DEFAULT NULL,
            content VARCHAR(255) DEFAULT NULL,
            click_id_type VARCHAR(16) DEFAULT NULL,
            device_type VARCHAR(16) DEFAULT NULL,
            user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            pageviews INT UNSIGNED NOT NULL DEFAULT 0,
            events INT UNSIGNED NOT NULL DEFAULT 0,
            conversions INT UNSIGNED NOT NULL DEFAULT 0,
            engaged_seconds INT UNSIGNED NOT NULL DEFAULT 0,
            consented TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (session_id),
            KEY visitor_last_seen (visitor_hash, last_seen_at),
            KEY started_at (started_at),
            KEY started_day (started_day),
            KEY channel_started (channel, started_at)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * The session for a new event: the visitor's open session, or a new one
     * that is created here with its attribution. Called by Event::insert()
     * before the event row is written.
     *
     * @param array<string, mixed> $event Event row about to be inserted. Needs
     *                                    unique_session_id and timestamp.
     *
     * @return array{session_id: string, user_id: int|null, is_new: bool}
     */
    public static function for_event(array $event): array
    {
        global $wpdb;
        $table_name = self::table_name();

        $visitor_hash = (string)$event['unique_session_id'];
        $timestamp = (string)$event['timestamp'];
        $page_url = isset($event['page_url']) ? (string)$event['page_url'] : '';
        $referrer = isset($event['referrer']) ? (string)$event['referrer'] : null;

        // Only a page the visitor opened can carry an entry signal. A
        // server-side event (checkout, form) has the page as its URL and no
        // referrer of its own.
        $can_start_session = ($event['event_type'] ?? '') === 'pageview';

        // An event that is not a page view (an order, a form, a click) joins
        // the visitor's latest session of the day even after the timeout:
        // someone who spent 40 minutes on the checkout page still bought
        // because of the campaign that brought them. The visitor hash only
        // lives for a day, so that is as far back as it can reach.
        $window = $can_start_session ? Visitor::SESSION_TIMEOUT : DAY_IN_SECONDS;
        $since = gmdate('Y-m-d H:i:s', (int)strtotime($timestamp . ' UTC') - $window);

        $open = $wpdb->get_row((string)$wpdb->prepare(
            "SELECT * FROM `$table_name` WHERE visitor_hash = %s AND last_seen_at >= %s ORDER BY last_seen_at DESC LIMIT 1",
            $visitor_hash,
            $since
        ), 'ARRAY_A');

        // Consent given during the visit: the first request with the new
        // key takes over the session that ran under today's hash, instead
        // of starting a new one with no origin.
        if (!is_array($open) && Visitor::is_consented_key($visitor_hash)) {
            $open = self::adopt_daily_session($visitor_hash, $since);
        }

        if (is_array($open) && !($can_start_session && Attribution::starts_new_session($open, $page_url, $referrer))) {
            $user_id = isset($open['user_id']) ? (int)$open['user_id'] : 0;
            return [
                'session_id' => (string)$open['session_id'],
                'user_id' => $user_id > 0 ? $user_id : null,
                'is_new' => false,
            ];
        }

        $session_id = bin2hex(random_bytes(16));
        $attribution = Attribution::from_landing($page_url, $referrer);

        $wpdb->insert($table_name, array_merge($attribution, [
            'session_id' => $session_id,
            'visitor_hash' => $visitor_hash,
            'started_at' => $timestamp,
            // The day in the site's time zone, fixed at the start. Reports
            // group by it; the visitor hash changes at the same midnight.
            'started_day' => wp_date('Y-m-d', (int)strtotime($timestamp . ' UTC')),
            'last_seen_at' => $timestamp,
            'landing_page' => $page_url !== '' ? URLs::strip_query($page_url) : null,
            'landing_path' => URLs::path_of($page_url),
            'device_type' => isset($event['device_type']) ? (string)$event['device_type'] : null,
            'user_id' => !empty($event['user_id']) ? (int)$event['user_id'] : null,
            'consented' => Visitor::is_consented_key($visitor_hash) ? 1 : 0,
        ]));

        return [
            'session_id' => $session_id,
            'user_id' => null,
            'is_new' => true,
        ];
    }

    /**
     * A session of its own for an event that is not a visitor's (cron, an
     * admin screen, a webhook): it must not join, or be credited to, the
     * latest session of whoever shares the server's or admin's hash.
     *
     * @param array<string, mixed> $event
     * @return array{session_id: string, user_id: int|null, is_new: bool}
     */
    public static function isolated(array $event): array
    {
        global $wpdb;

        $session_id = bin2hex(random_bytes(16));
        $timestamp = (string)$event['timestamp'];

        $wpdb->insert(self::table_name(), [
            'session_id' => $session_id,
            'visitor_hash' => (string)$event['unique_session_id'],
            'started_at' => $timestamp,
            'started_day' => wp_date('Y-m-d', (int)strtotime($timestamp . ' UTC')),
            'last_seen_at' => $timestamp,
            'channel' => Attribution::DIRECT,
            'device_type' => isset($event['device_type']) ? (string)$event['device_type'] : null,
        ]);

        return ['session_id' => $session_id, 'user_id' => null, 'is_new' => true];
    }

    /**
     * Move today's sessions and events of the current request's daily hash
     * to the consented key, and return the open one among them.
     *
     * @return array<string, mixed>|null
     */
    private static function adopt_daily_session(string $key, string $since): ?array
    {
        global $wpdb;
        $table_name = self::table_name();
        $events = Event::table_name();
        $daily = Visitor::hash();

        $open = $wpdb->get_row((string)$wpdb->prepare(
            "SELECT * FROM `$table_name` WHERE visitor_hash = %s AND last_seen_at >= %s ORDER BY last_seen_at DESC LIMIT 1",
            $daily,
            $since
        ), 'ARRAY_A');

        if (!is_array($open)) {
            return null;
        }

        $wpdb->query((string)$wpdb->prepare("UPDATE `$table_name` SET visitor_hash = %s, consented = 1 WHERE visitor_hash = %s", $key, $daily));
        $wpdb->query((string)$wpdb->prepare("UPDATE `$events` SET unique_session_id = %s WHERE unique_session_id = %s", $key, $daily));

        $open['visitor_hash'] = $key;
        return $open;
    }

    /**
     * Days a conversion looks back for the visits that led to it.
     */
    const LOOKBACK_DAYS = 30;

    /**
     * The visits a conversion is attributed to: the latest one with an
     * origin other than "direct" (or the converting one, if there is
     * none), and the first one, both within LOOKBACK_DAYS. Without consent
     * a visitor key only lives for a day, so that is as far back as it
     * reaches; with consent it spans days.
     *
     * @return array{last: string, first: string}
     */
    public static function attribution_for_conversion(string $visitor_hash, string $session_id, string $timestamp): array
    {
        global $wpdb;
        $table_name = self::table_name();

        $since = gmdate('Y-m-d H:i:s', (int)strtotime($timestamp . ' UTC') - self::LOOKBACK_DAYS * DAY_IN_SECONDS);
        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT session_id, channel FROM `$table_name` WHERE visitor_hash = %s AND started_at >= %s AND started_at <= %s ORDER BY started_at DESC LIMIT 100",
            $visitor_hash,
            $since,
            $timestamp
        ), 'ARRAY_A');

        $last = $session_id;
        $first = $session_id;
        $found_last = false;
        foreach (is_array($rows) ? $rows : [] as $row) {
            if (!$found_last && $row['channel'] !== Attribution::DIRECT) {
                $last = (string)$row['session_id'];
                $found_last = true;
            }
            $first = (string)$row['session_id'];
        }

        return ['last' => $last, 'first' => $first];
    }

    /**
     * Count an event that was just written into its session's totals.
     *
     * @param array<string, mixed> $event The inserted event row.
     */
    public static function record_event(array $event): void
    {
        global $wpdb;
        $table_name = self::table_name();

        $is_pageview = ($event['event_type'] ?? '') === 'pageview';
        $is_conversion = !empty($event['conversion_type']);
        $user_id = !empty($event['user_id']) ? (int)$event['user_id'] : 0;

        $sets = [
            'last_seen_at = %s',
            'events = events + 1',
        ];
        $values = [(string)$event['timestamp']];

        if ($is_pageview) {
            $sets[] = 'pageviews = pageviews + 1';
            $sets[] = 'exit_page = %s';
            $values[] = URLs::strip_query((string)($event['page_url'] ?? ''));
            $sets[] = 'exit_path = %s';
            $values[] = (string)URLs::path_of((string)($event['page_url'] ?? ''));
        }
        if ($is_conversion) {
            $sets[] = 'conversions = conversions + 1';
        }
        if ($user_id > 0) {
            $sets[] = 'user_id = %d';
            $values[] = $user_id;
        }

        $values[] = (string)$event['session_id'];

        $wpdb->query((string)$wpdb->prepare(
            "UPDATE `$table_name` SET " . implode(', ', $sets) . " WHERE session_id = %s",
            ...$values
        ));
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function find(string $session_id): ?array
    {
        global $wpdb;
        $table_name = self::table_name();

        $row = $wpdb->get_row((string)$wpdb->prepare("SELECT * FROM `$table_name` WHERE session_id = %s", $session_id), 'ARRAY_A');

        return is_array($row) ? $row : null;
    }
}
