<?php

namespace AnalyticsWP\Lib;

/**
 * Is the current request from a bot?
 *
 * Uses DeviceDetector's bot list, precompiled into one regex (BotPattern,
 * built by dev-tools/build-bot-pattern.php). DeviceDetector itself parses
 * its 125 KB bots.yml on every request (about 23 ms on the test site),
 * which the tracking endpoint pays for every page view. The result is the
 * same as DeviceDetector's Bot parser with discardDetails()
 * (dev-tools/tests/bot-test.php compares them).
 */
class BotDetection
{
    /**
     * Clients DeviceDetector does not count as bots, but that are never a
     * visitor of a page: headless browsers (Lighthouse, scrapers), HTTP
     * libraries and link preview fetchers.
     */
    const AUTOMATION_PATTERN = '/HeadlessChrome|PhantomJS|Puppeteer|Playwright|Selenium|\bcurl\/|Wget\/|python-|aiohttp|Go-http-client|okhttp|\bJava\/|node-fetch|axios\/|undici|libwww|HttpClient|Scrapy|PostmanRuntime|insomnia|WhatsApp\//i';

    /**
     * @param array<string, mixed> $request Unused; kept for the signature upstream callers use.
     */
    public static function should_block_current_request(array $request): bool
    {
        return self::is_bot();
    }

    public static function is_bot(): bool
    {
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? (string)$_SERVER['HTTP_USER_AGENT'] : '';
        return self::is_bot_by_user_agent($user_agent);
    }

    /**
     * @param string|null $user_agent
     */
    public static function is_bot_by_user_agent($user_agent): bool
    {
        $user_agent = trim((string)$user_agent);

        // Every browser sends a user agent; scripts often do not.
        if ($user_agent === '') {
            return true;
        }

        // A prerendering or prefetching browser is not a visitor yet.
        if (isset($_SERVER['HTTP_SEC_PURPOSE']) && stripos((string)$_SERVER['HTTP_SEC_PURPOSE'], 'prefetch') !== false) {
            return true;
        }

        return preg_match(self::AUTOMATION_PATTERN, $user_agent) === 1
            || preg_match(BotPattern::PATTERN, $user_agent) === 1;
    }
}
