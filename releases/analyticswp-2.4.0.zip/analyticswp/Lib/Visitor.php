<?php

namespace AnalyticsWP\Lib;

/**
 * Cookieless visitor and session identification.
 *
 * Nothing is stored on, or read from, the visitor's device. Instead the
 * server derives a visitor hash from the request: IP address (IPv6 per /64),
 * user agent and the site's host, keyed with a random salt that changes
 * every day. The salt of the previous day is deleted when the new one is
 * created, so a hash cannot be linked to the next day's hash, nor turned
 * back into an IP address.
 *
 * The hash goes into the `unique_session_id` column, which upstream filled
 * with a 365-day ID from a cookie and localStorage. A visitor is therefore
 * recognised for one day at most. Sessions (see Sessions) are cut after
 * SESSION_TIMEOUT seconds without an event, and get their own random
 * `session_id`.
 *
 * A server-side event (an order, a form submission) that runs in the
 * visitor's own request computes the same hash, and so lands in the same
 * session as the pageviews before it.
 */
class Visitor
{
    /**
     * A session ends after this many seconds without an event.
     */
    const SESSION_TIMEOUT = 1800;

    /**
     * Option name prefix of the daily salt. One option per day; earlier days
     * are deleted.
     */
    const SALT_OPTION_PREFIX = 'analyticswp_salt_';

    /** @var array<string, string> */
    private static $salts = [];

    /**
     * Who the current request belongs to, as stored in unique_session_id
     * and sessions.visitor_hash: with consent to statistics a stable key
     * from the visitor's awp_vid cookie ("k" + 31 hex), otherwise the
     * daily hash (32 hex). See Consent.
     */
    public static function key(): string
    {
        $visitor_id = Consent::visitor_id();
        if ($visitor_id !== '') {
            return 'k' . substr(wp_hash('awp_vid|' . $visitor_id), 0, 31);
        }

        return self::hash();
    }

    public static function is_consented_key(string $key): bool
    {
        return strlen($key) === 32 && $key[0] === 'k';
    }

    /**
     * The daily visitor hash for the current request, 32 hex characters.
     */
    public static function hash(): string
    {
        $ip = RequestGuard::client_ip();
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? (string)wp_unslash($_SERVER['HTTP_USER_AGENT']) : '';
        $host = (string)wp_parse_url(home_url(), PHP_URL_HOST);

        $subject = ($ip !== '' ? RequestGuard::rate_subject($ip) : '') . '|' . $user_agent . '|' . $host;

        return substr(hash_hmac('sha256', $subject, self::daily_salt()), 0, 32);
    }

    /**
     * Today's salt (site time zone), created on first use.
     *
     * The option is written with INSERT IGNORE rather than add_option():
     * add_option() ends in ON DUPLICATE KEY UPDATE, so two requests racing
     * past midnight would each store their own salt, and the visitors of the
     * first would get a second hash. With INSERT IGNORE the first one wins and
     * every request reads it back.
     */
    public static function daily_salt(): string
    {
        $day = wp_date('Ymd');
        $day = is_string($day) ? $day : gmdate('Ymd');

        if (isset(self::$salts[$day])) {
            return self::$salts[$day];
        }

        global $wpdb;
        $name = self::SALT_OPTION_PREFIX . $day;

        $salt = self::read_salt($name);

        if ($salt === '') {
            $wpdb->query((string)$wpdb->prepare(
                "INSERT IGNORE INTO `{$wpdb->options}` (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
                $name,
                bin2hex(random_bytes(32))
            ));

            $salt = self::read_salt($name);

            // Forget every earlier day: from here on yesterday's hashes can no
            // longer be reproduced.
            $wpdb->query((string)$wpdb->prepare(
                "DELETE FROM `{$wpdb->options}` WHERE option_name LIKE %s AND option_name <> %s",
                $wpdb->esc_like(self::SALT_OPTION_PREFIX) . '%',
                $name
            ));
        }

        if ($salt === '') {
            // The database refused the write. A per-request salt still keeps
            // the IP address out of the table; the visitor just is not
            // recognised on the next request.
            error_log('AnalyticsWP: could not store the daily salt.');
            $salt = bin2hex(random_bytes(32));
        }

        self::$salts[$day] = $salt;

        return $salt;
    }

    /**
     * Read a salt option straight from the table. get_option() would go
     * through the object cache, which may still hold a value another request
     * lost the race with.
     */
    private static function read_salt(string $name): string
    {
        global $wpdb;

        $value = $wpdb->get_var((string)$wpdb->prepare(
            "SELECT option_value FROM `{$wpdb->options}` WHERE option_name = %s",
            $name
        ));

        return (is_string($value) && strlen($value) === 64) ? $value : '';
    }
}
