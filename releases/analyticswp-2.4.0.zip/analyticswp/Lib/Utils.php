<?php

namespace AnalyticsWP\Lib;

class Utils
{
    /**
     * Is the logged-in user in a role that is not tracked (setting
     * "disabled-tracking-user-roles")? Visitors who are not logged in never
     * are.
     */
    public static function is_current_user_excluded_from_tracking(): bool
    {
        $current_user = wp_get_current_user();
        if ($current_user->ID == 0) {
            return false;
        }

        $excluded_user_roles = Validators::array_of_string_keys_and_values(SuperSimpleWP::get_setting('analyticswp', 'disabled-tracking-user-roles'));
        foreach ($current_user->roles as $role) {
            if (isset($excluded_user_roles[$role])) {
                return true;
            }
        }

        return false;
    }
}
