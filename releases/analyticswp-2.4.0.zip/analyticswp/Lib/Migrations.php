<?php

namespace AnalyticsWP\Lib;

/**
 * Data migrations between schema versions (Event::DB_VERSION), and the
 * plugin's daily housekeeping.
 *
 * Schema changes themselves happen in Event::create_table() (dbDelta);
 * this class changes rows. Work that can touch every row of the event table
 * runs in batches on WP-Cron, so that an upgrade on a large site does not
 * hang the request that triggered it.
 */
class Migrations
{
    const DAILY_HOOK = 'analyticswp_daily';
    const SCRUB_HOOK = 'analyticswp_scrub_personal_data';
    const PATHS_HOOK = 'analyticswp_backfill_paths';

    /** Options holding the highest IDs still without a path. */
    const PATHS_EVENTS_CURSOR = 'analyticswp_paths_events_cursor';
    const PATHS_SESSIONS_DONE = 'analyticswp_paths_sessions_done';

    /** Option holding the highest event ID still to be scrubbed. */
    const SCRUB_CURSOR_OPTION = 'analyticswp_scrub_cursor';

    /** Rows per UPDATE, and the time budget of one cron run in seconds. */
    const SCRUB_BATCH = 10000;
    const SCRUB_TIME_BUDGET = 20;

    public static function init(): void
    {
        add_action(self::DAILY_HOOK, [self::class, 'daily']);
        add_action(self::SCRUB_HOOK, [self::class, 'scrub_personal_data']);
        add_action(self::PATHS_HOOK, [self::class, 'backfill_paths']);
        Retention::init();

        if (wp_next_scheduled(self::DAILY_HOOK) === false) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::DAILY_HOOK);
        }
    }

    /**
     * Run every migration above $from. Called once per schema change by
     * Event::create_table_if_necessary(), after the tables are up to date.
     *
     * @param int $from Installed schema version, 0 on a fresh install.
     */
    public static function run(int $from): void
    {
        if ($from >= 1 && $from < 2) {
            self::to_2();
        }

        if ($from >= 3 && $from < 4) {
            self::to_4();
        }

        if ($from >= 1 && $from < 6) {
            self::to_6();
        }

        if ($from >= 1 && $from < 7) {
            self::to_7();
        }

        if ($from >= 7 && $from < 8) {
            self::to_8();
        }
    }

    /**
     * Version 2, cookieless tracking.
     *
     * Upstream stored the full IP address and, for logged-in visitors and
     * orders, the e-mail address on every event, and kept page URLs and
     * referrers with their whole query string. IP and e-mail are cleared,
     * URLs reduced as new events are (URLs::strip_private_query() and
     * strip_query()). The visitor's ID from the old cookie stays; it cannot
     * be tied back to a person without the browser that held it. Agency
     * Mode's hourly e-mail report cron is removed.
     */
    private static function to_2(): void
    {
        global $wpdb;
        $table_name = Event::table_name();

        wp_clear_scheduled_hook('analyticswp_trigger_email_reports');

        $max_id = (int)$wpdb->get_var("SELECT MAX(id) FROM `$table_name`");
        if ($max_id > 0) {
            update_option(self::SCRUB_CURSOR_OPTION, $max_id, false);
            if (wp_next_scheduled(self::SCRUB_HOOK) === false) {
                wp_schedule_single_event(time(), self::SCRUB_HOOK);
            }
        }
    }

    /**
     * Version 4: the local start day of sessions recorded under version 3.
     * Uses the site's current UTC offset; sessions from before a daylight
     * saving change may land an hour off at midnight, which only concerns
     * the few days of test data that version 3 ever recorded.
     */
    private static function to_4(): void
    {
        global $wpdb;
        $table_name = Sessions::table_name();

        // gmt_offset is empty when the site uses a named zone (Europe/Berlin).
        $offset = wp_timezone()->getOffset(new \DateTime('now', new \DateTimeZone('UTC')));
        $wpdb->query((string)$wpdb->prepare(
            "UPDATE `$table_name` SET started_day = DATE(DATE_ADD(started_at, INTERVAL %d SECOND)) WHERE started_day IS NULL",
            $offset
        ));
    }

    /**
     * Version 6: drop upstream indexes that only cost insert time.
     */
    private static function to_6(): void
    {
        global $wpdb;
        $table_name = Event::table_name();

        foreach (['idx_usession', 'idx_user_id', 'idx_event_type', 'idx_session_user_timestamp', 'idx_event_type_user_id_timestamp'] as $index) {
            if (Event::index_exists($table_name, $index)) {
                $wpdb->query("DROP INDEX $index ON `$table_name`");
            }
        }
    }

    /**
     * Version 7, after the security audit: drop the cached order source
     * blocks (they could hold injected markup, rendered for 30 days), clear
     * stored user agents (with today's salt they let a database dump be
     * brute-forced back to IP addresses), forget cached reports.
     */
    private static function to_7(): void
    {
        global $wpdb;
        $table_name = Event::table_name();

        $wpdb->query((string)$wpdb->prepare(
            "DELETE FROM `{$wpdb->options}` WHERE option_name LIKE %s OR option_name LIKE %s",
            $wpdb->esc_like('_transient_analyticswp_cache_') . '%',
            $wpdb->esc_like('_transient_timeout_analyticswp_cache_') . '%'
        ));

        $max_id = (int)$wpdb->get_var("SELECT MAX(id) FROM `$table_name`");
        if ($max_id > 0) {
            update_option(self::SCRUB_CURSOR_OPTION, $max_id, false);
            if (wp_next_scheduled(self::SCRUB_HOOK) === false) {
                wp_schedule_single_event(time(), self::SCRUB_HOOK);
            }
        }

        // Paths for the rows recorded before the columns existed.
        $max_event = (int)$wpdb->get_var("SELECT MAX(id) FROM `$table_name`");
        update_option(self::PATHS_EVENTS_CURSOR, $max_event, false);
        delete_option(self::PATHS_SESSIONS_DONE);
        if (wp_next_scheduled(self::PATHS_HOOK) === false) {
            wp_schedule_single_event(time(), self::PATHS_HOOK);
        }

        Reports::flush_cache();
    }

    /**
     * Version 8: the pages index became a covering one under a new name.
     */
    private static function to_8(): void
    {
        global $wpdb;
        $table_name = Event::table_name();

        if (Event::index_exists($table_name, 'idx_type_time_path')) {
            $wpdb->query("DROP INDEX idx_type_time_path ON `$table_name`");
        }
        Reports::flush_cache();
    }

    /**
     * Fill events.path and sessions.landing_path/exit_path for rows from
     * before schema 7, on WP-Cron, as set-based UPDATEs in ID ranges (the
     * same reduction as URLs::path_of() in SQL: this site's address cut
     * off, query string and fragment dropped, 191 characters).
     */
    public static function backfill_paths(): void
    {
        global $wpdb;
        $events = Event::table_name();
        $sessions = Sessions::table_name();
        $started = time();
        $home = untrailingslashit(home_url());

        $path_sql = function (string $column) use ($wpdb, $home): string {
            return (string)$wpdb->prepare(
                "LEFT(COALESCE(NULLIF(SUBSTRING_INDEX(SUBSTRING_INDEX(REPLACE($column, %s, ''), '?', 1), '#', 1), ''), '/'), 191)",
                $home
            );
        };

        if (!get_option(self::PATHS_SESSIONS_DONE)) {
            do {
                $updated = $wpdb->query(
                    "UPDATE `$sessions` SET landing_path = " . $path_sql('landing_page') . ", exit_path = IF(exit_page IS NULL, NULL, " . $path_sql('exit_page') . ")
                     WHERE landing_path IS NULL AND landing_page IS NOT NULL LIMIT 20000"
                );
            } while ($updated && (time() - $started) < self::SCRUB_TIME_BUDGET);

            if ($updated === 0) {
                update_option(self::PATHS_SESSIONS_DONE, 1, false);
            }
        }

        $cursor = (int)get_option(self::PATHS_EVENTS_CURSOR, 0);
        while ($cursor > 0 && (time() - $started) < self::SCRUB_TIME_BUDGET) {
            $low = max(1, $cursor - 20000 + 1);
            $wpdb->query((string)$wpdb->prepare(
                "UPDATE `$events` SET path = " . $path_sql('page_url') . " WHERE id BETWEEN %d AND %d AND path IS NULL AND page_url IS NOT NULL",
                $low,
                $cursor
            ));
            $cursor = $low - 1;
            update_option(self::PATHS_EVENTS_CURSOR, $cursor, false);
        }

        if ($cursor > 0 || !get_option(self::PATHS_SESSIONS_DONE)) {
            if (wp_next_scheduled(self::PATHS_HOOK) === false) {
                wp_schedule_single_event(time() + MINUTE_IN_SECONDS, self::PATHS_HOOK);
            }
        } else {
            delete_option(self::PATHS_EVENTS_CURSOR);
            Reports::flush_cache();
        }
    }

    /**
     * Clear ip_address and user_email and reduce stored URLs, working down
     * from the cursor in ID ranges (portable to SQLite, unlike
     * UPDATE ... LIMIT). Reschedules itself until the cursor reaches 0.
     * Events recorded after the upgrade are stored this way already, so only
     * IDs up to the cursor matter.
     */
    public static function scrub_personal_data(): void
    {
        global $wpdb;
        $table_name = Event::table_name();

        $cursor = (int)get_option(self::SCRUB_CURSOR_OPTION, 0);
        $started = time();

        while ($cursor > 0 && (time() - $started) < self::SCRUB_TIME_BUDGET) {
            $low = max(1, $cursor - self::SCRUB_BATCH + 1);

            $result = $wpdb->query((string)$wpdb->prepare(
                "UPDATE `$table_name` SET ip_address = NULL, user_email = NULL, user_agent = NULL WHERE id BETWEEN %d AND %d AND (ip_address IS NOT NULL OR user_email IS NOT NULL OR user_agent IS NOT NULL)",
                $low,
                $cursor
            ));

            if ($result === false) {
                error_log('AnalyticsWP: scrubbing personal data failed: ' . $wpdb->last_error);
                break;
            }

            self::reduce_urls($low, $cursor);

            $cursor = $low - 1;
            update_option(self::SCRUB_CURSOR_OPTION, $cursor, false);
        }

        if ($cursor > 0) {
            if (wp_next_scheduled(self::SCRUB_HOOK) === false) {
                wp_schedule_single_event(time() + MINUTE_IN_SECONDS, self::SCRUB_HOOK);
            }
        } else {
            delete_option(self::SCRUB_CURSOR_OPTION);
        }
    }

    /**
     * Rewrite page URLs and referrers with a query string or fragment in an
     * ID range. Row by row, since the reduction is done in PHP; only rows
     * that change are written.
     */
    private static function reduce_urls(int $low, int $high): void
    {
        global $wpdb;
        $table_name = Event::table_name();

        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT id, page_url, referrer FROM `$table_name` WHERE id BETWEEN %d AND %d AND (page_url LIKE %s OR page_url LIKE %s OR referrer LIKE %s OR referrer LIKE %s)",
            $low,
            $high,
            '%?%',
            '%#%',
            '%?%',
            '%#%'
        ), 'ARRAY_A');

        foreach (is_array($rows) ? $rows : [] as $row) {
            $page_url = is_string($row['page_url']) ? URLs::strip_private_query($row['page_url']) : null;
            $referrer = is_string($row['referrer']) ? URLs::strip_query($row['referrer']) : null;

            if ($page_url === $row['page_url'] && $referrer === $row['referrer']) {
                continue;
            }

            $wpdb->update(
                $table_name,
                ['page_url' => $page_url, 'referrer' => $referrer],
                ['id' => (int)$row['id']]
            );
        }
    }

    /**
     * Daily housekeeping.
     */
    public static function daily(): void
    {
        RequestGuard::cleanup();
        Retention::run();
    }

    /**
     * Remove the plugin's cron events. Called on deactivation.
     */
    public static function unschedule(): void
    {
        wp_clear_scheduled_hook(self::DAILY_HOOK);
        wp_clear_scheduled_hook(self::SCRUB_HOOK);
        wp_clear_scheduled_hook(self::PATHS_HOOK);
        wp_clear_scheduled_hook(Retention::HOOK);
        wp_clear_scheduled_hook('analyticswp_trigger_email_reports');
    }
}
