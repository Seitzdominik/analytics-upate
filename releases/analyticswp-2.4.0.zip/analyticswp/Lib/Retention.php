<?php

namespace AnalyticsWP\Lib;

/**
 * Deletes visits and events older than the retention period (setting
 * "retention_months"). Runs on the plugin's daily cron; a large backlog,
 * such as the first run after an update, is worked off in batches with a
 * follow-up run every few minutes.
 *
 * Deleted are the raw events and sessions themselves. A conversion inside
 * the period whose first visit lies before the cutoff keeps its last-touch
 * source; only "first visit" no longer resolves for it.
 */
class Retention
{
    const HOOK = 'analyticswp_retention';

    /** Months => label. 0 keeps everything. */
    const CHOICES = [
        6 => '6 Monate',
        13 => '13 Monate',
        25 => '25 Monate',
        38 => '38 Monate',
        0 => 'Nie automatisch löschen',
    ];

    const DEFAULT_MONTHS = 25;

    /** Rows per DELETE, and the time budget of one run in seconds. */
    const BATCH = 5000;
    const TIME_BUDGET = 20;

    public static function init(): void
    {
        add_action(self::HOOK, [self::class, 'run']);
    }

    public static function months(): int
    {
        $value = SuperSimpleWP::get_setting('analyticswp', 'retention_months');
        $months = is_numeric($value) ? (int)$value : self::DEFAULT_MONTHS;

        return array_key_exists($months, self::CHOICES) ? $months : self::DEFAULT_MONTHS;
    }

    /**
     * Rows before this UTC time are deleted; null when nothing is.
     */
    public static function cutoff(): ?string
    {
        $months = self::months();
        if ($months === 0) {
            return null;
        }

        return gmdate('Y-m-d H:i:s', (int)strtotime("-$months months", time()));
    }

    public static function run(): void
    {
        global $wpdb;

        $cutoff = self::cutoff();
        if ($cutoff === null) {
            return;
        }

        $started = time();
        $deleted = 0;
        $more = false;

        // Both on an indexed column (idx_timestamp, started_at).
        $targets = [
            [Event::table_name(), 'timestamp'],
            [Sessions::table_name(), 'started_at'],
        ];

        foreach ($targets as [$table, $column]) {
            while (true) {
                $result = $wpdb->query((string)$wpdb->prepare(
                    "DELETE FROM `$table` WHERE `$column` < %s LIMIT %d",
                    $cutoff,
                    self::BATCH
                ));

                if ($result === false) {
                    error_log('AnalyticsWP: retention cleanup failed: ' . $wpdb->last_error);
                    break 2;
                }

                $deleted += (int)$result;

                if ((int)$result < self::BATCH) {
                    break;
                }

                if (time() - $started >= self::TIME_BUDGET) {
                    $more = true;
                    break 2;
                }
            }
        }

        if ($deleted > 0) {
            Reports::flush_cache();
        }

        if ($more && wp_next_scheduled(self::HOOK) === false) {
            wp_schedule_single_event(time() + 5 * MINUTE_IN_SECONDS, self::HOOK);
        }
    }
}
