<?php

namespace AnalyticsWP\Lib;

/**
 * WordPress' personal data tools (Tools > Export/Erase Personal Data).
 *
 * Cookieless data cannot be tied to a person: the daily hash is gone with
 * its salt. What can be is the user ID on events and sessions, stored only
 * with the setting "link_logged_in_users", and before the fork by upstream.
 * The eraser removes the link (user ID); the visits stay as anonymous ones,
 * so totals do not change. The exporter lists the visits linked to the user.
 */
class Privacy
{
    const SLUG = 'analyticswp';

    public static function init(): void
    {
        add_filter('wp_privacy_personal_data_exporters', function ($exporters) {
            $exporters[self::SLUG] = [
                'exporter_friendly_name' => 'Analytics (Besuche)',
                'callback' => [self::class, 'export'],
            ];
            return $exporters;
        });

        add_filter('wp_privacy_personal_data_erasers', function ($erasers) {
            $erasers[self::SLUG] = [
                'eraser_friendly_name' => 'Analytics (Besuche)',
                'callback' => [self::class, 'erase'],
            ];
            return $erasers;
        });

        add_action('admin_init', function () {
            if (function_exists('wp_add_privacy_policy_content')) {
                wp_add_privacy_policy_content('AnalyticsWP', self::policy_html());
            }
        });
    }

    /**
     * Suggested text for the site's privacy policy, built from the current
     * settings: whether consent can extend recognition across days, whether
     * logged-in users are linked, the retention period. Shown in the
     * settings and in WordPress' privacy policy guide.
     *
     * @return list<string> Paragraphs; the first is the heading.
     */
    public static function policy_paragraphs(): array
    {
        $engagement = (bool)SuperSimpleWP::get_setting('analyticswp', 'engagement_tracking');
        $consent_tier = Consent::mhc_active() && (bool)SuperSimpleWP::get_setting('analyticswp', 'multi_day_with_consent');
        $link_users = (bool)SuperSimpleWP::get_setting('analyticswp', 'link_logged_in_users');
        $months = Retention::months();

        $collected = 'aufgerufene Seiten, die verweisende Website, Kampagnenparameter in der Adresse (etwa utm_source) und Klick-Kennungen von Werbenetzwerken, der Gerätetyp (Desktop, Tablet oder Smartphone)';
        if ($engagement) {
            $collected .= ', die aktive Verweildauer und Scrolltiefe, Klicks auf externe Links, Downloads und Kontaktlinks (Telefon, E-Mail, WhatsApp)';
        }
        $collected .= ' sowie abgeschlossene Bestellungen und abgesendete Formulare, ohne deren Inhalte';

        $paragraphs = [
            'Reichweitenmessung mit AnalyticsWP',
            'Diese Website misst ihre Nutzung mit dem WordPress-Plugin AnalyticsWP. Die Messung läuft vollständig auf dem Server dieser Website; es werden keine Daten an Dritte übermittelt.',
            'Erfasst werden ' . $collected . '.',
            'Dabei werden keine Cookies gesetzt und keine Daten dauerhaft im Browser gespeichert. Um Seitenaufrufe zu einem Besuch zusammenzufassen, wird aus der IP-Adresse, der Browserkennung (User-Agent) und einem täglich neu erzeugten Zufallswert ein Hashwert gebildet. IP-Adresse und Browserkennung selbst werden nicht gespeichert. Der Zufallswert wird nach einem Tag gelöscht; danach lässt sich der Hashwert weder zurückrechnen noch einem späteren Besuch zuordnen.',
            'Rechtsgrundlage ist das berechtigte Interesse an der Auswertung und Verbesserung dieser Website (Art. 6 Abs. 1 lit. f DSGVO).',
        ];

        if ($consent_tier) {
            $paragraphs[] = 'Mit Einwilligung (Kategorie „Statistik“ im Cookie-Hinweis) setzt AnalyticsWP zusätzlich das Cookie „awp_vid“ mit einer zufälligen Kennung und einer Speicherdauer von 13 Monaten. Damit lässt sich eine Bestellung oder Anfrage auch Tage später dem ursprünglichen Besuch, etwa über eine Anzeige, zuordnen. Rechtsgrundlage ist die Einwilligung (Art. 6 Abs. 1 lit. a DSGVO, § 25 Abs. 1 TDDDG). Sie kann jederzeit über den Cookie-Hinweis widerrufen werden; das Cookie wird dann gelöscht.';
        }

        if ($link_users) {
            $paragraphs[] = 'Bei angemeldeten Nutzern werden Besuche dem Benutzerkonto zugeordnet, um Kundenverläufe nachvollziehen zu können (Art. 6 Abs. 1 lit. f DSGVO). Diese Zuordnung kann jederzeit mit einer Löschanfrage aufgehoben werden.';
        }

        $paragraphs[] = $months > 0
            ? 'Die erfassten Daten werden nach ' . $months . ' Monaten automatisch gelöscht.'
            : 'Die erfassten Daten werden gespeichert, bis sie manuell gelöscht werden.';

        return $paragraphs;
    }

    public static function policy_text(): string
    {
        return implode("\n\n", self::policy_paragraphs());
    }

    public static function policy_html(): string
    {
        $paragraphs = self::policy_paragraphs();
        $html = '<h2>' . esc_html((string)array_shift($paragraphs)) . '</h2>';
        foreach ($paragraphs as $paragraph) {
            $html .= '<p>' . esc_html($paragraph) . '</p>';
        }

        return $html;
    }

    /**
     * @return array{data: list<array<string, mixed>>, done: bool}
     */
    public static function export(string $email, int $page = 1): array
    {
        global $wpdb;
        $user = get_user_by('email', $email);
        if (!$user) {
            return ['data' => [], 'done' => true];
        }

        $per_page = 200;
        $rows = $wpdb->get_results((string)$wpdb->prepare(
            "SELECT session_id, started_at, channel, source, medium, campaign, landing_page, pageviews, conversions FROM `" . Sessions::table_name() . "` WHERE user_id = %d ORDER BY started_at LIMIT %d OFFSET %d",
            $user->ID,
            $per_page,
            ($page - 1) * $per_page
        ), 'ARRAY_A');

        $data = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            $data[] = [
                'group_id' => 'analyticswp-visits',
                'group_label' => 'Besuche (Analytics)',
                'item_id' => 'visit-' . $row['session_id'],
                'data' => [
                    ['name' => 'Beginn (UTC)', 'value' => (string)$row['started_at']],
                    ['name' => 'Kanal', 'value' => (string)$row['channel']],
                    ['name' => 'Quelle', 'value' => (string)$row['source']],
                    ['name' => 'Medium', 'value' => (string)$row['medium']],
                    ['name' => 'Kampagne', 'value' => (string)$row['campaign']],
                    ['name' => 'Einstiegsseite', 'value' => (string)$row['landing_page']],
                    ['name' => 'Seitenaufrufe', 'value' => (string)$row['pageviews']],
                    ['name' => 'Conversions', 'value' => (string)$row['conversions']],
                ],
            ];
        }

        return ['data' => $data, 'done' => count($data) < $per_page];
    }

    /**
     * @return array{items_removed: bool, items_retained: bool, messages: list<string>, done: bool}
     */
    public static function erase(string $email, int $page = 1): array
    {
        global $wpdb;
        $user = get_user_by('email', $email);
        if (!$user) {
            return ['items_removed' => false, 'items_retained' => false, 'messages' => [], 'done' => true];
        }

        $events = (int)$wpdb->query((string)$wpdb->prepare("UPDATE `" . Event::table_name() . "` SET user_id = NULL, user_email = NULL WHERE user_id = %d", $user->ID));
        $sessions = (int)$wpdb->query((string)$wpdb->prepare("UPDATE `" . Sessions::table_name() . "` SET user_id = NULL WHERE user_id = %d", $user->ID));
        Reports::flush_cache();

        return [
            'items_removed' => ($events + $sessions) > 0,
            'items_retained' => false,
            'messages' => ($events + $sessions) > 0 ? ['Analytics: Die Besuche sind nicht mehr mit dem Konto verknüpft.'] : [],
            'done' => true,
        ];
    }
}
