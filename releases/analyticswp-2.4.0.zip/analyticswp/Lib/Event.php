<?php

namespace AnalyticsWP\Lib;

/**
 * 
 * @psalm-type JourneyEvent = array{
 *         event_id: string,
 *         timestamp: string,
 *         event_type: string,
 *         page_url: string,
 *         referrer: string,
 *         device_type: string,
 *         conversion_type: string,
 *         conversion_id?: int,
 *         event_properties_json?: string
 * }
 * 
 * @psalm-type EventInsertData = array{
 *         event_type: string,
 *         unique_session_id: string,
 *         conversion_type?: string|null,
 *         conversion_id?: int|null,
 *         referrer?: string|null,
 *         page_url?: string|null,
 *         device_type?: string|null,
 *         user_agent?: string|null,
 *         ip_address?: string|null,
 *         utm_source?: string|null,
 *         utm_medium?: string|null,
 *         utm_campaign?: string|null,
 *         utm_term?: string|null,
 *         utm_content?: string|null,
 *         user_id?: int|null,
 *         user_email?: string|null,
 *         timestamp?: string|null,
 *         event_properties_json?: string|null,
 *         unique_event_identifier?: string|null,
 *         session_id?: string|null,
 *         revenue?: float|null,
 *         currency?: string|null
 * }
 * 
 * @psalm-type EventData = EventInsertData & array{id: int}
 * 
 * @psalm-type IdentifiedJourney = array{
 *     user_id: int,
 *     unique_session_id?: string,
 *     events: list<JourneyEvent>
 * }
 * 
 * @psalm-type AnonymousJourney = array{
 *     unique_session_id: string,
 *     user_id?: int,
 *     events: list<JourneyEvent>
 * }
 * 
 * @psalm-type SourceData = array{
 *      referrer: string|null,
 *      landing_page: string|null,
 *      utm_source: string|null,
 *      utm_medium: string|null,
 *      utm_campaign: string|null,
 *      utm_term: string|null,
 *      source_event_id: int|null,
 * }
 * 
 * 
 */
class Event
{
    /**
     * @var string
     */
    private static $table_name = 'analytics_wp_events';
    // private static $table_name = 'analytics_wp_events_big';

    /**
     * @global \wpdb $wpdb The WordPress database class instance.
     * 
     * @return string
     */
    public static function table_name()
    {
        global $wpdb;

        return $wpdb->prefix . self::$table_name;
    }


    /**
     * Schema version of the fork. Raise it with every change to create_table()
     * or Migrations; that is the only trigger for either to run.
     *
     * 1 = upstream AnalyticsWP 2.3.0
     * 2 = cookieless: session_id, rate limit table, IP and e-mail cleared
     * 3 = sessions table with attribution, revenue and currency on events
     * 4 = sessions.started_day (local day) for reports
     * 5 = consent tier, engagement (scroll depth, engaged time), attribution
     *     of conversions across sessions
     * 6 = lean index set on events (see create_table())
     * 7 = security fixes: cached order source blocks purged, user agents
     *     cleared; path columns (events.path, sessions.landing_path and
     *     exit_path) and report indexes for large tables
     * 8 = covering index for the pages report
     */
    const DB_VERSION = 8;

    const DB_VERSION_OPTION = 'analyticswp_db_version';

    /**
     * @return array<array-key, mixed>|false Table creation results, or false.
     */
    public static function create_table_if_necessary()
    {
        $installed = (int)get_option(self::DB_VERSION_OPTION, 1);

        // A fresh install has neither our option nor upstream's.
        if (get_option('analyticswp_version_create_table') === false && get_option(self::DB_VERSION_OPTION) === false) {
            $installed = 0;
        }

        if ($installed >= self::DB_VERSION) {
            return false;
        }

        // One request migrates; the others go on as before. Without the
        // lock every request arriving during an upgrade would run the same
        // ALTER TABLE and CREATE INDEX statements at once.
        if (!self::acquire_migration_lock()) {
            return false;
        }

        // Adding an index to a large table takes a while: finish even if
        // the visitor who triggered it has gone.
        ignore_user_abort(true);
        if (function_exists('set_time_limit')) {
            @set_time_limit(300);
        }

        try {
            $table_creation_results = self::create_table();
            Migrations::run($installed);
            update_option(self::DB_VERSION_OPTION, self::DB_VERSION);
        } finally {
            self::release_migration_lock();
        }

        return $table_creation_results;
    }

    const MIGRATION_LOCK_OPTION = 'analyticswp_migration_lock';

    /**
     * Take the migration lock: an options row written with INSERT IGNORE,
     * so exactly one of several racing requests gets it. A lock older than
     * ten minutes belongs to a request that died and is taken over.
     */
    private static function acquire_migration_lock(): bool
    {
        global $wpdb;

        $now = time();
        $inserted = $wpdb->query((string)$wpdb->prepare(
            "INSERT IGNORE INTO `{$wpdb->options}` (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
            self::MIGRATION_LOCK_OPTION,
            (string)$now
        ));
        if ($inserted === 1) {
            return true;
        }

        $taken = $wpdb->query((string)$wpdb->prepare(
            "UPDATE `{$wpdb->options}` SET option_value = %s WHERE option_name = %s AND CAST(option_value AS UNSIGNED) < %d",
            (string)$now,
            self::MIGRATION_LOCK_OPTION,
            $now - 600
        ));

        return $taken === 1;
    }

    private static function release_migration_lock(): void
    {
        global $wpdb;
        $wpdb->delete($wpdb->options, ['option_name' => self::MIGRATION_LOCK_OPTION]);
        wp_cache_delete(self::DB_VERSION_OPTION, 'options');
        wp_cache_delete('alloptions', 'options');
    }

    /**
     * @global \wpdb $wpdb The WordPress database class instance.
     * 
     * @return array<array-key, mixed> dbDelta result
     */
    public static function create_table()
    {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        $table_name = self::table_name();

        // Support for versions below 5.6, we can't use the `DEFAULT CURRENT_TIMESTAMP` syntax
        // So, we check the version and use the appropriate syntax

        $mysql_version = $wpdb->db_version();
        if (!is_null($mysql_version) && version_compare($mysql_version, '5.6', '<')) {
            $timestamp_default = 'NULL';
        } else {
            $timestamp_default = 'CURRENT_TIMESTAMP';
        }

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            unique_session_id VARCHAR(255) NOT NULL,
            session_id CHAR(32) DEFAULT NULL,
            event_type VARCHAR(255) NOT NULL,
            conversion_type VARCHAR(255) DEFAULT NULL,
            conversion_id BIGINT(20) UNSIGNED DEFAULT NULL,
            referrer TEXT DEFAULT NULL,
            page_url TEXT DEFAULT NULL,
            path VARCHAR(191) DEFAULT NULL,
            device_type VARCHAR(50) DEFAULT NULL,
            user_agent TEXT DEFAULT NULL,
            ip_address VARCHAR(45) DEFAULT NULL,
            utm_source VARCHAR(255) DEFAULT NULL,
            utm_medium VARCHAR(255) DEFAULT NULL,
            utm_campaign VARCHAR(255) DEFAULT NULL,
            utm_term VARCHAR(255) DEFAULT NULL,
            utm_content TEXT DEFAULT NULL,
            user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            user_email VARCHAR(255) DEFAULT NULL,
            unique_event_identifier VARCHAR(255) DEFAULT NULL,
            event_properties_json longtext DEFAULT NULL,
            revenue DECIMAL(18,4) DEFAULT NULL,
            currency CHAR(3) DEFAULT NULL,
            scroll_depth TINYINT UNSIGNED DEFAULT NULL,
            engaged_seconds INT UNSIGNED DEFAULT NULL,
            attributed_session_id CHAR(32) DEFAULT NULL,
            first_session_id CHAR(32) DEFAULT NULL,
            timestamp DATETIME DEFAULT $timestamp_default,
            PRIMARY KEY (id)
        ) $charset_collate;";


        if (defined('ABSPATH')) {
            $path = ABSPATH . 'wp-admin/includes/upgrade.php';
            if (file_exists($path)) {
                require_once($path);
            }
        }

        $db_delta_result = dbDelta($sql);

        // Indexes. Each one slows every insert, so only what a query uses:
        // sessions and journeys (session_id, unique_session_id + timestamp),
        // logged-in users, the live view and legacy order screens
        // (timestamp, event_type + timestamp), duplicate checks of
        // conversions (unique_event_identifier, conversion_id + type) and
        // attribution (attributed_session_id). Schema 6 dropped upstream's
        // idx_usession, idx_user_id, idx_event_type (prefixes of the ones
        // below), idx_session_user_timestamp and
        // idx_event_type_user_id_timestamp (its removed reports).
        $indexes = [
            'idx_session_id' => '(session_id)',
            'idx_usession_timestamp' => '(unique_session_id, timestamp)',
            'idx_user_id_timestamp' => '(user_id, timestamp)',
            'idx_timestamp' => '(timestamp)',
            'idx_event_type_timestamp' => '(event_type, timestamp)',
            'idx_unique_event_identifier' => '(unique_event_identifier)',
            'idx_conversion' => '(conversion_id, conversion_type)',
            'idx_attributed_session_id' => '(attributed_session_id)',
            // Pages report: a time range of page views, grouped by path,
            // answered from the index alone (session, active time, scroll).
            'idx_pageview_cover' => '(event_type, timestamp, path, session_id, engaged_seconds, scroll_depth)',
            // Revenue per session: only the conversions, index only.
            'idx_conversion_revenue' => '(conversion_type, currency, session_id, revenue)',
        ];
        foreach ($indexes as $index => $columns) {
            if (!self::index_exists($table_name, $index)) {
                $wpdb->query("CREATE INDEX $index ON {$table_name} $columns");
            }
        }

        RequestGuard::create_table();
        Sessions::create_table();

        return $db_delta_result;
    }

    /**
     * @param string $table_name
     * @param string $index_name
     * 
     * @global \wpdb $wpdb The WordPress database class instance.
     * 
     * @return bool
     */
    public static function index_exists($table_name, $index_name)
    {
        global $wpdb;

        $query = (string)$wpdb->prepare(
            "SELECT COUNT(1) indexIsThere 
            FROM INFORMATION_SCHEMA.STATISTICS 
            WHERE table_schema=DATABASE() 
            AND table_name=%s 
            AND index_name=%s;",
            $table_name,
            $index_name
        );

        // If the result is 0, then the index doesn't exist
        return ($wpdb->get_var($query) == 0) ? false : true;
    }

    /**
     * Attempts to check that a value is a valid EventData object.
     * It doesn't actually do it all thought, it's just a basic check at this point.
     * 
     * We need to consider performance implications of using this. 
     * 
     * What if we want to get a giant list of events and cast them all to EventData objects?
     * 
     * 
     * @param mixed $val
     * @return EventData|null
     */
    public static function cast($val)
    {
        if (is_null($val) || empty($val) || !is_array($val)) {
            return null;
        }

        /** @var EventData */
        return $val;
    }

    /**
     * Undocumented function
     *
     * @global \wpdb $wpdb The WordPress database class instance.
     * 
     * @param string $sql
     * @return EventData|null
     */
    public static function db_get_row($sql)
    {
        global $wpdb;

        return self::cast($wpdb->get_row($sql, 'ARRAY_A'));
    }

    /**
     * @param EventInsertData $data
     * @param bool $force_timestamp
     * 
     * @global \wpdb $wpdb The WordPress database class instance.
     * 
     * @return array{error: non-empty-string}|int
     */
    public static function insert($data, $force_timestamp = true)
    {
        global $wpdb;
        $table_name = self::table_name();

        if ($force_timestamp || empty($data['timestamp'])) {
            $data['timestamp'] = current_time('mysql', true);
        }

        $isolated = !empty($data['_isolated']);
        unset($data['_isolated']);

        if (!empty($data['page_url'])) {
            $data['path'] = URLs::path_of((string)$data['page_url']);
        }

        $session = $isolated ? Sessions::isolated($data) : Sessions::for_event($data);
        $data['session_id'] = $session['session_id'];

        // An anonymous event in a session that has already logged in keeps
        // the user.
        if (empty($data['user_id']) && $session['user_id'] !== null) {
            $data['user_id'] = $session['user_id'];
        }

        // A conversion remembers which earlier visits led to it.
        if (!empty($data['conversion_type']) && !$isolated) {
            $attribution = Sessions::attribution_for_conversion((string)$data['unique_session_id'], $session['session_id'], (string)$data['timestamp']);
            $data['attributed_session_id'] = $attribution['last'];
            $data['first_session_id'] = $attribution['first'];
        }

        $result = $wpdb->insert($table_name, $data);

        if ($result === false) {
            $error = 'Error inserting data into ' . $table_name . ': ' . $wpdb->last_error;
            error_log($error);
            return [
                'error' => $error,
            ];
        }

        $insert_id = (int)$wpdb->insert_id;

        Sessions::record_event($data);

        if (!empty($data['user_id'])) {
            self::identify_session((string)$data['session_id'], (int)$data['user_id']);
        }

        return $insert_id;
    }


    /**
     * @param mixed $data
     * @return EventInsertData|null
     */
    public static function validate_event_insert_data($data)
    {
        // Basic checks, array, null, etc
        if (!is_array($data) || empty($data)) {
            return null;
        }

        // Initialize an array for validated data
        $validatedData = [];

        // Validate `event_type`
        if (isset($data['event_type']) && is_string($data['event_type'])) {
            $validatedData['event_type'] = $data['event_type'];
        } else {
            return null;
        }

        // Validate `unique_session_id`
        if (isset($data['unique_session_id']) && is_string($data['unique_session_id'])) {
            $validatedData['unique_session_id'] = $data['unique_session_id'];
        } else {
            return null;
        }

        // Validate `conversion_type`
        if (isset($data['conversion_type'])) {
            if ($data['conversion_type'] === null || is_string($data['conversion_type'])) {
                $validatedData['conversion_type'] = $data['conversion_type'];
            } else {
                return null;
            }
        }

        // Validate `conversion_id`
        if (isset($data['conversion_id'])) {
            if ($data['conversion_id'] === null || is_int($data['conversion_id'])) {
                $validatedData['conversion_id'] = $data['conversion_id'];
            } else {
                return null;
            }
        }

        // Validate `referrer`
        if (isset($data['referrer'])) {
            if ($data['referrer'] === null || is_string($data['referrer'])) {
                $validatedData['referrer'] = $data['referrer'];
            } else {
                return null;
            }
        }

        // Validate `page_url`
        if (isset($data['page_url'])) {
            if ($data['page_url'] === null || is_string($data['page_url'])) {
                $validatedData['page_url'] = $data['page_url'];
            } else {
                return null;
            }
        }

        // Validate `device_type`
        if (isset($data['device_type'])) {
            if ($data['device_type'] === null || is_string($data['device_type'])) {
                $validatedData['device_type'] = $data['device_type'];
            } else {
                return null;
            }
        }

        // Validate `user_agent`
        if (isset($data['user_agent'])) {
            if ($data['user_agent'] === null || is_string($data['user_agent'])) {
                $validatedData['user_agent'] = $data['user_agent'];
            } else {
                return null;
            }
        }

        // Validate `ip_address`
        if (isset($data['ip_address'])) {
            if ($data['ip_address'] === null || is_string($data['ip_address'])) {
                $validatedData['ip_address'] = $data['ip_address'];
            } else {
                return null;
            }
        }

        // Validate `utm_source`
        if (isset($data['utm_source'])) {
            if ($data['utm_source'] === null || is_string($data['utm_source'])) {
                $validatedData['utm_source'] = $data['utm_source'];
            } else {
                return null;
            }
        }

        // Validate `utm_medium`
        if (isset($data['utm_medium'])) {
            if ($data['utm_medium'] === null || is_string($data['utm_medium'])) {
                $validatedData['utm_medium'] = $data['utm_medium'];
            } else {
                return null;
            }
        }

        // Validate `utm_campaign`
        if (isset($data['utm_campaign'])) {
            if ($data['utm_campaign'] === null || is_string($data['utm_campaign'])) {
                $validatedData['utm_campaign'] = $data['utm_campaign'];
            } else {
                return null;
            }
        }

        // Validate `utm_term`
        if (isset($data['utm_term'])) {
            if ($data['utm_term'] === null || is_string($data['utm_term'])) {
                $validatedData['utm_term'] = $data['utm_term'];
            } else {
                return null;
            }
        }

        // Validate `utm_content`
        if (isset($data['utm_content'])) {
            if ($data['utm_content'] === null || is_string($data['utm_content'])) {
                $validatedData['utm_content'] = $data['utm_content'];
            } else {
                return null;
            }
        }

        // Validate `user_id`
        if (isset($data['user_id'])) {
            if ($data['user_id'] === null || is_int($data['user_id'])) {
                $validatedData['user_id'] = $data['user_id'];
            } else {
                return null;
            }
        }

        // Validate `user_email`
        if (isset($data['user_email'])) {
            if ($data['user_email'] === null || is_string($data['user_email'])) {
                $validatedData['user_email'] = $data['user_email'];
            } else {
                return null;
            }
        }

        // Validate `timestamp`
        if (isset($data['timestamp'])) {
            if ($data['timestamp'] === null || is_string($data['timestamp'])) {
                $validatedData['timestamp'] = $data['timestamp'];
            } else {
                return null;
            }
        }

        // Validate `event_properties_json`
        if (isset($data['event_properties_json'])) {
            if ($data['event_properties_json'] === null || is_string($data['event_properties_json'])) {
                $validatedData['event_properties_json'] = $data['event_properties_json'];
            } else {
                return null;
            }
        }

        // Validate `unique_event_identifier`
        if (isset($data['unique_event_identifier'])) {
            if ($data['unique_event_identifier'] === null || is_string($data['unique_event_identifier'])) {
                $validatedData['unique_event_identifier'] = $data['unique_event_identifier'];
            } else {
                return null;
            }
        }

        // `revenue`: a number, stored with four decimals. Anything else is
        // dropped rather than refusing the event.
        if (isset($data['revenue']) && is_numeric($data['revenue'])) {
            $validatedData['revenue'] = round((float)$data['revenue'], 4);
        }

        // `currency`: ISO 4217, three letters.
        if (isset($data['currency']) && is_string($data['currency']) && preg_match('/^[A-Za-z]{3}$/', $data['currency'])) {
            $validatedData['currency'] = strtoupper($data['currency']);
        }

        return $validatedData;
    }

    /**
     * When a session logs in (an event with a user ID), its earlier anonymous
     * events get that user too.
     *
     * Upstream did this across the visitor's whole history, keyed on a
     * 365-day cookie, and ran an extra lookup for every anonymous event. With
     * a daily visitor hash that is no longer a person, only a device for one
     * day, so the update is limited to the one session; the "forwards" case is
     * handled in insert() from the session lookup it already does.
     *
     * @global \wpdb $wpdb The WordPress database class instance.
     */
    public static function identify_session(string $session_id, int $user_id): void
    {
        global $wpdb;
        $table_name = self::table_name();

        if ($session_id === '' || $user_id <= 0) {
            return;
        }

        $wpdb->query((string)$wpdb->prepare(
            "UPDATE `$table_name` SET `user_id` = %d WHERE `session_id` = %s AND (`user_id` IS NULL OR `user_id` = 0)",
            $user_id,
            $session_id
        ));
    }

    /**
     * @param int $id
     * 
     * @global \wpdb $wpdb The WordPress database class instance.
     * 
     * @return array|object|null|void
     */
    public static function find($id)
    {
        global $wpdb;
        return self::db_get_row((string)$wpdb->prepare("SELECT * FROM " . self::table_name() . " WHERE id = %d", $id));
    }

    /**
     * @param array<string,string> $conditions
     * 
     * @global \wpdb $wpdb The WordPress database class instance.
     * 
     * @return EventData[]
     */
    public static function where($conditions)
    {
        global $wpdb;
        $table_name = self::table_name();

        $where_clauses = [];
        $where_values = [];

        foreach ($conditions as $column => $value) {
            $where_clauses[] = "$column = %s";
            $where_values[] = $value;
        }

        $where_sql = implode(' AND ', $where_clauses);

        $query = (string)$wpdb->prepare("SELECT * FROM $table_name WHERE $where_sql", ...$where_values);

        /** @var EventData[] */
        return Validators::arr($wpdb->get_results($query, 'ARRAY_A'));
    }

    /**
     * @param array<string,string> $conditions
     * 
     * @global \wpdb $wpdb The WordPress database class instance.
     * 
     * @return EventData|null
     */
    public static function find_where($conditions)
    {
        $results = self::where($conditions);
        return count($results) > 0 ? $results[0] : null;
    }

    ///////////////////////////////////////////////
    // Event Tracking - Serverside
    ///////////////////////////////////////////////
    /**
     * Keys that never go into event_properties_json. Integrations upstream
     * passed names, e-mail and addresses of customers along with an order;
     * the order itself already holds them, the event table does not need to.
     */
    const PII_PROPERTY_KEYS = [
        'email',
        'user_email',
        'first_name',
        'last_name',
        'name',
        'phone',
        'address',
        'billing_address',
        'shipping_address',
        'customer_id',
        'ip',
        'ip_address',
    ];

    /**
     * Track an event from the server side.
     *
     * The visitor is identified from the current request (Visitor::key():
     * the consented ID or the daily hash).
     * When that request is the visitor's own, as with an order placed at
     * checkout or a form submitted on the page, the event lands in the same
     * session as the visitor's pageviews. A webhook or a cron run gets a
     * session of its own.
     *
     * Only PHP calls this with arbitrary keys. The browser endpoint
     * (Core::analyticswp_handle_analytics) builds its array from a fixed
     * list, so a visitor cannot set conversion fields or a session.
     *
     * @param string $event_type
     * @param array<string, mixed> $event_properties
     *
     * @return array{error: non-empty-string}|int|null
     */
    public static function track_server_event($event_type, $event_properties = [])
    {
        global $wp;

        try {
            // Keys that map to columns rather than into event_properties_json.
            $significant_keys = [
                'conversion_type',
                'conversion_id',
                'referrer',
                'page_url',
                'device_type',
                'user_agent',
                'utm_source',
                'utm_medium',
                'utm_campaign',
                'utm_term',
                'utm_content',
                'user_id',
                'unique_event_identifier',
                'revenue',
                'currency',
            ];

            // On behalf of a visitor seen earlier: an order placed in their
            // request and paid later, by a payment provider's webhook or in
            // the admin. The caller passes the visitor key it stored then;
            // the event joins that visitor instead of this request's.
            $on_behalf = isset($event_properties['_visitor']) && is_string($event_properties['_visitor']) && preg_match('/^[0-9a-fk][0-9a-f]{31}$/', $event_properties['_visitor'])
                ? $event_properties['_visitor']
                : '';
            unset($event_properties['_visitor']);

            // A request that is not a visitor's: cron, an admin screen, or a
            // caller that says so (a webhook).
            $foreign = !empty($event_properties['_isolated']) || wp_doing_cron() || (is_admin() && !wp_doing_ajax());
            unset($event_properties['_isolated']);

            // Without a visitor to act for, such events get a session of
            // their own and borrow nobody's user or origin.
            $isolated = $foreign && $on_behalf === '';

            // The person in this request is excluded; on behalf of another
            // visitor, the caller has decided (it stored no key for them).
            if ($on_behalf === '' && is_user_logged_in() && Utils::is_current_user_excluded_from_tracking()) {
                return null;
            }

            // Tied to a WordPress account only with the setting on: a user
            // ID makes the visitor known by name and across days.
            $link_users = (bool)SuperSimpleWP::get_setting('analyticswp', 'link_logged_in_users');
            $user_id = $link_users && is_user_logged_in() && !$foreign ? get_current_user_id() : null;

            // Bots: not for orders and form submissions (a payment
            // provider's callback may look like one), but for everything else
            // the server records on page loads.
            if (empty($event_properties['conversion_type']) && !$isolated && BotDetection::is_bot()) {
                return null;
            }

            $referrer = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw(substr(wp_unslash((string)$_SERVER['HTTP_REFERER']), 0, Core::MAX_URL_LENGTH)) : null;
            // Read for the device type only. Not stored: next to the daily
            // salt it would let a database dump of the same day be brute-
            // forced back to IPv4 addresses.
            $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash((string)$_SERVER['HTTP_USER_AGENT'])) : '';

            // In an AJAX or REST request (a checkout, a form submission) the
            // request URL is an endpoint. The page the visitor was on is the
            // referrer.
            $is_background_request = wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST);

            $server_data = [
                'unique_session_id' => $on_behalf !== '' ? $on_behalf : Visitor::key(),
                'page_url' => $is_background_request ? $referrer : home_url(add_query_arg(array(), $wp->request ?? '')),
                'referrer' => $is_background_request ? null : $referrer,
                'device_type' => DeviceType::from_user_agent($user_agent),
                'user_id' => $user_id,
            ];

            // Page, referrer and device of a webhook or admin request say
            // nothing about the visitor.
            if ($foreign) {
                $server_data['page_url'] = null;
                $server_data['referrer'] = null;
                $server_data['device_type'] = null;
            }

            $significant_data = [];
            foreach ($significant_keys as $key) {
                if (array_key_exists($key, $event_properties)) {
                    $significant_data[$key] = $event_properties[$key];
                    unset($event_properties[$key]);
                }
            }

            // Values that are never stored, whoever passes them.
            foreach (array_merge(self::PII_PROPERTY_KEYS, ['unique_session_id', 'session_id', 'timestamp']) as $key) {
                unset($event_properties[$key]);
            }

            // Form contents. Upstream's form integrations copied every
            // submitted field (field_<label>, field-<key>, or a `fields`
            // array) into the event: names, e-mail addresses, messages.
            // Which form was sent is enough for analytics.
            foreach (array_keys($event_properties) as $key) {
                if ($key === 'fields' || preg_match('/^field[_-]/', (string)$key)) {
                    unset($event_properties[$key]);
                }
            }

            $event_data = array_merge($server_data, $significant_data);
            $event_data['event_type'] = $event_type;
            $event_data['page_url'] = isset($event_data['page_url']) ? URLs::strip_private_query((string)$event_data['page_url']) : null;
            $event_data['referrer'] = isset($event_data['referrer']) ? URLs::strip_query((string)$event_data['referrer']) : null;

            $event_data['event_properties_json'] = !empty($event_properties) ?
                json_encode($event_properties) ?: null :
                null;

            if (isset($event_data['user_id'])) {
                $event_data['user_id'] = $link_users && (int)$event_data['user_id'] > 0 ? (int)$event_data['user_id'] : null;
            }
            unset($event_data['user_agent']);
            $event_data['_isolated'] = $isolated;

            $event_insert_data = self::validate_event_insert_data($event_data);
            if (is_null($event_insert_data)) {
                return ['error' => 'Invalid event data'];
            }
            $event_insert_data['_isolated'] = $isolated;

            // An order confirmed twice (a reload of the thank-you page, a
            // webhook after the checkout request) is one conversion.
            if (!empty($event_insert_data['unique_event_identifier'])) {
                $existing = self::find_where(['unique_event_identifier' => (string)$event_insert_data['unique_event_identifier']]);
                if ($existing !== null) {
                    return (int)$existing['id'];
                }
            }

            return self::insert($event_insert_data);
        } catch (\Throwable $e) {
            error_log("Error tracking event: " . $e->getMessage());
            return null;
        }
    }
}
