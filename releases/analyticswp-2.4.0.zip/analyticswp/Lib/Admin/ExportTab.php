<?php

namespace AnalyticsWP\Lib\Admin;

use AnalyticsWP\Lib\Abilities;
use AnalyticsWP\Lib\AccessLog;
use AnalyticsWP\Lib\Export;

/**
 * Tab "KI & Export" (UI review 2026-10, stage 6, draft 08b): export with
 * live preview, questions to try, the connection to an AI via MCP, and
 * the access log. Administrators only.
 *
 * The export card is a GET form (the state stays in the URL and works
 * without JS); admin.js refreshes the preview in place. The download
 * posts to admin-post.php with a nonce.
 */
class ExportTab
{
    const NONCE = 'analyticswp_export';

    const PROMPTS = [
        'Welcher Kanal bringt am meisten Umsatz pro Besuch, und wo sollte ich mehr investieren?',
        'Wo verliere ich die meisten Besucher, ohne dass sie etwas abschließen?',
        'Was hat sich im Vergleich zum Zeitraum davor am stärksten verändert, und warum könnte das sein?',
        'Welche Seiten führen am häufigsten zu einer Anfrage oder einem Kauf?',
        'Fass die Zahlen in fünf Sätzen für meinen Kunden zusammen, ohne Fachbegriffe.',
    ];

    /** Assistant => label. The help texts are in assistant_help(). */
    const ASSISTANTS = [
        'claude' => 'Claude',
        'chatgpt' => 'ChatGPT',
        'cursor' => 'Cursor / Code-Editor',
        'other' => 'Andere',
    ];

    public static function init(): void
    {
        add_action('admin_post_analyticswp_export', [self::class, 'handle_download']);
        add_action('wp_ajax_analyticswp_export_preview', [self::class, 'ajax_preview']);
        add_action('admin_post_analyticswp_ai_access', [self::class, 'handle_ai_access']);
    }

    /**
     * The switch "Was die KI darf" without JS.
     */
    public static function handle_ai_access(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Keine Berechtigung.', '', ['response' => 403]);
        }
        check_admin_referer(self::NONCE);
        update_option(Abilities::ACCESS_OPTION, isset($_POST['analyticswp_ai_access']) ? '1' : '');

        wp_safe_redirect(add_query_arg(['page' => App::SLUG, 'tab' => 'export'], admin_url('admin.php')) . '#awp-mcp');
        exit;
    }

    // ---------------------------------------------------------------------
    // Requests
    // ---------------------------------------------------------------------

    /**
     * Range, parts and format from a request, limited to known values.
     *
     * @param array<string, mixed> $request
     * @return array{range: string, parts: list<string>, format: string}
     */
    public static function state(array $request): array
    {
        $range = isset($request['range']) && is_string($request['range']) ? sanitize_key(wp_unslash($request['range'])) : '';
        $format = isset($request['format']) && is_string($request['format']) ? sanitize_key(wp_unslash($request['format'])) : '';

        // "parts_sent": the form was sent, so no chip means no part.
        if (isset($request['parts']) && is_array($request['parts'])) {
            $parts = array_values(array_intersect(array_keys(Export::PARTS), array_map('sanitize_key', array_filter(wp_unslash($request['parts']), 'is_string'))));
        } else {
            $parts = isset($request['parts_sent']) ? [] : Export::DEFAULT_PARTS;
        }

        return [
            'range' => isset(Export::RANGES[$range]) ? $range : '30d',
            'parts' => $parts,
            'format' => isset(Export::FORMATS[$format]) ? $format : 'md',
        ];
    }

    /**
     * Download: Markdown, JSON or the CSV tables as ZIP.
     */
    public static function handle_download(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Keine Berechtigung.', '', ['response' => 403]);
        }
        check_admin_referer(self::NONCE);

        $state = self::state($_POST);
        if (empty($state['parts'])) {
            wp_die('Wähle mindestens einen Bereich für den Export.', '', ['response' => 400, 'back_link' => true]);
        }
        $period = Export::period($state['range']);
        $data = Export::build($period, $state['parts']);

        if ($state['format'] === 'csv') {
            $zip = Export::zip(Export::csv_files($data));
            if ($zip === null) {
                wp_die('Auf diesem Server fehlt die ZIP-Unterstützung von PHP. Nimm „Für KI und Kunden“ oder „Rohdaten (JSON)“.', '', ['response' => 500, 'back_link' => true]);
            }
            $body = (string)file_get_contents($zip);
            @unlink($zip);
            $type = 'application/zip';
            $name = Export::filename($data, 'zip');
        } elseif ($state['format'] === 'json') {
            $body = Export::json($data);
            $type = 'application/json; charset=utf-8';
            $name = Export::filename($data, 'json');
        } else {
            $body = Export::markdown($data);
            $type = 'text/markdown; charset=utf-8';
            $name = Export::filename($data, 'md');
        }

        AccessLog::add('export', 'Export', Export::describe($state['format'], $state['parts'], $period));

        nocache_headers();
        header('Content-Type: ' . $type);
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . strlen($body));
        header('X-Content-Type-Options: nosniff');
        echo $body; // phpcs:ignore WordPress.Security.EscapeOutput -- file download
        exit;
    }

    /**
     * The preview for the chosen range, parts and format (admin.js).
     */
    public static function ajax_preview(): void
    {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung.'], 403);
        }
        if (!check_ajax_referer(self::NONCE, 'nonce', false)) {
            wp_send_json_error(['message' => 'Die Seite ist abgelaufen. Lade sie neu.'], 403);
        }

        wp_send_json_success(self::preview(self::state($_POST)));
    }

    /**
     * @param array{range: string, parts: list<string>, format: string} $state
     * @return array{text: string, size: string, copy: string, download: string, dates: string}
     */
    private static function preview(array $state): array
    {
        $period = Export::period($state['range']);
        $out = [
            'text' => '',
            'size' => 'Nichts ausgewählt',
            'copy' => $state['format'] === 'md' ? 'Für KI kopieren' : 'Kopieren',
            'download' => Export::FORMATS[$state['format']][2],
            'dates' => Export::range_label($period['start'], $period['end']) . ', verglichen mit ' . Export::range_label($period['prev_start'], $period['prev_end']),
        ];
        if (empty($state['parts'])) {
            $out['text'] = 'Wähle mindestens einen Bereich.';
            return $out;
        }

        $data = Export::build($period, $state['parts']);
        if ($state['format'] === 'csv') {
            $files = Export::csv_files($data);
            $names = array_keys($files);
            $lines = [Export::filename($data, 'zip')];
            foreach ($names as $i => $name) {
                $lines[] = '  ' . ($i === count($names) - 1 ? '└' : '├') . ' ' . $name;
            }
            foreach ($files as $name => $content) {
                $lines[] = '';
                $lines[] = $name . ':';
                $lines[] = rtrim(str_replace(["\xEF\xBB\xBF", "\r\n"], ['', "\n"], $content));
            }
            $out['text'] = implode("\n", $lines);
            $out['size'] = (count($files) - 1) . ' Tabellen + Erklärung';
        } elseif ($state['format'] === 'json') {
            $out['text'] = Export::json($data);
            $out['size'] = 'etwa ' . max(1, (int)round(strlen($out['text']) / 1024)) . ' KB';
        } else {
            $out['text'] = Export::markdown($data);
            $words = count(preg_split('/\s+/u', trim($out['text'])) ?: []);
            $out['size'] = 'etwa ' . Format::number(round($words, -1)) . ' Wörter' . ($words < 8000 ? ', passt in jede KI' : '');
        }

        return $out;
    }

    // ---------------------------------------------------------------------
    // Tab
    // ---------------------------------------------------------------------

    public static function render(): void
    {
        if (!current_user_can('manage_options')) {
            echo '<p>Nur Administratoren können exportieren und die KI verbinden.</p>';
            return;
        }

        App::page_head('KI & Export', 'Zahlen an eine KI geben oder für Kunden exportieren', false);
        echo '<div class="awp-layout">';
        self::export_card(self::state($_GET));
        self::prompts_card();
        self::connect_card();
        self::log_card();
        echo '</div>';
    }

    /**
     * @param array{range: string, parts: list<string>, format: string} $state
     */
    private static function export_card(array $state): void
    {
        $preview = self::preview($state);

        Ui::card_open('download-simple', 'Daten exportieren', 'Mit Erklärungen, damit eine KI oder dein Kunde die Zahlen richtig liest', '', 'awp-span-all awp-export');
        echo '<form class="awp-card-body awp-export-form" method="get" action="' . esc_url(admin_url('admin.php')) . '" data-awp-export="' . esc_attr(wp_create_nonce(self::NONCE)) . '">';
        echo '<input type="hidden" name="page" value="' . esc_attr(App::SLUG) . '"><input type="hidden" name="tab" value="export"><input type="hidden" name="parts_sent" value="1">';

        echo '<div class="awp-export-grid">';
        echo '<fieldset class="awp-export-field"><legend>Zeitraum</legend><div class="awp-seg awp-seg--radio">';
        foreach (Export::RANGES as $range => $label) {
            $id = 'awp-range-' . $range;
            echo '<input type="radio" id="' . esc_attr($id) . '" name="range" value="' . esc_attr($range) . '"' . checked($state['range'], $range, false) . '><label for="' . esc_attr($id) . '">' . esc_html($label) . '</label>';
        }
        echo '</div><p class="awp-field-desc">Immer mit Vergleich zum Zeitraum davor: <span data-awp-export-dates>' . esc_html($preview['dates']) . '</span></p></fieldset>';

        echo '<fieldset class="awp-export-field"><legend>Inhalt</legend><div class="awp-role-chips">';
        foreach (Export::PARTS as $part => $label) {
            $id = 'awp-part-' . $part;
            echo '<input type="checkbox" class="awp-chip-check" id="' . esc_attr($id) . '" name="parts[]" value="' . esc_attr($part) . '"' . checked(in_array($part, $state['parts'], true), true, false) . '>'
                . '<label class="awp-chip-toggle" for="' . esc_attr($id) . '">' . Icons::svg('check') . esc_html($label) . '</label>';
        }
        echo '</div></fieldset>';
        echo '</div>';

        echo '<fieldset class="awp-export-field"><legend>Format</legend><div class="awp-formats">';
        $icons = ['md' => 'file', 'csv' => 'list', 'json' => 'code'];
        foreach (Export::FORMATS as $format => [$label, $description]) {
            $id = 'awp-format-' . $format;
            echo '<input type="radio" class="awp-format-input" id="' . esc_attr($id) . '" name="format" value="' . esc_attr($format) . '"' . checked($state['format'], $format, false) . '>'
                . '<label class="awp-format" for="' . esc_attr($id) . '"><span class="awp-format-head">' . Icons::svg($icons[$format]) . '<strong>' . esc_html($label) . '</strong>'
                . ($format === 'md' ? '<span class="awp-badge">Empfohlen</span>' : '') . '</span><span class="awp-format-desc">' . esc_html($description) . '</span></label>';
        }
        echo '</div></fieldset>';

        echo '<div class="awp-preview"><div class="awp-preview-head"><span>Vorschau</span><span data-awp-export-size>' . esc_html($preview['size']) . '</span></div>'
            . '<pre id="awp-export-preview" tabindex="0" aria-label="Vorschau des Exports" aria-live="polite">' . esc_html($preview['text']) . '</pre></div>';

        echo '<div class="awp-export-actions">'
            . '<button type="button" class="button button-primary" data-awp-copy="#awp-export-preview" data-awp-export-copy>' . esc_html($preview['copy']) . '</button>'
            . '<button type="submit" class="button" formmethod="post" formaction="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=analyticswp_export'), self::NONCE)) . '" data-awp-export-download>'
            . Icons::svg('download-simple') . '<span>' . esc_html($preview['download']) . '</span></button>'
            . '<button type="submit" class="button-link awp-export-refresh">Vorschau aktualisieren</button>'
            . '</div>';
        echo '</form>';
        Ui::card_close(Icons::svg('lock-simple') . '<span>Enthält nur zusammengefasste Zahlen, keine einzelnen Besucher und keine Einstellungen oder Zugangsdaten.</span>');
    }

    private static function prompts_card(): void
    {
        Ui::card_open('chat-circle', 'Fragen zum Ausprobieren', 'Nach dem Export oder mit verbundener KI einfach stellen', '', 'awp-span-all');
        echo '<ul class="awp-prompts">';
        foreach (self::PROMPTS as $i => $prompt) {
            $id = 'awp-prompt-' . $i;
            echo '<li><span id="' . esc_attr($id) . '">' . esc_html($prompt) . '</span>'
                . '<button type="button" class="button" data-awp-copy="#' . esc_attr($id) . '" aria-label="' . esc_attr('Frage kopieren: ' . $prompt) . '">Kopieren</button></li>';
        }
        echo '</ul>';
        Ui::card_close();
    }

    // ---------------------------------------------------------------------
    // Mit KI verbinden
    // ---------------------------------------------------------------------

    /**
     * no_api (WordPress before 6.9), no_adapter, no_app_passwords, off or
     * ready.
     */
    public static function mcp_state(): string
    {
        if (!function_exists('wp_register_ability')) {
            return 'no_api';
        }
        if (self::mcp_url() === '') {
            return 'no_adapter';
        }
        if (!function_exists('wp_is_application_passwords_available') || !wp_is_application_passwords_available()) {
            return 'no_app_passwords';
        }

        return Abilities::enabled() ? 'ready' : 'off';
    }

    /**
     * Address of the MCP server: the default server of the MCP Adapter,
     * else the first fixed route under /mcp/ ('' without adapter).
     */
    public static function mcp_url(): string
    {
        static $url = null;
        if ($url !== null) {
            return $url;
        }
        $url = '';
        if (!function_exists('rest_get_server')) {
            return $url;
        }

        $routes = array_keys((array)rest_get_server()->get_routes());
        if (in_array('/mcp/mcp-adapter-default-server', $routes, true)) {
            return $url = rest_url('mcp/mcp-adapter-default-server');
        }
        foreach ($routes as $route) {
            $route = (string)$route;
            if (strpos($route, '/mcp/') === 0 && !preg_match('/[()\[\]?*+\\\\^$]|oauth/i', $route)) {
                return $url = rest_url(ltrim($route, '/'));
            }
        }

        return $url;
    }

    private static function connect_card(): void
    {
        $state = self::mcp_state();
        $url = self::mcp_url();

        Ui::card_open('sparkle', 'Mit KI verbinden', 'Die KI fragt die Zahlen selbst ab (MCP)', '', 'awp-span-all awp-connect');
        echo '<div class="awp-card-body awp-connect-body" id="awp-mcp">';
        self::connect_status($state);

        if ($state !== 'no_api') {
            $user = wp_get_current_user();
            $profile = admin_url('profile.php#application-passwords-section');

            echo '<ol class="awp-connect-steps">';
            echo '<li><span class="awp-connect-num" aria-hidden="true">1</span><div class="awp-connect-step"><p class="awp-connect-title">Adresse kopieren</p>';
            if ($url !== '') {
                echo '<div class="awp-addr"><input type="text" id="awp-mcp-url" readonly value="' . esc_attr($url) . '" aria-label="MCP-Adresse"><button type="button" class="button" data-awp-copy="#awp-mcp-url">Kopieren</button></div>';
            } else {
                echo '<p class="awp-field-desc">Erscheint, sobald ein MCP-Adapter aktiv ist.</p>';
            }
            echo '</div></li>';

            echo '<li><span class="awp-connect-num" aria-hidden="true">2</span><div class="awp-connect-step"><p class="awp-connect-title">In deiner KI eintragen</p>'
                . '<p class="awp-field-desc">Die KI meldet sich mit deinem WordPress-Konto und einem <a href="' . esc_url($profile) . '">Anwendungspasswort</a> an. Gib ihm den Namen deiner KI, etwa „Claude“: So steht er unter „Letzte Zugriffe“.</p>'
                . '<div class="awp-assistants" role="group" aria-label="Assistent" data-awp-assistants>';
            foreach (self::ASSISTANTS as $key => $label) {
                echo '<button type="button" class="awp-chip-toggle" aria-pressed="' . ($key === 'claude' ? 'true' : 'false') . '" data-awp-assistant="' . esc_attr($key) . '">' . esc_html($label) . '</button>';
            }
            echo '</div>';
            foreach (self::ASSISTANTS as $key => $label) {
                echo '<div class="awp-assistant-help" data-awp-assistant-help="' . esc_attr($key) . '"><p class="awp-assistant-name">' . esc_html($label) . '</p>' . self::assistant_help($key, $url, (string)$user->user_login) . '</div>';
            }
            echo '</div></li>';

            echo '<li><span class="awp-connect-num" aria-hidden="true">3</span><div class="awp-connect-step"><p class="awp-connect-title">Verbindung testen</p>';
            $testing = isset($_GET['view']) && sanitize_key(wp_unslash($_GET['view'])) === 'test';
            echo '<a class="button" href="' . esc_url(App::url(['tab' => 'export', 'view' => 'test']) . '#awp-mcp') . '">Jetzt testen</a>';
            if ($testing) {
                echo '<ul class="awp-checks">';
                foreach (self::connection_checks() as [$ok, $text]) {
                    echo '<li class="' . ($ok ? 'is-ok' : 'is-bad') . '">' . Icons::svg($ok ? 'check-circle' : 'warning') . '<span>' . esc_html($text) . '</span></li>';
                }
                echo '</ul>';
            }
            echo '</div></li>';
            echo '</ol>';

            // Saves on change (admin.js); without JS through the form.
            echo '<form class="awp-ai-access" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            echo '<input type="hidden" name="action" value="analyticswp_ai_access">' . wp_nonce_field(self::NONCE, '_wpnonce', true, false);
            echo Ui::toggle('ai_access', Abilities::enabled(), 'Was die KI darf', [
                'description' => 'Nur lesen. Die KI kann keine Einstellungen ändern und nichts löschen. Ausgeschaltet antwortet sie, dass der Zugriff gesperrt ist.',
            ]);
            echo '<noscript><p><button type="submit" class="button">Speichern</button></p></noscript>';
            echo '<details class="awp-abilities"><summary>' . count(Abilities::SUMMARIES) . ' Fähigkeiten ansehen' . Icons::svg('caret-down') . '</summary><ul>';
            foreach (Abilities::SUMMARIES as [$name, $summary]) {
                echo '<li>' . Icons::svg('check') . '<span><strong>' . esc_html($name) . '</strong> · ' . esc_html($summary) . '</span></li>';
            }
            echo '</ul></details>';
            echo '</form>';
        }
        echo '</div>';
        Ui::card_close(Icons::svg('lock-simple') . '<span>Zugriff nur mit einem WordPress-Konto mit Administrator-Rechten. Die KI sieht dieselben zusammengefassten Zahlen wie der Export.</span>');
    }

    private static function connect_status(string $state): void
    {
        $last = AccessLog::last_ai();
        switch ($state) {
            case 'no_api':
                [$tone, $icon, $title, $text] = ['is-warn', 'warning', 'Braucht WordPress 6.9 oder neuer.', 'Die Verbindung zur KI läuft über die Abilities-API von WordPress. Der Export oben funktioniert trotzdem.'];
                break;
            case 'no_adapter':
                [$tone, $icon, $title, $text] = ['is-warn', 'warning', 'Es fehlt ein MCP-Adapter.', 'Installiere das Plugin „MCP Adapter“ von WordPress (github.com/WordPress/mcp-adapter). Danach steht hier die Adresse für deine KI.'];
                break;
            case 'no_app_passwords':
                [$tone, $icon, $title, $text] = ['is-warn', 'warning', 'Anwendungspasswörter sind ausgeschaltet.', 'Ohne sie kann sich keine KI anmelden. Oft schaltet ein Sicherheits-Plugin sie ab, oder die Website läuft ohne HTTPS.'];
                break;
            case 'off':
                [$tone, $icon, $title, $text] = ['', 'info', 'KI-Zugriff ist ausgeschaltet.', 'Schalte unten „Was die KI darf“ ein, wenn eine KI die Zahlen selbst abfragen soll.'];
                break;
            default:
                if ($last !== null) {
                    [$tone, $icon, $title, $text] = ['is-good', 'check-circle', 'Verbunden mit ' . $last['who'] . '.', 'Letzter Zugriff ' . self::lower(Format::datetime(gmdate('Y-m-d H:i:s', $last['t']))) . ' Uhr: ' . $last['what'] . '.'];
                } else {
                    [$tone, $icon, $title, $text] = ['is-good', 'check-circle', 'Bereit für deine KI.', 'Noch keine Abfrage. Trag die Adresse in deiner KI ein und stell eine Frage.'];
                }
        }

        echo '<div class="awp-status ' . esc_attr($tone) . '">' . Icons::svg($icon) . '<div><p class="awp-glance-title">' . esc_html($title) . '</p><p class="awp-glance-text">' . esc_html($text) . '</p></div></div>';
    }

    /**
     * How to add the address in an assistant (HTML).
     */
    private static function assistant_help(string $assistant, string $url, string $login): string
    {
        $url = $url !== '' ? $url : rest_url('mcp/mcp-adapter-default-server');
        $config = (string)wp_json_encode([
            'mcpServers' => [
                'analytics' => [
                    'command' => 'npx',
                    'args' => ['-y', '@automattic/mcp-wordpress-remote@latest'],
                    'env' => [
                        'WP_API_URL' => $url,
                        'WP_API_USERNAME' => $login,
                        'WP_API_PASSWORD' => 'DEIN-ANWENDUNGSPASSWORT',
                    ],
                ],
            ],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $snippet = function (string $id, string $code) {
            return '<div class="awp-snippet"><pre id="' . esc_attr($id) . '">' . esc_html($code) . '</pre><button type="button" class="button" data-awp-copy="#' . esc_attr($id) . '">Kopieren</button></div>';
        };

        switch ($assistant) {
            case 'claude':
                return '<p>Claude Desktop: Unter Einstellungen › Entwickler › „Konfiguration bearbeiten“ diesen Eintrag ergänzen, dein Anwendungspasswort einsetzen und Claude neu starten. Braucht Node.js.</p>'
                    . $snippet('awp-snippet-claude', $config)
                    . '<p>Claude Code: im Terminal</p>'
                    . $snippet('awp-snippet-claude-code', 'claude mcp add analytics -e WP_API_URL=' . $url . ' -e WP_API_USERNAME=' . $login . ' -e WP_API_PASSWORD=DEIN-ANWENDUNGSPASSWORT -- npx -y @automattic/mcp-wordpress-remote@latest');
            case 'chatgpt':
                return '<p>ChatGPT verbindet eigene Konnektoren nur mit einer OAuth-Anmeldung. Die bietet WordPress nicht von Haus aus, ein Anwendungspasswort reicht dort nicht. Nimm für ChatGPT den Export oben („Für KI kopieren“) oder Claude.</p>';
            case 'cursor':
                return '<p>In der MCP-Konfiguration (bei Cursor <code>.cursor/mcp.json</code>) diesen Server eintragen und dein Anwendungspasswort einsetzen. Braucht Node.js.</p>'
                    . $snippet('awp-snippet-cursor', $config);
            default:
                return '<p>Jede KI, die MCP unterstützt, kann sich mit der Adresse oben verbinden. Anmeldung per HTTP Basic: dein Benutzername („' . esc_html($login) . '“) und ein Anwendungspasswort. Kann die KI nur lokale Server starten, nimm den Eintrag wie bei Claude Desktop.</p>';
        }
    }

    /**
     * The steps of the connection test: [ok, text].
     *
     * @return list<array{0: bool, 1: string}>
     */
    private static function connection_checks(): array
    {
        $checks = [];
        $api = function_exists('wp_register_ability');
        $checks[] = [$api, $api ? 'Abilities-API von WordPress vorhanden.' : 'Die Abilities-API fehlt (erst ab WordPress 6.9).'];
        if (!$api) {
            return $checks;
        }

        $url = self::mcp_url();
        $checks[] = [$url !== '', $url !== '' ? 'MCP-Adapter aktiv, Adresse gefunden.' : 'Kein MCP-Adapter aktiv. Installiere das Plugin „MCP Adapter“.'];

        $registered = Abilities::registered();
        $count = count($registered);
        $checks[] = [$count === count(Abilities::SUMMARIES), $count . ' von ' . count(Abilities::SUMMARIES) . ' Fähigkeiten angemeldet.'];

        $available = function_exists('wp_is_application_passwords_available') && wp_is_application_passwords_available();
        $checks[] = [$available, $available ? 'Anwendungspasswörter sind verfügbar.' : 'Anwendungspasswörter sind ausgeschaltet (Sicherheits-Plugin oder kein HTTPS).'];
        if ($available && class_exists('WP_Application_Passwords')) {
            $own = count(\WP_Application_Passwords::get_user_application_passwords(get_current_user_id()));
            $checks[] = [$own > 0, $own > 0 ? 'Dein Konto hat ' . $own . ' ' . ($own === 1 ? 'Anwendungspasswort.' : 'Anwendungspasswörter.') : 'Dein Konto hat noch kein Anwendungspasswort. Leg eins im Profil an.'];
        }

        $on = Abilities::enabled();
        $checks[] = [$on, $on ? 'KI-Zugriff ist eingeschaltet.' : 'KI-Zugriff ist ausgeschaltet („Was die KI darf“).'];

        if ($on && isset($registered['get-overview'])) {
            $result = Abilities::quietly(function () use ($registered) {
                return $registered['get-overview']->execute(['range' => '7d']);
            });
            $ok = is_array($result) && isset($result['overview']);
            $checks[] = [$ok, $ok ? 'Testabfrage „Übersicht, 7 Tage“ beantwortet.' : 'Testabfrage fehlgeschlagen: ' . (is_wp_error($result) ? $result->get_error_message() : 'unerwartete Antwort.')];
        }

        $last = AccessLog::last_ai();
        $checks[] = [$last !== null, $last !== null ? 'Letzte Abfrage einer KI: ' . self::lower(Format::datetime(gmdate('Y-m-d H:i:s', $last['t']))) . ' Uhr (' . $last['who'] . ').' : 'Noch keine Abfrage einer KI. Stell ihr eine Frage zu deinen Zahlen.'];

        return $checks;
    }

    // ---------------------------------------------------------------------
    // Letzte Zugriffe
    // ---------------------------------------------------------------------

    private static function log_card(): void
    {
        $entries = AccessLog::entries();

        Ui::card_open('clock', 'Letzte Zugriffe', 'Exporte und Abfragen der KI, die letzten ' . AccessLog::DAYS . ' Tage', '', 'awp-span-all');
        if (empty($entries)) {
            echo '<div class="awp-card-body">' . Ui::empty_state('Noch keine Exporte oder Abfragen.') . '</div>';
            Ui::card_close();
            return;
        }

        $names = [];
        echo '<div class="awp-card-body is-flush awp-scroll-x"><table class="awp-table awp-log"><thead><tr>'
            . '<th scope="col">Zeit</th><th scope="col">Wer</th><th scope="col">Was</th><th scope="col">Von</th></tr></thead><tbody>';
        foreach (array_slice($entries, 0, 50) as $entry) {
            if (!isset($names[$entry['user']])) {
                $user = get_userdata($entry['user']);
                $names[$entry['user']] = $user ? $user->display_name : '–';
            }
            echo '<tr><td class="awp-num-cell">' . esc_html(Format::datetime(gmdate('Y-m-d H:i:s', $entry['t']))) . '</td>'
                . '<td><span class="awp-log-who">' . Icons::svg($entry['kind'] === 'ai' ? 'sparkle' : 'download-simple') . esc_html($entry['who']) . '</span></td>'
                . '<td>' . esc_html($entry['what']) . '</td>'
                . '<td>' . esc_html($names[$entry['user']]) . '</td></tr>';
        }
        echo '</tbody></table></div>';
        Ui::card_close();
    }

    /**
     * "Heute, 09:14" mid-sentence: "heute, 09:14".
     */
    private static function lower(string $text): string
    {
        return preg_replace_callback('/^(Heute|Gestern)/', function ($m) {
            return strtolower($m[1]);
        }, $text) ?? $text;
    }
}
