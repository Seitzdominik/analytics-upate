<?php

namespace AnalyticsWP\Lib\Admin;

use AnalyticsWP\Lib\Attribution;

/**
 * Colour and icon per channel, in one place. The colours are fixed per
 * channel and checked for colour blindness; they leave out petrol, amber
 * and WordPress blue, which already mean something on these screens
 * (brand and good, warning, link). A colour never stands alone: always with
 * the icon and the name, and text stays in text colours.
 *
 * The CSS tokens (--awp-ch-organic-search, ...) are generated from here
 * (App::enqueue), so admin.css and the SVG charts use the same values.
 */
class Channels
{
    /** Channel => [colour, icon]. */
    const STYLES = [
        Attribution::ORGANIC_SEARCH => ['#1baf7a', 'magnifying-glass'],
        Attribution::PAID_SEARCH => ['#0f7a55', 'magnifying-glass'],
        Attribution::DIRECT => ['#a3a39c', 'browser'],
        Attribution::EMAIL => ['#6250d6', 'envelope-simple'],
        Attribution::ORGANIC_SOCIAL => ['#e87ba4', 'chat-circle'],
        Attribution::PAID_SOCIAL => ['#a8456f', 'chat-circle'],
        Attribution::REFERRAL => ['#a07d2e', 'signpost'],
        Attribution::AI => ['#7d4e9e', 'sparkle'],
        Attribution::DISPLAY => ['#c9c9c3', 'megaphone'],
        Attribution::AFFILIATE => ['#c9c9c3', 'megaphone'],
        Attribution::OTHER => ['#c9c9c3', 'dots-three'],
    ];

    /** What a channel means, for the hover in the overview. */
    const NOTES = [
        Attribution::ORGANIC_SEARCH => 'Meist Google, dazu Ecosia, Bing und andere Suchmaschinen.',
        Attribution::PAID_SEARCH => 'Anzeigen in Suchmaschinen, erkannt an gclid oder utm_medium=cpc.',
        Attribution::DIRECT => 'Adresse eingetippt, Lesezeichen oder ohne erkennbare Herkunft.',
        Attribution::EMAIL => 'Links aus Newslettern und Mails.',
        Attribution::ORGANIC_SOCIAL => 'Unbezahlte Links aus Facebook, Instagram, LinkedIn und Co.',
        Attribution::PAID_SOCIAL => 'Anzeigen in sozialen Netzwerken.',
        Attribution::REFERRAL => 'Links von anderen Websites.',
        Attribution::AI => 'Besuche über ChatGPT, Claude, Perplexity und Co.',
        Attribution::DISPLAY => 'Banner und andere Display-Anzeigen.',
        Attribution::AFFILIATE => 'Links von Partnern und Affiliates.',
        Attribution::OTHER => 'Kampagnen-Links, die keinem Kanal zuzuordnen sind.',
    ];

    /** Unknown or missing channel. */
    const FALLBACK = ['#c9c9c3', 'dots-three'];

    /** Bar opacity behind a channel label, and behind any other label (petrol). */
    const BAR_ALPHA = 0.24;
    const BAR_ALPHA_PLAIN = 0.14;
    const PLAIN_BAR = '#0f6e68';

    public static function color(?string $channel): string
    {
        return (self::STYLES[(string)$channel] ?? self::FALLBACK)[0];
    }

    public static function note(?string $channel): string
    {
        return self::NOTES[(string)$channel] ?? '';
    }

    public static function icon(?string $channel): string
    {
        return (self::STYLES[(string)$channel] ?? self::FALLBACK)[1];
    }

    /**
     * The CSS custom property of a channel: var(--awp-ch-paid-search).
     */
    public static function css_var(?string $channel): string
    {
        $key = isset(self::STYLES[(string)$channel]) ? (string)$channel : 'other';

        return 'var(--awp-ch-' . str_replace('_', '-', $key) . ')';
    }

    /**
     * :root { --awp-ch-organic-search: #1baf7a; ... }
     */
    public static function css_tokens(): string
    {
        $css = ':root{';
        foreach (self::STYLES as $channel => [$color]) {
            $css .= '--awp-ch-' . str_replace('_', '-', $channel) . ':' . $color . ';';
        }

        return $css . '}';
    }

    /**
     * "#a8456f" with alpha as "rgba(168,69,111,0.24)".
     */
    public static function rgba(string $hex, float $alpha): string
    {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        [$r, $g, $b] = array_map('hexdec', str_split(substr($hex . '000000', 0, 6), 2));

        return 'rgba(' . $r . ',' . $g . ',' . $b . ',' . rtrim(rtrim(number_format($alpha, 2, '.', ''), '0'), '.') . ')';
    }

    /**
     * Bar colour behind a ranking label: the channel's colour, or petrol
     * for anything that is not a channel.
     */
    public static function bar_color(?string $channel = null): string
    {
        return $channel === null
            ? self::rgba(self::PLAIN_BAR, self::BAR_ALPHA_PLAIN)
            : self::rgba(self::color($channel), self::BAR_ALPHA);
    }

    /**
     * Icon in the channel's colour; the name follows as text.
     */
    public static function icon_html(?string $channel): string
    {
        return '<span class="awp-ch-icon" style="color:' . esc_attr(self::css_var($channel)) . '">' . Icons::svg(self::icon($channel)) . '</span>';
    }

    /**
     * A small dot in the channel's colour, for dense lists (with the name
     * next to it).
     */
    public static function dot(?string $channel): string
    {
        return '<span class="awp-ch-dot" style="background:' . esc_attr(self::css_var($channel)) . '" aria-hidden="true"></span>';
    }

    /**
     * Icon and name: "(icon) Bezahlte Suche".
     */
    public static function label(?string $channel): string
    {
        return '<span class="awp-ch">' . self::icon_html($channel) . '<span>' . esc_html(Format::channel($channel)) . '</span></span>';
    }
}
