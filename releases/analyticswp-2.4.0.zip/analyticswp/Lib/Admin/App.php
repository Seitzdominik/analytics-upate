<?php

namespace AnalyticsWP\Lib\Admin;

use AnalyticsWP\Lib\Reports;
use AnalyticsWP\Lib\SuperSimpleWP;
use AnalyticsWP\Lib\Validators;

/**
 * The admin app: one menu entry "Analytics" with its own sidebar, as in
 * Pixel Made Simple. Views are server-rendered; the period and filters live
 * in the URL, so every state can be bookmarked and shared.
 *
 * Upstream's journey screens are kept as hidden pages under their old slugs
 * (WooCommerce, EDD and form integrations link to them) and rendered inside
 * this frame.
 */
class App
{
    const SLUG = 'analyticswp';

    /** Tab => [group, icon, title]. */
    const TABS = [
        'overview' => ['Auswerten', 'squares-four', 'Übersicht'],
        'campaigns' => ['Auswerten', 'link', 'Kanäle & Kampagnen'],
        'pages' => ['Auswerten', 'stack', 'Seiten'],
        'engagement' => ['Auswerten', 'cursor-click', 'Engagement'],
        'conversions' => ['Auswerten', 'receipt', 'Conversions'],
        'live' => ['Auswerten', 'lightning', 'Live'],
        'journeys' => ['Verlauf', 'footprints', 'Journeys'],
        'integrations' => ['Mehr', 'plugs-connected', 'Integrationen'],
        'export' => ['Mehr', 'sparkle', 'KI & Export'],
        'settings' => ['Mehr', 'list-checks', 'Einstellungen'],
    ];

    /**
     * Upstream's journey pages. WooCommerce, EDD and form integrations
     * still link to them; they redirect to the journeys view.
     */
    const LEGACY_PAGES = ['Journeys', 'anonymous_journeys', 'user_journeys', 'event_id_journeys', 'conversion_journeys'];

    /** Parameters that make up the current view. */
    const STATE_PARAMS = ['tab', 'range', 'from', 'to', 'metric', 'dim', 'model', 'visitor', 'user', 'p', 'sort', 'dir', 'cmp', 'view', 'q', 'sel', 'only', 'empty'];

    /** View parameters that belong to one tab and are dropped when switching tabs. */
    const VIEW_PARAMS = ['metric', 'dim', 'model', 'visitor', 'user', 'p', 'sort', 'dir', 'cmp', 'view', 'q', 'sel', 'only', 'empty'];

    /**
     * Settings a switch may save on its own (Ui::toggle(), admin.js), with
     * the values each accepts. Anything not listed here is refused.
     */
    const AUTOSAVE_SETTINGS = [
        'engagement_tracking' => ['', '1'],
        'contact_clicks_as_conversion' => ['', '1'],
        'multi_day_with_consent' => ['', '1'],
        'link_logged_in_users' => ['', '1'],
        'delete_data_on_uninstall' => ['', '1'],
        'enable_woocommerce_order_notification_source_section' => ['', '1'],
        'retention_months' => ['6', '13', '25', '38', '0'],
        'ai_access' => ['', '1'],
        'fast_endpoint' => ['', '1'],
        // Rules instead of a list: checked in ajax_save_setting().
        'value_per_form' => 'amount',
        'value_per_contact' => 'amount',
        'how_did_you_hear' => 'wc_position',
        'form_value' => 'amount_by_key',
        'exclude_role' => 'role',
        'access_role' => 'role',
    ];

    const AUTOSAVE_NONCE = 'analyticswp_autosave';

    /** @var array<string, string> */
    private static $hooks = [];

    public static function init(): void
    {
        add_action('admin_menu', [self::class, 'register_menu']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue']);
        add_action('admin_post_analyticswp_integration', [Pages::class, 'handle_integration_toggle']);
        add_action('admin_init', [self::class, 'redirect_legacy_pages']);
        add_action('wp_ajax_analyticswp_save_setting', [self::class, 'ajax_save_setting']);
        add_action('wp_ajax_analyticswp_view', [self::class, 'ajax_view']);
        add_filter('pre_update_option_analyticswp_value_per_form', [self::class, 'sanitize_amount_option']);
        add_filter('pre_update_option_analyticswp_value_per_contact', [self::class, 'sanitize_amount_option']);
        add_filter('pre_update_option_analyticswp_form_values', [self::class, 'sanitize_amounts_option']);
    }

    /**
     * Save one setting from a switch. Administrators only, with nonce, and
     * only the settings and values in AUTOSAVE_SETTINGS. Answers with the
     * privacy policy text, which follows the settings.
     */
    public static function ajax_save_setting(): void
    {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Keine Berechtigung.'], 403);
        }
        if (!check_ajax_referer(self::AUTOSAVE_NONCE, 'nonce', false)) {
            wp_send_json_error(['message' => 'Die Seite ist abgelaufen. Lade sie neu.'], 403);
        }

        $setting = isset($_POST['setting']) && is_string($_POST['setting']) ? sanitize_key(wp_unslash($_POST['setting'])) : '';
        $value = isset($_POST['value']) && is_string($_POST['value']) ? sanitize_text_field(wp_unslash($_POST['value'])) : '';
        $key = isset($_POST['key']) && is_string($_POST['key']) ? sanitize_text_field(wp_unslash($_POST['key'])) : '';
        $rule = self::AUTOSAVE_SETTINGS[$setting] ?? null;
        $refuse = function () {
            wp_send_json_error(['message' => 'Diese Einstellung lässt sich so nicht speichern.'], 400);
        };

        if (is_array($rule)) {
            if (!in_array($value, $rule, true)) {
                $refuse();
            }
            update_option('analyticswp_' . $setting, $value);
        } elseif ($rule === 'amount') {
            $amount = \AnalyticsWP\Lib\ConversionValue::sanitize($value);
            if ($amount === null) {
                wp_send_json_error(['message' => 'Bitte einen Betrag eingeben, z. B. 50 oder 49,90.'], 400);
            }
            update_option('analyticswp_' . $setting, $amount);
        } elseif ($rule === 'amount_by_key') {
            $amount = \AnalyticsWP\Lib\ConversionValue::sanitize($value);
            if ($amount === null) {
                wp_send_json_error(['message' => 'Bitte einen Betrag eingeben, z. B. 50 oder 49,90.'], 400);
            }
            if (!preg_match('/^[a-z0-9_-]{1,40}\|.{0,120}$/', $key)) {
                $refuse();
            }
            $values = \AnalyticsWP\Lib\ConversionValue::form_values();
            if ($amount === '') {
                unset($values[$key]);
            } elseif (count($values) < \AnalyticsWP\Lib\ConversionValue::MAX_FORMS || isset($values[$key])) {
                $values[$key] = $amount;
            }
            update_option('analyticswp_form_values', $values);
        } elseif ($rule === 'wc_position') {
            $positions = class_exists('WooCommerce') ? \AnalyticsWP\Lib\Integrations\WooCommerceIntegration::get_wc_field_positions() : [];
            if ($value !== 'disable' && !isset($positions[$value])) {
                $refuse();
            }
            update_option('analyticswp_how_did_you_hear', $value);
        } elseif ($rule === 'role') {
            $roles = wp_roles()->get_names();
            if (!isset($roles[$key]) || !in_array($value, ['', '1'], true)) {
                $refuse();
            }
            $option = $setting === 'exclude_role' ? 'analyticswp_disabled-tracking-user-roles' : 'analyticswp_admin-access-user-roles';
            $current = Validators::array_of_string_keys_and_values(get_option($option, $setting === 'access_role' ? ['administrator' => '1'] : []));
            if ($value === '1') {
                $current[$key] = '1';
            } elseif ($setting !== 'access_role' || $key !== 'administrator') {
                unset($current[$key]);
            }
            update_option($option, $current);
        } else {
            $refuse();
        }

        wp_send_json_success([
            'policy' => \AnalyticsWP\Lib\Privacy::policy_text(),
        ]);
    }

    /**
     * Amounts that arrive through the settings form (without JS) are
     * stored the same way as through autosave: per form, as a list.
     *
     * @param mixed $value
     * @return array<string, string>
     */
    public static function sanitize_amounts_option($value): array
    {
        $out = [];
        foreach (is_array($value) ? $value : [] as $key => $amount) {
            $amount = is_string($amount) ? \AnalyticsWP\Lib\ConversionValue::sanitize($amount) : null;
            if (is_string($key) && $amount !== null && $amount !== '' && count($out) < \AnalyticsWP\Lib\ConversionValue::MAX_FORMS) {
                $out[sanitize_text_field($key)] = $amount;
            }
        }

        return $out;
    }

    /**
     * The same for a single amount.
     *
     * @param mixed $value
     */
    public static function sanitize_amount_option($value)
    {
        $amount = is_string($value) ? \AnalyticsWP\Lib\ConversionValue::sanitize($value) : null;

        return $amount ?? '';
    }

    /**
     * After activation, once: open the app. Not for WP-CLI and bulk
     * activation; the transient is set in the activation hook.
     */
    public static function redirect_after_activation(): void
    {
        if ((defined('WP_CLI') && WP_CLI) || isset($_GET['activate-multi']) || !get_transient('analyticswp_redirect_to_welcome_page')) {
            return;
        }
        delete_transient('analyticswp_redirect_to_welcome_page');
        if (!get_option('analyticswp_dont_redirect_to_homescreen_after_install') && self::can_view()) {
            wp_safe_redirect(admin_url('admin.php?page=' . self::SLUG));
            exit;
        }
    }

    /**
     * Send upstream's journey URLs to the journeys view.
     */
    public static function redirect_legacy_pages(): void
    {
        $page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        if (!in_array($page, self::LEGACY_PAGES, true) || !self::can_view()) {
            return;
        }

        $args = ['page' => self::SLUG, 'tab' => 'journeys'];
        if (!empty($_GET['unique_session_id'])) {
            $args['visitor'] = sanitize_text_field(wp_unslash($_GET['unique_session_id']));
        } elseif (!empty($_GET['user_id'])) {
            $args['user'] = (string)absint($_GET['user_id']);
        } elseif (!empty($_GET['event_id'])) {
            $event = \AnalyticsWP\Lib\Event::find(absint($_GET['event_id']));
            if (is_array($event)) {
                if (!empty($event['user_id'])) {
                    $args['user'] = (string)(int)$event['user_id'];
                } else {
                    $args['visitor'] = (string)$event['unique_session_id'];
                }
            }
        } elseif ($page === 'conversion_journeys') {
            $args['tab'] = 'conversions';
        }

        wp_safe_redirect(add_query_arg(array_map('rawurlencode', $args), admin_url('admin.php')));
        exit;
    }

    /**
     * Roles allowed to see the screens (setting "admin-access-user-roles";
     * administrators always).
     */
    public static function can_view(): bool
    {
        $allowed_roles = Validators::array_of_string_keys_and_values(SuperSimpleWP::get_setting('analyticswp', 'admin-access-user-roles'));

        return current_user_can('manage_options') || SuperSimpleWP::does_current_user_have_admin_access($allowed_roles);
    }

    public static function register_menu(): void
    {
        if (!self::can_view()) {
            return;
        }

        self::$hooks[] = (string)add_menu_page(
            'Analytics',
            'Analytics',
            'read',
            self::SLUG,
            [self::class, 'render'],
            'dashicons-chart-area',
            3
        );

    }

    /**
     * @param string $hook_suffix
     */
    public static function enqueue($hook_suffix): void
    {
        if (!in_array($hook_suffix, self::$hooks, true)) {
            return;
        }

        $dir = dirname(__DIR__, 2);
        $base = plugin_dir_url($dir . '/analyticswp.php');
        // The file time in the version: a changed file is fetched again even
        // while ANALYTICSWP_VERSION stays the same (development builds).
        $version = function (string $file) use ($dir) {
            return ANALYTICSWP_VERSION . '.' . (string)@filemtime($dir . '/' . $file);
        };
        wp_enqueue_style('analyticswp-admin', $base . 'assets/admin.css', [], $version('assets/admin.css'));
        wp_add_inline_style('analyticswp-admin', Channels::css_tokens());
        wp_enqueue_script('analyticswp-admin', $base . 'assets/admin.js', [], $version('assets/admin.js'), ['in_footer' => true, 'strategy' => 'defer']);
        wp_add_inline_script('analyticswp-admin', 'var analyticswpAdmin = ' . wp_json_encode([
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => current_user_can('manage_options') ? wp_create_nonce(self::AUTOSAVE_NONCE) : '',
        ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';', 'before');
    }

    public static function current_tab(): string
    {
        $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'overview';

        return isset(self::TABS[$tab]) ? $tab : 'overview';
    }

    /**
     * URL of the app with the current view's state, changed by $args
     * (null removes a parameter). Filters (f_*) are kept unless $args sets
     * them; pass ['f_*' => null] to drop them all.
     *
     * @param array<string, string|null> $args
     */
    public static function url(array $args = []): string
    {
        $query = ['page' => self::SLUG];

        foreach (self::STATE_PARAMS as $param) {
            if (isset($_GET[$param]) && is_string($_GET[$param]) && $_GET[$param] !== '') {
                $query[$param] = sanitize_text_field(wp_unslash($_GET[$param]));
            }
        }

        $drop_filters = array_key_exists('f_*', $args);
        unset($args['f_*']);
        if (!$drop_filters) {
            foreach (Reports::filters_from($_GET) as $key => $value) {
                $query['f_' . $key] = $value;
            }
        }

        foreach ($args as $key => $value) {
            if ($value === null) {
                unset($query[$key]);
            } else {
                $query[$key] = $value;
            }
        }

        return add_query_arg(array_map('rawurlencode', $query), admin_url('admin.php'));
    }

    public static function render(): void
    {
        if (!self::can_view()) {
            echo '<div class="wrap"><h1>Analytics</h1><p>Deine Benutzerrolle hat keinen Zugriff auf diese Seite.</p></div>';
            return;
        }

        $tab = self::current_tab();
        Icons::start_sprite();
        self::render_frame($tab, function () use ($tab) {
            self::render_tab($tab);
        });
        echo Icons::sprite();
    }

    /**
     * The app without the WordPress admin around it, for admin.js: a click
     * inside the app swaps the frame instead of loading the whole admin
     * page again. Same checks and the same output as render(); read only.
     */
    public static function ajax_view(): void
    {
        if (!self::can_view()) {
            status_header(403);
            exit;
        }

        // Forms take their referer from the request (wp_referer_field()):
        // it must be the app's address, not admin-ajax.php.
        $query = wp_unslash($_GET);
        unset($query['action']);
        $_SERVER['REQUEST_URI'] = (string)wp_parse_url(admin_url('admin.php'), PHP_URL_PATH) . '?' . http_build_query($query);

        $tab = self::current_tab();
        Icons::start_sprite();
        ob_start();
        self::render_frame($tab, function () use ($tab) {
            self::render_tab($tab);
        });
        $html = (string)ob_get_clean() . Icons::sprite();

        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('X-Robots-Tag: noindex');
        echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped while rendering
        exit;
    }

    public static function render_tab(string $tab): void
    {
        switch ($tab) {
            case 'campaigns':
                Pages::campaigns();
                break;
            case 'pages':
                Pages::pages();
                break;
            case 'engagement':
                Pages::engagement();
                break;
            case 'conversions':
                Pages::conversions();
                break;
            case 'live':
                Pages::live();
                break;
            case 'journeys':
                Pages::journeys();
                break;
            case 'integrations':
                Pages::integrations();
                break;
            case 'settings':
                Pages::settings();
                break;
            case 'export':
                ExportTab::render();
                break;
            default:
                Pages::overview();
        }
    }

    /**
     * The frame: sidebar and main column.
     */
    public static function render_frame(string $active, callable $content): void
    {
        echo '<div class="awp-app">';
        echo '<aside class="awp-side">';
        echo '<div class="awp-brand"><span class="awp-brand-mark">' . Icons::svg('chart-bar') . '</span><span>'
            . '<span class="awp-brand-name">Analytics</span>'
            . '<span class="awp-brand-meta">Cookielos · Version ' . esc_html(ANALYTICSWP_VERSION) . '</span></span></div>';

        echo '<nav class="awp-nav" aria-label="Analytics">';
        $group = '';
        foreach (self::TABS as $tab => [$tab_group, $icon, $title]) {
            if (in_array($tab, ['settings', 'export'], true) && !current_user_can('manage_options')) {
                continue;
            }
            if ($tab_group !== $group) {
                if ($group !== '') {
                    echo '</ul>';
                }
                echo '<p class="awp-nav-group">' . esc_html($tab_group) . '</p><ul class="awp-nav-list">';
                $group = $tab_group;
            }
            $is_active = $tab === $active;
            // Switching tabs keeps the period and filters, not the tab's own
            // view (metric, dimension).
            $url = self::url(['tab' => $tab === 'overview' ? null : $tab] + array_fill_keys(self::VIEW_PARAMS, null));
            echo '<li><a class="awp-nav-item' . ($is_active ? ' is-active' : '') . '" href="' . esc_url($url) . '"' . ($is_active ? ' aria-current="page"' : '') . '>'
                . '<span class="awp-tile">' . Icons::svg($icon) . '</span><span>' . esc_html($title) . '</span></a></li>';
        }
        echo '</ul></nav>';

        echo '<div class="awp-side-foot">Ohne Cookies, ohne IP-Adressen. Besucher werden höchstens einen Tag lang wiedererkannt.</div>';
        echo '</aside>';

        // WordPress moves admin notices of other plugins behind .wp-header-end
        // (common.js), so they land in this column instead of above the app.
        echo '<main class="awp-main"><hr class="wp-header-end">';
        $content();
        echo '</main></div>';
    }

    /**
     * Page title with period selector.
     */
    public static function page_head(string $title, string $subtitle, bool $with_period = true): void
    {
        echo '<div class="awp-page-head"><div><h1 class="awp-title">' . esc_html($title) . '</h1>';
        if ($subtitle !== '' || $with_period) {
            echo '<div class="awp-subline">';
            if ($subtitle !== '') {
                echo '<p class="awp-subtitle">' . esc_html($subtitle) . '</p>';
            }
            if ($with_period) {
                self::filter_chips();
            }
            echo '</div>';
        }
        echo '</div>';
        if ($with_period) {
            echo '<div class="awp-head-tools">';
            if (self::current_tab() !== 'live') {
                self::live_pill();
            }
            self::period_selector();
            echo '</div>';
        }
        echo '</div>';
    }

    /**
     * "● 3 gerade online ›", a link to the live view. Grey dot at 0,
     * petrol with a pulse from 1.
     */
    private static function live_pill(): void
    {
        $count = Reports::online_count();
        $label = $count === 1 ? '1 Besucher gerade online, Live öffnen' : Format::number($count) . ' Besucher gerade online, Live öffnen';

        echo '<a class="awp-live-pill' . ($count > 0 ? ' is-active' : '') . '" href="' . esc_url(self::url(['tab' => 'live', 'f_*' => null, 'p' => null])) . '" aria-label="' . esc_attr($label) . '" title="In den letzten 5 Minuten aktiv">'
            . '<span class="awp-live-dot" aria-hidden="true"></span>'
            . '<span><strong>' . esc_html(Format::number($count)) . '</strong> gerade online</span>'
            . Icons::svg('caret-right') . '</a>';
    }

    /**
     * @return array{key: string, start: string, end: string, prev_start: string, prev_end: string, days: int, hourly: bool}
     */
    public static function period(): array
    {
        $range = isset($_GET['range']) ? sanitize_key(wp_unslash($_GET['range'])) : '30d';
        $from = isset($_GET['from']) ? sanitize_text_field(wp_unslash($_GET['from'])) : '';
        $to = isset($_GET['to']) ? sanitize_text_field(wp_unslash($_GET['to'])) : '';

        return Reports::period($range, $from, $to);
    }

    /**
     * @return array<string, string>
     */
    public static function filters(): array
    {
        return Reports::filters_from($_GET);
    }

    private static function period_selector(): void
    {
        $period = self::period();
        $quick = ['today' => 'Heute', '7d' => '7 Tage', '30d' => '30 Tage', '90d' => '90 Tage', '12m' => '12 Monate'];
        $more = ['yesterday' => 'Gestern', 'month' => 'Dieser Monat', 'last_month' => 'Letzter Monat'];

        echo '<div class="awp-toolbar"><nav class="awp-segmented" aria-label="Zeitraum">';
        foreach ($quick as $key => $label) {
            $is = $period['key'] === $key;
            echo '<a href="' . esc_url(self::url(['range' => $key, 'from' => null, 'to' => null])) . '"' . ($is ? ' class="is-active" aria-current="true"' : '') . '>' . esc_html($label) . '</a>';
        }
        echo '</nav>';

        $more_active = isset($more[$period['key']]) || $period['key'] === 'custom';
        $more_label = $more[$period['key']] ?? ($period['key'] === 'custom' ? Format::day($period['start'], true) . ' – ' . Format::day($period['end'], true) : 'Mehr');
        echo '<details class="awp-more' . ($more_active ? ' is-active' : '') . '"><summary>' . esc_html($more_label) . Icons::svg('caret-down') . '</summary><div class="awp-more-panel">';
        foreach ($more as $key => $label) {
            echo '<a href="' . esc_url(self::url(['range' => $key, 'from' => null, 'to' => null])) . '"' . ($period['key'] === $key ? ' class="is-active"' : '') . '>' . esc_html($label) . '</a>';
        }

        // Custom range: a GET form that carries the current state along.
        echo '<form method="get" action="' . esc_url(admin_url('admin.php')) . '">';
        echo '<input type="hidden" name="page" value="' . esc_attr(self::SLUG) . '"><input type="hidden" name="range" value="custom">';
        foreach (array_merge(['tab', 'metric', 'dim'], array_map(function ($k) {
            return 'f_' . $k;
        }, array_keys(Reports::FILTERS))) as $param) {
            if (isset($_GET[$param]) && is_string($_GET[$param]) && $_GET[$param] !== '') {
                echo '<input type="hidden" name="' . esc_attr($param) . '" value="' . esc_attr(sanitize_text_field(wp_unslash($_GET[$param]))) . '">';
            }
        }
        echo '<label>Von<input type="date" name="from" value="' . esc_attr($period['start']) . '" max="' . esc_attr(wp_date('Y-m-d')) . '"></label>';
        echo '<label>Bis<input type="date" name="to" value="' . esc_attr($period['end']) . '" max="' . esc_attr(wp_date('Y-m-d')) . '"></label>';
        echo '<button type="submit" class="button">Zeitraum anzeigen</button></form>';
        echo '</div></details></div>';
    }

    /**
     * Active filters as chips under the title: "Nur E-Mail ×". A click
     * removes the filter.
     */
    private static function filter_chips(): void
    {
        $filters = self::filters();
        if (empty($filters)) {
            return;
        }

        $names = [
            'source' => 'Quelle',
            'medium' => 'Medium',
            'campaign' => 'Kampagne',
            'term' => 'Begriff',
            'content' => 'Inhalt',
            'landing' => 'Einstieg',
            'referrer' => 'Verweis',
            'device' => 'Gerät',
        ];

        echo '<span class="awp-chips">';
        foreach ($filters as $key => $value) {
            $text = $value === Reports::NONE ? Ui::dimension_label($key, null) : Ui::dimension_label($key, $value);
            $label = $key === 'channel' ? 'Nur ' . $text : 'Nur ' . ($names[$key] ?? $key) . ' „' . $text . '“';
            echo '<a class="awp-chip" href="' . esc_url(self::url(['f_' . $key => null])) . '" title="Filter entfernen">'
                . Icons::svg('funnel') . '<span>' . esc_html($label) . '</span>'
                . '<span class="awp-chip-x">' . Icons::svg('x') . '<span class="awp-sr">Filter entfernen</span></span></a>';
        }
        if (count($filters) > 1) {
            echo '<a class="awp-chips-clear" href="' . esc_url(self::url(['f_*' => null])) . '">Alle entfernen</a>';
        }
        echo '</span>';
    }
}
