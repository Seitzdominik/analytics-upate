<?php

namespace AnalyticsWP\Lib\Admin;

use AnalyticsWP\Lib\Attribution;

/**
 * German labels and number formats for the admin screens. The admin is
 * German only (Du-Form), so the texts live here rather than in a .po file.
 */
class Format
{
    const CHANNELS = [
        Attribution::DIRECT => 'Direkt',
        Attribution::ORGANIC_SEARCH => 'Organische Suche',
        Attribution::PAID_SEARCH => 'Bezahlte Suche',
        Attribution::ORGANIC_SOCIAL => 'Social Media',
        Attribution::PAID_SOCIAL => 'Bezahlte Social Ads',
        Attribution::EMAIL => 'E-Mail',
        Attribution::REFERRAL => 'Verweise',
        Attribution::DISPLAY => 'Display',
        Attribution::AFFILIATE => 'Affiliate',
        Attribution::AI => 'KI-Assistenten',
        Attribution::OTHER => 'Sonstige Kampagnen',
    ];

    const DEVICES = [
        'desktop' => 'Desktop',
        'mobile' => 'Smartphone',
        'tablet' => 'Tablet',
    ];

    const CONVERSION_TYPES = [
        'surecart_checkout' => 'SureCart-Kauf',
        'sureforms' => 'SureForms',
        'woocommerce_order' => 'WooCommerce-Bestellung',
        'woocommerce_order-subscription-renewal' => 'WooCommerce-Abo-Verlängerung',
        'edd_order' => 'EDD-Bestellung',
        'wpforms' => 'WPForms',
        'gravity_forms' => 'Gravity Forms',
        'fluent_forms' => 'Fluent Forms',
        'contact_form_7' => 'Contact Form 7',
        'elementor_form' => 'Elementor-Formular',
        'formidable_forms' => 'Formidable Forms',
        'ninja_forms' => 'Ninja Forms',
        'everest_forms' => 'Everest Forms',
        'forminator_form' => 'Forminator',
        'contact_tel' => 'Klick auf Telefonnummer',
        'contact_mailto' => 'Klick auf E-Mail-Adresse',
        'contact_whatsapp' => 'Klick auf WhatsApp',
    ];

    /** German descriptions of upstream's integrations, by slug. */
    const INTEGRATION_DESCRIPTIONS = [
        'bricks-builder' => 'Klicks auf Buttons, Formular-Absendungen und CTAs in Bricks.',
        'contact-form-7' => 'Absendungen von Contact-Form-7-Formularen als Conversion.',
        'elementor' => 'Formulare von Elementor Pro als Conversion, Klicks auf Buttons und CTAs, die du im Widget einschaltest.',
        'fluent-forms' => 'Absendungen von Fluent-Forms-Formularen als Conversion.',
        'woocommerce' => 'Bestellungen mit Umsatz, Herkunft an der Bestellung und in der E-Mail „Neue Bestellung“.',
    ];

    /**
     * What each integration is and reports: slug => [group, what it reports
     * (chips), conversion types, other event types]. Groups: shop, form,
     * builder.
     */
    const INTEGRATIONS = [
        'woocommerce' => ['shop', ['Käufe mit Umsatz', 'Herkunft an der Bestellung', 'Herkunft in der Mail „Neue Bestellung“'], ['woocommerce_order', 'woocommerce_order-subscription-renewal'], []],
        'surecart' => ['shop', ['Käufe mit Umsatz'], ['surecart_checkout'], []],
        'sureforms' => ['form', ['Absendungen je Formular'], ['sureforms'], []],
        'fluent-forms' => ['form', ['Absendungen je Formular'], ['fluent_forms'], []],
        'contact-form-7' => ['form', ['Absendungen je Formular'], ['contact_form_7'], ['contact_form_7_submission']],
        'bricks-builder' => ['builder', ['Klicks auf Buttons', 'Formular-Absendungen'], [], []],
        'elementor' => ['builder', ['Formulare (Pro)', 'Klicks auf Buttons'], ['elementor_form'], []],
    ];

    /** Integration groups => [label, kind label, icon]. */
    const INTEGRATION_GROUPS = [
        'shop' => ['Shops', 'Shop', 'shopping-cart'],
        'form' => ['Formulare', 'Formulare', 'textbox'],
        'builder' => ['Page Builder', 'Page Builder', 'squares-four'],
    ];

    public static function integration_description(string $slug, string $fallback): string
    {
        return self::INTEGRATION_DESCRIPTIONS[$slug] ?? $fallback;
    }

    const CURRENCY_SYMBOLS = [
        'EUR' => '€',
        'USD' => '$',
        'GBP' => '£',
        'CHF' => 'CHF',
    ];

    public static function channel(?string $key): string
    {
        return self::CHANNELS[(string)$key] ?? ($key ?: 'Unbekannt');
    }

    public static function device(?string $key): string
    {
        return self::DEVICES[(string)$key] ?? ($key ?: 'Unbekannt');
    }

    public static function conversion_type(string $type): string
    {
        return self::CONVERSION_TYPES[$type] ?? $type;
    }

    /**
     * A page path with numbers and IDs folded: "/kasse/order-received/219/"
     * becomes "/kasse/order-received/…/", so order confirmations count as
     * one page. Returns the path and a label for it ("Startseite",
     * "Bestellbestätigung", or '').
     *
     * @return array{0: string, 1: string}
     */
    public static function page_group(string $path): array
    {
        $segments = explode('/', $path);
        foreach ($segments as $i => $segment) {
            if ($segment !== '' && (ctype_digit($segment) || preg_match('/^(?:[0-9a-f]{12,}|[0-9a-f-]{32,36}|wc_order_\w+)$/i', $segment))) {
                $segments[$i] = '…';
            }
        }
        $group = implode('/', $segments);

        $label = '';
        if ($group === '/') {
            $label = 'Startseite';
        } elseif (preg_match('#order-received|bestellung-erhalten|order-confirmation|bestellbestaetigung|danke#i', $group) && strpos($group, '…') !== false) {
            $label = 'Bestellbestätigung';
        }

        return [$group, $label];
    }

    /** Kinds of conversion => [label, icon], in display order. */
    const CONVERSION_KINDS = [
        'purchase' => ['Käufe', 'shopping-cart'],
        'form' => ['Formulare', 'textbox'],
        'contact' => ['Kontakt-Klicks', 'phone'],
        'other' => ['Sonstige', 'target'],
    ];

    /**
     * Purchase, form, contact click or other, from the conversion type.
     *
     * @return 'purchase'|'form'|'contact'|'other'
     */
    public static function conversion_kind(string $type): string
    {
        if (strpos($type, 'contact_') === 0) {
            return 'contact';
        }
        if (in_array($type, ['surecart_checkout', 'edd_order'], true) || strpos($type, 'woocommerce_order') === 0) {
            return 'purchase';
        }
        if (preg_match('/form|sureforms/', $type)) {
            return 'form';
        }

        return 'other';
    }

    /**
     * 1.234 / 1,2 Mio.
     *
     * @param int|float $n
     */
    public static function number($n): string
    {
        $n = (float)$n;
        if ($n >= 1000000) {
            return number_format($n / 1000000, 1, ',', '.') . ' Mio.';
        }

        return number_format($n, 0, ',', '.');
    }

    /**
     * A share (0..1) as "12,3 %".
     *
     * @param int|float $share
     */
    public static function percent($share, int $decimals = 1): string
    {
        return number_format((float)$share * 100, $decimals, ',', '.') . ' %';
    }

    /**
     * @param int|float $amount
     */
    public static function money($amount, string $currency, int $decimals = 2): string
    {
        $symbol = self::CURRENCY_SYMBOLS[$currency] ?? $currency;

        return number_format((float)$amount, $decimals, ',', '.') . ' ' . $symbol;
    }

    /**
     * Seconds as "1:05 Min." or "42 Sek.".
     *
     * @param int|float $seconds
     */
    public static function duration($seconds): string
    {
        $seconds = (int)round((float)$seconds);
        if ($seconds < 60) {
            return $seconds . ' Sek.';
        }
        if ($seconds < 3600) {
            return sprintf('%d:%02d Min.', intdiv($seconds, 60), $seconds % 60);
        }

        return sprintf('%d:%02d Std.', intdiv($seconds, 3600), intdiv($seconds % 3600, 60));
    }

    /**
     * Change from $previous to $current as a share, or null without a base.
     *
     * @param int|float $current
     * @param int|float $previous
     */
    public static function change($current, $previous): ?float
    {
        if ((float)$previous == 0.0) {
            return null;
        }

        return ((float)$current - (float)$previous) / (float)$previous;
    }

    /**
     * A day (Y-m-d) as "19.10." or with year "19.10.2026".
     */
    public static function day(string $ymd, bool $with_year = false): string
    {
        $time = strtotime($ymd . ' 12:00:00');
        return $time ? gmdate($with_year ? 'j.n.Y' : 'j.n.', $time) : $ymd;
    }

    /**
     * A UTC MySQL datetime as local "19.10., 10:24".
     */
    public static function datetime(string $utc): string
    {
        $time = strtotime($utc . ' UTC');
        if (!$time) {
            return $utc;
        }

        $local = wp_date('Y-m-d', $time);
        if ($local === wp_date('Y-m-d')) {
            return 'Heute, ' . wp_date('H:i', $time);
        }
        if ($local === wp_date('Y-m-d', time() - DAY_IN_SECONDS)) {
            return 'Gestern, ' . wp_date('H:i', $time);
        }

        return (string)wp_date('j.n., H:i', $time);
    }

    /**
     * "vor 3 Min." for the live view.
     */
    public static function ago(string $utc): string
    {
        $time = strtotime($utc . ' UTC');
        if (!$time) {
            return '';
        }

        $diff = max(0, time() - $time);
        if ($diff < 60) {
            return 'gerade eben';
        }
        if ($diff < 3600) {
            return 'vor ' . intdiv($diff, 60) . ' Min.';
        }

        return 'vor ' . intdiv($diff, 3600) . ' Std.';
    }

    /**
     * A URL on this site as its path ("/kontakt/"); other URLs unchanged.
     */
    public static function path(?string $url): string
    {
        if ($url === null || $url === '') {
            return '–';
        }

        $home = untrailingslashit(home_url());
        if (stripos($url, $home) === 0) {
            $path = substr($url, strlen($home));
            return $path === '' ? '/' : $path;
        }

        return $url;
    }
}
