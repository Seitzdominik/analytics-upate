<?php

namespace AnalyticsWP\Lib\Admin;

use AnalyticsWP\Lib\Integrations;
use AnalyticsWP\Lib\Reports;
use AnalyticsWP\Lib\SuperSimpleWP;
use AnalyticsWP\Lib\URLs;
use AnalyticsWP\Lib\Validators;

/**
 * The views of the admin app. Each one reads the period and filters from
 * the URL (App::period(), App::filters()) and renders cards.
 */
class Pages
{
    // ---------------------------------------------------------------------
    // Übersicht
    // ---------------------------------------------------------------------

    /**
     * Key figures of the overview: metric => [label, chart title, format,
     * higher is better, explanation]. Every tile switches the chart.
     */
    const OVERVIEW_KPIS = [
        'visitors' => ['Besucher', 'Besucher', 'number', true, 'visitors'],
        'pageviews' => ['Seitenaufrufe', 'Seitenaufrufe', 'number', true, 'pageviews'],
        'bounce_rate' => ['Absprungrate', 'Absprungrate', 'percent', false, 'bounce'],
        'duration' => ['Ø Besuchsdauer', 'Ø Besuchsdauer', 'duration', true, 'duration'],
        'conversions' => ['Conversions', 'Conversions', 'number', true, 'conversions'],
        'revenue' => ['Umsatz', 'Umsatz', 'money', true, 'revenue'],
    ];

    public static function overview(): void
    {
        $period = App::period();
        $filters = App::filters();

        if (!Reports::has_data()) {
            App::page_head('Übersicht', self::period_sentence($period));
            self::first_start();
            return;
        }

        // Measurement start: before it there is nothing to compare with,
        // and the chart starts there instead of at zero.
        $since = Reports::first_seen_day();
        $compare = $since === null || $since <= $period['prev_end'];
        $since_in_period = $since !== null && $since > $period['start'] && $since <= $period['end'];

        App::page_head('Übersicht', self::period_sentence($period, $since_in_period ? $since : null));

        $currency = Reports::main_currency($period);
        $totals = Reports::totals($period, $filters, $currency);
        $series = Reports::timeseries($period, $filters, $currency);
        $channels = Reports::breakdown('channel', $period, $filters, $currency, 11);
        $types = Reports::conversion_types($period, $filters, $currency);

        $measured_days = $since !== null ? (int)floor((strtotime(wp_date('Y-m-d')) - strtotime($since)) / DAY_IN_SECONDS) + 1 : 0;
        $early = !$compare && ($measured_days < 7 || (int)$totals['current']['sessions'] < \AnalyticsWP\Lib\Insights::MIN_VISITS);

        echo '<div class="awp-layout">';
        self::glance($totals, $period, $currency, $channels, $types, $compare, $early, $since);
        self::kpi_chart($totals, $series, $period, $currency, $compare, $since_in_period ? $since : null);
        self::channel_mix($channels, $currency, (int)$totals['current']['sessions']);

        echo '<div class="awp-span-all awp-cols-3">';
        self::conversion_groups($types, $currency, (int)$totals['current']['conversions'], (float)$totals['current']['revenue']);
        self::top_pages(Reports::pages($period, $filters, 5));
        self::top_campaigns(Reports::breakdown('campaign', $period, $filters, $currency, 6), $currency);
        echo '</div>';

        echo '</div>';
    }

    private static function first_start(): void
    {
        echo '<div class="awp-layout">';
        Ui::card_open('lightning', 'Noch keine Besuche', 'Das Tracking ist aktiv. Die ersten Zahlen erscheinen nach dem nächsten Besuch.', '', 'awp-span-all');
        echo '<div class="awp-card-body">';
        echo '<p>Öffne deine Website in einem privaten Fenster: Eingeloggte Besuche zählen nur, wenn deine Rolle nicht ausgeschlossen ist.</p>';
        echo Ui::info('Es werden keine Cookies gesetzt und keine IP-Adressen gespeichert. Ein Cookie-Banner braucht die Messung deshalb nicht.');
        echo '</div>';
        Ui::card_close('<a class="awp-linkline" href="' . esc_url(home_url('/')) . '" target="_blank" rel="noopener">Website öffnen' . Icons::svg('arrow-square-out') . '<span class="awp-sr"> (öffnet in einem neuen Tab)</span></a>');
        echo '</div>';
    }

    /**
     * "Auf einen Blick": one sentence on what changed, three findings.
     *
     * @param array{current: array<string, float|int>, previous: array<string, float|int>} $totals
     * @param list<array<string, mixed>> $channels
     * @param list<array<string, mixed>> $types
     */
    private static function glance(array $totals, array $period, string $currency, array $channels, array $types, bool $compare, bool $early, ?string $since): void
    {
        $figures = \AnalyticsWP\Lib\Insights::summary($totals['current'], $compare ? $totals['previous'] : [], (int)$period['days'], $currency);

        if ($early) {
            $tone = 'info';
            $title = 'Die ersten Zahlen sind da.';
            $text = 'Aussagekräftig wird es nach etwa einer Woche. Bis dahin schwanken die Werte stark.';
        } elseif (!$compare) {
            $tone = 'info';
            $title = 'Noch kein Vergleich: Gemessen wird seit ' . Format::day((string)$since, true) . '.';
            $text = $figures['text'];
        } else {
            $tone = $figures['tone'];
            $title = $figures['title'];
            $text = $figures['text'];
        }
        $icon = ['good' => 'arrow-up', 'bad' => 'arrow-down', 'neutral' => 'info', 'info' => 'info'][$tone];

        echo '<section class="awp-card awp-span-all awp-glance" aria-label="Auf einen Blick">';
        echo '<div class="awp-glance-summary is-' . esc_attr($tone) . '">' . Icons::svg($icon) . '<div><p class="awp-glance-title">' . esc_html($title) . '</p><p class="awp-glance-text">' . esc_html($text) . '</p></div></div>';

        $cards = [
            \AnalyticsWP\Lib\Insights::largest_channel($channels, $currency),
            \AnalyticsWP\Lib\Insights::best_conversion_rate($channels),
            \AnalyticsWP\Lib\Insights::top_conversion($types),
        ];
        $fallback_icons = ['largest_channel' => 'magnifying-glass', 'best_conversion_rate' => 'sparkle', 'top_conversion' => 'textbox'];

        echo '<div class="awp-insights">';
        foreach ($cards as $card) {
            if ($card['status'] === 'ok' && $card['channel'] !== null) {
                $icon = Channels::icon($card['channel']);
            } elseif (isset($card['kind'])) {
                $icon = Format::CONVERSION_KINDS[$card['kind']][1];
            } else {
                $icon = $fallback_icons[$card['key']];
            }
            echo '<a class="awp-insight' . ($card['status'] === 'pending' ? ' is-pending' : '') . '" href="' . esc_url(App::url(['tab' => $card['tab']])) . '">'
                . '<span class="awp-tile">' . Icons::svg($icon) . '</span>'
                . '<span class="awp-insight-text"><span class="awp-insight-label">' . esc_html($card['label']) . '</span>'
                . '<span class="awp-insight-value">' . esc_html($card['value']) . '</span>'
                . '<span class="awp-insight-detail">' . esc_html($card['detail']) . '</span></span>'
                . Icons::svg('caret-right') . '</a>';
        }
        echo '</div></section>';
    }

    /**
     * Six key figures with the value before, and the chart they switch.
     *
     * @param array{current: array<string, float|int>, previous: array<string, float|int>, other_currencies: array<string, float>} $totals
     * @param array{labels: list<string>, series: array<string, list<float|int>>, previous: array<string, list<float|int>>} $series
     */
    private static function kpi_chart(array $totals, array $series, array $period, string $currency, bool $compare, ?string $since): void
    {
        $metric = self::requested_metric();
        $per = $period['hourly'] ? ' pro Stunde' : ' pro Tag';
        $since_text = $since !== null ? 'Messung seit ' . Format::day($since) : 'Noch kein Vergleich';

        echo '<section class="awp-card awp-span-all" aria-label="Kennzahlen und Verlauf">';
        echo '<div class="awp-kpis" role="tablist" aria-label="Kennzahl im Diagramm">';
        foreach (self::OVERVIEW_KPIS as $key => [$label, , $format, $higher_is_better, $term]) {
            $value = $totals['current'][$key] ?? 0;
            $previous = $totals['previous'][$key] ?? 0;
            $help = $key === 'revenue'
                ? 'Summe der Käufe aus WooCommerce, SureCart und Easy Digital Downloads in ' . $currency . '.'
                : Ui::TERMS[$term];

            if ($compare) {
                $delta = self::kpi_delta($value, $previous, $higher_is_better);
                $sub = 'vorher ' . self::format_value($previous, $format, $currency) . ($higher_is_better ? '' : ' · weniger ist besser');
            } else {
                $delta = '<span class="awp-delta">Noch kein Vergleich</span>';
                $sub = $since_text;
            }
            if ($key === 'conversions') {
                $sub = Format::percent($totals['current']['conversion_rate'] ?? 0) . ' der Besuche';
            }

            echo '<button type="button" class="awp-kpi" role="tab" data-awp-metric="' . esc_attr($key) . '" aria-selected="' . ($key === $metric ? 'true' : 'false') . '">'
                . '<span class="awp-kpi-label">' . Ui::term($label, $help) . '</span>'
                . '<span class="awp-kpi-value">' . esc_html(self::format_value($value, $format, $currency)) . '</span>'
                . $delta
                . '<span class="awp-kpi-sub">' . esc_html($sub) . '</span>'
                . '</button>';
        }
        echo '</div>';

        $metrics = [];
        foreach (self::OVERVIEW_KPIS as $key => [$label, $title, $format, $higher_is_better]) {
            $metrics[$key] = ['label' => $label, 'title' => $title . $per, 'format' => $format, 'better' => $higher_is_better];
        }

        $count = count($series['labels']);
        $today = wp_date('Y-m-d');
        $open = $period['end'] === $today;
        $end = $open && $period['hourly'] ? (int)wp_date('G') : $count - 1;
        $start = 0;
        if ($since !== null && !$period['hourly']) {
            $start = (int)floor((strtotime($since) - strtotime($period['start'])) / DAY_IN_SECONDS);
        }

        echo Chart::render($series['labels'], $series['series'], $series['previous'], $metrics, $metric, $period['hourly'], $currency, [
            'start' => $start,
            'end' => $end,
            'open' => $open,
            'compare' => $compare,
            'strip' => $series['series']['conversions'] ?? [],
            'strip_off' => ['conversions', 'revenue'],
            'since' => $since !== null ? 'Messung seit ' . Format::day($since) : '',
        ]);

        if (!empty($totals['other_currencies'])) {
            $parts = [];
            foreach ($totals['other_currencies'] as $code => $amount) {
                $parts[] = Format::money($amount, $code);
            }
            echo '<div class="awp-card-foot">Umsatz in ' . esc_html($currency) . '. Nicht eingerechnet: ' . esc_html(implode(', ', $parts)) . '.</div>';
        }
        echo '</section>';
    }

    /**
     * "▲ +14,7 %" in petrol when better, amber when worse; the direction is
     * in the text for screen readers.
     *
     * @param int|float $value
     * @param int|float $previous
     */
    private static function kpi_delta($value, $previous, bool $higher_is_better): string
    {
        $text = \AnalyticsWP\Lib\Insights::signed_change($value, $previous);
        if ($text === null || $text === '± 0 %') {
            return '<span class="awp-delta">' . esc_html($text ?? '–') . ($text === null ? '<span class="awp-sr"> kein Vergleichswert</span>' : '') . '</span>';
        }

        $up = (float)$value > (float)$previous;
        $good = $up === $higher_is_better;

        return '<span class="awp-delta ' . ($good ? 'is-good' : 'is-bad') . '">' . Icons::svg($up ? 'arrow-up' : 'arrow-down')
            . esc_html($text) . '<span class="awp-sr">' . ($good ? ' (besser)' : ' (schlechter)') . '</span></span>';
    }

    /**
     * "Woher die Besuche kommen": donut and table, joined by hover.
     *
     * @param list<array<string, mixed>> $rows
     */
    private static function channel_mix(array $rows, string $currency, int $sessions): void
    {
        $total = 0;
        foreach ($rows as $row) {
            $total += (int)$row['sessions'];
        }
        $enough = $total >= \AnalyticsWP\Lib\Insights::MIN_VISITS;
        $max = $rows ? max(array_column($rows, 'sessions')) : 1;

        Ui::card_open('link', 'Woher die Besuche kommen', Format::number($total) . ' Besuche nach Kanal', '', 'awp-span-all');
        echo '<div class="awp-mix" data-awp-hover="channel-mix">';
        echo Chart::donut($rows, $total, \AnalyticsWP\Lib\Insights::MIN_VISITS);

        echo '<div class="awp-mix-table">';
        if (empty($rows)) {
            echo Ui::empty_state('Für diesen Zeitraum gibt es noch keine Besuche.');
        } else {
            echo '<table class="awp-table awp-table--mix"><thead><tr><th scope="col">Kanal</th><th scope="col">Besuche</th><th scope="col">Anteil</th><th scope="col">Conv.</th>'
                . '<th scope="col" class="is-optional">' . Ui::term('Conv.-Rate', Ui::TERMS['conversion_rate']) . '</th><th scope="col">Umsatz</th></tr></thead><tbody>';
            foreach ($rows as $row) {
                $channel = (string)$row['value'];
                $name = Format::channel($row['value']);
                $width = max(1.5, round((int)$row['sessions'] / max(1, $max) * 100, 1));
                $bar = $enough ? Channels::bar_color($channel) : Channels::rgba('#8e8e98', 0.16);
                $tip = trim(Channels::note($channel) . ' Absprungrate: ' . ((int)$row['sessions'] >= \AnalyticsWP\Lib\Insights::MIN_RATE_BASE ? Format::percent($row['bounce_rate'], 0) : 'zu wenig Besuche') . '.');
                $filter = Ui::dimension_filter('channel', $row['value']);

                echo '<tr data-awp-key="' . esc_attr($channel) . '">'
                    . '<td class="awp-cell-label" data-awp-tip-title="' . esc_attr($name) . '" data-awp-tip="' . esc_attr($tip) . '">'
                    . '<span class="awp-cell-bar" style="width:calc(' . $width . '% - 14px);background:' . esc_attr($bar) . '"></span>'
                    . '<span class="awp-cell-text">' . Channels::icon_html($channel) . '<a href="' . esc_url(App::url($filter)) . '">' . esc_html($name) . '</a></span></td>'
                    . '<td class="is-strong">' . esc_html(Format::number((int)$row['sessions'])) . '</td>'
                    . '<td>' . esc_html($total > 0 ? Format::percent((int)$row['sessions'] / $total) : '–') . '</td>'
                    . '<td>' . esc_html(Format::number((int)$row['conversions'])) . '</td>'
                    . '<td class="is-optional">' . Ui::rate($row['conversion_rate'], (int)$row['sessions']) . '</td>'
                    . '<td>' . ((float)$row['revenue'] > 0 ? esc_html(Format::money((float)$row['revenue'], $currency, 0)) : '<span class="awp-none">–</span>') . '</td>'
                    . '</tr>';
            }
            echo '</tbody></table>';
        }
        if (!$enough && !empty($rows)) {
            echo Ui::info('Die ersten Zahlen sind da. Der Kreis zeigt die Verteilung ab ' . \AnalyticsWP\Lib\Insights::MIN_VISITS . ' Besuchen, aussagekräftig wird es nach etwa einer Woche.');
        }
        echo '</div></div>';
        Ui::card_close(Ui::link(App::url(['tab' => 'campaigns', 'dim' => 'channel']), 'Alle Kanäle und Quellen'));
    }

    /**
     * "Was Besucher abschließen": purchases, forms and contact clicks.
     *
     * @param list<array{type: string, name: string|null, conversions: int, revenue: float, sessions: int}> $types
     */
    private static function conversion_groups(array $types, string $currency, int $conversions, float $revenue, string $title = 'Was Besucher abschließen', string $subtitle = '', string $foot = ''): void
    {
        $sub = $subtitle !== '' ? $subtitle : ($conversions > 0
            ? Format::number($conversions) . ' Conversions' . ($revenue > 0 ? ' · ' . Format::money($revenue, $currency, 0) . ' Umsatz' : '')
            : 'Noch keine Conversions');
        Ui::card_open('target', $title, $sub);

        if (empty($types)) {
            echo '<div class="awp-card-body">' . Ui::info('Noch keine Conversions. Sie erscheinen hier, sobald jemand kauft, ein Formular absendet oder anruft.') . '</div>';
        } else {
            $groups = [];
            foreach ($types as $row) {
                $groups[Format::conversion_kind($row['type'])][] = $row;
            }
            $max = max(array_column($types, 'conversions')) ?: 1;

            echo '<div class="awp-card-body awp-groups">';
            foreach (Format::CONVERSION_KINDS as $kind => [$label, $icon]) {
                if (empty($groups[$kind])) {
                    continue;
                }
                $count = array_sum(array_column($groups[$kind], 'conversions'));
                $sum = array_sum(array_column($groups[$kind], 'revenue'));
                // Forms and contact clicks: the estimated value from the
                // settings, marked "≈" and never added to revenue.
                $estimate = function (array $rows) {
                    $total = 0.0;
                    foreach ($rows as $row) {
                        $total += (int)$row['conversions'] * \AnalyticsWP\Lib\ConversionValue::of($row['type'], $row['name']);
                    }
                    return $total;
                };
                $money = function (float $revenue, float $estimated) use ($currency) {
                    if ($revenue > 0) {
                        return esc_html(Format::money($revenue, $currency, 0));
                    }
                    return $estimated > 0 ? '<span class="awp-estimate" title="Geschätzter Wert aus den Einstellungen, nicht im Umsatz">≈ ' . esc_html(Format::money($estimated, 'EUR', 0)) . '</span>' : '–';
                };
                echo '<div class="awp-group"><div class="awp-group-head"><span class="awp-tile">' . Icons::svg($icon) . '</span>'
                    . '<span class="awp-group-label">' . esc_html($label) . '</span>'
                    . '<span class="awp-group-count">' . esc_html(Format::number($count)) . '</span>'
                    . '<span class="awp-group-rev">' . $money($sum, $estimate($groups[$kind])) . '</span></div>';
                foreach ($groups[$kind] as $row) {
                    $name = Format::conversion_type($row['type']) . ($row['name'] !== null ? ': ' . $row['name'] : '');
                    echo '<div class="awp-group-row" title="' . esc_attr($name . ': ' . $row['conversions']) . '">'
                        . self::bar_label($name, (int)$row['conversions'], $max)
                        . '<span class="awp-num">' . esc_html(Format::number($row['conversions'])) . '</span>'
                        . '<span class="awp-num is-muted">' . $money((float)$row['revenue'], $estimate([$row])) . '</span></div>';
                }
                echo '</div>';
            }
            echo '</div>';
        }

        Ui::card_close($foot !== '' ? $foot : Ui::link(App::url(['tab' => 'conversions']), 'Alle Conversions'));
    }

    /**
     * @param list<array{path: string, pageviews: int, entries: int}> $pages
     */
    private static function top_pages(array $pages): void
    {
        Ui::card_open('stack', 'Beliebteste Seiten', 'Aufrufe und wie oft ein Besuch dort begann');
        if (empty($pages)) {
            echo '<div class="awp-card-body">' . Ui::info('Noch keine Seitenaufrufe in diesem Zeitraum.') . '</div>';
        } else {
            $max = max(array_column($pages, 'pageviews')) ?: 1;
            echo '<div class="awp-card-body is-flush"><table class="awp-table awp-table--compact"><thead><tr><th scope="col">Seite</th><th scope="col">Aufrufe</th>'
                . '<th scope="col">' . Ui::term('Einstiege', 'So oft war diese Seite die erste eines Besuchs.') . '</th></tr></thead><tbody>';
            foreach ($pages as $page) {
                echo '<tr><td class="awp-cell-label">' . self::bar_label($page['path'], (int)$page['pageviews'], $max) . '</td>'
                    . '<td class="is-strong">' . esc_html(Format::number($page['pageviews'])) . '</td>'
                    . '<td>' . esc_html(Format::number($page['entries'])) . '</td></tr>';
            }
            echo '</tbody></table></div>';
        }
        Ui::card_close(Ui::link(App::url(['tab' => 'pages']), 'Alle Seiten'));
    }

    /**
     * @param list<array<string, mixed>> $rows Reports::breakdown('campaign', ...)
     */
    private static function top_campaigns(array $rows, string $currency): void
    {
        $campaigns = array_slice(array_values(array_filter($rows, function ($row) {
            return $row['value'] !== null;
        })), 0, 5);

        Ui::card_open('megaphone', 'Kampagnen', 'Links mit ' . Ui::term('utm_campaign', 'Ein Zusatz an der Adresse, z. B. ?utm_campaign=herbst-aktion. Baust du unter Kanäle & Kampagnen.'), '', '', true);
        if (empty($campaigns)) {
            echo '<div class="awp-card-body">' . Ui::info('Noch keine Kampagnen-Besuche. Mit einem UTM-Link siehst du, welcher Newsletter oder welche Anzeige Besucher bringt.') . '</div>';
        } else {
            $max = max(array_column($campaigns, 'sessions')) ?: 1;
            echo '<div class="awp-card-body is-flush"><table class="awp-table awp-table--compact"><thead><tr><th scope="col">Kampagne</th><th scope="col">Besuche</th><th scope="col">Conv.</th><th scope="col">Umsatz</th></tr></thead><tbody>';
            foreach ($campaigns as $row) {
                $url = App::url(Ui::dimension_filter('campaign', $row['value']));
                echo '<tr><td class="awp-cell-label">' . self::bar_label((string)$row['value'], (int)$row['sessions'], $max, $url) . '</td>'
                    . '<td class="is-strong">' . esc_html(Format::number($row['sessions'])) . '</td>'
                    . '<td>' . esc_html(Format::number($row['conversions'])) . '</td>'
                    . '<td>' . ((float)$row['revenue'] > 0 ? esc_html(Format::money((float)$row['revenue'], $currency, 0)) : '–') . '</td></tr>';
            }
            echo '</tbody></table></div>';
        }
        Ui::card_close(Ui::link(App::url(['tab' => 'campaigns', 'dim' => 'campaign']), 'Alle Kampagnen') . Ui::link(App::url(['tab' => 'campaigns', 'dim' => 'campaign']) . '#awp-utm', 'UTM-Link bauen'));
    }

    /**
     * A label with a petrol bar behind it, for the compact lists.
     */
    private static function bar_label(string $text, int $value, int $max, string $url = ''): string
    {
        $width = max(1.5, round($value / max(1, $max) * 100, 1));
        $label = $url !== '' ? '<a href="' . esc_url($url) . '">' . esc_html($text) . '</a>' : esc_html($text);

        return '<span class="awp-barlabel"><span class="awp-cell-bar" style="width:' . $width . '%;background:' . esc_attr(Channels::bar_color(null)) . '"></span>'
            . '<span class="awp-cell-text" title="' . esc_attr($text) . '">' . $label . '</span></span>';
    }

    private static function requested_metric(): string
    {
        $metric = isset($_GET['metric']) ? sanitize_key(wp_unslash($_GET['metric'])) : 'visitors';

        return isset(self::OVERVIEW_KPIS[$metric]) ? $metric : 'visitors';
    }

    /**
     * @param int|float $value
     */
    private static function format_value($value, string $format, string $currency): string
    {
        switch ($format) {
            case 'percent':
                return Format::percent($value);
            case 'money':
                return Format::money($value, $currency, 0);
            case 'duration':
                return Format::duration($value);
            default:
                return Format::number($value);
        }
    }

    /**
     * @param array{key: string, start: string, end: string, days: int} $period
     */
    private static function period_sentence(array $period, ?string $since = null): string
    {
        $range = $period['days'] === 1
            ? Format::day($period['start'], true)
            : Format::day($period['start'], true) . ' bis ' . Format::day($period['end'], true);

        if ($since !== null) {
            return $range . ' · Messung seit ' . Format::day($since);
        }

        return $range . ($period['days'] === 1 ? ', verglichen mit dem Tag davor' : ', verglichen mit den ' . $period['days'] . ' Tagen davor');
    }

    // ---------------------------------------------------------------------
    // Kanäle & Kampagnen
    // ---------------------------------------------------------------------

    /** Main views of the channel table, and the ones under "Weitere". */
    const MAIN_DIMENSIONS = [
        'channel' => ['Kanal', 'Alle Kanäle', 'Gruppiert nach Art der Herkunft', 'Kanal'],
        'source_medium' => ['Quelle', 'Quellen', 'Woher genau: Website und Art, z. B. google / organic', 'Quelle / Art'],
        'campaign' => ['Kampagne', 'Kampagnen', 'Aus utm_campaign, mit dem Kanal dahinter', 'Kampagne'],
    ];
    const MORE_DIMENSIONS = [
        'content' => ['Inhalt', 'Inhalte', 'Aus utm_content, z. B. zwei Buttons im selben Newsletter', 'Inhalt'],
        'term' => ['Begriff', 'Begriffe', 'Aus utm_term, meist das Suchwort einer Anzeige', 'Begriff'],
        'referrer' => ['Verweis-Domain', 'Verweis-Domains', 'Die Website, von der ein Link kam', 'Domain'],
    ];

    /** Filter keys that belong to a dimension (the table ignores its own). */
    const DIMENSION_FILTER_KEYS = [
        'channel' => ['channel'],
        'source_medium' => ['source', 'medium'],
        'campaign' => ['campaign'],
        'content' => ['content'],
        'term' => ['term'],
        'referrer' => ['referrer'],
    ];

    public static function campaigns(): void
    {
        $period = App::period();
        $filters = App::filters();
        $all = self::MAIN_DIMENSIONS + self::MORE_DIMENSIONS;
        $dimension = isset($_GET['dim']) ? sanitize_key(wp_unslash($_GET['dim'])) : 'channel';
        if (!isset($all[$dimension])) {
            $dimension = 'channel';
        }

        App::page_head('Kanäle & Kampagnen', self::period_sentence($period));
        $currency = Reports::main_currency($period);

        echo '<div class="awp-layout">';

        // What each channel brings: always all channels, the channel filter
        // only dims the others.
        $channel_filters = $filters;
        unset($channel_filters['channel']);
        $channels = Reports::breakdown('channel', $period, $channel_filters, $currency, 20);
        self::channel_value($channels, $currency, $filters['channel'] ?? null);

        // The table ignores the filter of its own dimension, so the other
        // values stay visible and the chosen one is marked.
        $table_filters = $filters;
        foreach (self::DIMENSION_FILTER_KEYS[$dimension] as $key) {
            unset($table_filters[$key]);
        }
        $rows = Reports::breakdown($dimension, $period, $table_filters, $currency, 100);
        $channel_of = $dimension === 'channel' ? [] : Reports::breakdown_channels($dimension, $period, $table_filters);
        self::dimension_table($dimension, $all[$dimension], $rows, $channel_of, $filters, $currency);

        $campaigns = array_values(array_filter(array_map(function ($row) {
            return $row['value'];
        }, Reports::breakdown('campaign', $period, [], $currency, 30))));
        echo self::utm_builder($campaigns);

        echo '</div>';
    }

    /**
     * Share of visits next to share of revenue (or conversions) per channel,
     * with the finding that stands out.
     *
     * @param list<array<string, mixed>> $rows
     */
    private static function channel_value(array $rows, string $currency, ?string $active): void
    {
        $rows = array_values(array_filter($rows, function ($row) {
            return $row['value'] !== null && $row['value'] !== \AnalyticsWP\Lib\Attribution::OTHER && (int)$row['sessions'] > 0;
        }));
        $revenue = array_sum(array_column($rows, 'revenue'));
        $requested = isset($_GET['cmp']) ? sanitize_key(wp_unslash($_GET['cmp'])) : '';
        $basis = $requested === 'conv' || ($requested !== 'rev' && $revenue <= 0) ? 'conversions' : 'revenue';
        $is_revenue = $basis === 'revenue';
        $of = $is_revenue ? 'am Umsatz' : 'an den Conversions';

        $switch = Ui::segmented('cmp', ['rev' => 'Umsatz', 'conv' => 'Conversions'], $is_revenue ? 'rev' : 'conv', 'Vergleichen mit');
        Ui::card_open('lightbulb', 'Was jeder Kanal bringt', 'Anteil an den Besuchen im Vergleich zum Anteil ' . $of, $switch, 'awp-span-all');

        $gap = \AnalyticsWP\Lib\Insights::value_gap($rows, $basis);
        $visits = array_sum(array_column($rows, 'sessions'));
        $total = array_sum(array_column($rows, $basis));
        if ($gap !== null) {
            $headline = $gap['text'];
            $sub = $is_revenue ? 'Kein anderer Kanal macht aus so wenigen Besuchen so viel Umsatz.' : 'Kein anderer Kanal macht aus so wenigen Besuchen so viele Abschlüsse.';
        } elseif ($visits < \AnalyticsWP\Lib\Insights::MIN_VISITS || array_sum(array_column($rows, 'conversions')) < \AnalyticsWP\Lib\Insights::MIN_CONVERSIONS) {
            $headline = 'Noch zu wenig Daten für einen Vergleich.';
            $sub = 'Ab ' . \AnalyticsWP\Lib\Insights::MIN_VISITS . ' Besuchen und ' . \AnalyticsWP\Lib\Insights::MIN_CONVERSIONS . ' Conversions.';
        } else {
            $headline = 'Kein Kanal sticht heraus.';
            $sub = $is_revenue ? 'Die Kanäle bringen etwa so viel Umsatz, wie sie Besuche haben.' : 'Die Kanäle bringen etwa so viele Abschlüsse, wie sie Besuche haben.';
        }

        echo '<div class="awp-value-head">' . Icons::svg('sparkle') . '<div><p class="awp-glance-title">' . esc_html($headline) . '</p><p class="awp-glance-text">' . esc_html($sub) . '</p></div></div>';

        if (empty($rows)) {
            echo '<div class="awp-card-body">' . Ui::empty_state('Für diesen Zeitraum gibt es noch keine Besuche.') . '</div>';
            Ui::card_close();
            return;
        }

        echo '<div class="awp-value-legend" aria-hidden="true"><span><i class="is-visits"></i>Anteil an Besuchen</span><span><i class="is-value"></i>Anteil ' . esc_html($of) . ' (Farbe des Kanals)</span></div>';

        $pairs = [];
        foreach ($rows as $row) {
            $pairs[] = [
                'channel' => (string)$row['value'],
                'a' => $visits > 0 ? (int)$row['sessions'] / $visits : 0.0,
                'b' => $total > 0 ? (float)$row[$basis] / $total : 0.0,
            ];
        }
        usort($pairs, function ($x, $y) {
            return $y['b'] <=> $x['b'] ?: $y['a'] <=> $x['a'];
        });
        $max = max(array_merge([0.0001], array_column($pairs, 'a'), array_column($pairs, 'b')));

        echo '<div class="awp-pairs" role="table" aria-label="Anteil an Besuchen und ' . esc_attr($is_revenue ? 'Umsatz' : 'Conversions') . ' je Kanal">';
        foreach ($pairs as $pair) {
            $name = Format::channel($pair['channel']);
            $dim = $active !== null && $active !== $pair['channel'];
            echo '<div class="awp-pair' . ($dim ? ' is-dim' : '') . '" role="row" title="' . esc_attr($name . ': ' . Format::percent($pair['a']) . ' der Besuche, ' . Format::percent($pair['b']) . ($is_revenue ? ' des Umsatzes' : ' der Conversions')) . '">'
                . '<span role="cell" class="awp-pair-name">' . Channels::icon_html($pair['channel']) . '<span>' . esc_html($name) . '</span></span>'
                . '<span role="cell" class="awp-pair-bars"><span><i style="width:' . round($pair['a'] / $max * 100, 2) . '%"></i></span>'
                . '<span><i style="width:' . max(0.5, round($pair['b'] / $max * 100, 2)) . '%;background:' . esc_attr(Channels::css_var($pair['channel'])) . '"></i></span></span>'
                . '<span role="cell" class="awp-pair-values"><span>' . esc_html(Format::percent($pair['a'])) . '</span><strong>' . esc_html(Format::percent($pair['b'])) . '</strong></span>'
                . '</div>';
        }
        echo '</div>';
        Ui::card_close();
    }

    /**
     * The breakdown table: switch Kanal | Quelle | Kampagne (+ Weitere),
     * sortable columns, a click on a row filters the whole page.
     *
     * @param array{0: string, 1: string, 2: string, 3: string} $meta label, title, subtitle, column
     * @param list<array<string, mixed>> $rows
     * @param array<string, string> $channel_of
     * @param array<string, string> $filters
     */
    private static function dimension_table(string $dimension, array $meta, array $rows, array $channel_of, array $filters, string $currency): void
    {
        [, $title, $subtitle, $column] = $meta;
        $show_bounce = $dimension !== 'campaign';
        [$sort, $dir] = Ui::requested_sort(['sessions', 'bounce', 'conversions', 'rate', 'revenue'], 'sessions');

        $main = [];
        foreach (self::MAIN_DIMENSIONS as $key => $info) {
            $main[$key] = $info[0];
        }
        $actions = Ui::segmented('dim', $main, $dimension, 'Aufteilen nach', ['sort' => null, 'dir' => null]);
        $more_active = isset(self::MORE_DIMENSIONS[$dimension]);
        $actions .= '<details class="awp-more awp-more--small' . ($more_active ? ' is-active' : '') . '"><summary>' . esc_html($more_active ? self::MORE_DIMENSIONS[$dimension][0] : 'Weitere') . Icons::svg('caret-down') . '</summary><div class="awp-more-panel">';
        foreach (self::MORE_DIMENSIONS as $key => $info) {
            $actions .= '<a href="' . esc_url(App::url(['dim' => $key, 'sort' => null, 'dir' => null])) . '"' . ($key === $dimension ? ' class="is-active"' : '') . '>' . esc_html($info[0]) . '</a>';
        }
        $actions .= '</div></details>';

        Ui::card_open('link', $title, $subtitle, $actions, 'awp-span-all');

        if (empty($rows)) {
            echo '<div class="awp-card-body">' . Ui::empty_state('Für diesen Zeitraum gibt es noch keine Besuche.') . '</div>';
            Ui::card_close();
            return;
        }

        $value_of = function (array $row) use ($sort) {
            switch ($sort) {
                case 'bounce':
                    return (int)$row['sessions'] >= \AnalyticsWP\Lib\Insights::MIN_RATE_BASE ? (float)$row['bounce_rate'] : null;
                case 'rate':
                    return (int)$row['sessions'] >= \AnalyticsWP\Lib\Insights::MIN_RATE_BASE ? (float)$row['conversion_rate'] : null;
                default:
                    return (float)$row[$sort];
            }
        };
        $rows = Ui::sort_rows($rows, $value_of, $dir);
        $max = max(array_column($rows, 'sessions')) ?: 1;

        echo '<div class="awp-card-body is-flush awp-scroll-x"><table class="awp-table awp-table--rows"><thead><tr><th scope="col">' . esc_html($column) . '</th>'
            . Ui::sort_header('Besuche', 'sessions', Ui::TERMS['sessions'], $sort, $dir)
            . ($show_bounce ? Ui::sort_header('Absprung', 'bounce', Ui::TERMS['bounce'], $sort, $dir, 'is-optional') : '')
            . Ui::sort_header('Conv.', 'conversions', 'Abschlüsse in diesen Besuchen', $sort, $dir)
            . Ui::sort_header('Conv.-Rate', 'rate', Ui::TERMS['conversion_rate'] . ' Erst ab 10 Besuchen.', $sort, $dir, 'is-optional')
            . Ui::sort_header('Umsatz', 'revenue', 'Umsatz aus diesen Besuchen', $sort, $dir)
            . '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $text = Ui::dimension_label($dimension, $row['value']);
            $filter = Ui::dimension_filter($dimension, $row['value']);
            $on = !empty($filter) && array_intersect_assoc($filter, array_combine(array_map(function ($k) {
                return 'f_' . $k;
            }, array_keys($filters)), array_values($filters))) == $filter;
            $channel = $dimension === 'channel' ? (string)$row['value'] : ($channel_of[(string)$row['value']] ?? null);
            $width = max(1.5, round((int)$row['sessions'] / $max * 100, 1));
            $bar = $channel !== null ? Channels::rgba(Channels::color($channel), $on ? 0.45 : Channels::BAR_ALPHA) : Channels::bar_color(null);

            $remove = [];
            foreach (array_keys($filter) as $param) {
                $remove[$param] = null;
            }
            $href = App::url($on ? $remove : $filter);
            $label = '<span class="awp-cell-bar" style="width:calc(' . $width . '% - 14px);background:' . esc_attr($bar) . '"></span>'
                . '<a class="awp-cell-text awp-filter-link" href="' . esc_url($href) . '" aria-label="' . esc_attr(($on ? 'Filter ' . $text . ' entfernen' : 'Nur ' . $text . ' zeigen')) . '">'
                . ($channel !== null ? Channels::icon_html($channel) : '')
                . '<span class="awp-filter-name' . ($row['value'] === null ? ' awp-none' : '') . '">' . esc_html($text) . '</span>'
                . ($dimension !== 'channel' && $channel !== null && $row['value'] !== null ? '<span class="awp-row-meta">' . esc_html(Format::channel($channel)) . '</span>' : '')
                . Icons::svg('funnel', 'awp-icon awp-funnel') . '</a>';

            echo '<tr' . ($on ? ' class="is-filtered"' : '') . '><td class="awp-cell-label">' . $label . '</td>'
                . '<td class="is-strong">' . esc_html(Format::number((int)$row['sessions'])) . '</td>'
                . ($show_bounce ? '<td class="is-optional">' . Ui::rate($row['bounce_rate'], (int)$row['sessions'], 0) . '</td>' : '')
                . '<td>' . esc_html(Format::number((int)$row['conversions'])) . '</td>'
                . '<td class="is-optional">' . Ui::rate($row['conversion_rate'], (int)$row['sessions']) . '</td>'
                . '<td>' . ((float)$row['revenue'] > 0 ? esc_html(Format::money((float)$row['revenue'], $currency, 0)) : '<span class="awp-none">–</span>') . '</td></tr>';
        }
        echo '</tbody></table></div>';
        Ui::card_close('<span>Klick auf eine Zeile zeigt nur noch diese Besuche, auf der ganzen Seite.</span><span>Conversions zählen für den Besuch, in dem sie passiert sind.</span>');
    }

    /**
     * Link builder for a campaign (admin.js builds and copies the link).
     *
     * @param list<string> $campaigns Known campaign names, as suggestions.
     */
    private static function utm_builder(array $campaigns = []): string
    {
        $presets = [
            'newsletter' => ['Newsletter', 'envelope-simple', 'newsletter', 'email'],
            'facebook' => ['Facebook-Post', 'chat-circle', 'facebook', 'social'],
            'instagram' => ['Instagram', 'chat-circle', 'instagram', 'social'],
            'google' => ['Google-Anzeige', 'magnifying-glass', 'google', 'cpc'],
            'meta' => ['Meta-Anzeige', 'megaphone', 'facebook', 'paid'],
        ];

        $html = '<section class="awp-card awp-span-all" id="awp-utm"><header class="awp-card-head"><span class="awp-card-icon">' . Icons::svg('megaphone') . '</span>'
            . '<div class="awp-card-heading"><h2 class="awp-card-title">Link für eine Kampagne bauen</h2><p class="awp-card-sub">Damit du siehst, welcher Newsletter, Post oder welche Anzeige Besucher bringt.</p></div></header>'
            . '<div class="awp-card-body awp-utm" data-awp-utm>';

        $html .= '<div class="awp-utm-presets"><span class="awp-utm-label">Wo teilst du den Link?</span><div>';
        foreach ($presets as $key => [$label, $icon, $source, $medium]) {
            $on = $key === 'newsletter';
            $html .= '<button type="button" class="awp-preset" data-awp-utm-preset data-source="' . esc_attr($source) . '" data-medium="' . esc_attr($medium) . '" aria-pressed="' . ($on ? 'true' : 'false') . '">'
                . Icons::svg($icon) . esc_html($label) . '</button>';
        }
        $html .= '</div></div>';

        $field = function (string $name, string $label, string $param, string $value, string $placeholder, string $extra = '') {
            return '<label class="awp-utm-field"><span class="awp-utm-label">' . esc_html($label) . ($param !== '' ? ' <span>· ' . esc_html($param) . '</span>' : '') . '</span>'
                . '<input type="text" data-awp-utm-field="' . esc_attr($name) . '" value="' . esc_attr($value) . '" placeholder="' . esc_attr($placeholder) . '"' . $extra . '></label>';
        };

        $html .= '<div class="awp-utm-grid">'
            . '<div class="awp-utm-wide">' . $field('url', 'Zielseite', '', home_url('/'), home_url('/')) . '</div>'
            . $field('utm_source', 'Quelle', 'utm_source', 'newsletter', 'z. B. newsletter')
            . $field('utm_medium', 'Art', 'utm_medium', 'email', 'z. B. email')
            . $field('utm_campaign', 'Kampagne', 'utm_campaign', '', 'z. B. herbst-aktion', ' list="awp-campaigns"')
            . '</div><datalist id="awp-campaigns">';
        foreach ($campaigns as $campaign) {
            $html .= '<option value="' . esc_attr($campaign) . '"></option>';
        }
        $html .= '</datalist>';

        $html .= '<details class="awp-utm-more"><summary>Inhalt unterscheiden · optional</summary>'
            . '<label class="awp-utm-field"><span class="awp-field-desc">Zum Beispiel zwei Buttons im selben Newsletter. utm_content</span>'
            . '<input type="text" data-awp-utm-field="utm_content" placeholder="z. B. button-oben"></label></details>';

        $html .= '<div class="awp-utm-result"><div class="awp-utm-link" data-awp-utm-out aria-label="Fertiger Link" aria-live="polite">' . esc_html(home_url('/')) . '</div>'
            . '<button type="button" class="button button-primary awp-utm-copy" data-awp-copy-utm>' . Icons::svg('copy') . '<span>Link kopieren</span></button></div>'
            . '<p class="awp-field-desc">Großbuchstaben und Leerzeichen passen wir automatisch an, damit gleiche Namen in der Auswertung zusammenlaufen.</p>';

        return $html . '</div></section>';
    }

    // ---------------------------------------------------------------------
    // Seiten
    // ---------------------------------------------------------------------

    /** Views of the pages table: id => [label, icon, title, subtitle]. */
    const PAGE_VIEWS = [
        'all' => ['Alle Seiten', 'file', 'Meistbesuchte Seiten', 'Wie oft jede Seite aufgerufen wurde'],
        'entry' => ['Einstieg', 'sign-in', 'Wo Besuche beginnen', 'Die erste Seite eines Besuchs, mit dem Ergebnis des ganzen Besuchs'],
        'exit' => ['Ausstieg', 'sign-out', 'Wo Besuche enden', 'Die letzte Seite eines Besuchs'],
    ];

    public static function pages(): void
    {
        $period = App::period();
        $filters = App::filters();
        $view = isset($_GET['view']) ? sanitize_key(wp_unslash($_GET['view'])) : 'all';
        if (!isset(self::PAGE_VIEWS[$view])) {
            $view = 'all';
        }
        $query = isset($_GET['q']) ? mb_substr(trim(sanitize_text_field(wp_unslash($_GET['q']))), 0, 100) : '';

        App::page_head('Seiten', self::period_sentence($period));
        $currency = Reports::main_currency($period);

        // Pages with numbers in the address (order confirmations) as one.
        $pages = self::group_pages(Reports::pages($period, $filters, 200), 'path', ['pageviews', 'sessions', 'entries'], ['engaged', 'scroll'], 'pageviews');
        $entries = self::group_pages(Reports::breakdown('landing', $period, $filters, $currency, 200), 'value', ['sessions', 'conversions', 'converting', 'revenue'], ['bounce_rate'], 'sessions');
        $exits = self::group_pages(Reports::breakdown('exit', $period, $filters, $currency, 200), 'value', ['sessions', 'conversions', 'converting', 'revenue'], ['bounce_rate'], 'sessions');
        foreach ([&$entries, &$exits] as &$list) {
            foreach ($list as &$row) {
                $row['conversion_rate'] = (int)$row['sessions'] > 0 ? (int)($row['converting'] ?? 0) / (int)$row['sessions'] : 0.0;
            }
            unset($row);
        }
        unset($list);

        $not_found = [];
        foreach (Reports::events_by('404', $period, $filters, 50) as $row) {
            $path = (string)\AnalyticsWP\Lib\URLs::path_of($row['value']);
            $not_found[$path] = ($not_found[$path] ?? 0) + (int)$row['count'];
        }

        echo '<div class="awp-layout">';
        self::page_insights($pages, $entries, $exits, $not_found, $currency);
        self::pages_table($view, $query, $pages, $entries, $exits, $not_found, $period, $filters);
        echo '</div>';
    }

    /**
     * Merge rows whose paths differ only by numbers (Format::page_group()).
     *
     * @param list<array<string, mixed>> $rows
     * @param list<string> $sums Columns to add up.
     * @param list<string> $averages Columns averaged, weighted by $weight.
     * @return list<array<string, mixed>>
     */
    public static function group_pages(array $rows, string $key, array $sums, array $averages, string $weight): array
    {
        $out = [];
        foreach ($rows as $row) {
            if ($row[$key] === null) {
                continue;
            }
            [$group, $meta] = Format::page_group((string)$row[$key]);
            if (!isset($out[$group])) {
                $out[$group] = $row;
                $out[$group][$key] = $group;
                $out[$group]['path'] = $group;
                $out[$group]['meta'] = $meta;
                $out[$group]['grouped'] = $group !== (string)$row[$key];
                continue;
            }
            $merged = &$out[$group];
            $w_old = (float)$merged[$weight];
            $w_new = (float)$row[$weight];
            foreach ($averages as $column) {
                if ($row[$column] === null) {
                    continue;
                }
                $merged[$column] = $merged[$column] === null || $w_old + $w_new <= 0
                    ? $row[$column]
                    : ((float)$merged[$column] * $w_old + (float)$row[$column] * $w_new) / ($w_old + $w_new);
            }
            foreach ($sums as $column) {
                $merged[$column] = ($merged[$column] ?? 0) + ($row[$column] ?? 0);
            }
            $merged['grouped'] = true;
            unset($merged);
        }

        return array_values($out);
    }

    /**
     * @param list<array<string, mixed>> $pages
     * @param list<array<string, mixed>> $entries
     * @param list<array<string, mixed>> $exits
     */
    private static function page_insights(array $pages, array $entries, array $exits, array $not_found, string $currency): void
    {
        $top = \AnalyticsWP\Lib\Insights::top_page($pages);
        $best = \AnalyticsWP\Lib\Insights::best_entry($entries, $currency);
        $leaky = \AnalyticsWP\Lib\Insights::leaky_exit($exits, $pages, array_keys($not_found));

        $cards = [
            [$top, 'eye', ['view' => 'all', 'sort' => null, 'dir' => null], false],
            [$best, 'sign-in', ['view' => 'entry', 'sort' => 'rate', 'dir' => 'desc'], false],
            [$leaky ?? ['status' => 'ok', 'label' => 'Ausstiege ohne Abschluss', 'value' => 'Nichts Auffälliges', 'detail' => 'Keine Seite, auf der die meisten Besuche ohne Abschluss enden.'], 'sign-out', ['view' => 'exit', 'sort' => null, 'dir' => null], $leaky !== null],
        ];

        echo '<div class="awp-span-all awp-insights">';
        foreach ($cards as [$card, $icon, $args, $warn]) {
            if (!empty($card['path'])) {
                $args['sel'] = $card['path'];
            }
            echo '<a class="awp-insight awp-insight--card' . ($card['status'] === 'pending' ? ' is-pending' : '') . ($warn ? ' is-warn' : '') . '" href="' . esc_url(App::url($args + ['q' => null]) . '#awp-pages') . '">'
                . '<span class="awp-tile">' . Icons::svg($icon) . ($warn ? '<span class="awp-tile-mark" aria-hidden="true"></span>' : '') . '</span>'
                . '<span class="awp-insight-text"><span class="awp-insight-label">' . esc_html($card['label']) . '</span>'
                . '<span class="awp-insight-value">' . esc_html($card['value']) . '</span>'
                . '<span class="awp-insight-detail">' . esc_html($card['detail']) . '</span></span>'
                . Icons::svg('caret-right') . '</a>';
        }
        echo '</div>';
    }

    /**
     * One table for all pages, entries or exits, with search, sort and the
     * detail panel of the chosen page.
     *
     * @param list<array<string, mixed>> $pages
     * @param list<array<string, mixed>> $entries
     * @param list<array<string, mixed>> $exits
     * @param array<string, int> $not_found 404 path => views
     */
    private static function pages_table(string $view, string $query, array $pages, array $entries, array $exits, array $not_found, array $period, array $filters): void
    {
        [$label, $icon, $title, $subtitle] = self::PAGE_VIEWS[$view];
        $columns = [
            'all' => [
                ['pageviews', 'Aufrufe', 'Jeder Aufruf zählt'],
                ['sessions', 'Besuche', 'Besuche, in denen die Seite mindestens einmal vorkam'],
                ['entries', 'Einstiege', 'So oft war die Seite die erste eines Besuchs'],
                ['engaged', 'Ø aktiv', 'Aktive Zeit auf der Seite, ohne Hintergrund-Tabs'],
                ['scroll', 'Scrolltiefe', 'Wie weit im Schnitt gescrollt wurde'],
            ],
            'entry' => [
                ['sessions', 'Einstiege', 'So oft war die Seite die erste eines Besuchs'],
                ['conversions', 'Conv.', 'Abschlüsse in Besuchen, die hier begannen'],
                ['rate', 'Conv.-Rate', 'Erst ab 10 Einstiegen'],
                ['revenue', 'Umsatz', 'Umsatz aus Besuchen, die hier begannen'],
            ],
            'exit' => [
                ['sessions', 'Ausstiege', 'So oft war die Seite die letzte eines Besuchs'],
                ['bounce', 'Absprung', 'Anteil der Besuche, die nur diese eine Seite sahen'],
                ['conversions', 'Conv.', 'Abschlüsse in Besuchen, die hier endeten'],
                ['rate', 'Conv.-Rate', 'Erst ab 10 Ausstiegen'],
            ],
        ][$view];
        $base = $columns[0][0];
        [$sort, $dir] = Ui::requested_sort(array_column($columns, 0), $base);
        $rows = ['all' => $pages, 'entry' => $entries, 'exit' => $exits][$view];

        if ($query !== '') {
            $rows = array_values(array_filter($rows, function ($row) use ($query) {
                return stripos((string)$row['path'], $query) !== false;
            }));
        }
        $rows = Ui::sort_rows($rows, function ($row) use ($sort) {
            switch ($sort) {
                case 'rate':
                    return (int)$row['sessions'] >= \AnalyticsWP\Lib\Insights::MIN_RATE_BASE ? (float)$row['conversion_rate'] : null;
                case 'bounce':
                    return (int)$row['sessions'] >= \AnalyticsWP\Lib\Insights::MIN_RATE_BASE ? (float)$row['bounce_rate'] : null;
                default:
                    return $row[$sort] === null ? null : (float)$row[$sort];
            }
        }, $dir);
        $rows = array_slice($rows, 0, 100);

        $selected = isset($_GET['sel']) ? sanitize_text_field(wp_unslash($_GET['sel'])) : '';
        $known = array_column($pages, 'path');
        if ($selected === '' || !in_array($selected, array_merge($known, array_column($entries, 'path'), array_column($exits, 'path')), true)) {
            $selected = $rows[0]['path'] ?? ($pages[0]['path'] ?? '');
        }

        // Search: a GET form that keeps the view.
        $search = '<form class="awp-search" method="get" action="' . esc_url(admin_url('admin.php')) . '" role="search">'
            . '<input type="hidden" name="page" value="' . esc_attr(App::SLUG) . '"><input type="hidden" name="tab" value="pages"><input type="hidden" name="view" value="' . esc_attr($view) . '">';
        foreach (['range', 'from', 'to'] as $param) {
            if (isset($_GET[$param]) && is_string($_GET[$param]) && $_GET[$param] !== '') {
                $search .= '<input type="hidden" name="' . $param . '" value="' . esc_attr(sanitize_text_field(wp_unslash($_GET[$param]))) . '">';
            }
        }
        foreach ($filters as $key => $value) {
            $search .= '<input type="hidden" name="f_' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
        }
        $search .= '<label>' . Icons::svg('magnifying-glass') . '<span class="awp-sr">Seite suchen</span><input type="search" name="q" value="' . esc_attr($query) . '" placeholder="Seite suchen"></label></form>';

        $views = [];
        foreach (self::PAGE_VIEWS as $key => $info) {
            $views[$key] = [$info[0], $info[1]];
        }
        $actions = $search . Ui::segmented('view', $views, $view, 'Ansicht', ['sort' => null, 'dir' => null]);

        echo '<section class="awp-card awp-span-all" id="awp-pages"><header class="awp-card-head"><span class="awp-card-icon">' . Icons::svg($icon) . '</span>'
            . '<div class="awp-card-heading"><h2 class="awp-card-title">' . esc_html($title) . '</h2><p class="awp-card-sub">' . esc_html($subtitle) . '</p></div>'
            . '<div class="awp-card-actions">' . $actions . '</div></header>';

        $views_404 = array_sum($not_found);
        if ($views_404 > 0) {
            $one = count($not_found) === 1 ? (string)array_key_first($not_found) : '';
            $show = $one !== '' ? App::url(['view' => 'all', 'q' => $one, 'sel' => $one, 'sort' => null, 'dir' => null]) . '#awp-pages' : App::url(['tab' => 'engagement'] + array_fill_keys(App::VIEW_PARAMS, null));
            echo '<div class="awp-warnline awp-warnline--bar"><span class="awp-warn-dot" aria-hidden="true"></span><span><strong>'
                . esc_html(Format::number($views_404) . ($views_404 === 1 ? ' Aufruf einer Seite, die es nicht gibt' : ' Aufrufe von Seiten, die es nicht gibt'))
                . '</strong> (Fehler 404). Vielleicht zeigt ein Link ins Leere.</span><a href="' . esc_url($show) . '">Zeigen</a></div>';
        }

        echo '<div class="awp-pages-split"><div class="awp-pages-table awp-scroll-x">';
        if (empty($rows)) {
            echo $query !== ''
                ? Ui::empty_state('Keine Seite enthält „' . $query . '“.')
                : Ui::empty_state('Für diesen Zeitraum gibt es noch keine Seitenaufrufe.');
        } else {
            $max = max(array_map(function ($row) use ($base) {
                return (float)$row[$base];
            }, $rows)) ?: 1;
            echo '<table class="awp-table awp-table--rows"><thead><tr><th scope="col">Seite</th>';
            foreach ($columns as $i => [$key, $label_col, $help]) {
                echo Ui::sort_header($label_col, $key, $help, $sort, $dir, $i >= 3 ? 'is-optional' : '');
            }
            echo '</tr></thead><tbody>';
            foreach ($rows as $row) {
                $path = (string)$row['path'];
                $on = $path === $selected;
                $width = max(1.5, round((float)$row[$base] / $max * 100, 1));
                $is_404 = isset($not_found[$path]);
                $meta = $is_404 ? '<span class="awp-chip-warn">Seite nicht gefunden</span>' : ($row['meta'] !== '' ? '<span class="awp-row-meta">' . esc_html($row['meta']) . '</span>' : '');
                echo '<tr' . ($on ? ' class="is-selected"' : '') . '><td class="awp-cell-label">'
                    . '<span class="awp-cell-bar" style="width:calc(' . $width . '% - 14px);background:' . esc_attr(Channels::rgba(Channels::PLAIN_BAR, $on ? 0.26 : 0.13)) . '"></span>'
                    . '<a class="awp-cell-text awp-filter-link" href="' . esc_url(App::url(['sel' => $path]) . '#awp-pages') . '" aria-label="' . esc_attr('Details zu ' . $path . ' zeigen') . '"' . ($on ? ' aria-current="true"' : '') . '>'
                    . '<span class="awp-filter-name">' . esc_html($path) . '</span>' . $meta . '</a></td>';
                foreach ($columns as $i => [$key]) {
                    echo '<td class="' . ($key === $base ? 'is-strong' : '') . ($i >= 3 ? ' is-optional' : '') . '">' . self::page_cell($key, $row) . '</td>';
                }
                echo '</tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';

        if ($selected !== '') {
            self::page_detail($selected, $pages, $entries, $exits, $period, $filters);
        }
        echo '</div>';

        echo '<footer class="awp-card-foot awp-card-foot--split"><span>Adressen ohne Parameter. Seiten mit Nummern, z. B. Bestellbestätigungen, werden zusammengefasst.</span>'
            . '<span>„Ø aktiv“ und „Scrolltiefe“ gibt es seit dem Einschalten von „Engagement messen“.</span></footer></section>';
    }

    /**
     * @param array<string, mixed> $row
     */
    private static function page_cell(string $key, array $row): string
    {
        $empty = '<span class="awp-empty-value" title="Noch nicht gemessen">–</span>';
        switch ($key) {
            case 'engaged':
                return $row['engaged'] === null ? $empty : esc_html(Format::duration($row['engaged']));
            case 'scroll':
                return $row['scroll'] === null ? $empty : esc_html(Format::percent((float)$row['scroll'] / 100, 0));
            case 'rate':
                return Ui::rate($row['conversion_rate'], (int)$row['sessions']);
            case 'bounce':
                return Ui::rate($row['bounce_rate'], (int)$row['sessions'], 0);
            case 'revenue':
                return (float)$row['revenue'] > 0 ? esc_html(Format::money((float)$row['revenue'], Reports::main_currency(App::period()), 0)) : '<span class="awp-none">–</span>';
            default:
                return esc_html(Format::number((float)$row[$key]));
        }
    }

    /**
     * The panel next to the table: key figures of one page, where its
     * visitors come from, where they go next.
     *
     * @param list<array<string, mixed>> $pages
     * @param list<array<string, mixed>> $entries
     * @param list<array<string, mixed>> $exits
     */
    private static function page_detail(string $path, array $pages, array $entries, array $exits, array $period, array $filters): void
    {
        $find = function (array $rows) use ($path) {
            foreach ($rows as $row) {
                if ($row['path'] === $path) {
                    return $row;
                }
            }
            return null;
        };
        $page = $find($pages);
        $entry = $find($entries);
        $exit = $find($exits);
        $grouped = strpos($path, '…') !== false;

        echo '<aside class="awp-page-detail" aria-label="Details zur Seite"><div class="awp-detail-head"><span class="awp-insight-label">Ausgewählte Seite</span>'
            . '<span class="awp-detail-path">' . esc_html($path) . '</span>';
        if (!$grouped) {
            echo '<a class="awp-linkline" href="' . esc_url(home_url($path)) . '" target="_blank" rel="noopener">Seite öffnen' . Icons::svg('arrow-square-out') . '<span class="awp-sr"> (öffnet in einem neuen Tab)</span></a>';
        }
        echo '</div>';

        $stat = function (string $icon, string $label, string $value, bool $missing = false) {
            return '<div class="awp-stat"><span class="awp-stat-label">' . Icons::svg($icon) . esc_html($label) . '</span><span class="awp-stat-value' . ($missing ? ' is-missing' : '') . '">' . esc_html($value) . '</span></div>';
        };
        $entry_rate = $entry !== null && (int)$entry['sessions'] >= \AnalyticsWP\Lib\Insights::MIN_RATE_BASE ? Format::percent((float)$entry['conversion_rate']) : 'zu wenig';
        echo '<div class="awp-stats">'
            . $stat('eye', 'Aufrufe', Format::number($page['pageviews'] ?? 0))
            . $stat('sign-in', 'Einstiege', Format::number($entry['sessions'] ?? 0))
            . $stat('clock', 'Ø aktiv', isset($page['engaged']) && $page['engaged'] !== null ? Format::duration($page['engaged']) : '–', !isset($page['engaged']) || $page['engaged'] === null)
            . $stat('scroll', 'Scrolltiefe', isset($page['scroll']) && $page['scroll'] !== null ? Format::percent((float)$page['scroll'] / 100, 0) : '–', !isset($page['scroll']) || $page['scroll'] === null)
            . $stat('shopping-cart', 'Conv.-Rate', $entry_rate, $entry_rate === 'zu wenig')
            . $stat('sign-out', 'Ausstiege', Format::number($exit['sessions'] ?? 0))
            . '</div>';

        if ($grouped) {
            echo '<p class="awp-field-desc">Zusammengefasst aus mehreren Adressen mit Nummern. Herkunft und Weg gibt es nur für einzelne Adressen.</p></aside>';
            return;
        }

        // Where visitors who start here come from.
        $mix = Reports::landing_channels($path, $period, $filters);
        $mix_total = array_sum($mix);
        echo '<div class="awp-detail-block"><span class="awp-detail-title">Wer hier einsteigt, kommt über</span>';
        if ($mix_total === 0) {
            echo '<p class="awp-field-desc">Kein Besuch hat im Zeitraum hier begonnen.</p>';
        } else {
            echo '<div class="awp-mixbar" role="img" aria-label="Kanäle der Einstiege">';
            foreach ($mix as $channel => $count) {
                $share = $count / $mix_total;
                echo '<span style="flex:' . round($share * 100, 2) . ' 1 0;background:' . esc_attr(Channels::css_var($channel)) . '" title="' . esc_attr(Format::channel($channel) . ': ' . Format::percent($share, 0)) . '"></span>';
            }
            echo '</div><div class="awp-mix-legend">';
            foreach (array_slice($mix, 0, 6, true) as $channel => $count) {
                echo '<span>' . Channels::dot($channel) . esc_html(Format::channel($channel) . ' ' . Format::percent($count / $mix_total, 0)) . '</span>';
            }
            echo '</div>';
        }
        echo '</div>';

        // Where they go next.
        $next = Reports::next_pages($path, $period);
        echo '<div class="awp-detail-block"><span class="awp-detail-title">Danach geht es weiter zu</span>';
        if ($next['views'] === 0) {
            echo '<p class="awp-field-desc">Keine Aufrufe im Zeitraum.</p>';
        } else {
            $max = max(array_merge([1], array_values($next['next'])));
            foreach ($next['next'] as $to => $count) {
                $share = $count / $next['views'];
                echo '<div class="awp-next-row"><span class="awp-barlabel"><span class="awp-cell-bar" style="width:' . round($count / $max * 100, 1) . '%;background:' . esc_attr(Channels::bar_color(null)) . '"></span><span class="awp-cell-text">' . esc_html($to) . '</span></span>'
                    . '<span class="awp-num is-muted">' . esc_html(Format::percent($share, 0)) . '</span></div>';
            }
            echo '<p class="awp-field-desc">' . esc_html(Format::percent($next['ended'] / $next['views'], 0) . ' der Aufrufe sind die letzte Seite des Besuchs.' . ($next['sampled'] ? ' Aus den letzten ' . Format::number(Reports::NEXT_PAGES_SAMPLE) . ' Besuchen mit dieser Seite.' : '')) . '</p>';
        }
        echo '</div>';

        echo Ui::link(App::url(['tab' => 'journeys', 'f_landing' => $path] + array_fill_keys(App::VIEW_PARAMS, null)), 'Journeys, die hier beginnen');
        echo '</aside>';
    }

    // ---------------------------------------------------------------------
    // Conversions
    // ---------------------------------------------------------------------

    /** Attribution models: id => [label, subtitle, explanation]. */
    const MODELS = [
        'last' => ['Letzter Kanal', 'Gezählt für den letzten Kanal vor der Conversion, ohne Direkt', 'Kam jemand zuletzt direkt zurück, zählt der Besuch davor, etwa die Anzeige oder der Newsletter. Empfohlen, weil Direkt sonst zu gut aussieht.'],
        'session' => ['Besuch der Conversion', 'Gezählt für den Besuch, in dem die Conversion passiert ist', 'Am einfachsten zu verstehen: Woher kam der Besuch, in dem gekauft oder angefragt wurde? Direkt bekommt dabei oft mehr, als es verdient.'],
        'first' => ['Erster Kontakt', 'Gezählt für den ersten bekannten Besuch desselben Besuchers', 'Zeigt, was Leute zuerst auf dich aufmerksam macht. Ohne Einwilligung geht das nur innerhalb eines Tages, mit Einwilligung (Must-Have Cookie) über mehrere Tage.'],
    ];

    /** Key figures of the conversions view: metric => [label, chart title, format, explanation]. */
    const CONVERSION_KPIS = [
        'conversions' => ['Conversions', 'Conversions', 'number', 'Abschlüsse: Käufe, Formulare und Kontakt-Klicks.'],
        'conversion_rate' => ['Conv.-Rate', 'Conversion-Rate', 'percent', 'Anteil der Besuche mit mindestens einem Abschluss.'],
        'revenue' => ['Umsatz', 'Umsatz', 'money', 'Summe der Käufe aus WooCommerce, SureCart und Easy Digital Downloads.'],
        'avg_order' => ['Ø Kaufwert', 'Ø Kaufwert', 'money2', 'Umsatz geteilt durch die Zahl der Käufe.'],
    ];

    public static function conversions(): void
    {
        $period = App::period();
        $filters = App::filters();
        $model = isset($_GET['model']) ? sanitize_key(wp_unslash($_GET['model'])) : 'last';
        if (!isset(self::MODELS[$model])) {
            $model = 'last';
        }

        App::page_head('Conversions', self::period_sentence($period));
        $currency = Reports::main_currency($period);
        $totals = Reports::totals($period, $filters, $currency);
        $types = Reports::conversion_types($period, $filters, $currency);
        $types_before = Reports::conversion_types(Reports::previous_period($period), $filters, $currency);

        $purchases = function (array $rows): array {
            $count = 0;
            $sum = 0.0;
            foreach ($rows as $row) {
                if (Format::conversion_kind($row['type']) === 'purchase') {
                    $count += (int)$row['conversions'];
                    $sum += (float)$row['revenue'];
                }
            }
            return [$count, $sum];
        };
        [$bought, $bought_revenue] = $purchases($types);
        [$bought_before, $bought_revenue_before] = $purchases($types_before);
        $avg = $bought > 0 ? $bought_revenue / $bought : 0.0;
        $avg_before = $bought_before > 0 ? $bought_revenue_before / $bought_before : 0.0;

        $current = $totals['current'] + ['avg_order' => $avg];
        $previous = $totals['previous'] + ['avg_order' => $avg_before];

        echo '<div class="awp-layout">';
        self::conversion_chart($current, $previous, $period, $filters, $currency);

        echo '<div class="awp-span-all awp-cols-2">';
        $foot = $bought > 0 ? 'Ø Kaufwert ' . Format::money($avg, $currency) . ' · Formulare und Klicks haben keinen Geldwert.' : 'Formulare und Klicks haben keinen Geldwert.';
        self::conversion_groups($types, $currency, (int)$current['conversions'], (float)$current['revenue'], 'Was abgeschlossen wurde', 'Käufe je Shop, Formulare je Formular', esc_html($foot));
        self::conversion_feed(Reports::recent_conversions($period, $filters, 10, $model), $currency);
        echo '</div>';

        self::conversion_origin($model, $period, $filters, $currency);
        echo '</div>';
    }

    /**
     * Four tiles and a bar chart per day, the dashed line is the daily
     * average of the period before.
     *
     * @param array<string, float|int> $current
     * @param array<string, float|int> $previous
     */
    private static function conversion_chart(array $current, array $previous, array $period, array $filters, string $currency): void
    {
        $metric = isset($_GET['metric']) ? sanitize_key(wp_unslash($_GET['metric'])) : 'conversions';
        if (!isset(self::CONVERSION_KPIS[$metric])) {
            $metric = 'conversions';
        }

        echo '<section class="awp-card awp-span-all" aria-label="Kennzahlen und Verlauf"><div class="awp-kpis" role="tablist" aria-label="Kennzahl im Diagramm">';
        foreach (self::CONVERSION_KPIS as $key => [$label, , $format, $help]) {
            $value = $current[$key] ?? 0;
            $before = $previous[$key] ?? 0;
            $shown = $format === 'money2' ? Format::money($value, $currency) : self::format_value($value, $format, $currency);
            $shown_before = $format === 'money2' ? Format::money($before, $currency) : self::format_value($before, $format, $currency);
            echo '<button type="button" class="awp-kpi" role="tab" data-awp-metric="' . esc_attr($key) . '" aria-selected="' . ($key === $metric ? 'true' : 'false') . '">'
                . '<span class="awp-kpi-label">' . Ui::term($label, $help) . '</span>'
                . '<span class="awp-kpi-value">' . esc_html($shown) . '</span>'
                . self::kpi_delta($value, $before, true)
                . '<span class="awp-kpi-sub">vorher ' . esc_html($shown_before) . '</span></button>';
        }
        echo '</div>';

        $series = Reports::timeseries($period, $filters, $currency);
        $parts = Reports::conversion_series($period, $filters, $currency);
        $count = count($series['labels']);
        $days = max(1, (int)$period['days']);
        $buckets = $period['hourly'] ? 24 : $days;

        $avg_per_day = [];
        foreach (array_keys($parts['purchase']) as $i) {
            $avg_per_day[] = $parts['purchase'][$i] > 0 ? $parts['revenue'][$i] / $parts['purchase'][$i] : null;
        }

        $metrics = [
            'conversions' => ['label' => 'Conversions', 'format' => 'number', 'values' => $series['series']['conversions'], 'average' => (float)($previous['conversions'] ?? 0) / $buckets],
            'conversion_rate' => ['label' => 'Conv.-Rate', 'format' => 'percent', 'values' => $series['series']['conversion_rate'] ?? array_fill(0, $count, 0), 'average' => (float)($previous['conversion_rate'] ?? 0)],
            'revenue' => ['label' => 'Umsatz', 'format' => 'money', 'values' => $series['series']['revenue'], 'average' => (float)($previous['revenue'] ?? 0) / $buckets],
            'avg_order' => ['label' => 'Ø Kaufwert', 'format' => 'money', 'values' => $avg_per_day, 'average' => (float)($previous['avg_order'] ?? 0)],
        ];
        $per = $period['hourly'] ? ' pro Stunde' : ' pro Tag';
        foreach ($metrics as $key => &$meta) {
            $meta['title'] = self::CONVERSION_KPIS[$key][1] . $per . ($key === 'avg_order' ? ' (nur ' . ($period['hourly'] ? 'Stunden' : 'Tage') . ' mit Kauf)' : '');
        }
        unset($meta);

        $open = $period['end'] === wp_date('Y-m-d');
        echo Chart::bars($series['labels'], $metrics, $metric, $period['hourly'], $currency, [
            'open' => $open,
            'end' => $open && $period['hourly'] ? (int)wp_date('G') : $count - 1,
            'parts' => $parts,
        ]);
        echo '</section>';
    }

    /**
     * "Letzte Conversions": newest first, with the channel they count for.
     *
     * @param list<array<string, mixed>> $rows
     */
    private static function conversion_feed(array $rows, string $currency): void
    {
        Ui::card_open('clock', 'Letzte Conversions', 'Neueste zuerst, mit der Herkunft');
        if (empty($rows)) {
            echo '<div class="awp-card-body">' . Ui::info('Noch keine Conversions in diesem Zeitraum.') . '</div>';
        } else {
            echo '<ul class="awp-feed">';
            foreach ($rows as $row) {
                $type = (string)$row['conversion_type'];
                $kind = Format::conversion_kind($type);
                $name = Format::conversion_type($type);
                $extra = '';
                if (!empty($row['form_name']) && $row['form_name'] !== 'null') {
                    $name .= ': ' . $row['form_name'];
                } elseif (!empty($row['order_number']) && $row['order_number'] !== 'null') {
                    $extra = 'Nr. ' . $row['order_number'];
                } elseif (!empty($row['conversion_id']) && $kind === 'purchase') {
                    $extra = 'Nr. ' . $row['conversion_id'];
                }
                $channel = (string)$row['channel'];
                $origin = implode(' · ', array_filter([
                    Format::channel($channel),
                    (string)$row['source'],
                    (string)$row['campaign'],
                    !empty($row['earlier_visit']) ? 'früherer Besuch' : '',
                ]));
                $value = $row['revenue'] !== null && (float)$row['revenue'] > 0 ? Format::money((float)$row['revenue'], (string)($row['currency'] ?: $currency)) : '–';
                $time = Format::datetime((string)$row['timestamp']);
                $journey = App::url(['tab' => 'journeys', 'visitor' => (string)$row['unique_session_id'], 'f_*' => null]);

                echo '<li class="awp-feed-item"><span class="awp-tile">' . Icons::svg(Format::CONVERSION_KINDS[$kind][1]) . '</span>'
                    . '<span class="awp-feed-main"><span class="awp-feed-title"><strong>' . esc_html($name) . '</strong>' . ($extra !== '' ? '<span>' . esc_html($extra) . '</span>' : '') . '</span>'
                    . '<span class="awp-feed-origin">' . Channels::dot($channel) . '<span>' . esc_html($origin) . '</span></span></span>'
                    . '<span class="awp-feed-side"><strong>' . esc_html($value) . '</strong><span>' . esc_html($time) . '</span></span>'
                    . '<a class="awp-icon-button" href="' . esc_url($journey) . '" title="Journey ansehen" aria-label="' . esc_attr('Journey zu ' . $name . ', ' . $time . ' ansehen') . '">' . Icons::svg('footprints') . '</a></li>';
            }
            echo '</ul>';
        }
        Ui::card_close(Ui::link(App::url(['tab' => 'journeys'] + array_fill_keys(App::VIEW_PARAMS, null)), 'Alle Journeys'));
    }

    /**
     * "Woher die Conversions kommen", with the attribution model as switch.
     */
    private static function conversion_origin(string $model, array $period, array $filters, string $currency): void
    {
        [, $subtitle, $explanation] = self::MODELS[$model];
        $options = [];
        foreach (self::MODELS as $key => $info) {
            $options[$key] = $info[0];
        }
        $actions = '<span class="awp-seg-label">Zählen für</span>' . Ui::segmented('model', $options, $model, 'Zählen für');

        Ui::card_open('link', 'Woher die Conversions kommen', $subtitle, $actions, 'awp-span-all');
        echo '<div class="awp-card-body">' . Ui::info($explanation) . '</div>';

        $by_channel = Reports::conversions_by('channel', $model, $period, $filters, $currency);
        $by_campaign = array_values(array_filter(Reports::conversions_by('campaign', $model, $period, $filters, $currency), function ($row) {
            return $row['value'] !== null;
        }));
        $campaign_channel = Reports::breakdown_channels('campaign', $period, []);

        echo '<div class="awp-cols-2 awp-origin-tables">';
        echo self::origin_table('Kanal', $by_channel, $currency, function ($row) {
            return (string)$row['value'];
        }, true);
        echo self::origin_table('Kampagne', $by_campaign, $currency, function ($row) use ($campaign_channel) {
            return $campaign_channel[(string)$row['value']] ?? null;
        }, false);
        echo '</div>';
        Ui::card_close();
    }

    /**
     * @param list<array{value: string|null, conversions: int, revenue: float}> $rows
     * @param callable(array<string, mixed>): ?string $channel_of
     */
    private static function origin_table(string $label, array $rows, string $currency, callable $channel_of, bool $is_channel): string
    {
        if (empty($rows)) {
            return '<div>' . Ui::empty_state($is_channel ? 'Noch keine Conversions in diesem Zeitraum.' : 'Keine Conversion kam über eine Kampagne.') . '</div>';
        }

        $by_revenue = array_sum(array_column($rows, 'revenue')) > 0;
        $max = max(array_map(function ($row) use ($by_revenue) {
            return $by_revenue ? max(1.0, (float)$row['revenue']) : (float)$row['conversions'];
        }, $rows)) ?: 1;

        $html = '<table class="awp-table awp-table--compact awp-table--origin"><thead><tr><th scope="col">' . esc_html($label) . '</th><th scope="col">Conv.</th><th scope="col">Umsatz</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            $channel = $channel_of($row);
            $text = $is_channel ? Format::channel($row['value']) : (string)$row['value'];
            $amount = $by_revenue ? max(1.0, (float)$row['revenue']) : (float)$row['conversions'];
            $bar = $is_channel ? Channels::bar_color($channel) : Channels::bar_color(null);
            $filter = Ui::dimension_filter($is_channel ? 'channel' : 'campaign', $row['value']);
            $html .= '<tr><td class="awp-cell-label"><span class="awp-barlabel"><span class="awp-cell-bar" style="width:' . max(1.5, round($amount / $max * 100, 1)) . '%;background:' . esc_attr($bar) . '"></span>'
                . '<a class="awp-cell-text" href="' . esc_url(App::url($filter)) . '">' . ($is_channel ? Channels::icon_html($channel) : '') . esc_html($text)
                . (!$is_channel && $channel !== null ? '<span class="awp-row-meta">' . esc_html(Format::channel($channel)) . '</span>' : '') . '</a></span></td>'
                . '<td class="is-strong">' . esc_html(Format::number($row['conversions'])) . '</td>'
                . '<td>' . ((float)$row['revenue'] > 0 ? esc_html(Format::money((float)$row['revenue'], $currency, 0)) : '–') . '</td></tr>';
        }

        return $html . '</tbody></table>';
    }

    // ---------------------------------------------------------------------
    // Engagement
    // ---------------------------------------------------------------------

    /** Key figures: key => [label, format, higher is better, explanation]. */
    const ENGAGEMENT_KPIS = [
        'engaged' => ['Ø aktiv je Seite', 'duration', true, 'Zeit, in der eine Seite sichtbar war und benutzt wurde, je Seitenaufruf. Nicht dasselbe wie die Ø Besuchsdauer in der Übersicht: Die misst vom ersten bis zum letzten Seitenaufruf eines Besuchs.'],
        'scroll' => ['Ø Scrolltiefe', 'scroll', true, 'Wie weit eine Seite im Schnitt gelesen wurde.'],
        'contacts' => ['Kontakt-Klicks', 'number', true, 'Klicks auf Telefonnummern, E-Mail-Adressen und WhatsApp.'],
        'downloads' => ['Downloads', 'number', true, 'Klicks auf PDFs, Dokumente, Archive und Medien.'],
        'outbound' => ['Links nach außen', 'number', true, 'Klicks auf Links zu anderen Websites.'],
        'not_found' => ['Nicht gefundene Seiten', 'number', false, 'Aufrufe, die auf einer 404-Seite endeten. Meist ein kaputter Link.'],
    ];

    const CONTACT_NAMES = ['tel' => 'Telefon', 'mailto' => 'E-Mail', 'whatsapp' => 'WhatsApp'];

    public static function engagement(): void
    {
        $period = App::period();
        $filters = App::filters();

        App::page_head('Engagement', self::period_sentence($period));

        if (!\AnalyticsWP\Lib\Core::engagement_enabled()) {
            echo '<div class="awp-layout"><div class="awp-span-all">' . Ui::info('Die Engagement-Messung ist ausgeschaltet. Du kannst sie unter Einstellungen einschalten.') . '</div></div>';
            return;
        }

        $since = Reports::first_seen_day();
        $compare = $since === null || $since <= $period['prev_end'];
        $totals = Reports::engagement_totals($period, $filters);
        $before = Reports::engagement_totals(Reports::previous_period($period), $filters);

        echo '<div class="awp-layout">';
        self::engagement_kpis($totals, $before, $compare);
        self::devices_card($period, $filters);

        // Brief order; cards without rows fold into one card at the end.
        $cards = [
            ['phone', 'Kontakt-Klicks', 'Klicks auf Telefonnummern, E-Mail-Adressen und WhatsApp', 'contact', 'Art'],
            ['download-simple', 'Downloads', 'PDFs, Dokumente, Archive und Medien', 'download', 'Datei'],
            ['magnifying-glass', 'Suchbegriffe', 'Was Besucher in der Suche deiner Website eingegeben haben', 'search', 'Begriff'],
            ['arrow-square-out', 'Links nach außen', 'Wohin Besucher deine Website verlassen', 'outbound', 'Ziel'],
            ['warning', 'Nicht gefundene Seiten', 'Aufrufe, die auf einer 404-Seite endeten', '404', 'Adresse'],
            ['cursor-click', 'Eigene Events', 'Klicks und Aktionen, die du selbst markiert hast', 'custom', 'Event'],
        ];
        $empty = [];
        foreach ($cards as [$icon, $title, $subtitle, $kind, $label]) {
            $rows = Reports::events_by($kind, $period, $filters);
            if (empty($rows)) {
                $empty[] = [$icon, $title, $kind];
                continue;
            }
            self::events_card($icon, $title, $subtitle, $rows, $label, $kind);
        }
        if (!empty($empty)) {
            self::empty_events_card($empty);
        }

        echo '</div>';
    }

    /**
     * Six key figures with the period before.
     *
     * @param array<string, float|int|null> $totals
     * @param array<string, float|int|null> $before
     */
    private static function engagement_kpis(array $totals, array $before, bool $compare): void
    {
        echo '<section class="awp-card awp-span-all" aria-label="Kennzahlen"><div class="awp-kpis">';
        foreach (self::ENGAGEMENT_KPIS as $key => [$label, $format, $higher_is_better, $help]) {
            $value = $totals[$key];
            $previous = $before[$key];
            $show = function ($v) use ($format) {
                if ($v === null) {
                    return '–';
                }
                if ($format === 'duration') {
                    return Format::duration($v);
                }
                return $format === 'scroll' ? Format::percent((float)$v / 100, 0) : Format::number($v);
            };
            $warn = $key === 'not_found' && (int)$value > 0;

            if (!$compare || $value === null || $previous === null) {
                $delta = '<span class="awp-delta">' . ($compare ? '–' : 'Noch kein Vergleich') . '</span>';
                $sub = '';
            } else {
                $delta = self::kpi_delta($value, $previous, $higher_is_better);
                $sub = 'vorher ' . $show($previous) . ($higher_is_better ? '' : ' · weniger ist besser');
            }

            echo '<div class="awp-kpi is-static' . ($warn ? ' is-warn' : '') . '"><span class="awp-kpi-label">' . Ui::term($label, $help) . '</span>'
                . '<span class="awp-kpi-value">' . ($warn ? '<span class="awp-warn-dot" aria-hidden="true"></span>' : '') . esc_html($show($value)) . '</span>'
                . $delta . ($sub !== '' ? '<span class="awp-kpi-sub">' . esc_html($sub) . '</span>' : '') . '</div>';
        }
        echo '</div></section>';
    }

    /**
     * Visits by device (moved here from the channels tab).
     *
     * @param array<string, string> $filters
     */
    private static function devices_card(array $period, array $filters): void
    {
        $currency = Reports::main_currency($period);
        $rows = array_values(array_filter(Reports::breakdown('device', $period, $filters, $currency, 5), function ($row) {
            return $row['value'] !== null;
        }));

        Ui::card_open('desktop', 'Geräte', 'Mit welchem Gerät Besucher kommen und wie gut das klappt', '', 'awp-span-all');
        if (empty($rows)) {
            echo '<div class="awp-card-body">' . Ui::empty_state('In diesem Zeitraum noch keine Besuche.') . '</div>';
            Ui::card_close();
            return;
        }

        $total = array_sum(array_column($rows, 'sessions')) ?: 1;
        echo '<div class="awp-card-body is-flush awp-scroll-x"><table class="awp-table awp-table--rows"><thead><tr><th scope="col">Gerät</th>'
            . '<th scope="col">' . Ui::term('Besuche', Ui::TERMS['sessions']) . '</th><th scope="col">Anteil</th>'
            . '<th scope="col">' . Ui::term('Absprung', Ui::TERMS['bounce']) . '</th>'
            . '<th scope="col">Conv.</th><th scope="col">' . Ui::term('Conv.-Rate', Ui::TERMS['conversion_rate']) . '</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            $device = (string)$row['value'];
            $share = (int)$row['sessions'] / $total;
            echo '<tr><td class="awp-cell-label"><span class="awp-cell-bar" style="width:calc(' . round($share * 100, 1) . '% - 14px);background:' . esc_attr(Channels::bar_color(null)) . '"></span>'
                . '<span class="awp-cell-text awp-device">' . Icons::svg(self::DEVICE_ICONS[$device] ?? 'desktop') . esc_html(Format::device($device)) . '</span></td>'
                . '<td>' . esc_html(Format::number($row['sessions'])) . '</td>'
                . '<td>' . esc_html(Format::percent($share, 0)) . '</td>'
                . '<td>' . Ui::rate($row['bounce_rate'], (int)$row['sessions']) . '</td>'
                . '<td>' . esc_html(Format::number($row['conversions'])) . '</td>'
                . '<td>' . Ui::rate($row['conversion_rate'], (int)$row['sessions']) . '</td></tr>';
        }
        echo '</tbody></table></div>';
        Ui::card_close();
    }

    /**
     * @param list<array{value: string, count: int, sessions: int, empty?: int|null}> $rows
     */
    private static function events_card(string $icon, string $title, string $subtitle, array $rows, string $label, string $kind): void
    {
        $count = array_sum(array_column($rows, 'count'));
        $actions = $kind === '404' ? '<span class="awp-chip-warn">' . esc_html(Format::number($count) . ($count === 1 ? ' Aufruf' : ' Aufrufe')) . '</span>' : '';
        $empty_searches = $kind === 'search' ? array_sum(array_map('intval', array_column($rows, 'empty'))) : 0;
        if ($empty_searches > 0) {
            $actions = '<span class="awp-chip-warn" title="Suchen, die keinen Treffer fanden">' . esc_html(Format::number($empty_searches) . ' ohne Ergebnis') . '</span>';
        }

        Ui::card_open($icon, $title, $subtitle, $actions);
        $max = max(array_column($rows, 'count')) ?: 1;
        echo '<div class="awp-card-body is-flush"><table class="awp-table awp-table--rows"><thead><tr><th scope="col">' . esc_html($label) . '</th><th scope="col">Anzahl</th><th scope="col" class="is-optional">Besuche</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            if ($kind === 'contact') {
                $text = self::CONTACT_NAMES[$row['value']] ?? $row['value'];
            } elseif ($kind === '404') {
                $text = Format::path($row['value']);
            } else {
                $text = $row['value'];
            }
            $tag = $kind === 'search' && !empty($row['empty'])
                ? ' <span class="awp-chip-warn" title="' . esc_attr(Format::number($row['empty']) . ' von ' . Format::number($row['count']) . ' Suchen ohne Treffer') . '">ohne Ergebnis</span>'
                : '';
            $width = round($row['count'] / $max * 100, 1);
            echo '<tr><td class="awp-cell-label"><span class="awp-cell-bar" style="width:calc(' . $width . '% - 14px);background:' . esc_attr(Channels::bar_color(null)) . '"></span>'
                . '<span class="awp-cell-text" title="' . esc_attr($text) . '">' . esc_html($text) . '</span>' . $tag . '</td>'
                . '<td>' . esc_html(Format::number($row['count'])) . '</td><td class="is-optional">' . esc_html(Format::number($row['sessions'])) . '</td></tr>';
        }
        echo '</tbody></table></div>';
        Ui::card_close();
    }

    /**
     * Kinds without a single event, folded into one card, with a short
     * "So geht's" for own events.
     *
     * @param list<array{0: string, 1: string, 2: string}> $empty icon, title, kind
     */
    private static function empty_events_card(array $empty): void
    {
        $hints = [
            'contact' => 'Zählt Klicks auf Telefonnummern, E-Mail-Adressen und WhatsApp.',
            'download' => 'Zählt Klicks auf PDFs, Dokumente, Archive und Medien.',
            'search' => 'Zählt Suchen über die WordPress-Suche.',
            'outbound' => 'Zählt Klicks auf Links zu anderen Websites.',
            '404' => 'Gut so: Kein Besucher ist auf einer nicht vorhandenen Seite gelandet.',
            'custom' => 'Markiere Buttons oder Links, die du zählen willst.',
        ];

        Ui::card_open('', 'In diesem Zeitraum nichts', 'Diese Bereiche haben noch keine Ereignisse', '', 'awp-span-all awp-empty-events');
        echo '<ul class="awp-empty-list">';
        foreach ($empty as [$icon, $title, $kind]) {
            echo '<li><span class="awp-tile">' . Icons::svg($icon) . '</span><div><strong>' . esc_html($title) . '</strong><span>' . esc_html($hints[$kind] ?? '') . '</span>';
            if ($kind === 'custom') {
                echo '<details class="awp-howto"><summary>So geht\'s' . Icons::svg('caret-down') . '</summary>'
                    . '<p>Gib einem Button oder Link das Attribut <code>data-awp-event</code> mit einem Namen. Jeder Klick zählt dann als Event:</p>'
                    . '<pre>' . esc_html('<a href="/angebot/" data-awp-event="angebot-angefragt">Angebot anfragen</a>') . '</pre>'
                    . '<p>Oder aus eigenem JavaScript:</p><pre>' . esc_html("AnalyticsWP.event('newsletter-angemeldet', { liste: 'herbst' })") . '</pre></details>';
            }
            echo '</div></li>';
        }
        echo '</ul>';
        Ui::card_close();
    }

    // ---------------------------------------------------------------------
    // Journeys
    // ---------------------------------------------------------------------

    /** Result of a visit => [label, colour]. */
    const VISIT_RESULTS = [
        'conv' => ['Mit Conversion', '#0f6e68'],
        'multi' => ['Mehrere Seiten, ohne Conversion', '#9fcbc6'],
        'bounce' => ['Abgesprungen', '#dcdcd7'],
    ];

    const DEVICE_ICONS = ['desktop' => 'desktop', 'mobile' => 'device-mobile', 'tablet' => 'device-tablet'];

    const MONTHS = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

    /** Visits per page of the journeys list. */
    const VISITS_PER_PAGE = 20;

    public static function journeys(): void
    {
        $visitor = isset($_GET['visitor']) ? sanitize_text_field(wp_unslash($_GET['visitor'])) : '';
        $user_id = isset($_GET['user']) ? absint($_GET['user']) : 0;

        if ($visitor !== '' || $user_id > 0) {
            self::journey_detail($visitor, $user_id);
            return;
        }

        $period = App::period();
        $filters = App::filters();
        $only = isset($_GET['only']) ? sanitize_key(wp_unslash($_GET['only'])) : 'all';
        $only = in_array($only, ['all', 'conv', 'multi'], true) ? $only : 'all';
        $with_empty = !empty($_GET['empty']);
        $page = isset($_GET['p']) ? max(1, min(50, absint($_GET['p']))) : 1;

        App::page_head('Journeys', self::period_sentence($period));
        echo '<div class="awp-layout">';

        $mosaic = Reports::recent_visits($filters);
        self::journey_mosaic($mosaic, $only);

        $limit = $page * self::VISITS_PER_PAGE;
        $rows = Reports::visits_list($period, $filters, $only, $with_empty, $limit + 1);
        $has_more = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);
        $counts = Reports::visits_counts($period, $filters, $with_empty);
        self::journey_list($rows, $counts, $only, $with_empty, $has_more, $page, $filters);

        echo '</div>';
    }

    /**
     * Purchase, multi-page or bounce.
     *
     * @param array<string, mixed> $visit
     */
    private static function visit_result(array $visit): string
    {
        if ((int)$visit['conversions'] > 0) {
            return 'conv';
        }

        return (int)$visit['pageviews'] > 1 ? 'multi' : 'bounce';
    }

    /**
     * The path of a visit as dots: one per page (at most 10), a conversion
     * marks the page it happened on.
     *
     * @param list<array<string, mixed>> $events
     * @return list<string> 'p' page, 'c' page with conversion
     */
    private static function visit_dots(array $events, int $pageviews): array
    {
        $dots = [];
        foreach ($events as $event) {
            if ($event['event_type'] === 'pageview') {
                $dots[] = 'p';
            } elseif (!empty($event['conversion_type'])) {
                if (empty($dots)) {
                    $dots[] = 'p';
                }
                $dots[count($dots) - 1] = 'c';
            }
        }
        if (empty($dots)) {
            $dots = array_fill(0, max(0, min(10, $pageviews)), 'p');
        }

        return array_slice($dots, 0, 10);
    }

    /**
     * @param array<string, mixed> $visit
     */
    private static function visit_detail(array $visit): string
    {
        $parts = array_filter([(string)$visit['source'], (string)$visit['campaign']]);
        if (empty($parts)) {
            return $visit['channel'] === \AnalyticsWP\Lib\Attribution::DIRECT ? 'ohne Quelle' : '';
        }

        return implode(' · ', $parts);
    }

    /**
     * @param array<string, mixed> $visit
     */
    private static function visit_duration(array $visit): string
    {
        $seconds = (int)strtotime($visit['last_seen_at'] . ' UTC') - (int)strtotime($visit['started_at'] . ' UTC');

        return (int)$visit['events'] > 1 && $seconds > 0 ? Format::duration($seconds) : '–';
    }

    /**
     * "Heute", "Gestern" or "18. Oktober" for a UTC timestamp.
     */
    private static function day_label(string $utc): string
    {
        $time = (int)strtotime($utc . ' UTC');
        $day = wp_date('Y-m-d', $time);
        if ($day === wp_date('Y-m-d')) {
            return 'Heute';
        }
        if ($day === wp_date('Y-m-d', time() - DAY_IN_SECONDS)) {
            return 'Gestern';
        }

        return wp_date('j', $time) . '. ' . self::MONTHS[(int)wp_date('n', $time) - 1] . ((string)wp_date('Y', $time) !== (string)wp_date('Y') ? ' ' . wp_date('Y', $time) : '');
    }

    /**
     * The last 260 visits as squares, the time they fell in as stacked bars,
     * a preview of the visit under the pointer.
     *
     * @param list<array<string, mixed>> $visits
     */
    private static function journey_mosaic(array $visits, string $only): void
    {
        $count = count($visits);
        $switch = '<span class="awp-seg-label">Farbe nach</span><div class="awp-seg awp-seg--buttons" role="group" aria-label="Farbe nach">'
            . '<button type="button" class="is-active" aria-pressed="true" data-awp-mosaic-mode="result">Ergebnis</button>'
            . '<button type="button" aria-pressed="false" data-awp-mosaic-mode="channel">Kanal</button></div>';

        if ($count === 0) {
            Ui::card_open('squares-four', 'Die letzten Besuche', '', '', 'awp-span-all');
            echo '<div class="awp-card-body">' . Ui::empty_state('Noch keine Besuche.') . '</div>';
            Ui::card_close();
            return;
        }

        $oldest = (string)end($visits)['started_at'];
        $newest = (string)$visits[0]['started_at'];
        $subtitle = 'Jedes Quadrat ist ein Besuch, vom ' . Format::datetime($oldest) . ' bis ' . Format::datetime($newest);
        Ui::card_open('squares-four', $count >= Reports::MOSAIC_SIZE ? 'Die letzten ' . Reports::MOSAIC_SIZE . ' Besuche' : 'Die letzten ' . $count . ' Besuche', $subtitle, $switch, 'awp-span-all awp-mosaic-card');

        $steps = Reports::visit_steps(array_column($visits, 'session_id'), 8000);
        $timeline = self::visit_bins($visits);

        $data = [];
        $results = ['conv' => 0, 'multi' => 0, 'bounce' => 0];
        $channels = [];
        $pages = 0;
        $mobile = 0;
        $squares = '';
        foreach ($visits as $i => $visit) {
            $result = self::visit_result($visit);
            $channel = (string)$visit['channel'];
            $results[$result]++;
            $channels[$channel] = ($channels[$channel] ?? 0) + 1;
            $pages += (int)$visit['pageviews'];
            $mobile += $visit['device_type'] === 'mobile' ? 1 : 0;
            $conversions = (int)$visit['conversions'];
            $revenue = $visit['revenue'] !== null && (float)$visit['revenue'] > 0 ? Format::money((float)$visit['revenue'], (string)($visit['currency'] ?: 'EUR')) : '';
            $matches = $only === 'all' || ($only === 'conv' && $result === 'conv') || ($only === 'multi' && (int)$visit['pageviews'] > 1);

            $data[] = [
                'id' => (string)$visit['session_id'],
                'v' => $visit['user_id'] ? '' : (string)$visit['visitor_hash'],
                'u' => (int)$visit['user_id'],
                'k' => $channel,
                'n' => Format::channel($channel),
                'd' => self::visit_detail($visit),
                'dv' => Format::device((string)$visit['device_type']),
                'di' => self::DEVICE_ICONS[(string)$visit['device_type']] ?? 'desktop',
                'w' => Format::datetime((string)$visit['started_at']) . ' Uhr',
                'e' => (string)$visit['landing_path'],
                'p' => (int)$visit['pageviews'],
                't' => self::visit_duration($visit),
                'c' => $conversions,
                'r' => $revenue,
                'x' => self::visit_dots($steps[(string)$visit['session_id']] ?? [], (int)$visit['pageviews']),
                'b' => $timeline['of'][$i],
                's' => $result,
            ];

            $aria = Format::channel($channel) . ', ' . Format::datetime((string)$visit['started_at']) . ', '
                . ($conversions > 0 ? $conversions . ($conversions === 1 ? ' Conversion' : ' Conversions') : ((int)$visit['pageviews'] > 1 ? $visit['pageviews'] . ' Seiten' : 'abgesprungen'));
            $squares .= '<button type="button" class="awp-sq' . ($matches ? '' : ' is-out') . '" data-i="' . $i . '" aria-label="' . esc_attr($aria) . '" aria-pressed="false"'
                . ' style="--sq-res:' . self::VISIT_RESULTS[$result][1] . ';--sq-ch:' . esc_attr(Channels::color($channel)) . '"></button>';
        }

        $channel_icons = [];
        foreach (Channels::STYLES as $channel => [, $icon]) {
            $channel_icons[$channel] = $icon;
        }
        // The visits as a JSON script: no attribute escaping for 260 entries.
        echo '<div class="awp-mosaic" data-awp-mosaic data-awp-channel-icons="' . esc_attr((string)wp_json_encode($channel_icons)) . '">'
            . '<script type="application/json" class="awp-mosaic-data">' . wp_json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) . '</script>';

        // Squares and timeline.
        echo '<div class="awp-mosaic-left"><div class="awp-sq-grid" role="group" aria-label="Besuche als Quadrate, neueste oben links">' . $squares . '</div>'
            . '<div class="awp-sq-ends" aria-hidden="true"><span>neuester</span><span>älter</span></div>';
        echo '<div class="awp-bins-wrap"><div class="awp-bins-head"><span>Wann die Besuche waren</span><span>' . esc_html($timeline['unit']) . '</span></div>'
            . '<div class="awp-bins" role="img" aria-label="' . esc_attr('Besuche ' . $timeline['unit'] . ', neueste links') . '">';
        foreach ($timeline['bins'] as $b => $bin) {
            echo '<div class="awp-bin" data-b="' . $b . '" data-title="' . esc_attr($bin['title']) . '" data-text="' . esc_attr(Format::number($bin['n']) . ($bin['n'] === 1 ? ' Besuch' : ' Besuche') . ($bin['conv'] ? ' · ' . $bin['conv'] . ' mit Conversion' : '')) . '"' . ($bin['gap'] ? ' style="margin-right:3px"' : '') . '>'
                . '<span class="awp-bin-mark" aria-hidden="true"></span><span class="awp-bin-by-result">';
            foreach (['conv', 'multi', 'bounce'] as $key) {
                if ($bin[$key] > 0) {
                    echo '<i style="height:' . round($bin[$key] / $timeline['max'] * 48, 1) . 'px;background:' . self::VISIT_RESULTS[$key][1] . '"></i>';
                }
            }
            echo '</span><span class="awp-bin-by-channel">';
            foreach ($bin['ch'] as $channel => $n) {
                echo '<i style="height:' . round($n / $timeline['max'] * 48, 1) . 'px;background:' . esc_attr(Channels::color($channel)) . '"></i>';
            }
            echo '</span></div>';
        }
        echo '<div class="awp-bin-tip" hidden></div></div><div class="awp-bins-x" aria-hidden="true">';
        foreach ($timeline['ticks'] as [$position, $label]) {
            echo '<span style="left:' . $position . '%">' . esc_html($label) . '</span>';
        }
        echo '</div></div></div>';

        // Preview, legend, figures.
        echo '<div class="awp-mosaic-right">';
        echo '<div class="awp-preview" aria-live="polite">'
            . '<div class="awp-preview-empty">' . Icons::svg('squares-four') . '<span>Fahr über ein Quadrat oder einen Balken.<br>Hier erscheint die Vorschau des Besuchs.</span></div>'
            . '<div class="awp-preview-card" hidden><div class="awp-preview-head"><span class="awp-tile" data-slot="icon"></span>'
            . '<span class="awp-preview-origin"><strong data-slot="channel"></strong><span data-slot="detail"></span></span>'
            . '<button type="button" class="awp-preview-close" data-awp-unpin hidden aria-label="Vorschau schließen">' . Icons::svg('x') . '</button></div>'
            . '<div class="awp-preview-when"><span data-slot="device-icon"></span><span data-slot="when"></span></div>'
            . '<div class="awp-preview-path"><span class="awp-dots" data-slot="dots"></span><span><span class="awp-row-meta">Einstieg</span> <span data-slot="entry"></span></span><span class="awp-field-desc" data-slot="summary"></span></div>'
            . '<div class="awp-preview-foot"><span data-slot="result"></span><a href="#" class="awp-linkline" data-slot="open">Ganze Journey' . Icons::svg('caret-down') . '</a></div></div>'
            . '</div>';

        // Icons the preview borrows (channel and device).
        echo '<div hidden data-awp-icon-sprite>';
        foreach (array_unique(array_merge(array_column(Channels::STYLES, 1), array_values(self::DEVICE_ICONS))) as $icon) {
            echo '<span data-name="' . esc_attr($icon) . '">' . Icons::svg($icon) . '</span>';
        }
        echo '</div>';

        $percent = function (int $n) use ($count) {
            return Format::percent($n / max(1, $count), 0);
        };
        echo '<div class="awp-legend"><span class="awp-insight-label">Legende</span><div class="awp-legend-by-result">';
        foreach (self::VISIT_RESULTS as $key => [$label, $color]) {
            echo '<div class="awp-legend-row"><i style="background:' . $color . '"></i><span>' . esc_html($label) . '</span><strong>' . esc_html(Format::number($results[$key])) . '</strong><span>' . esc_html($percent($results[$key])) . '</span></div>';
        }
        echo '</div><div class="awp-legend-by-channel">';
        arsort($channels);
        foreach ($channels as $channel => $n) {
            echo '<div class="awp-legend-row"><i style="background:' . esc_attr(Channels::color($channel)) . '"></i><span>' . esc_html(Format::channel($channel)) . '</span><strong>' . esc_html(Format::number($n)) . '</strong><span>' . esc_html($percent($n)) . '</span></div>';
        }
        echo '</div></div>';

        echo '<div class="awp-stats">'
            . '<div class="awp-stat"><span class="awp-stat-label">Ø Seiten je Besuch</span><span class="awp-stat-value">' . esc_html(number_format($pages / max(1, $count), 1, ',', '.')) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Mit Conversion</span><span class="awp-stat-value">' . esc_html($percent($results['conv'])) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Abgesprungen</span><span class="awp-stat-value">' . esc_html($percent($results['bounce'])) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Smartphone</span><span class="awp-stat-value">' . esc_html($percent($mobile)) . '</span></div>'
            . '</div><span class="awp-field-desc">Klick auf ein Quadrat hält die Vorschau fest.</span>';
        echo '</div></div>';

        Ui::card_close();
    }

    /**
     * Time windows of the mosaic's visits, newest left: 6 hours while the
     * visits span two weeks at most, else days, else weeks, so that there
     * are never more than about 60 bars.
     *
     * @param list<array<string, mixed>> $visits Newest first.
     * @return array{bins: list<array<string, mixed>>, of: list<int>, ticks: list<array{0: float, 1: string}>, unit: string, max: int}
     */
    private static function visit_bins(array $visits): array
    {
        $offset = wp_timezone()->getOffset(new \DateTime('now', new \DateTimeZone('UTC')));
        $local = array_map(function ($visit) use ($offset) {
            return (int)strtotime($visit['started_at'] . ' UTC') + $offset;
        }, $visits);
        $span = max(1, $local[0] - end($local));

        if ($span <= 14 * DAY_IN_SECONDS) {
            [$size, $unit] = [6 * HOUR_IN_SECONDS, 'je 6 Stunden'];
        } elseif ($span <= 60 * DAY_IN_SECONDS) {
            [$size, $unit] = [DAY_IN_SECONDS, 'je Tag'];
        } else {
            [$size, $unit] = [WEEK_IN_SECONDS, 'je Woche'];
        }

        $end = (int)(floor($local[0] / $size) + 1) * $size;
        $count = (int)floor(($end - end($local) - 1) / $size) + 1;
        $bins = [];
        for ($b = 0; $b < $count; $b++) {
            $start = $end - ($b + 1) * $size;
            $bins[$b] = ['n' => 0, 'conv' => 0, 'multi' => 0, 'bounce' => 0, 'ch' => [], 'start' => $start, 'gap' => false, 'title' => ''];
        }

        $of = [];
        foreach ($visits as $i => $visit) {
            $b = min($count - 1, (int)floor(($end - 1 - $local[$i]) / $size));
            $of[$i] = $b;
            $bins[$b]['n']++;
            $bins[$b][self::visit_result($visit)]++;
            $channel = (string)$visit['channel'];
            $bins[$b]['ch'][$channel] = ($bins[$b]['ch'][$channel] ?? 0) + 1;
        }

        $weekday = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
        $today = (int)floor((time() + $offset) / DAY_IN_SECONDS);
        $day_name = function (int $local_time) use ($weekday, $today) {
            $day = (int)floor($local_time / DAY_IN_SECONDS);
            if ($day === $today) {
                return 'Heute';
            }
            if ($day === $today - 1) {
                return 'Gestern';
            }
            return $weekday[(int)gmdate('w', $local_time)] . ' ' . gmdate('j.', $local_time);
        };

        $ticks = [];
        foreach ($bins as $b => &$bin) {
            $start = $bin['start'];
            if ($size === 6 * HOUR_IN_SECONDS) {
                $hour = (int)gmdate('G', $start);
                $name = $day_name($start);
                $bin['title'] = (in_array($name, ['Heute', 'Gestern'], true) ? $name : $weekday[(int)gmdate('w', $start)] . ', ' . gmdate('j.n.', $start)) . ', ' . $hour . '–' . ($hour + 6) . ' Uhr';
                if ($hour === 0 && $b < $count - 1) {
                    $bin['gap'] = true;
                }
                if ($hour === 12) {
                    $ticks[] = [round(($b + 0.5) / $count * 100, 2), $day_name($start)];
                }
            } elseif ($size === DAY_IN_SECONDS) {
                $bin['title'] = $weekday[(int)gmdate('w', $start)] . ', ' . gmdate('j.n.', $start);
                if ($b % 7 === 0) {
                    $ticks[] = [round(($b + 0.5) / $count * 100, 2), $day_name($start)];
                }
            } else {
                $bin['title'] = 'Woche ab ' . gmdate('j.n.', $start);
                if ($b % 4 === 0) {
                    $ticks[] = [round(($b + 0.5) / $count * 100, 2), gmdate('j.n.', $start)];
                }
            }
            arsort($bin['ch']);
        }
        unset($bin);

        return ['bins' => $bins, 'of' => $of, 'ticks' => $ticks, 'unit' => $unit, 'max' => max(1, max(array_column($bins, 'n')))];
    }

    /**
     * The visits of the period, by day, each with its steps to unfold.
     *
     * @param list<array<string, mixed>> $rows
     * @param array{all: int, conv: int, multi: int, empty: int} $counts
     * @param array<string, string> $filters
     */
    private static function journey_list(array $rows, array $counts, string $only, bool $with_empty, bool $has_more, int $page, array $filters): void
    {
        $chips = '<nav class="awp-filter-chips" aria-label="Besuche filtern">';
        foreach (['all' => ['Alle Besuche', 'list'], 'conv' => ['Mit Conversion', 'target'], 'multi' => ['Mehr als 1 Seite', 'stack']] as $key => [$label, $icon]) {
            $on = $key === $only;
            $chips .= '<a href="' . esc_url(App::url(['only' => $key === 'all' ? null : $key, 'p' => null]) . '#awp-visits') . '" class="awp-fchip' . ($on ? ' is-active' : '') . '"' . ($on ? ' aria-current="true"' : '') . '>'
                . Icons::svg($icon) . esc_html($label) . '<span>' . esc_html(Format::number($counts[$key])) . '</span></a>';
        }
        $chips .= '</nav>';

        $menu = function (string $label, string $param, array $options, ?string $active) {
            $html = '<details class="awp-more awp-more--small' . ($active !== null ? ' is-active' : '') . '"><summary>' . esc_html($active !== null ? ($options[$active] ?? $active) : $label) . Icons::svg('caret-down') . '</summary><div class="awp-more-panel">';
            $html .= '<a href="' . esc_url(App::url(['f_' . $param => null, 'p' => null]) . '#awp-visits') . '"' . ($active === null ? ' class="is-active"' : '') . '>' . esc_html($label) . '</a>';
            foreach ($options as $value => $text) {
                $html .= '<a href="' . esc_url(App::url(['f_' . $param => (string)$value, 'p' => null]) . '#awp-visits') . '"' . ($active === (string)$value ? ' class="is-active"' : '') . '>' . esc_html($text) . '</a>';
            }
            return $html . '</div></details>';
        };
        $actions = $menu('Alle Kanäle', 'channel', Format::CHANNELS, $filters['channel'] ?? null) . $menu('Alle Geräte', 'device', Format::DEVICES, $filters['device'] ?? null);

        echo '<section class="awp-card awp-span-all awp-visits" id="awp-visits" aria-label="Besuche"><header class="awp-card-head awp-visits-head">' . $chips . '<div class="awp-card-actions">' . $actions . '</div></header>';

        if (empty($rows)) {
            echo '<div class="awp-card-body">' . Ui::empty_state('Keine Besuche in diesem Zeitraum' . ($only !== 'all' ? ' mit diesem Filter' : '') . '.') . '</div>';
        } else {
            $steps = Reports::visit_steps(array_column($rows, 'session_id'), 6000);
            echo '<div class="awp-visit-head" aria-hidden="true"><span>Herkunft</span><span>Weg durch die Website</span><span>Ergebnis</span><span>Dauer</span><span>Gerät</span><span>Beginn</span><span></span></div>';
            $day = '';
            foreach ($rows as $row) {
                $label = self::day_label((string)$row['started_at']);
                if ($label !== $day) {
                    echo '<div class="awp-visit-day">' . esc_html($label) . '</div>';
                    $day = $label;
                }
                self::visit_row($row, $steps[(string)$row['session_id']] ?? []);
            }
        }

        if ($has_more) {
            echo '<div class="awp-visits-more"><a class="button" href="' . esc_url(App::url(['p' => (string)($page + 1)]) . '#awp-visits') . '">Weitere ' . self::VISITS_PER_PAGE . ' Besuche laden</a></div>';
        }

        $foot = '';
        if ($counts['empty'] > 0) {
            $foot = Icons::svg('info') . '<span>' . esc_html(
                $with_empty
                    ? Format::number($counts['empty']) . ($counts['empty'] === 1 ? ' Besuch ohne Seitenaufruf wird gezeigt' : ' Besuche ohne Seitenaufruf werden gezeigt') . ' (etwa ein Kauf, den ein Zahlungsdienst bestätigt hat).'
                    : Format::number($counts['empty']) . ($counts['empty'] === 1 ? ' Besuch ohne Seitenaufruf ausgeblendet' : ' Besuche ohne Seitenaufruf ausgeblendet') . ' (etwa ein Kauf, den ein Zahlungsdienst bestätigt hat).'
            ) . '</span><a href="' . esc_url(App::url(['empty' => $with_empty ? null : '1', 'p' => null]) . '#awp-visits') . '">' . ($with_empty ? 'Ausblenden' : 'Zeigen') . '</a>';
        }
        echo $foot !== '' ? '<footer class="awp-card-foot awp-visits-foot">' . $foot . '</footer>' : '';
        echo '</section>';
    }

    /**
     * One visit: a summary row that unfolds into its steps.
     *
     * @param array<string, mixed> $row
     * @param list<array<string, mixed>> $events
     */
    private static function visit_row(array $row, array $events): void
    {
        $channel = (string)$row['channel'];
        $result = self::visit_result($row);
        $pageviews = (int)$row['pageviews'];
        $conversions = (int)$row['conversions'];
        $revenue = $row['revenue'] !== null && (float)$row['revenue'] > 0 ? Format::money((float)$row['revenue'], (string)($row['currency'] ?: 'EUR')) : '';
        $device = (string)$row['device_type'];
        $path = $pageviews === 0 ? 'Kein Seitenaufruf' : (string)$row['landing_path'] . ($pageviews > 1 ? ' + ' . ($pageviews - 1) . ($pageviews === 2 ? ' Seite' : ' Seiten') : '');

        $dots = '';
        foreach (self::visit_dots($events, $pageviews) as $i => $dot) {
            $dots .= '<i class="' . ($dot === 'c' ? 'is-conv' : ($i === 0 ? 'is-first' : '')) . '"></i>';
        }
        if ($pageviews === 0) {
            $dots .= '<i class="is-none"></i>';
        }

        if ($conversions > 0) {
            $outcome = '<span class="awp-outcome"><span class="awp-pill-conv">' . Icons::svg('target') . esc_html($conversions === 1 ? '1 Conversion' : $conversions . ' Conversions') . '</span>'
                . ($revenue !== '' ? '<span>' . esc_html($revenue) . '</span>' : '') . '</span>';
        } else {
            $outcome = '<span class="awp-none">' . ($pageviews === 1 ? 'Abgesprungen' : '–') . '</span>';
        }

        echo '<details class="awp-visit" id="awp-visit-' . esc_attr((string)$row['session_id']) . '"><summary class="awp-visit-row">'
            . '<span class="awp-visit-origin"><span class="awp-tile">' . Icons::svg(Channels::icon($channel)) . '<span class="awp-swatch" style="background:' . esc_attr(Channels::css_var($channel)) . '"></span></span>'
            . '<span class="awp-visit-text"><span>' . esc_html(Format::channel($channel)) . '</span><span class="awp-row-meta">' . esc_html(self::visit_detail($row)) . '</span></span></span>'
            . '<span class="awp-visit-path"><span class="awp-dots" aria-hidden="true">' . $dots . '</span><span class="awp-visit-pathtext">' . esc_html($path) . '</span></span>'
            . '<span>' . $outcome . '</span>'
            . '<span class="awp-num is-muted">' . esc_html(self::visit_duration($row)) . '</span>'
            . '<span class="awp-visit-device" title="' . esc_attr(Format::device($device)) . '">' . Icons::svg(self::DEVICE_ICONS[$device] ?? 'desktop') . '<span class="awp-sr">' . esc_html(Format::device($device)) . '</span></span>'
            . '<span class="awp-num is-muted">' . esc_html((string)wp_date('H:i', (int)strtotime($row['started_at'] . ' UTC'))) . '</span>'
            . '<span class="awp-visit-caret">' . Icons::svg('caret-down') . '</span>'
            . '</summary>';

        echo '<div class="awp-visit-body">' . self::visit_steps_html($row, $events);
        $journey = $row['user_id'] ? ['user' => (string)(int)$row['user_id']] : ['visitor' => (string)$row['visitor_hash']];
        echo '<div class="awp-visit-side"><div class="awp-stats">'
            . '<div class="awp-stat"><span class="awp-stat-label">Seiten</span><span class="awp-stat-value">' . esc_html(Format::number($pageviews)) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Dauer</span><span class="awp-stat-value">' . esc_html(self::visit_duration($row)) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Gerät</span><span class="awp-stat-value">' . esc_html(Format::device($device)) . '</span></div>'
            . '<div class="awp-stat"><span class="awp-stat-label">Ergebnis</span><span class="awp-stat-value">' . esc_html($conversions > 0 ? $conversions . '× · ' . ($revenue !== '' ? $revenue : 'ohne Wert') : 'keine Conversion') . '</span></div>'
            . '</div><p class="awp-field-desc">Ohne Einwilligung endet ein Besuch nach 30 Minuten ohne Aktivität, spätestens um Mitternacht.</p>'
            . Ui::link(App::url($journey + ['only' => null, 'empty' => null, 'p' => null, 'f_*' => null]), 'Alle Besuche dieses Besuchers') . '</div>';
        echo '</div></details>';
    }

    /**
     * The steps of one visit as a timeline: entry, pages, clicks,
     * conversions, end.
     *
     * @param array<string, mixed> $visit
     * @param list<array<string, mixed>> $events
     */
    private static function visit_steps_html(array $visit, array $events): string
    {
        $start = (int)strtotime($visit['started_at'] . ' UTC');
        $relative = function (string $timestamp) use ($start) {
            $seconds = max(0, (int)strtotime($timestamp . ' UTC') - $start);
            return intdiv($seconds, 60) . ':' . str_pad((string)($seconds % 60), 2, '0', STR_PAD_LEFT);
        };
        $origin = Format::channel((string)$visit['channel']) . (self::visit_detail($visit) !== '' && self::visit_detail($visit) !== 'ohne Quelle' ? ' · ' . self::visit_detail($visit) : '');

        $steps = [];
        $first_page = true;
        $last_path = '';
        foreach ($events as $event) {
            $props = json_decode((string)$event['event_properties_json'], true);
            $props = is_array($props) ? $props : [];
            $path = (string)($event['path'] ?? '') !== '' ? (string)$event['path'] : Format::path((string)$event['page_url']);

            if (!empty($event['conversion_type'])) {
                $type = (string)$event['conversion_type'];
                $label = Format::conversion_type($type) . (!empty($props['form_name']) ? ': ' . $props['form_name'] : '');
                $value = $event['revenue'] !== null && (float)$event['revenue'] > 0 ? Format::money((float)$event['revenue'], (string)($event['currency'] ?: 'EUR')) : '';
                $steps[] = [$relative($event['timestamp']), Format::CONVERSION_KINDS[Format::conversion_kind($type)][1], $label, $path !== '' ? 'Auf ' . $path : '', $value, 'conv'];
                continue;
            }

            switch ($event['event_type']) {
                case 'pageview':
                    $sub = [];
                    if ((int)($props['status'] ?? 0) === 404) {
                        $sub[] = 'Seite nicht gefunden';
                    }
                    if (!empty($props['search'])) {
                        $sub[] = 'Suche: ' . $props['search'];
                    }
                    if ($event['engaged_seconds'] !== null && (int)$event['engaged_seconds'] > 0) {
                        $sub[] = Format::duration((int)$event['engaged_seconds']) . ' aktiv';
                    }
                    if ($event['scroll_depth'] !== null && (int)$event['scroll_depth'] > 0) {
                        $sub[] = (int)$event['scroll_depth'] . ' % gescrollt';
                    }
                    if ($first_page) {
                        $steps[] = [$relative($event['timestamp']), 'sign-in', 'Einstieg auf ' . $path, implode(', ', array_merge([$origin], $sub)), '', 'entry'];
                        $first_page = false;
                    } else {
                        $steps[] = [$relative($event['timestamp']), 'file', $path, implode(', ', $sub), '', 'page'];
                    }
                    $last_path = $path;
                    break;
                case 'outbound':
                    $steps[] = [$relative($event['timestamp']), 'arrow-square-out', 'Link nach außen: ' . (string)wp_parse_url((string)($props['url'] ?? ''), PHP_URL_HOST), 'Auf ' . $path, '', 'event'];
                    break;
                case 'download':
                    $steps[] = [$relative($event['timestamp']), 'download-simple', 'Download: ' . basename((string)($props['file'] ?? '')), 'Auf ' . $path, '', 'event'];
                    break;
                case 'contact':
                    $labels = ['tel' => 'Telefonnummer', 'mailto' => 'E-Mail-Adresse', 'whatsapp' => 'WhatsApp'];
                    $steps[] = [$relative($event['timestamp']), 'phone', 'Klick auf ' . ($labels[$props['type'] ?? ''] ?? 'Kontakt'), 'Auf ' . $path, '', 'event'];
                    break;
                default:
                    $steps[] = [$relative($event['timestamp']), 'cursor-click', (string)$event['event_type'], $path !== '' ? 'Auf ' . $path : '', '', 'event'];
            }
        }

        $more = 0;
        if (count($steps) > 40) {
            $more = count($steps) - 40;
            $steps = array_slice($steps, 0, 40);
        }
        $pageviews = (int)$visit['pageviews'];
        if ($pageviews > 0) {
            $steps[] = [
                self::visit_duration($visit) !== '–' ? $relative((string)$visit['last_seen_at']) : '',
                'sign-out',
                $pageviews <= 1 ? 'Abgesprungen' : 'Ende auf ' . ((string)$visit['exit_path'] !== '' ? $visit['exit_path'] : $last_path),
                $pageviews <= 1 ? 'Nur diese eine Seite' : '',
                '',
                'end',
            ];
        }

        $html = '<ol class="awp-steps">';
        foreach ($steps as [$time, $icon, $label, $sub, $value, $kind]) {
            $html .= '<li class="awp-step is-' . $kind . '"><span class="awp-step-time">' . esc_html($time) . '</span>'
                . '<span class="awp-step-node">' . Icons::svg($icon) . '</span>'
                . '<span class="awp-step-text"><span class="awp-step-label">' . esc_html($label) . '</span>' . ($sub !== '' ? '<span class="awp-step-sub">' . esc_html($sub) . '</span>' : '') . '</span>'
                . '<span class="awp-step-value">' . esc_html($value) . '</span></li>';
        }
        if ($more > 0) {
            $html .= '<li class="awp-step is-more"><span class="awp-step-time"></span><span class="awp-step-node"></span><span class="awp-step-text"><span class="awp-step-sub">' . esc_html('… ' . $more . ' weitere Schritte') . '</span></span><span></span></li>';
        }

        return $html . '</ol>';
    }

    /**
     * Everything one visitor did (a daily hash, or a logged-in user across
     * days), visit by visit, with the same steps as the list.
     */
    private static function journey_detail(string $visitor, int $user_id): void
    {
        $journey = Reports::journey($visitor, $user_id);
        $back = Ui::link(App::url(['visitor' => null, 'user' => null]), 'Alle Besuche');

        if ($user_id > 0) {
            $user = get_userdata($user_id);
            $title = $user ? 'Journey von ' . $user->display_name : 'Journey von Nutzer ' . $user_id;
            $subtitle = 'Eingeloggt, deshalb über mehrere Tage. Neueste Besuche zuerst.';
        } else {
            $last = !empty($journey) ? $journey[count($journey) - 1]['session']['started_at'] : '';
            $title = 'Journey eines Besuchers';
            $subtitle = ($last !== '' ? 'Am ' . wp_date('j.n.Y', (int)strtotime($last . ' UTC')) . '. ' : '') . 'Ohne Einwilligung ist ein Besucher höchstens einen Tag lang erkennbar.';
        }

        App::page_head($title, $subtitle, false);
        echo '<p class="awp-back">' . $back . '</p>';

        if (empty($journey)) {
            echo Ui::info('Zu diesem Besucher gibt es keine Besuche (mehr).');
            return;
        }

        echo '<div class="awp-layout">';
        foreach ($journey as $entry) {
            $session = $entry['session'];
            $events = array_map(function ($event) {
                return $event + ['path' => null, 'engaged_seconds' => null, 'scroll_depth' => null];
            }, $entry['events']);
            $subtitle = Format::datetime((string)$session['started_at']) . ' · ' . Format::device((string)$session['device_type'])
                . ' · ' . Format::number($session['pageviews']) . ((int)$session['pageviews'] === 1 ? ' Seite' : ' Seiten')
                . (self::visit_duration($session) !== '–' ? ' · ' . self::visit_duration($session) : '');
            $detail = self::visit_detail($session);

            echo '<section class="awp-card awp-span-all"><header class="awp-card-head"><span class="awp-card-icon" style="color:' . esc_attr(Channels::css_var((string)$session['channel'])) . '">' . Icons::svg(Channels::icon((string)$session['channel'])) . '</span>'
                . '<div class="awp-card-heading"><h2 class="awp-card-title">' . esc_html(Format::channel((string)$session['channel']) . ($detail !== '' && $detail !== 'ohne Quelle' ? ' · ' . $detail : '')) . '</h2>'
                . '<p class="awp-card-sub">' . esc_html($subtitle) . '</p></div></header>'
                . '<div class="awp-card-body">' . self::visit_steps_html($session, $events) . '</div></section>';
        }
        echo '</div>';
    }

    // ---------------------------------------------------------------------
    // Live
    // ---------------------------------------------------------------------

    /** Feed icon per event type; conversions use their kind's icon. */
    const FEED_ICONS = [
        'pageview' => 'file',
        'outbound' => 'arrow-square-out',
        'download' => 'download-simple',
        'contact' => 'phone',
        'form_submission' => 'textbox',
        'checkout_confirmed' => 'shopping-cart',
    ];

    const FEED_LABELS = [
        'pageview' => 'Seitenaufruf',
        'outbound' => 'Link nach außen',
        'download' => 'Download',
        'contact' => 'Kontakt-Klick',
        'form_submission' => 'Formular',
        'checkout_confirmed' => 'Bestellung bestätigt',
    ];

    public static function live(): void
    {
        $live = Reports::live();
        $count = (int)$live['visitors'];

        // "Aktualisiert vor x Sek." counts up in admin.js; without JS the time.
        $updated = '<span data-awp-updated="' . esc_attr((string)time()) . '">Aktualisiert um ' . esc_html(wp_date('H:i:s')) . ' Uhr</span> · alle 30 Sekunden neu';
        echo '<div class="awp-page-head"><div><h1 class="awp-title">Live</h1><div class="awp-subline"><p class="awp-subtitle">' . $updated . '</p></div></div></div>';

        echo '<div class="awp-layout" data-awp-refresh="30">';

        Ui::card_open('lightning', 'Gerade auf der Website', 'In den letzten fünf Minuten aktiv', '', 'awp-span-all');
        echo '<div class="awp-card-body awp-live-top">';
        echo '<div class="awp-live-now"><div class="awp-live-big' . ($count > 0 ? ' is-active' : '') . '"><span class="awp-live-dot" aria-hidden="true"></span>'
            . '<span class="awp-live-number">' . esc_html(Format::number($count)) . '</span><span>' . ($count === 1 ? 'Besucher' : 'Besucher') . ' gerade online</span></div>'
            . '<p class="awp-card-sub">Gestern um diese Zeit: ' . esc_html(Format::number($live['yesterday'])) . ' · heute bisher ' . esc_html(Format::number($live['sessions_today'])) . ' Besuche</p></div>';
        echo self::minute_bars($live['per_minute']);
        echo '</div>';

        if (!empty($live['visits'])) {
            echo '<div class="awp-card-body is-flush awp-scroll-x"><table class="awp-table awp-live-visits"><thead><tr><th scope="col">Seite</th><th scope="col">Kanal</th><th scope="col">Gerät</th><th scope="col">Seiten</th><th scope="col">Seit</th></tr></thead><tbody>';
            foreach ($live['visits'] as $visit) {
                $device = (string)$visit['device'];
                echo '<tr><td><span class="awp-cell-text">' . esc_html($visit['path'] ?? '–') . '</span>'
                    . ($visit['conversions'] > 0 ? ' <span class="awp-tag is-conversion">Conversion</span>' : '') . '</td>'
                    . '<td><span class="awp-live-channel">' . Channels::dot($visit['channel']) . esc_html(Format::channel($visit['channel'])) . '</span></td>'
                    . '<td><span class="awp-device" title="' . esc_attr(Format::device($device)) . '">' . Icons::svg(self::DEVICE_ICONS[$device] ?? 'desktop') . '<span class="awp-sr">' . esc_html(Format::device($device)) . '</span></span></td>'
                    . '<td>' . esc_html(Format::number($visit['pageviews'])) . '</td>'
                    . '<td>' . esc_html(self::since($visit['started_at'])) . '</td></tr>';
            }
            echo '</tbody></table></div>';
        }
        Ui::card_close();

        Ui::card_open('list', 'Was gerade passiert', 'Die letzten 30 Minuten, neueste oben', '', 'awp-span-all');
        if (empty($live['events'])) {
            echo '<div class="awp-card-body">' . Ui::empty_state('In der letzten halben Stunde ist nichts passiert.') . '</div>';
        } else {
            echo '<ul class="awp-feed">';
            foreach ($live['events'] as $row) {
                $type = (string)$row['event_type'];
                $conversion = (string)($row['conversion_type'] ?? '');
                if ($conversion !== '') {
                    $kind = Format::conversion_kind($conversion);
                    $icon = Format::CONVERSION_KINDS[$kind][1];
                    $what = Format::conversion_type($conversion);
                } elseif ($type === 'pageview' && !empty($row['search'])) {
                    $icon = 'magnifying-glass';
                    $what = 'Suche „' . mb_substr((string)$row['search'], 0, 60) . '“';
                } else {
                    $icon = self::FEED_ICONS[$type] ?? 'cursor-click';
                    $what = self::FEED_LABELS[$type] ?? $type;
                }
                $value = $conversion !== '' && $row['revenue'] !== null && (float)$row['revenue'] > 0 ? ' · ' . Format::money((float)$row['revenue'], (string)$row['currency']) : '';
                echo '<li' . ($conversion !== '' ? ' class="is-conversion"' : '') . '><span class="awp-feed-time">' . esc_html(Format::ago((string)$row['timestamp'])) . '</span>'
                    . '<span class="awp-feed-what"><span class="awp-feed-icon">' . Icons::svg($icon) . '</span><span><strong>' . esc_html($what) . '</strong> ' . esc_html((string)($row['path'] ?? '') . $value) . '</span></span>'
                    . '<span class="awp-live-channel">' . Channels::dot($row['channel']) . esc_html(Format::channel($row['channel'])) . '</span></li>';
            }
            echo '</ul>';
        }
        Ui::card_close();

        echo '</div>';
    }

    /**
     * "Besucher pro Minute, letzte 30 Min." as small bars.
     *
     * @param list<int> $per_minute oldest first
     */
    private static function minute_bars(array $per_minute): string
    {
        $max = max(1, max($per_minute));
        $html = '<figure class="awp-minutes"><figcaption>Besucher pro Minute, letzte 30 Min.</figcaption><div class="awp-minute-bars" role="img" aria-label="'
            . esc_attr('Besucher pro Minute in den letzten 30 Minuten, zuletzt ' . end($per_minute)) . '">';
        $last = count($per_minute) - 1;
        foreach ($per_minute as $i => $value) {
            $ago = $last - $i;
            $title = ($ago === 0 ? 'Diese Minute' : 'Vor ' . $ago . ' Min.') . ': ' . $value . ' Besucher';
            $html .= '<span title="' . esc_attr($title) . '"' . ($value > 0 ? '' : ' class="is-zero"') . '><i style="height:' . ($value > 0 ? max(8, round($value / $max * 100)) : 4) . '%"></i></span>';
        }

        return $html . '</div><div class="awp-minute-axis"><span>vor 30 Min.</span><span>jetzt</span></div></figure>';
    }

    /**
     * "3 Min." since a UTC time.
     */
    private static function since(string $utc): string
    {
        $time = strtotime($utc . ' UTC');
        $minutes = $time ? max(0, intdiv(time() - $time, 60)) : 0;
        if ($minutes < 1) {
            return 'gerade';
        }

        return $minutes < 60 ? $minutes . ' Min.' : intdiv($minutes, 60) . ' Std. ' . ($minutes % 60) . ' Min.';
    }

    // ---------------------------------------------------------------------
    // Integrationen
    // ---------------------------------------------------------------------

    public static function integrations(): void
    {
        App::page_head('Integrationen', 'Welche Plugins Käufe, Formulare und Klicks an die Auswertung melden', false);

        if (isset($_GET['updated'])) {
            echo '<div class="notice notice-success"><p>Gespeichert.</p></div>';
        }

        $installed = [];
        $others = [];
        foreach (Integrations::get_integrations() as $integration) {
            $slug = (string)$integration['slug'];
            $meta = Format::INTEGRATIONS[$slug] ?? ['builder', [], [], []];
            $row = $integration + ['group' => $meta[0], 'reports' => $meta[1], 'types' => $meta[2], 'events' => $meta[3]];
            if ($integration['isAvailable']) {
                $row['activity'] = Reports::integration_activity($meta[2], $meta[3]);
                $installed[] = $row;
            } else {
                $others[] = $row;
            }
        }
        $order = array_flip(array_keys(Format::INTEGRATION_GROUPS));
        usort($installed, function ($a, $b) use ($order) {
            return [$order[$a['group']] ?? 9, $a['name']] <=> [$order[$b['group']] ?? 9, $b['name']];
        });

        // Status: which installed plugins report, and the last report.
        $reporting = array_values(array_filter($installed, function ($row) {
            return $row['isEnabled'];
        }));
        $latest = null;
        foreach ($reporting as $row) {
            if ($row['activity']['last'] !== null && ($latest === null || $row['activity']['last'] > $latest[1])) {
                $latest = [$row, $row['activity']['last']];
            }
        }
        echo '<div class="awp-layout">';
        if (!empty($reporting)) {
            $text = implode(', ', array_column($reporting, 'name')) . '.';
            if ($latest !== null) {
                $what = self::activity_label($latest[0]['activity']['recent'][0] ?? []);
                $text .= ' Zuletzt ' . ($what !== '' ? $what . ', ' : '') . self::lower_day(Format::datetime($latest[1])) . '.';
            }
            echo '<div class="awp-span-all awp-status is-good">' . Icons::svg('check-circle') . '<div><p class="awp-glance-title">'
                . esc_html(count($reporting) . (count($reporting) === 1 ? ' Plugin meldet an die Auswertung.' : ' Plugins melden an die Auswertung.'))
                . '</p><p class="awp-glance-text">' . esc_html($text) . '</p></div></div>';
        } else {
            echo '<div class="awp-span-all awp-status is-warn">' . Icons::svg('warning') . '<div><p class="awp-glance-title">Kein Plugin meldet gerade.</p>'
                . '<p class="awp-glance-text">' . esc_html(empty($installed) ? 'Auf deiner Website ist keines der unterstützten Plugins installiert. Seitenaufrufe, Klicks und Kontakt-Klicks misst die Auswertung trotzdem.' : 'Käufe und Formulare tauchen erst wieder auf, wenn du eine Integration einschaltest.') . '</p></div></div>';
        }

        if (!empty($installed)) {
            Ui::card_open('plugs-connected', 'Auf deiner Website', 'Installiert und aktiv. Speichert automatisch.', '', 'awp-span-all');
            foreach ($installed as $row) {
                self::integration_row($row);
            }
            Ui::card_close();
        }

        if (!empty($others)) {
            echo '<details class="awp-card awp-span-all awp-more-plugins"><summary class="awp-card-head"><span class="awp-card-icon">' . Icons::svg('plugs-connected') . '</span>'
                . '<div class="awp-card-heading"><h2 class="awp-card-title">Weitere unterstützte Plugins <span class="awp-row-meta">· ' . count($others) . '</span></h2>'
                . '<p class="awp-card-sub">Nicht installiert. Sobald du eines installierst, meldet es automatisch.</p></div>' . Icons::svg('caret-down', 'awp-icon awp-details-caret') . '</summary>'
                . '<div class="awp-card-body">';
            foreach (Format::INTEGRATION_GROUPS as $group => [$label, , $icon]) {
                $items = array_values(array_filter($others, function ($row) use ($group) {
                    return $row['group'] === $group;
                }));
                if (empty($items)) {
                    continue;
                }
                echo '<div class="awp-plugin-group"><span class="awp-group-title">' . Icons::svg($icon) . esc_html($label) . '</span><div class="awp-plugin-grid">';
                foreach ($items as $row) {
                    echo '<div class="awp-plugin"><strong>' . esc_html((string)$row['name']) . '</strong><span>' . esc_html(Format::integration_description((string)$row['slug'], (string)$row['description'])) . '</span></div>';
                }
                echo '</div></div>';
            }
            echo '</div></details>';
        }

        echo '<div class="awp-span-all">' . Ui::info('Dein Plugin fehlt? Jeder Button und jeder Link kann ein eigenes Ereignis melden: Gib ihm das Attribut data-awp-event mit einem Namen, zum Beispiel data-awp-event="angebot-angefragt". Die Ereignisse stehen unter Engagement › Eigene Events.', 'code') . '</div>';
        echo '</div>';
    }

    /**
     * "Heute, 12:09" inside a sentence: "heute, 12:09".
     */
    private static function lower_day(string $datetime): string
    {
        return preg_match('/^(Heute|Gestern)\b/', $datetime) ? lcfirst($datetime) : $datetime;
    }

    /**
     * "WooCommerce-Bestellung Nr. 219", "SureForms: Kontakt".
     *
     * @param array<string, mixed> $event
     */
    private static function activity_label(array $event): string
    {
        if (empty($event)) {
            return '';
        }
        $props = json_decode((string)($event['event_properties_json'] ?? ''), true);
        $props = is_array($props) ? $props : [];
        if (!empty($event['conversion_type'])) {
            $label = Format::conversion_type((string)$event['conversion_type']);
            if (!empty($props['form_name'])) {
                return $label . ': ' . $props['form_name'];
            }
            if (!empty($props['order_number'])) {
                return $label . ' Nr. ' . $props['order_number'];
            }
            return $label . (!empty($event['conversion_id']) && Format::conversion_kind((string)$event['conversion_type']) === 'purchase' ? ' Nr. ' . $event['conversion_id'] : '');
        }

        return (string)$event['event_type'];
    }

    /**
     * One installed integration: what it reports, when last, a switch, and
     * its latest reports to unfold.
     *
     * @param array<string, mixed> $row
     */
    private static function integration_row(array $row): void
    {
        $enabled = (bool)$row['isEnabled'];
        [, $kind, $icon] = Format::INTEGRATION_GROUPS[$row['group']] ?? Format::INTEGRATION_GROUPS['builder'];
        $activity = $row['activity'];
        $noun = $row['group'] === 'shop' ? ['Bestellung', 'Bestellungen'] : ($row['group'] === 'form' ? ['Absendung', 'Absendungen'] : ['Meldung', 'Meldungen']);

        if (!$enabled) {
            $last = '<span class="awp-warnline">' . esc_html('Ausgeschaltet: meldet nichts mehr. Bisherige Zahlen bleiben.') . '</span>';
        } elseif ($activity['last'] !== null) {
            $last = '<span class="awp-row-meta">' . esc_html('Zuletzt ' . self::lower_day(Format::datetime($activity['last'])) . ' · ' . Format::number($activity['count']) . ' ' . ($activity['count'] === 1 ? $noun[0] : $noun[1]) . ' in 30 Tagen') . '</span>';
        } elseif (empty($row['types']) && empty($row['events'])) {
            $last = '<span class="awp-row-meta">Meldet Klicks als eigene Ereignisse (Engagement).</span>';
        } else {
            $last = '<span class="awp-row-meta">In den letzten 30 Tagen nichts gemeldet.</span>';
        }

        echo '<div class="awp-integration"><div class="awp-integration-main"><span class="awp-tile awp-tile--large">' . Icons::svg($icon) . '</span>'
            . '<div class="awp-integration-text"><div class="awp-integration-name"><strong>' . esc_html((string)$row['name']) . '</strong><span class="awp-row-meta">' . esc_html($kind) . '</span></div>'
            . '<span class="awp-field-desc">' . esc_html(Format::integration_description((string)$row['slug'], (string)$row['description'])) . '</span>';
        if (!empty($row['reports'])) {
            echo '<div class="awp-tags">';
            foreach ($row['reports'] as $report) {
                echo '<span>' . esc_html($report) . '</span>';
            }
            echo '</div>';
        }
        echo $last;
        if ($enabled && !empty($activity['recent'])) {
            echo '<details class="awp-integration-recent"><summary>Letzte Meldungen' . Icons::svg('caret-down') . '</summary><div class="awp-recent-list">';
            foreach ($activity['recent'] as $event) {
                $channel = (string)($event['channel'] ?? '');
                $origin = implode(' · ', array_filter([$channel !== '' ? Format::channel($channel) : '', (string)($event['source'] ?? ''), (string)($event['campaign'] ?? '')]));
                $value = $event['revenue'] !== null && (float)$event['revenue'] > 0 ? Format::money((float)$event['revenue'], (string)($event['currency'] ?: 'EUR')) : '–';
                echo '<div class="awp-recent-row"><span>' . esc_html(self::activity_label($event)) . '</span>'
                    . '<span class="awp-feed-origin">' . ($channel !== '' ? Channels::dot($channel) : '') . '<span>' . esc_html($origin !== '' ? $origin : '–') . '</span></span>'
                    . '<span class="awp-num">' . esc_html($value) . '</span><span class="awp-num is-muted">' . esc_html(Format::datetime((string)$event['timestamp'])) . '</span></div>';
            }
            echo '</div></details>';
        }
        echo '</div></div>';

        if (current_user_can('manage_options')) {
            $id = 'awp-int-' . sanitize_html_class((string)$row['slug']);
            echo '<form class="awp-integration-switch" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-awp-form-autosave>';
            wp_nonce_field('analyticswp_integration');
            echo '<input type="hidden" name="action" value="analyticswp_integration"><input type="hidden" name="slug" value="' . esc_attr((string)$row['slug']) . '"><input type="hidden" name="enabled" value="0">'
                . '<input type="checkbox" class="awp-switch" role="switch" id="' . esc_attr($id) . '" name="enabled" value="1"' . checked($enabled, true, false) . ' aria-label="' . esc_attr($row['name'] . ' melden') . '">'
                . '<noscript><button type="submit" class="button">Speichern</button></noscript></form>';
        }
        echo '</div>';

    }

    public static function handle_integration_toggle(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Keine Berechtigung.', 403);
        }
        check_admin_referer('analyticswp_integration');

        $slug = isset($_POST['slug']) ? sanitize_key(wp_unslash($_POST['slug'])) : '';
        $enabled = isset($_POST['enabled']) && $_POST['enabled'] === '1';

        $known = array_column(Integrations::get_integrations(), 'slug');
        if (in_array($slug, $known, true)) {
            Integrations::update_integration_is_enabled($slug, $enabled);
            Reports::flush_cache();
        }

        wp_safe_redirect(add_query_arg(['page' => App::SLUG, 'tab' => 'integrations', 'updated' => 1], admin_url('admin.php')));
        exit;
    }

    // ---------------------------------------------------------------------
    // Einstellungen
    // ---------------------------------------------------------------------

    /** WordPress' own roles; every other role counts as "Shop und Plugins". */
    const CORE_ROLES = ['administrator', 'editor', 'author', 'contributor', 'subscriber'];

    public static function settings(): void
    {
        if (!current_user_can('manage_options')) {
            echo Ui::info('Nur Administratoren können die Einstellungen ändern.');
            return;
        }

        App::page_head('Einstellungen', 'Änderungen werden sofort gespeichert.', false);
        if (isset($_GET['settings-updated'])) {
            echo '<div class="notice notice-success"><p>Gespeichert.</p></div>';
        }
        if (\AnalyticsWP\Lib\RequestGuard::shared_address()) {
            echo '<div class="awp-span-all" style="margin-bottom:20px">' . Ui::info('Der Server sieht alle Besucher unter derselben internen Adresse. Davor steht ein Proxy, der die Besucher-IP nicht weitergibt: Alle teilen sich dann ein Limit, und ähnliche Besucher fallen zusammen. Bitte den Hoster, die echte IP weiterzugeben, oder setze den Filter analyticswp_client_ip.', 'warning') . '</div>';
        }

        $roles = wp_roles()->get_names();
        $excluded = Validators::array_of_string_keys_and_values(SuperSimpleWP::get_setting('analyticswp', 'disabled-tracking-user-roles'));
        $access = Validators::array_of_string_keys_and_values(SuperSimpleWP::get_setting('analyticswp', 'admin-access-user-roles'));

        // Without JS the whole form saves through options.php, as before.
        echo '<form method="post" action="' . esc_url(admin_url('options.php')) . '" class="awp-settings-form"><div class="awp-layout">';
        settings_fields('analyticswp');

        // Was gemessen wird.
        Ui::card_open('eye', 'Was gemessen wird', 'Ohne Cookies, für alle Besucher', '', 'awp-span-all');
        echo Ui::toggle('engagement_tracking', (bool)SuperSimpleWP::get_setting('analyticswp', 'engagement_tracking'), 'Engagement messen', ['description' => 'Aktive Zeit und Scrolltiefe je Seite, Links nach außen, Downloads, Klicks auf Telefon, E-Mail und WhatsApp.']);
        echo '<div class="awp-field"><span class="awp-switch-label">Diese Besucher nicht zählen</span><p class="awp-field-desc">Eingeloggte Nutzer mit diesen Rollen zählen nicht, ihre Bestellungen und Formulare auch nicht.</p>';
        if (!isset($excluded['administrator'])) {
            echo '<div class="awp-tipline">' . Icons::svg('info') . '<span>Tipp: Schließ dich selbst aus, sonst zählen deine eigenen Besuche und Testbestellungen mit.</span>'
                . '<button type="button" class="button" data-awp-check="#awp-role-exclude-administrator">Administrator ausschließen</button></div>';
        }
        echo self::role_chips('exclude_role', 'analyticswp_disabled-tracking-user-roles', $roles, $excluded, 'awp-role-exclude-');
        echo '</div>';
        Ui::card_close('Im Browser wird nichts gespeichert, keine IP-Adresse und keine E-Mail-Adresse. Besucher werden über einen täglich wechselnden Hash höchstens einen Tag lang wiedererkannt.');

        // Was als Conversion zählt.
        $contact = (bool)SuperSimpleWP::get_setting('analyticswp', 'contact_clicks_as_conversion');
        Ui::card_open('target', 'Was als Conversion zählt', 'Käufe zählen immer, mit ihrem Umsatz', '', 'awp-span-all');
        echo Ui::toggle('contact_clicks_as_conversion', $contact, 'Kontakt-Klicks als Conversion zählen', ['description' => 'Ein Klick auf Telefonnummer, E-Mail-Adresse oder WhatsApp zählt wie eine Anfrage, höchstens einmal je Besucher, Tag und Art.']);
        self::value_fields();
        Ui::card_close('Welchem Besuch eine Conversion zählt, stellst du direkt unter ' . Ui::link(App::url(['tab' => 'conversions'] + array_fill_keys(App::VIEW_PARAMS, null)), 'Conversions') . ' um.');

        // Mit Einwilligung über mehrere Tage.
        $multi_day = (bool)SuperSimpleWP::get_setting('analyticswp', 'multi_day_with_consent');
        $mhc = \AnalyticsWP\Lib\Consent::mhc_active();
        Ui::card_open('lock-simple', 'Mit Einwilligung über mehrere Tage', 'Nur für Besucher, die zustimmen', '', 'awp-span-all');
        echo '<div class="awp-field"><p class="awp-field-desc" style="margin:0">Stimmt ein Besucher im Cookie-Banner der Statistik zu, kann ein Kauf nach einer Woche noch der Anzeige zugeordnet werden, über die er kam.</p></div>';
        if ($mhc) {
            echo Ui::toggle('multi_day_with_consent', $multi_day, 'Besucher mit Einwilligung wiedererkennen', ['description' => 'Wer in Must-Have Cookie der Kategorie „Statistik“ zustimmt (oder „Alle akzeptieren“), bekommt ein Cookie mit einer Zufalls-ID (awp_vid, 13 Monate). Widerruft er, wird es gelöscht.']);
            $share = Reports::consent_share(Reports::period('30d'));
            Ui::card_close('Trage das Cookie awp_vid in Must-Have Cookie unter „Statistik“ ein. In den letzten 30 Tagen liefen ' . esc_html(Format::percent($share, 0)) . ' der Besuche mit Einwilligung.');
        } else {
            echo '<div class="awp-card-body">' . self::info_html('Dafür braucht es das Plugin Must-Have Cookie. Ohne bleibt die Messung immer cookielos, und das ist für die meisten Websites genau richtig. ' . Ui::link(admin_url('plugin-install.php?s=Must-Have+Cookie&tab=search&type=term'), 'Must-Have Cookie ansehen'), 'lock-simple') . '</div>';
            echo '<input type="hidden" name="analyticswp_multi_day_with_consent" value="' . ($multi_day ? '1' : '') . '">';
            Ui::card_close();
        }

        // Eingeloggte Besucher.
        Ui::card_open('user-circle-dashed', 'Eingeloggte Besucher', 'Zum Beispiel Kunden mit Konto', '', 'awp-span-all');
        echo Ui::toggle('link_logged_in_users', (bool)SuperSimpleWP::get_setting('analyticswp', 'link_logged_in_users'), 'Besuche dem Konto zuordnen', [
            'description' => 'Die Journeys zeigen dann Kunden mit Namen und über mehrere Tage. Aus, zählen auch eingeloggte Besucher cookielos.',
            'warning' => 'Das sind personenbezogene Daten. Nimm sie in deine Datenschutzerklärung auf (der Text unten passt sich an). Löschanfragen erledigst du unter Werkzeuge › Personenbezogene Daten löschen.',
        ]);
        Ui::card_close();

        // Aufbewahrung.
        $months = \AnalyticsWP\Lib\Retention::months();
        Ui::card_open('hourglass-simple-medium', 'Aufbewahrung', 'Wie lange Besuche gespeichert bleiben', '', 'awp-span-all');
        echo '<div class="awp-field awp-switch-field"><div class="awp-switch-text"><span class="awp-switch-label">Besuche und Events löschen nach</span>'
            . '<p class="awp-field-desc">Einmal am Tag. Bestellungen und Formulare selbst bleiben, nur ihre gemessene Herkunft geht mit.</p></div>'
            . '<div class="awp-seg awp-seg--radio" role="radiogroup" aria-label="Aufbewahrung">';
        foreach (\AnalyticsWP\Lib\Retention::CHOICES as $value => $label) {
            $id = 'awp-keep-' . $value;
            echo '<input type="radio" id="' . esc_attr($id) . '" name="analyticswp_retention_months" value="' . esc_attr((string)$value) . '"' . checked($months, $value, false) . ' data-awp-autosave="retention_months">'
                . '<label for="' . esc_attr($id) . '">' . esc_html($value === 0 ? 'Nie' : str_replace(' Monate', ' Mon.', $label)) . '</label>';
        }
        echo '</div></div>';
        echo Ui::toggle('delete_data_on_uninstall', (bool)SuperSimpleWP::get_setting('analyticswp', 'delete_data_on_uninstall'), 'Beim Löschen des Plugins alle Daten entfernen', [
            'description' => 'Aus, bleiben die Daten für eine spätere Neuinstallation erhalten. Deaktivieren allein löscht nie etwas.',
            'warning' => 'Beim Löschen des Plugins sind alle Besuche und Einstellungen endgültig weg. Ein Backup gibt es nicht.',
        ]);
        Ui::card_close();

        // Datenschutzerklärung.
        Ui::card_open('book-open', 'Text für die Datenschutzerklärung', 'Passt sich deinen Einstellungen an. Ein Vorschlag, keine Rechtsberatung.', '<button type="button" class="button" data-awp-copy="#awp-policy-text">' . Icons::svg('copy') . ' Text kopieren</button>', 'awp-span-all');
        echo '<div class="awp-card-body"><div class="awp-policy-preview" id="awp-policy" aria-live="polite">' . self::policy_preview() . '</div>'
            . '<textarea id="awp-policy-text" class="awp-sr" readonly tabindex="-1" aria-hidden="true">' . esc_textarea(\AnalyticsWP\Lib\Privacy::policy_text()) . '</textarea></div>';
        Ui::card_close('Steht auch unter Einstellungen › Datenschutz in der Anleitung für die Datenschutzerklärung.');

        // Leistung: the must-use plugin for the tracking request.
        $fast = \AnalyticsWP\Lib\FastEndpoint::status();
        $fast_texts = [
            'active' => ['', 'Aktiv. Jeder Seitenaufruf kostet den Server nur noch einen Bruchteil.'],
            'off' => ['', 'Aus. Jede Messanfrage lädt alle Plugins der Website.'],
            'outdated' => ['', 'Wird beim nächsten Aufruf einer Admin-Seite eingerichtet.'],
            'blocked' => ['warn', 'Auf diesem Server darf WordPress keine Dateien in wp-content/mu-plugins anlegen. Die Messung läuft trotzdem, nur ohne Schnellweg.'],
            'foreign' => ['warn', 'In wp-content/mu-plugins liegt schon eine Datei analyticswp-fast-endpoint.php, die nicht von Analytics stammt. Sie bleibt unangetastet.'],
        ];
        [$fast_tone, $fast_text] = $fast_texts[$fast] ?? $fast_texts['off'];
        Ui::card_open('lightning', 'Leistung', 'Wie viel Server jeder Seitenaufruf kostet', '', 'awp-span-all');
        $description = 'Für die Messanfrage, die jeder Seitenaufruf schickt, lädt WordPress nur Analytics (und Must-Have Cookie) statt aller Plugins. Dafür legt Analytics eine kleine Datei in wp-content/mu-plugins an und entfernt sie beim Ausschalten oder Deaktivieren wieder.';
        echo Ui::toggle('fast_endpoint', \AnalyticsWP\Lib\FastEndpoint::enabled(), 'Schneller Messpunkt', $fast_tone === 'warn'
            ? ['description' => $description, 'warning' => $fast_text]
            : ['description' => $description . ' ' . $fast_text]);
        Ui::card_close('Code, der die Messung über Filter anpasst, muss dann in einem MU-Plugin oder in wp-config.php stehen. Weitere Plugins lassen sich mit ANALYTICSWP_FAST_ENDPOINT_KEEP freigeben.');

        // Zugriff.
        Ui::card_open('user-circle-dashed', 'Zugriff', 'Wer die Auswertung sehen darf', '', 'awp-span-all');
        echo '<div class="awp-field"><p class="awp-field-desc">Administratoren immer. Die Einstellungen bleiben Administratoren vorbehalten.</p>';
        $access_roles = $roles;
        unset($access_roles['subscriber']);
        echo self::role_chips('access_role', 'analyticswp_admin-access-user-roles', $access_roles, $access + ['administrator' => '1'], 'awp-role-access-', ['administrator']);
        echo '</div>';
        Ui::card_close();

        // Shop.
        if (class_exists('WooCommerce')) {
            $positions = \AnalyticsWP\Lib\Integrations\WooCommerceIntegration::get_wc_field_positions();
            $how = (string)SuperSimpleWP::get_setting('analyticswp', 'how_did_you_hear');
            Ui::card_open('shopping-cart', 'Shop', 'WooCommerce', '', 'awp-span-all');
            echo '<div class="awp-field awp-switch-field"><div class="awp-switch-text"><label class="awp-switch-label" for="awp-how">Frage „Wie hast du von uns erfahren?“ an der Kasse</label><p class="awp-field-desc">Die Antwort steht an der Bestellung, neben der gemessenen Herkunft.</p></div>';
            echo '<select id="awp-how" name="analyticswp_how_did_you_hear" data-awp-autosave="how_did_you_hear"><option value="disable"' . selected($how, 'disable', false) . '>Nicht fragen</option>';
            foreach ($positions as $key => $label) {
                echo '<option value="' . esc_attr($key) . '"' . selected($how, $key, false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select></div>';
            echo Ui::toggle('enable_woocommerce_order_notification_source_section', (bool)SuperSimpleWP::get_setting('analyticswp', 'enable_woocommerce_order_notification_source_section'), 'Herkunft in der E-Mail „Neue Bestellung“ zeigen');
            Ui::card_close();
        }

        echo '<noscript><div class="awp-span-all"><button type="submit" class="button button-primary button-large">Einstellungen speichern</button></div></noscript>';
        echo '</div></form>';
    }

    /**
     * Roles as chips: a checkbox per role (posts with the form), saved on
     * change. Grouped into WordPress' roles and the rest.
     *
     * @param array<string, string> $roles
     * @param array<string, string> $active
     * @param list<string> $locked Always on, not changeable.
     */
    private static function role_chips(string $setting, string $name, array $roles, array $active, string $id_prefix, array $locked = []): string
    {
        $groups = ['WordPress' => [], 'Shop und Plugins' => []];
        foreach ($roles as $role => $label) {
            $groups[in_array($role, self::CORE_ROLES, true) ? 'WordPress' : 'Shop und Plugins'][$role] = $label;
        }

        $html = '';
        foreach ($groups as $group => $items) {
            if (empty($items)) {
                continue;
            }
            $html .= '<div class="awp-role-group"><span class="awp-insight-label">' . esc_html($group) . '</span><div class="awp-role-chips">';
            foreach ($items as $role => $label) {
                $id = $id_prefix . sanitize_html_class((string)$role);
                $is_locked = in_array($role, $locked, true);
                $html .= '<input type="checkbox" class="awp-chip-check" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '[' . esc_attr((string)$role) . ']" value="1"'
                    . checked(isset($active[$role]) || $is_locked, true, false) . ($is_locked ? ' disabled' : '')
                    . ' data-awp-autosave="' . esc_attr($setting) . '" data-awp-autosave-key="' . esc_attr((string)$role) . '">'
                    . '<label class="awp-chip-toggle" for="' . esc_attr($id) . '">' . Icons::svg('check') . esc_html(translate_user_role($label)) . '</label>';
                if ($is_locked) {
                    $html .= '<input type="hidden" name="' . esc_attr($name) . '[' . esc_attr((string)$role) . ']" value="1">';
                }
            }
            $html .= '</div></div>';
        }

        return $html;
    }

    /**
     * "Was ist eine Anfrage wert?": per form, per contact click, optionally
     * per form, with what that would add up to.
     */
    private static function value_fields(): void
    {
        $period = Reports::period('30d');
        $types = Reports::conversion_types($period, [], Reports::main_currency($period));
        $forms = 0;
        $clicks = 0;
        $form_rows = [];
        foreach ($types as $row) {
            $kind = Format::conversion_kind($row['type']);
            if ($kind === 'form') {
                $forms += (int)$row['conversions'];
                $form_rows[] = $row;
            } elseif ($kind === 'contact') {
                $clicks += (int)$row['conversions'];
            }
        }
        $per_form = (string)SuperSimpleWP::get_setting('analyticswp', 'value_per_form');
        $per_contact = (string)SuperSimpleWP::get_setting('analyticswp', 'value_per_contact');
        $own = \AnalyticsWP\Lib\ConversionValue::form_values();

        $input = function (string $name, string $setting, string $value, string $placeholder, string $key = '') {
            return '<span class="awp-amount"><input type="text" inputmode="decimal" name="' . esc_attr($name) . '" value="' . esc_attr(str_replace('.', ',', $value)) . '" placeholder="' . esc_attr($placeholder) . '"'
                . ' data-awp-autosave="' . esc_attr($setting) . '"' . ($key !== '' ? ' data-awp-autosave-key="' . esc_attr($key) . '"' : '') . '><span>€</span></span>';
        };

        echo '<div class="awp-field" data-awp-value-hint data-forms="' . $forms . '" data-clicks="' . $clicks . '"><span class="awp-switch-label">Was ist eine Anfrage wert?</span>'
            . '<p class="awp-field-desc">Dann sehen auch Formulare und Kontakt-Klicks einen Wert, und Kanäle lassen sich ohne Shop vergleichen. Leer lassen, wenn du das nicht brauchst.</p>'
            . '<div class="awp-amounts"><label><span class="awp-utm-label">Je Formular-Anfrage</span>' . $input('analyticswp_value_per_form', 'value_per_form', $per_form, '0') . '</label>'
            . '<label><span class="awp-utm-label">Je Kontakt-Klick</span>' . $input('analyticswp_value_per_contact', 'value_per_contact', $per_contact, '0') . '</label></div>'
            . '<p class="awp-field-desc awp-value-hint">' . esc_html(self::value_hint($forms, $clicks, (float)$per_form, (float)$per_contact)) . '</p>';

        if (!empty($form_rows)) {
            echo '<details class="awp-utm-more"><summary>Je Formular unterschiedlich · optional</summary><div class="awp-form-values">';
            foreach ($form_rows as $row) {
                $key = \AnalyticsWP\Lib\ConversionValue::form_key($row['type'], $row['name']);
                $label = Format::conversion_type($row['type']) . ($row['name'] !== null ? ': ' . $row['name'] : '');
                echo '<label><span>' . esc_html($label) . '</span>' . $input('analyticswp_form_values[' . $key . ']', 'form_value', $own[$key] ?? '', $per_form !== '' ? str_replace('.', ',', $per_form) : '0', $key) . '</label>';
            }
            echo '</div></details>';
        }
        echo '</div>';
    }

    private static function value_hint(int $forms, int $clicks, float $per_form, float $per_contact): string
    {
        if ($forms === 0 && $clicks === 0) {
            return 'In den letzten 30 Tagen gab es noch keine Anfragen. Der Wert wird getrennt vom Umsatz gezeigt.';
        }

        $parts = [];
        if ($forms > 0) {
            $parts[] = Format::number($forms) . ($forms === 1 ? ' Anfrage' : ' Anfragen');
        }
        if ($clicks > 0) {
            $parts[] = Format::number($clicks) . ($clicks === 1 ? ' Kontakt-Klick' : ' Kontakt-Klicks');
        }
        $total = $forms * $per_form + $clicks * $per_contact;

        return 'Bei ' . implode(' und ', $parts) . ' in den letzten 30 Tagen wären das zusätzlich ' . Format::money($total, 'EUR', 0) . ' Wert. Er wird getrennt vom Umsatz gezeigt.';
    }

    /**
     * The privacy text as paragraphs; the first is the heading.
     */
    private static function policy_preview(): string
    {
        $paragraphs = \AnalyticsWP\Lib\Privacy::policy_paragraphs();
        $html = '<p class="awp-policy-title">' . esc_html((string)array_shift($paragraphs)) . '</p>';
        foreach ($paragraphs as $paragraph) {
            $html .= '<p>' . esc_html($paragraph) . '</p>';
        }

        return $html;
    }

    /**
     * Ui::info() with HTML (a link) in the text, escaped by the caller.
     */
    private static function info_html(string $html, string $icon = 'info'): string
    {
        return '<div class="awp-info">' . Icons::svg($icon) . '<div>' . $html . '</div></div>';
    }
}
