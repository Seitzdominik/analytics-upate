<?php

namespace AnalyticsWP\Lib\Admin;

use AnalyticsWP\Lib\Insights;
use AnalyticsWP\Lib\Reports;

/**
 * Building blocks of the admin screens, after Pixel Made Simple's
 * PXMS_Admin_UI: cards with head and foot, key figure tiles, tables whose
 * rows filter the page, hints, switches, term tooltips. All output is
 * escaped here.
 */
class Ui
{
    /** Explanations of technical terms, for Ui::term(). One wording everywhere. */
    const TERMS = [
        'visitors' => 'Verschiedene Menschen im Zeitraum. Ohne Einwilligung wird ein Besucher höchstens einen Tag lang wiedererkannt.',
        'sessions' => 'Ein Besuch endet nach 30 Minuten ohne neuen Seitenaufruf.',
        'bounce' => 'Besuche mit nur einer Seite, ohne Abschluss und unter 10 Sekunden aktiv.',
        'conversion_rate' => 'Anteil der Besuche mit mindestens einem Abschluss.',
        'conversions' => 'Abschlüsse: Käufe, Formular-Anfragen und, wenn eingestellt, Klicks auf Telefon, E-Mail oder WhatsApp.',
        'duration' => 'Zeit vom ersten bis zum letzten Seitenaufruf eines Besuchs.',
        'engaged' => 'Zeit, in der die Seite sichtbar war und benutzt wurde, je Seitenaufruf. Nicht dasselbe wie die Besuchsdauer.',
        'pageviews' => 'Jedes Laden einer Seite, auch mehrmals im selben Besuch.',
    ];

    /**
     * Open a card. $actions is HTML for the right of the head (already
     * escaped by the caller), as is $subtitle with $subtitle_is_html.
     */
    public static function card_open(string $icon, string $title, string $subtitle = '', string $actions = '', string $class = '', bool $subtitle_is_html = false): void
    {
        echo '<section class="awp-card ' . esc_attr($class) . '">';
        echo '<header class="awp-card-head">';
        if ($icon !== '') {
            echo '<span class="awp-card-icon">' . Icons::svg($icon) . '</span>';
        }
        echo '<div class="awp-card-heading"><h2 class="awp-card-title">' . esc_html($title) . '</h2>';
        if ($subtitle !== '') {
            echo '<p class="awp-card-sub">' . ($subtitle_is_html ? $subtitle : esc_html($subtitle)) . '</p>';
        }
        echo '</div>';
        if ($actions !== '') {
            echo '<div class="awp-card-actions">' . $actions . '</div>';
        }
        echo '</header>';
    }

    /**
     * Close a card, with an optional foot (HTML, escaped by the caller).
     */
    public static function card_close(string $foot = ''): void
    {
        if ($foot !== '') {
            echo '<footer class="awp-card-foot">' . $foot . '</footer>';
        }
        echo '</section>';
    }

    public static function info(string $text, string $icon = 'info'): string
    {
        return '<div class="awp-info">' . Icons::svg($icon) . '<div>' . esc_html($text) . '</div></div>';
    }

    public static function empty_state(string $text): string
    {
        return '<p class="awp-empty">' . esc_html($text) . '</p>';
    }

    /**
     * A link to another view, with caret.
     */
    public static function link(string $url, string $text): string
    {
        return '<a class="awp-linkline" href="' . esc_url($url) . '">' . esc_html($text) . Icons::svg('caret-right') . '</a>';
    }

    /**
     * A technical term with its explanation: dotted underline, the
     * explanation on hover and keyboard focus (admin.js). Without JS the
     * browser shows the title.
     */
    public static function term(string $label, string $help): string
    {
        return '<span class="awp-term" tabindex="0" title="' . esc_attr($help) . '">' . esc_html($label) . '</span>';
    }

    /**
     * A rate, or "zu wenig" while fewer than Insights::MIN_RATE_BASE visits
     * stand behind it: 1 of 2 visits converting is no 50 % rate.
     *
     * @param float|int $rate 0..1
     */
    public static function rate($rate, int $base, int $decimals = 1): string
    {
        if (!Insights::rate_is_meaningful($base)) {
            return '<span class="awp-few" tabindex="0" title="Unter ' . Insights::MIN_RATE_BASE . ' Besuchen ist eine Rate nicht aussagekräftig">zu wenig</span>';
        }

        return esc_html(Format::percent($rate, $decimals));
    }

    /**
     * An on/off switch (44 × 26), as a native checkbox with role="switch":
     * it posts with its form as before, and with JS it saves on change
     * (data-awp-autosave, see App::ajax_save_setting()).
     *
     * @param array{description?: string, disabled?: bool, autosave?: bool, warning?: string} $options warning: amber line while on
     */
    public static function toggle(string $setting, bool $checked, string $label, array $options = []): string
    {
        $id = 'awp-sw-' . sanitize_html_class($setting);
        $autosave = ($options['autosave'] ?? true) && isset(App::AUTOSAVE_SETTINGS[$setting]);

        $html = '<div class="awp-field awp-switch-field"><div class="awp-switch-text">'
            . '<label for="' . esc_attr($id) . '" class="awp-switch-label">' . esc_html($label) . '</label>';
        if (!empty($options['description'])) {
            $html .= '<p class="awp-field-desc">' . esc_html($options['description']) . '</p>';
        }
        if (!empty($options['warning'])) {
            // Amber line at the decision, shown while the switch is on.
            $html .= '<p class="awp-warnline" data-awp-when-on' . ($checked ? '' : ' hidden') . '><span class="awp-warn-dot" aria-hidden="true"></span><span>' . esc_html($options['warning']) . '</span></p>';
        }
        $html .= '</div><input type="checkbox" class="awp-switch" role="switch" id="' . esc_attr($id) . '" name="analyticswp_' . esc_attr($setting) . '" value="1"'
            . checked($checked, true, false)
            . (!empty($options['disabled']) ? ' disabled' : '')
            . ($autosave ? ' data-awp-autosave="' . esc_attr($setting) . '"' : '')
            . '></div>';

        return $html;
    }

    /**
     * Change badge: "+12,3 %" with an arrow, petrol when the change is an
     * improvement, amber when it is not. The direction is in the text too.
     */
    public static function change(?float $change, bool $higher_is_better = true): string
    {
        if ($change === null) {
            return '<span class="awp-change">–<span class="awp-sr"> kein Vergleichswert</span></span>';
        }

        $rounded = round($change * 100, 1);
        if ($rounded == 0.0) {
            return '<span class="awp-change">± 0 %</span>';
        }

        $up = $rounded > 0;
        $good = $up === $higher_is_better;
        $text = ($up ? '▲ +' : '▼ ') . number_format($rounded, 1, ',', '.') . ' %';

        return '<span class="awp-change ' . ($good ? 'is-good' : 'is-bad') . '" title="im Vergleich zum Zeitraum davor">'
            . esc_html($text) . '<span class="awp-sr"> zum Zeitraum davor</span></span>';
    }

    /**
     * Label of a breakdown value.
     */
    public static function dimension_label(string $dimension, ?string $value): string
    {
        if ($dimension === 'source_medium') {
            [$source, $medium] = array_pad(explode("\x1f", (string)$value, 2), 2, '');
            if ($source === '' && $medium === '') {
                return 'Direkt (ohne Quelle)';
            }
            return ($source !== '' ? $source : '(keine Quelle)') . ' / ' . ($medium !== '' ? $medium : '(kein Medium)');
        }

        if ($value === null) {
            switch ($dimension) {
                case 'campaign':
                    return '(keine Kampagne)';
                case 'referrer':
                    return '(kein Verweis)';
                case 'source':
                    return '(keine Quelle)';
                case 'medium':
                    return '(kein Medium)';
                default:
                    return '(nicht gesetzt)';
            }
        }

        switch ($dimension) {
            case 'channel':
                return Format::channel($value);
            case 'device':
                return Format::device($value);
            case 'landing':
            case 'exit':
                return Format::path($value);
            default:
                return $value;
        }
    }

    /**
     * Filter parameters that select a breakdown value, or [] when the
     * dimension cannot be filtered on.
     *
     * @return array<string, string>
     */
    public static function dimension_filter(string $dimension, ?string $value): array
    {
        if ($dimension === 'source_medium') {
            [$source, $medium] = array_pad(explode("\x1f", (string)$value, 2), 2, '');
            return [
                'f_source' => $source !== '' ? $source : Reports::NONE,
                'f_medium' => $medium !== '' ? $medium : Reports::NONE,
            ];
        }

        if (!isset(Reports::FILTERS[$dimension])) {
            return [];
        }

        return ['f_' . $dimension => $value === null ? Reports::NONE : $value];
    }

    /**
     * A breakdown as table: label with a bar for its share of sessions,
     * then sessions, conversions, conversion rate and revenue.
     *
     * @param list<array{value: string|null, sessions: int, visitors: int, bounce_rate: float, conversions: int, conversion_rate: float, revenue: float}> $rows
     * @param array{revenue?: bool, bounce?: bool, visitors?: bool} $columns
     */
    public static function breakdown_table(string $dimension, string $label, array $rows, string $currency, array $columns = []): string
    {
        if (empty($rows)) {
            return self::empty_state('Für diesen Zeitraum gibt es noch keine Daten.');
        }

        $show_revenue = $columns['revenue'] ?? true;
        $show_bounce = $columns['bounce'] ?? false;
        $show_visitors = $columns['visitors'] ?? false;
        $max = max(array_column($rows, 'sessions')) ?: 1;

        $is_channel = $dimension === 'channel';

        $html = '<table class="awp-table" data-awp-hover="' . esc_attr($dimension) . '"><thead><tr>';
        $html .= '<th scope="col">' . esc_html($label) . '</th>';
        if ($show_visitors) {
            $html .= '<th scope="col" class="is-optional">' . self::term('Besucher', self::TERMS['visitors']) . '</th>';
        }
        $html .= '<th scope="col">' . self::term('Besuche', self::TERMS['sessions']) . '</th>';
        if ($show_bounce) {
            $html .= '<th scope="col" class="is-optional">' . self::term('Absprung', self::TERMS['bounce']) . '</th>';
        }
        $html .= '<th scope="col">Conv.</th>';
        $html .= '<th scope="col" class="is-optional">' . self::term('Conv.-Rate', self::TERMS['conversion_rate']) . '</th>';
        if ($show_revenue) {
            $html .= '<th scope="col">Umsatz</th>';
        }
        $html .= '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $text = self::dimension_label($dimension, $row['value']);
            $filter = self::dimension_filter($dimension, $row['value']);
            $width = max(1.5, round($row['sessions'] / $max * 100, 1));
            $bar = Channels::bar_color($is_channel ? (string)$row['value'] : null);

            $label_html = $filter
                ? '<a href="' . esc_url(App::url($filter)) . '" title="Nach „' . esc_attr($text) . '“ filtern">' . esc_html($text) . '</a>'
                : esc_html($text);
            if ($row['value'] === null) {
                $label_html = '<span class="awp-none">' . $label_html . '</span>';
            }
            if ($is_channel) {
                $label_html = Channels::icon_html((string)$row['value']) . $label_html;
            }

            $html .= '<tr data-awp-key="' . esc_attr((string)$row['value']) . '"><td class="awp-cell-label"><span class="awp-cell-bar" style="width:calc(' . $width . '% - 14px);background:' . esc_attr($bar) . '"></span>'
                . '<span class="awp-cell-text">' . $label_html . '</span></td>';
            if ($show_visitors) {
                $html .= '<td class="is-optional">' . esc_html(Format::number($row['visitors'])) . '</td>';
            }
            $html .= '<td>' . esc_html(Format::number($row['sessions'])) . '</td>';
            if ($show_bounce) {
                $html .= '<td class="is-optional">' . self::rate($row['bounce_rate'], (int)$row['sessions'], 0) . '</td>';
            }
            $html .= '<td>' . esc_html(Format::number($row['conversions'])) . '</td>';
            $html .= '<td class="is-optional">' . self::rate($row['conversion_rate'], (int)$row['sessions']) . '</td>';
            if ($show_revenue) {
                $html .= '<td>' . ($row['revenue'] > 0 ? esc_html(Format::money($row['revenue'], $currency, 0)) : '<span class="awp-none">–</span>') . '</td>';
            }
            $html .= '</tr>';
        }

        return $html . '</tbody></table>';
    }

    /**
     * Pills to switch a card between dimensions, as links.
     *
     * @param array<string, string> $options value => label
     */
    public static function pills(string $param, array $options, string $active): string
    {
        $html = '<nav class="awp-pills" aria-label="Ansicht">';
        foreach ($options as $value => $text) {
            $is = $value === $active;
            $html .= '<a href="' . esc_url(App::url([$param => $value])) . '"' . ($is ? ' class="is-active" aria-current="true"' : '') . '>' . esc_html($text) . '</a>';
        }

        return $html . '</nav>';
    }

    /**
     * A segmented switch (grey track, white active segment) as links:
     * "Kanal | Quelle | Kampagne". Extra URL arguments come along, e.g. to
     * reset the sort when the view changes.
     *
     * @param array<string, string|array{0: string, 1: string}> $options value => label, or [label, icon]
     * @param array<string, string|null> $extra
     */
    public static function segmented(string $param, array $options, string $active, string $label, array $extra = []): string
    {
        $html = '<nav class="awp-seg" aria-label="' . esc_attr($label) . '">';
        foreach ($options as $value => $option) {
            [$text, $icon] = is_array($option) ? $option : [$option, ''];
            $is = (string)$value === $active;
            $html .= '<a href="' . esc_url(App::url([$param => (string)$value] + $extra)) . '"' . ($is ? ' class="is-active" aria-current="true"' : '') . '>'
                . ($icon !== '' ? Icons::svg($icon) : '') . esc_html($text) . '</a>';
        }

        return $html . '</nav>';
    }

    /**
     * A sortable column head: a link that sorts by $key, descending first,
     * a second click flips. The arrow shows the current order.
     */
    public static function sort_header(string $label, string $key, string $help, string $sort, string $dir, string $class = ''): string
    {
        $on = $sort === $key;
        $next = $on && $dir === 'desc' ? 'asc' : 'desc';
        $icon = $on ? ($dir === 'desc' ? 'caret-down' : 'caret-up') : 'caret-up-down';
        $aria = $on ? ($dir === 'desc' ? 'descending' : 'ascending') : 'none';

        return '<th scope="col" class="' . esc_attr(trim('awp-sortable ' . $class)) . '" aria-sort="' . $aria . '">'
            . '<a href="' . esc_url(App::url(['sort' => $key, 'dir' => $next])) . '"' . ($on ? ' class="is-active"' : '') . ($help !== '' ? ' title="' . esc_attr($help) . '"' : '') . '>'
            . esc_html($label) . Icons::svg($icon) . '</a></th>';
    }

    /**
     * The requested sort, limited to $allowed, with a default.
     *
     * @param list<string> $allowed
     * @return array{0: string, 1: string} key, 'asc'|'desc'
     */
    public static function requested_sort(array $allowed, string $default): array
    {
        $sort = isset($_GET['sort']) ? sanitize_key(wp_unslash($_GET['sort'])) : '';
        $dir = isset($_GET['dir']) && $_GET['dir'] === 'asc' ? 'asc' : 'desc';

        return in_array($sort, $allowed, true) ? [$sort, $dir] : [$default, 'desc'];
    }

    /**
     * Sort report rows by a key; null values (and rates over too few
     * visits, passed as null) last.
     *
     * @param list<array<string, mixed>> $rows
     * @param callable(array<string, mixed>): (int|float|null) $value
     * @return list<array<string, mixed>>
     */
    public static function sort_rows(array $rows, callable $value, string $dir): array
    {
        usort($rows, function ($a, $b) use ($value, $dir) {
            $x = $value($a);
            $y = $value($b);
            if ($x === null || $y === null) {
                return $x === $y ? 0 : ($x === null ? 1 : -1);
            }
            return $dir === 'asc' ? $x <=> $y : $y <=> $x;
        });

        return $rows;
    }
}
