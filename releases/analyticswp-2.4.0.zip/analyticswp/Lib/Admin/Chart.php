<?php

namespace AnalyticsWP\Lib\Admin;

/**
 * Charts as server-side SVG.
 *
 * Line chart: one line per metric (only the selected one visible), the
 * previous period dashed in grey, the bucket still running (today, this
 * hour) dashed in petrol, a strip of conversions per bucket underneath. The
 * plot scales to the card's width (preserveAspectRatio none, non-scaling
 * strokes); axis labels are HTML so they do not stretch. admin.js switches
 * metrics and shows a tooltip from the JSON in data-awp-chart.
 *
 * Donut: share of visits per channel, segments in channel colours, joined
 * to the table next to it by data-awp-key (hover groups in admin.js).
 */
class Chart
{
    const WIDTH = 1000;
    const HEIGHT = 240;

    const WEEKDAYS = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];

    /**
     * @param list<string>                   $labels   Bucket keys (Y-m-d or "H").
     * @param array<string, list<float|int>> $series   Metric => values.
     * @param array<string, list<float|int>> $previous Metric => values of the period before.
     * @param array<string, array{label: string, title: string, format: string, better: bool}> $metrics
     * @param array{start?: int, end?: int, open?: bool, compare?: bool, strip?: list<int|float>, strip_off?: list<string>, since?: string} $options
     *   start: first bucket with measurement (earlier ones stay empty);
     *   end: last bucket with data (today in an hourly view: the current hour);
     *   open: the end bucket is still running (drawn dashed);
     *   compare: show the previous period;
     *   strip: conversions per bucket; strip_off: metrics without the strip;
     *   since: label of the measurement start mark.
     */
    public static function render(array $labels, array $series, array $previous, array $metrics, string $active, bool $hourly, string $currency, array $options = []): string
    {
        $count = count($labels);
        $start = min(max(0, (int)($options['start'] ?? 0)), max(0, $count - 1));
        $end = min(max($start, (int)($options['end'] ?? $count - 1)), max(0, $count - 1));
        $open = !empty($options['open']);
        $compare = $options['compare'] ?? true;
        $strip = $options['strip'] ?? [];
        $strip_off = $options['strip_off'] ?? [];

        $short = [];
        $long = [];
        foreach ($labels as $i => $label) {
            if ($hourly) {
                $short[] = $label . ':00';
                $long[] = $label . ':00 Uhr';
            } else {
                $time = strtotime($label . ' 12:00:00 UTC');
                $short[] = Format::day($label);
                $long[] = ($time ? self::WEEKDAYS[(int)gmdate('w', $time)] . ', ' : '') . Format::day($label);
            }
        }
        if ($open && !$hourly && $count > 0) {
            $short[$end] = 'Heute';
        }

        $data = [
            'labels' => $long,
            'currency' => $currency,
            'start' => $start,
            'end' => $end,
            'open' => $open,
            'compare' => $compare,
            'extras' => [
                'visitors' => $series['visitors'] ?? [],
                'conversions' => $series['conversions'] ?? [],
                'revenue' => $series['revenue'] ?? [],
            ],
            'metrics' => [],
        ];

        $groups = '';
        $y_axes = '';
        $last_solid = $open ? $end - 1 : $end;
        foreach ($metrics as $key => $meta) {
            $values = array_values($series[$key] ?? array_fill(0, $count, 0));
            $prev = $compare ? array_values($previous[$key] ?? []) : [];
            $visible = array_slice($values, $start, $end - $start + 1);
            $max = self::nice_max(max(array_merge([0], $visible, $prev)), $meta['format']);

            $data['metrics'][$key] = [
                'label' => $meta['label'],
                'title' => $meta['title'],
                'format' => $meta['format'],
                'better' => $meta['better'],
                'values' => $values,
                'previous' => $prev,
                'max' => $max,
            ];

            $hidden = $key === $active ? '' : ' hidden';
            $groups .= '<g data-awp-series="' . esc_attr($key) . '"' . $hidden . '>';
            if (!empty($prev)) {
                $groups .= '<path class="awp-line-prev" d="' . esc_attr(self::line_path($prev, $max, $count, 0, count($prev) - 1)) . '"/>';
            }
            if ($last_solid >= $start) {
                $groups .= '<path class="awp-area" d="' . esc_attr(self::area_path($values, $max, $count, $start, $last_solid)) . '"/>';
                $groups .= '<path class="awp-line" d="' . esc_attr(self::line_path($values, $max, $count, $start, $last_solid)) . '"/>';
            }
            if ($open && $end > $start) {
                $groups .= '<path class="awp-line-open" d="' . esc_attr(self::line_path($values, $max, $count, $end - 1, $end)) . '"/>';
            }
            $groups .= '</g>';

            $y_axes .= '<div class="awp-chart-y" data-awp-series="' . esc_attr($key) . '"' . $hidden . ' aria-hidden="true">';
            foreach ([1.0, 0.5, 0.0] as $fraction) {
                $top = (1 - $fraction) * 100 * (220 / self::HEIGHT) + (20 / self::HEIGHT) * 100;
                $y_axes .= '<span style="top:' . round($top, 2) . '%">' . esc_html(self::format_axis($max * $fraction, $meta['format'], $currency)) . '</span>';
            }
            $y_axes .= '</div>';
        }

        $grid = '<g class="awp-grid">';
        foreach ([0.0, 0.5, 1.0] as $fraction) {
            $y = self::y($fraction, 1);
            $grid .= '<line x1="0" x2="' . self::WIDTH . '" y1="' . $y . '" y2="' . $y . '"/>';
        }
        $grid .= '</g>';

        // Measurement start: a dashed mark, nothing drawn before it.
        $start_mark = '';
        if ($start > 0 && !empty($options['since'])) {
            $left = $count > 1 ? $start / ($count - 1) * 100 : 0;
            $start_mark = '<div class="awp-chart-start" style="left:' . round($left, 2) . '%"><span>' . esc_html((string)$options['since']) . '</span></div>';
        }

        // Conversions per bucket.
        $strip_html = '';
        if (!empty($strip)) {
            $strip_max = max(1, max($strip));
            $strip_html = '<div class="awp-chart-strip" role="img" aria-label="Conversions pro ' . ($hourly ? 'Stunde' : 'Tag') . '" data-awp-strip-off="' . esc_attr(implode(' ', $strip_off)) . '"' . (in_array($active, $strip_off, true) ? ' hidden' : '') . '>';
            foreach (array_values($strip) as $i => $value) {
                $height = $value > 0 ? max(15, round($value / $strip_max * 100)) : 0;
                $strip_html .= '<span data-i="' . $i . '"><i style="height:' . $height . '%"></i></span>';
            }
            $strip_html .= '</div>';
        }

        $x_labels = '';
        $step = max(1, (int)ceil($count / 7));
        $ticks = range(0, max(0, $count - 1), $step);
        if ($count > 1 && end($ticks) !== $count - 1) {
            // The last bucket gets a label; drop the tick just before if crowded.
            if ($count - 1 - end($ticks) < $step / 2) {
                array_pop($ticks);
            }
            $ticks[] = $count - 1;
        }
        foreach ($ticks as $i) {
            $left = $count > 1 ? $i / ($count - 1) * 100 : 50;
            $align = $i === 0 ? ' is-first' : ($i === $count - 1 && $count > 1 ? ' is-last' : '');
            $x_labels .= '<span class="' . trim($align) . '" style="left:' . round($left, 2) . '%">' . esc_html($short[$i]) . '</span>';
        }

        $active_meta = $metrics[$active] ?? reset($metrics);
        $summary = ($active_meta['title'] ?? '') . ', ' . ($long[0] ?? '') . ' bis ' . (end($long) ?: '');

        $legend = '<span><i></i>' . esc_html($open ? 'Gewählter Zeitraum (heute läuft noch)' : 'Gewählter Zeitraum') . '</span>';
        if ($compare) {
            $legend .= '<span><i class="is-prev"></i>Zeitraum davor</span>';
        }
        if ($strip_html !== '') {
            $legend .= '<span data-awp-strip-legend' . (in_array($active, $strip_off, true) ? ' hidden' : '') . '><i class="is-strip"></i>Conversions</span>';
        }

        return '<div class="awp-chart" data-awp-chart="' . esc_attr((string)wp_json_encode($data)) . '" data-awp-active="' . esc_attr($active) . '">'
            . '<div class="awp-chart-head"><span class="awp-chart-title" data-awp-chart-title>' . esc_html($active_meta['title'] ?? '') . '</span>'
            . '<div class="awp-chart-legend" aria-hidden="true">' . $legend . '</div></div>'
            . '<div class="awp-chart-plot">' . $y_axes
            . '<svg viewBox="0 0 ' . self::WIDTH . ' ' . self::HEIGHT . '" preserveAspectRatio="none" role="img" aria-label="' . esc_attr($summary) . '">'
            . $grid . $groups . '</svg>' . $start_mark . '</div>'
            . $strip_html
            . '<div class="awp-chart-x" aria-hidden="true">' . $x_labels . '</div>'
            . '</div>';
    }

    /**
     * Donut of visits per channel. Below $min_total visits only a grey ring:
     * a share of 12 visits says nothing yet.
     *
     * @param list<array{value: string|null, sessions: int}> $rows
     */
    public static function donut(array $rows, int $total, int $min_total): string
    {
        $radius = 60;
        $circumference = 2 * M_PI * $radius;
        $enough = $total >= $min_total && $total > 0;

        $segments = '';
        $offset = 0.0;
        if ($enough) {
            foreach ($rows as $row) {
                if ((int)$row['sessions'] <= 0) {
                    continue;
                }
                $share = (int)$row['sessions'] / $total;
                $length = $share * $circumference;
                // A small gap between segments.
                $dash = max(0.5, $length - 1.6);
                $channel = (string)$row['value'];
                $name = Format::channel($row['value']);
                $segments .= '<circle class="awp-donut-seg" cx="80" cy="80" r="' . $radius . '" fill="none"'
                    . ' stroke="' . esc_attr(Channels::color($channel)) . '"'
                    . ' stroke-dasharray="' . round($dash, 2) . ' ' . round($circumference - $dash, 2) . '"'
                    . ' stroke-dashoffset="' . round(-$offset, 2) . '"'
                    . ' data-awp-key="' . esc_attr($channel) . '"'
                    . ' data-share="' . esc_attr(Format::percent($share)) . '" data-name="' . esc_attr($name) . '">'
                    . '<title>' . esc_html($name . ': ' . Format::number((int)$row['sessions']) . ' Besuche (' . Format::percent($share) . ')') . '</title></circle>';
                $offset += $length;
            }
        }

        return '<div class="awp-donut" data-awp-donut>'
            . '<svg viewBox="0 0 160 160" role="img" aria-label="Anteil der Kanäle an allen Besuchen">'
            . '<circle class="awp-donut-track" cx="80" cy="80" r="' . $radius . '" fill="none"/>'
            . $segments . '</svg>'
            . '<div class="awp-donut-center" aria-hidden="true"><span class="awp-donut-value" data-default="' . esc_attr(Format::number($total)) . '">' . esc_html(Format::number($total)) . '</span>'
            . '<span class="awp-donut-label" data-default="Besuche">Besuche</span></div>'
            . '</div>';
    }

    /**
     * Y coordinate of a value: 20 units of headroom at the top.
     *
     * @param int|float $value
     * @param int|float $max
     */
    private static function y($value, $max): float
    {
        $max = $max > 0 ? $max : 1;
        return round(self::HEIGHT - (min($value, $max) / $max) * (self::HEIGHT - 20), 2);
    }

    private static function x(int $i, int $count): float
    {
        return $count > 1 ? round($i / ($count - 1) * self::WIDTH, 2) : self::WIDTH / 2;
    }

    /**
     * Line through the buckets $from..$to.
     *
     * @param list<float|int> $values
     * @param int|float       $max
     */
    private static function line_path(array $values, $max, int $count, int $from, int $to): string
    {
        if ($count === 1 || $from === $to) {
            // One bucket: a flat line across (one day) or a dot-like stub.
            $y = self::y($values[$from] ?? 0, $max);
            return $count === 1 ? 'M0,' . $y . 'L' . self::WIDTH . ',' . $y : 'M' . self::x($from, $count) . ',' . $y . 'l0.01,0';
        }

        $parts = [];
        for ($i = $from; $i <= $to && $i < count($values); $i++) {
            $parts[] = ($i === $from ? 'M' : 'L') . self::x($i, $count) . ',' . self::y($values[$i], $max);
        }

        return implode('', $parts);
    }

    /**
     * @param list<float|int> $values
     * @param int|float       $max
     */
    private static function area_path(array $values, $max, int $count, int $from, int $to): string
    {
        if ($count === 0) {
            return '';
        }
        if ($count === 1) {
            return self::line_path($values, $max, 1, 0, 0) . 'L' . self::WIDTH . ',' . self::HEIGHT . 'L0,' . self::HEIGHT . 'Z';
        }

        return self::line_path($values, $max, $count, $from, $to)
            . 'L' . self::x($to, $count) . ',' . self::HEIGHT . 'L' . self::x($from, $count) . ',' . self::HEIGHT . 'Z';
    }

    /**
     * A round maximum for the axis: 1, 2, 2.5 or 5 times a power of ten.
     *
     * @param int|float $value
     * @return int|float
     */
    private static function nice_max($value, string $format)
    {
        if ($format === 'percent') {
            return $value > 0.5 ? 1 : ($value > 0.2 ? 0.5 : max(0.1, ceil($value * 20) / 20));
        }
        if ($value <= 0) {
            return 1;
        }

        $power = 10 ** floor(log10($value));
        foreach ([1, 2, 2.5, 5, 10] as $step) {
            if ($value <= $step * $power) {
                return $step * $power;
            }
        }

        return 10 * $power;
    }

    /**
     * @param int|float $value
     */
    private static function format_axis($value, string $format, string $currency): string
    {
        switch ($format) {
            case 'percent':
                return Format::percent($value, 0);
            case 'money':
                return Format::money($value, $currency, 0);
            case 'duration':
                $seconds = (int)round((float)$value);
                return intdiv($seconds, 60) . ':' . str_pad((string)($seconds % 60), 2, '0', STR_PAD_LEFT);
            default:
                // Small axes have halves (2,5); show them instead of rounding.
                return floor((float)$value) == (float)$value ? Format::number($value) : number_format((float)$value, 1, ',', '.');
        }
    }

    /**
     * Bars per bucket for one of several metrics (only the selected one
     * visible), a dashed line for the average per bucket of the period
     * before, the running bucket hatched. admin.js switches metrics from
     * the tiles and shows the tooltip, which splits the bucket into
     * purchases, forms and contact clicks.
     *
     * @param list<string> $labels Bucket keys (Y-m-d or "H").
     * @param array<string, array{label: string, title: string, format: string, values: list<float|int|null>, average: float}> $metrics
     * @param array{open?: bool, end?: int, parts?: array<string, list<float|int>>} $options
     */
    public static function bars(array $labels, array $metrics, string $active, bool $hourly, string $currency, array $options = []): string
    {
        $count = count($labels);
        $end = min(max(0, (int)($options['end'] ?? $count - 1)), max(0, $count - 1));
        $open = !empty($options['open']);

        $short = [];
        $long = [];
        foreach ($labels as $label) {
            if ($hourly) {
                $short[] = $label . ':00';
                $long[] = $label . ':00 Uhr';
            } else {
                $time = strtotime($label . ' 12:00:00 UTC');
                $short[] = Format::day($label);
                $long[] = ($time ? self::WEEKDAYS[(int)gmdate('w', $time)] . ', ' : '') . Format::day($label);
            }
        }
        if ($open && !$hourly && $count > 0) {
            $short[$end] = 'Heute';
        }

        $data = ['labels' => $long, 'currency' => $currency, 'open' => $open, 'end' => $end, 'parts' => $options['parts'] ?? [], 'metrics' => []];

        $groups = '';
        $y_axes = '';
        $averages = '';
        foreach ($metrics as $key => $meta) {
            $values = array_values($meta['values']);
            $max = self::nice_max(max(array_merge([0, $meta['average']], array_map('floatval', array_filter(array_slice($values, 0, $end + 1), 'is_numeric')))), $meta['format']);
            $data['metrics'][$key] = ['label' => $meta['label'], 'title' => $meta['title'], 'format' => $meta['format'], 'values' => $values, 'average' => $meta['average']];
            $hidden = $key === $active ? '' : ' hidden';

            $groups .= '<div class="awp-bars-set" data-awp-series="' . esc_attr($key) . '"' . $hidden . '>';
            foreach ($values as $i => $value) {
                $height = $value !== null && $i <= $end && $value > 0 ? max(2, round((float)$value / $max * 100, 2)) : 0;
                $groups .= '<span data-i="' . $i . '"><i style="height:' . $height . '%"' . ($open && $i === $end ? ' class="is-open"' : '') . '></i></span>';
            }
            $groups .= '</div>';

            $averages .= '<div class="awp-bars-avg" data-awp-series="' . esc_attr($key) . '"' . $hidden . ' style="bottom:' . round(min(1, $meta['average'] / $max) * 100, 2) . '%"></div>';

            $y_axes .= '<div class="awp-chart-y" data-awp-series="' . esc_attr($key) . '"' . $hidden . ' aria-hidden="true">';
            foreach ([1.0, 0.5, 0.0] as $fraction) {
                $y_axes .= '<span style="top:' . round((1 - $fraction) * 100, 2) . '%">' . esc_html(self::format_axis($max * $fraction, $meta['format'], $currency)) . '</span>';
            }
            $y_axes .= '</div>';
        }

        $x_labels = '';
        $step = max(1, (int)ceil($count / 7));
        foreach (range(0, max(0, $count - 1), $step) as $i) {
            $x_labels .= '<span style="left:' . round(($i + 0.5) / max(1, $count) * 100, 2) . '%">' . esc_html($short[$i]) . '</span>';
        }
        if ($count > 1 && ($count - 1) % $step !== 0) {
            $x_labels .= '<span style="left:' . round(($count - 0.5) / $count * 100, 2) . '%">' . esc_html($short[$count - 1]) . '</span>';
        }

        $title = $metrics[$active]['title'] ?? '';

        return '<div class="awp-chart awp-barchart" data-awp-bars="' . esc_attr((string)wp_json_encode($data)) . '" data-awp-active="' . esc_attr($active) . '">'
            . '<div class="awp-chart-head"><span class="awp-chart-title" data-awp-chart-title>' . esc_html($title) . '</span>'
            . '<div class="awp-chart-legend" aria-hidden="true"><span><i class="is-bar"></i>' . esc_html($open ? 'Gewählter Zeitraum (heute läuft noch)' : 'Gewählter Zeitraum') . '</span><span><i class="is-prev"></i>Ø Zeitraum davor</span></div></div>'
            . '<div class="awp-chart-plot awp-bars-plot" role="img" aria-label="' . esc_attr($title) . '">' . $y_axes . $groups . $averages . '</div>'
            . '<div class="awp-chart-x" aria-hidden="true">' . $x_labels . '</div>'
            . '</div>';
    }
}
