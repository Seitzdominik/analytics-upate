<?php

namespace AnalyticsWP\Lib;

/**
 * Where a session came from: channel, source, medium and campaign, decided
 * once from the session's first event.
 *
 * Inputs, strongest first:
 * 1. utm_* parameters on the landing page. They are normalised (lower case,
 *    trimmed, known aliases folded: "fb" and "facebook.com" are "facebook").
 * 2. Click IDs that ad platforms append (gclid, msclkid, ttclid, ...). They
 *    mark the visit as paid even when the advertiser set no UTMs.
 * 3. The referrer's domain, matched against lists of search engines, social
 *    networks, AI assistants and webmail. Payment providers and this site's
 *    own host are not a source: a visitor returning from PayPal continues
 *    where they were and counts as direct.
 *
 * Channel keys are stable identifiers for storage; labels belong to the UI.
 *
 * @psalm-type AttributionData = array{
 *   channel: string,
 *   source: string|null,
 *   medium: string|null,
 *   campaign: string|null,
 *   term: string|null,
 *   content: string|null,
 *   click_id_type: string|null,
 *   referrer_domain: string|null,
 * }
 */
class Attribution
{
    const DIRECT = 'direct';
    const ORGANIC_SEARCH = 'organic_search';
    const PAID_SEARCH = 'paid_search';
    const ORGANIC_SOCIAL = 'organic_social';
    const PAID_SOCIAL = 'paid_social';
    const EMAIL = 'email';
    const REFERRAL = 'referral';
    const DISPLAY = 'display';
    const AFFILIATE = 'affiliate';
    const AI = 'ai';
    const OTHER = 'other_campaign';

    const CHANNELS = [
        self::DIRECT,
        self::ORGANIC_SEARCH,
        self::PAID_SEARCH,
        self::ORGANIC_SOCIAL,
        self::PAID_SOCIAL,
        self::EMAIL,
        self::REFERRAL,
        self::DISPLAY,
        self::AFFILIATE,
        self::AI,
        self::OTHER,
    ];

    /**
     * Click ID parameter => [source, medium, channel]. fbclid is not paid:
     * Facebook and Instagram append it to every outbound link, ads or not.
     */
    const CLICK_IDS = [
        'gclid' => ['google', 'cpc', self::PAID_SEARCH],
        'gbraid' => ['google', 'cpc', self::PAID_SEARCH],
        'wbraid' => ['google', 'cpc', self::PAID_SEARCH],
        'msclkid' => ['bing', 'cpc', self::PAID_SEARCH],
        'ttclid' => ['tiktok', 'paid', self::PAID_SOCIAL],
        'li_fat_id' => ['linkedin', 'paid', self::PAID_SOCIAL],
        'fbclid' => ['facebook', 'social', self::ORGANIC_SOCIAL],
    ];

    /**
     * Referrer host (without "www.", matched on the end) => source name.
     * Order matters: the first match wins, so more specific hosts come first
     * (gemini.google.com before google.).
     */
    const AI_HOSTS = [
        'chatgpt.com' => 'chatgpt',
        'chat.openai.com' => 'chatgpt',
        'perplexity.ai' => 'perplexity',
        'claude.ai' => 'claude',
        'gemini.google.com' => 'gemini',
        'copilot.microsoft.com' => 'copilot',
        'chat.mistral.ai' => 'mistral',
        'you.com' => 'you.com',
    ];

    const SEARCH_HOSTS = [
        'google.' => 'google',
        'bing.com' => 'bing',
        'duckduckgo.com' => 'duckduckgo',
        'ecosia.org' => 'ecosia',
        'search.yahoo.' => 'yahoo',
        'yahoo.com' => 'yahoo',
        'startpage.com' => 'startpage',
        'qwant.com' => 'qwant',
        'search.brave.com' => 'brave',
        'yandex.' => 'yandex',
        'baidu.com' => 'baidu',
        'suche.web.de' => 'web.de',
        'suche.gmx.' => 'gmx',
        'suche.t-online.de' => 't-online',
        'metager.' => 'metager',
    ];

    const SOCIAL_HOSTS = [
        'facebook.com' => 'facebook',
        'fb.me' => 'facebook',
        'instagram.com' => 'instagram',
        'linkedin.com' => 'linkedin',
        'lnkd.in' => 'linkedin',
        'xing.com' => 'xing',
        't.co' => 'x',
        'x.com' => 'x',
        'twitter.com' => 'x',
        'pinterest.' => 'pinterest',
        'pin.it' => 'pinterest',
        'youtube.com' => 'youtube',
        'youtu.be' => 'youtube',
        'tiktok.com' => 'tiktok',
        'reddit.com' => 'reddit',
        'threads.net' => 'threads',
        'threads.com' => 'threads',
        'bsky.app' => 'bluesky',
        'wa.me' => 'whatsapp',
        'whatsapp.com' => 'whatsapp',
        't.me' => 'telegram',
        'snapchat.com' => 'snapchat',
    ];

    const EMAIL_HOSTS = [
        'mail.google.com' => 'gmail',
        'outlook.live.com' => 'outlook',
        'outlook.office.com' => 'outlook',
        'outlook.office365.com' => 'outlook',
        'mail.yahoo.com' => 'yahoo mail',
        'navigator.web.de' => 'web.de mail',
        'navigator.gmx.net' => 'gmx mail',
        'email.t-online.de' => 't-online mail',
        'mail.proton.me' => 'proton mail',
    ];

    /**
     * Referrers that are a step inside the visitor's own visit, not where
     * they came from.
     */
    const IGNORED_HOSTS = [
        'paypal.com',
        'paypal.me',
        'stripe.com',
        'klarna.com',
        'mollie.com',
        'sofort.com',
        'giropay.de',
        'adyen.com',
        'pay.google.com',
        'surecart.com',
        'accounts.google.com',
    ];

    /** utm_source aliases => source name. */
    const SOURCE_ALIASES = [
        'fb' => 'facebook',
        'facebook.com' => 'facebook',
        'm.facebook.com' => 'facebook',
        'l.facebook.com' => 'facebook',
        'meta' => 'facebook',
        'ig' => 'instagram',
        'instagram.com' => 'instagram',
        'google.com' => 'google',
        'google.de' => 'google',
        'adwords' => 'google',
        'googleads' => 'google',
        'li' => 'linkedin',
        'linkedin.com' => 'linkedin',
        'twitter' => 'x',
        'twitter.com' => 'x',
        'yt' => 'youtube',
        'youtube.com' => 'youtube',
        'tt' => 'tiktok',
        'tiktok.com' => 'tiktok',
        'bing.com' => 'bing',
        'microsoft' => 'bing',
    ];

    const PAID_MEDIUMS = ['cpc', 'ppc', 'paid', 'paidsearch', 'paid_search', 'paid-search', 'sem', 'retargeting', 'paid_ads', 'paid-ads', 'ads'];
    const PAID_SOCIAL_MEDIUMS = ['paid_social', 'paid-social', 'paidsocial', 'social_paid', 'social-paid', 'socialpaid', 'social_ads', 'social-ads'];
    const SOCIAL_MEDIUMS = ['social', 'social-network', 'social_network', 'social-media', 'social_media', 'sm', 'organic_social', 'organic-social'];
    const EMAIL_MEDIUMS = ['email', 'e-mail', 'e_mail', 'mail', 'newsletter'];
    const DISPLAY_MEDIUMS = ['display', 'banner', 'cpm', 'programmatic', 'video'];
    const AFFILIATE_MEDIUMS = ['affiliate', 'affiliates', 'partner'];
    const REFERRAL_MEDIUMS = ['referral', 'link'];
    const ORGANIC_MEDIUMS = ['organic', 'seo'];

    /**
     * @param string      $page_url Landing page, with its query string.
     * @param string|null $referrer Referrer as the browser sent it.
     *
     * @return AttributionData
     */
    public static function from_landing(string $page_url, ?string $referrer): array
    {
        $params = self::query_params($page_url);
        $referrer_host = self::host((string)$referrer);
        $own_host = self::host(home_url());

        $data = [
            'channel' => self::DIRECT,
            'source' => null,
            'medium' => null,
            'campaign' => self::clean($params['utm_campaign'] ?? null),
            'term' => self::clean($params['utm_term'] ?? null),
            'content' => self::clean($params['utm_content'] ?? null),
            'click_id_type' => null,
            'referrer_domain' => null,
        ];

        $is_external_referrer = $referrer_host !== '' && $referrer_host !== $own_host && !self::is_ignored_host($referrer_host);
        if ($is_external_referrer) {
            $data['referrer_domain'] = $referrer_host;
        }

        // What the referrer says, used to fill gaps below.
        [$referrer_channel, $referrer_source] = $is_external_referrer ? self::classify_host($referrer_host) : [null, null];

        foreach (self::CLICK_IDS as $param => $click) {
            if (!empty($params[$param])) {
                $data['click_id_type'] = $param;
                break;
            }
        }

        $utm_source = self::normalise_source(self::clean($params['utm_source'] ?? null));
        $utm_medium = self::clean($params['utm_medium'] ?? null);

        if ($utm_source !== null || $utm_medium !== null) {
            $data['source'] = $utm_source ?? $referrer_source;
            $data['medium'] = $utm_medium;
            $data['channel'] = self::channel_for_campaign($data['source'], $utm_medium, $data['click_id_type'], $referrer_channel);
        } elseif ($data['click_id_type'] !== null) {
            [$source, $medium, $channel] = self::CLICK_IDS[$data['click_id_type']];
            // fbclid on a link from Instagram is Instagram.
            $data['source'] = ($data['click_id_type'] === 'fbclid' && $referrer_source !== null && $referrer_channel === self::ORGANIC_SOCIAL) ? $referrer_source : $source;
            $data['medium'] = $medium;
            $data['channel'] = $channel;
        } elseif ($is_external_referrer) {
            $data['source'] = $referrer_source;
            $data['medium'] = self::medium_for_channel((string)$referrer_channel);
            $data['channel'] = (string)$referrer_channel;
        }

        /**
         * Adjust how a session is attributed.
         *
         * @param array  $data     Channel, source, medium, campaign, term, content, click_id_type, referrer_domain.
         * @param string $page_url Landing page with its query string.
         * @param string $referrer Referrer as the browser sent it.
         */
        $filtered = apply_filters('analyticswp_session_attribution', $data, $page_url, (string)$referrer);
        if (is_array($filtered) && isset($filtered['channel']) && in_array($filtered['channel'], self::CHANNELS, true)) {
            $data = array_merge($data, array_intersect_key($filtered, $data));
        }

        return $data;
    }

    /**
     * Does this event carry a new entry signal, one that should end the
     * current session and start another (a different campaign, click ID or
     * external referrer)? Mirrors GA4: a click on an ad or newsletter link
     * within 30 minutes is a new visit from that campaign.
     *
     * @param AttributionData $session  Attribution of the current session.
     */
    public static function starts_new_session(array $session, string $page_url, ?string $referrer): bool
    {
        $params = self::query_params($page_url);
        $has_campaign = !empty($params['utm_source']) || !empty($params['utm_medium']) || !empty($params['utm_campaign']);
        $has_click_id = false;
        foreach (array_keys(self::CLICK_IDS) as $param) {
            if (!empty($params[$param])) {
                $has_click_id = true;
                break;
            }
        }

        $referrer_host = self::host((string)$referrer);
        $has_external_referrer = $referrer_host !== '' && $referrer_host !== self::host(home_url()) && !self::is_ignored_host($referrer_host);

        if (!$has_campaign && !$has_click_id && !$has_external_referrer) {
            return false;
        }

        $incoming = self::from_landing($page_url, $referrer);

        foreach (['channel', 'source', 'medium', 'campaign', 'click_id_type', 'referrer_domain'] as $key) {
            if (($incoming[$key] ?? null) !== ($session[$key] ?? null)) {
                return true;
            }
        }

        return false;
    }

    private static function channel_for_campaign(?string $source, ?string $medium, ?string $click_id_type, ?string $referrer_channel): string
    {
        $medium = $medium ?? '';
        $source_channel = $source !== null ? self::classify_source_name($source) : null;

        if (in_array($medium, self::PAID_SOCIAL_MEDIUMS, true)) {
            return self::PAID_SOCIAL;
        }
        if (in_array($medium, self::PAID_MEDIUMS, true)) {
            return $source_channel === self::ORGANIC_SOCIAL ? self::PAID_SOCIAL : self::PAID_SEARCH;
        }
        if (in_array($medium, self::EMAIL_MEDIUMS, true) || ($source !== null && preg_match('/newsletter|e-?mail/', $source))) {
            return self::EMAIL;
        }
        if (in_array($medium, self::DISPLAY_MEDIUMS, true)) {
            return self::DISPLAY;
        }
        if (in_array($medium, self::AFFILIATE_MEDIUMS, true)) {
            return self::AFFILIATE;
        }
        if (in_array($medium, self::SOCIAL_MEDIUMS, true)) {
            return self::ORGANIC_SOCIAL;
        }
        if (in_array($medium, self::ORGANIC_MEDIUMS, true)) {
            return $source_channel === self::ORGANIC_SOCIAL ? self::ORGANIC_SOCIAL : self::ORGANIC_SEARCH;
        }
        if (in_array($medium, self::REFERRAL_MEDIUMS, true)) {
            return self::REFERRAL;
        }

        // A medium nobody standardised, or none at all: go by what is known
        // about the source, then by a click ID, then by the referrer.
        if ($click_id_type !== null) {
            return self::CLICK_IDS[$click_id_type][2];
        }
        if ($medium === '' && $source_channel !== null) {
            return $source_channel;
        }
        if ($medium === '' && $referrer_channel !== null) {
            return $referrer_channel;
        }

        return self::OTHER;
    }

    /**
     * @return array{0: string, 1: string} [channel, source]
     */
    private static function classify_host(string $host): array
    {
        foreach ([
            [self::AI_HOSTS, self::AI],
            [self::EMAIL_HOSTS, self::EMAIL],
            [self::SEARCH_HOSTS, self::ORGANIC_SEARCH],
            [self::SOCIAL_HOSTS, self::ORGANIC_SOCIAL],
        ] as [$hosts, $channel]) {
            $source = self::match_host($host, $hosts);
            if ($source !== null) {
                return [$channel, $source];
            }
        }

        return [self::REFERRAL, $host];
    }

    /**
     * Channel a bare source name implies ("google" is search, "instagram"
     * social), or null when it implies none.
     */
    private static function classify_source_name(string $source): ?string
    {
        $names = [
            self::AI => array_values(self::AI_HOSTS),
            self::ORGANIC_SEARCH => array_values(self::SEARCH_HOSTS),
            self::ORGANIC_SOCIAL => array_values(self::SOCIAL_HOSTS),
        ];

        foreach ($names as $channel => $list) {
            if (in_array($source, $list, true)) {
                return $channel;
            }
        }

        // A domain as utm_source ("newsletter.example.com", "chatgpt.com").
        if (strpos($source, '.') !== false) {
            [$channel] = self::classify_host($source);
            return $channel === self::REFERRAL ? null : $channel;
        }

        return null;
    }

    private static function medium_for_channel(string $channel): ?string
    {
        switch ($channel) {
            case self::ORGANIC_SEARCH:
                return 'organic';
            case self::ORGANIC_SOCIAL:
                return 'social';
            case self::EMAIL:
                return 'email';
            case self::AI:
                return 'ai';
            case self::REFERRAL:
                return 'referral';
            default:
                return null;
        }
    }

    /**
     * @param array<string, string> $hosts
     */
    private static function match_host(string $host, array $hosts): ?string
    {
        foreach ($hosts as $pattern => $source) {
            if (substr($pattern, -1) === '.') {
                // "google." matches google.de, www.google.co.uk, ...
                if (preg_match('/(^|\.)' . preg_quote($pattern, '/') . '[a-z.]+$/', $host)) {
                    return $source;
                }
            } elseif ($host === $pattern || substr($host, -strlen('.' . $pattern)) === '.' . $pattern) {
                return $source;
            }
        }

        return null;
    }

    private static function is_ignored_host(string $host): bool
    {
        foreach (self::IGNORED_HOSTS as $ignored) {
            if ($host === $ignored || substr($host, -strlen('.' . $ignored)) === '.' . $ignored) {
                return true;
            }
        }

        return false;
    }

    private static function normalise_source(?string $source): ?string
    {
        if ($source === null) {
            return null;
        }

        return self::SOURCE_ALIASES[$source] ?? $source;
    }

    /**
     * Lower case, trimmed, at most 255 characters; '' becomes null.
     *
     * @param mixed $value
     */
    private static function clean($value): ?string
    {
        if (!is_scalar($value)) {
            return null;
        }

        $value = strtolower(trim(str_replace(['"', "'", '<', '>', '`'], '', sanitize_text_field((string)$value))));

        return $value === '' ? null : mb_substr($value, 0, 255);
    }

    /**
     * Host in lower case, without "www.".
     */
    public static function host(string $url): string
    {
        $host = strtolower((string)wp_parse_url(trim($url), PHP_URL_HOST));

        return strpos($host, 'www.') === 0 ? substr($host, 4) : $host;
    }

    /**
     * @return array<string, mixed>
     */
    private static function query_params(string $url): array
    {
        $query = (string)wp_parse_url($url, PHP_URL_QUERY);
        $params = [];
        if ($query !== '') {
            parse_str($query, $params);
        }

        return $params;
    }
}
