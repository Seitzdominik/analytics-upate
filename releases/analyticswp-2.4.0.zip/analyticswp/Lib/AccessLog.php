<?php

namespace AnalyticsWP\Lib;

/**
 * "Letzte Zugriffe": who exported figures or let an AI read them, for 30
 * days. One small option (not autoloaded), at most MAX entries; nothing
 * about visitors, only the WordPress user and what was read.
 */
class AccessLog
{
    const OPTION = 'analyticswp_access_log';

    const DAYS = 30;

    const MAX = 100;

    /**
     * @param 'export'|'ai' $kind
     * @param string $who  "Export", or the AI client (application password name)
     * @param string $what "Für KI und Kunden · Übersicht, Kanäle, 30 Tage"
     */
    public static function add(string $kind, string $who, string $what): void
    {
        $entries = self::entries();
        array_unshift($entries, [
            't' => time(),
            'kind' => $kind,
            'who' => mb_substr($who, 0, 60),
            'what' => mb_substr($what, 0, 200),
            'user' => get_current_user_id(),
        ]);

        update_option(self::OPTION, array_slice($entries, 0, self::MAX), false);
    }

    /**
     * Entries of the last DAYS days, newest first.
     *
     * @return list<array{t: int, kind: string, who: string, what: string, user: int}>
     */
    public static function entries(): array
    {
        $stored = get_option(self::OPTION, []);
        $since = time() - self::DAYS * DAY_IN_SECONDS;
        $out = [];
        foreach (is_array($stored) ? $stored : [] as $entry) {
            if (is_array($entry) && isset($entry['t'], $entry['kind'], $entry['who'], $entry['what']) && (int)$entry['t'] >= $since) {
                $out[] = [
                    't' => (int)$entry['t'],
                    'kind' => (string)$entry['kind'],
                    'who' => (string)$entry['who'],
                    'what' => (string)$entry['what'],
                    'user' => (int)($entry['user'] ?? 0),
                ];
            }
        }

        return $out;
    }

    /**
     * The newest AI access, or null.
     *
     * @return array{t: int, kind: string, who: string, what: string, user: int}|null
     */
    public static function last_ai(): ?array
    {
        foreach (self::entries() as $entry) {
            if ($entry['kind'] === 'ai') {
                return $entry;
            }
        }

        return null;
    }

    /**
     * Name of the AI client of the current request: the name of the
     * application password it signed in with ("Claude Desktop"), else a
     * generic one.
     */
    public static function client(): string
    {
        if (function_exists('rest_get_authenticated_app_password')) {
            $uuid = rest_get_authenticated_app_password();
            if (is_string($uuid) && $uuid !== '' && class_exists('WP_Application_Passwords')) {
                $item = \WP_Application_Passwords::get_user_application_password(get_current_user_id(), $uuid);
                if (is_array($item) && !empty($item['name'])) {
                    return sanitize_text_field((string)$item['name']);
                }
            }
        }

        return 'KI-Assistent';
    }
}
