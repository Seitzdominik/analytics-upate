<?php

namespace AnalyticsWP\Lib;

/**
 * @psalm-import-type JourneyEvent from Event
 *
 * @psalm-import-type IdentifiedJourney from Event
 * @psalm-import-type AnonymousJourney from Event
 *
 * @psalm-import-type SourceData from Event
 */
class Core
{
    /**
     * Events one visitor IP may send per RequestGuard::RATE_WINDOW. Generous
     * enough for a visitor clicking through quickly with a few custom events
     * per page, and for several people behind one office address.
     */
    const RATE_LIMIT = 120;

    /**
     * Event types only the server may record. A browser sending one of these
     * is refused, so a visitor cannot fake an order from the console.
     */
    const SERVER_ONLY_EVENT_TYPES = [
        'conversion',
        'checkout_confirmed',
    ];

    /**
     * Keys a browser may not set through event properties. They map to
     * columns (Event::track_server_event()) or identify the visitor.
     */
    const RESERVED_PROPERTY_KEYS = [
        'unique_session_id',
        'session_id',
        'conversion_type',
        'conversion_id',
        'unique_event_identifier',
        'referrer',
        'page_url',
        'device_type',
        'user_agent',
        'ip_address',
        'user_id',
        'user_email',
        'timestamp',
        'utm_source',
        'utm_medium',
        'utm_campaign',
        'utm_term',
        'utm_content',
        'revenue',
        'currency',
        'attributed_session_id',
        'first_session_id',
        'scroll_depth',
        'engaged_seconds',
    ];

    /**
     * Events from all visitors together per RequestGuard::RATE_WINDOW. A cap
     * on what the endpoint writes even when an attacker rotates addresses;
     * far above what a small business site sees. Filter:
     * analyticswp_global_rate_limit.
     */
    const GLOBAL_RATE_LIMIT = 3000;

    /** Longest page URL or referrer stored. */
    const MAX_URL_LENGTH = 2000;

    /** Events the tracker sends by itself (assets: analyticswp.js). */
    const ENGAGEMENT_EVENT_TYPES = ['outbound', 'download', 'contact'];

    /** Engagement reports of a page view older than this are ignored. */
    const ENGAGEMENT_MAX_AGE = 6 * HOUR_IN_SECONDS;

    public static function engagement_enabled(): bool
    {
        return (bool)SuperSimpleWP::get_setting('analyticswp', 'engagement_tracking');
    }

    /**
     * Active time and scroll depth of a page view, reported when the page
     * is left. Only updates a recent page view of the same visitor; the
     * values only ever grow (a report can arrive twice).
     *
     * @param array<string, scalar> $properties pv (page view ID), t (seconds), s (percent)
     */
    private static function record_engagement(array $properties): void
    {
        global $wpdb;

        if (!self::engagement_enabled()) {
            return;
        }

        $pageview_id = isset($properties['pv']) ? (int)$properties['pv'] : 0;
        $seconds = isset($properties['t']) ? max(0, min(6 * 3600, (int)$properties['t'])) : 0;
        $scroll = isset($properties['s']) ? max(0, min(100, (int)$properties['s'])) : 0;
        if ($pageview_id <= 0) {
            return;
        }

        $events = Event::table_name();
        $sessions = Sessions::table_name();
        $since = gmdate('Y-m-d H:i:s', time() - self::ENGAGEMENT_MAX_AGE);

        // Both keys: a page left right after consent was recorded under the
        // daily hash, its report arrives with the consented key.
        $pageview = $wpdb->get_row((string)$wpdb->prepare(
            "SELECT id, session_id, timestamp FROM `$events` WHERE id = %d AND unique_session_id IN (%s, %s) AND event_type = 'pageview' AND timestamp >= %s",
            $pageview_id,
            Visitor::key(),
            Visitor::hash(),
            $since
        ), 'ARRAY_A');
        if (!is_array($pageview)) {
            return;
        }

        $wpdb->query((string)$wpdb->prepare(
            "UPDATE `$events` SET scroll_depth = GREATEST(COALESCE(scroll_depth, 0), %d), engaged_seconds = GREATEST(COALESCE(engaged_seconds, 0), %d) WHERE id = %d",
            $scroll,
            $seconds,
            $pageview_id
        ));

        // The session's active time is the sum over its page views; it
        // also lasted at least until this page was left.
        $left_at = gmdate('Y-m-d H:i:s', (int)strtotime($pageview['timestamp'] . ' UTC') + $seconds);
        $wpdb->query((string)$wpdb->prepare(
            "UPDATE `$sessions` SET
                engaged_seconds = (SELECT COALESCE(SUM(e.engaged_seconds), 0) FROM `$events` e WHERE e.session_id = %s AND e.event_type = 'pageview'),
                last_seen_at = GREATEST(last_seen_at, %s)
             WHERE session_id = %s",
            (string)$pageview['session_id'],
            $left_at,
            (string)$pageview['session_id']
        ));
    }

    /** Limits for custom event properties from the browser. */
    const MAX_PROPERTIES = 20;
    const MAX_PROPERTY_LENGTH = 500;

    /**
     * @return void
     */
    public static function init()
    {
        Event::create_table_if_necessary();
        Migrations::init();

        add_action('wp_enqueue_scripts', function () {
            wp_enqueue_script(
                'analyticswp',
                plugin_dir_url(__FILE__) . 'analyticswp.js',
                [],
                // The file time, so a changed tracker is fetched again even
                // while ANALYTICSWP_VERSION stays the same.
                ANALYTICSWP_VERSION . '.' . (string)@filemtime(__DIR__ . '/analyticswp.js'),
                ['in_footer' => true, 'strategy' => 'defer']
            );
            $page = [];
            if (is_404()) {
                $page['status'] = 404;
            }
            if (is_search()) {
                $page['search'] = mb_substr(get_search_query(false), 0, 100);
                // Only the number of hits, so the report can mark searches
                // that found nothing.
                $page['results'] = (int)$GLOBALS['wp_query']->found_posts;
            }
            // wp_localize_script() encodes without JSON_HEX_TAG: a search for
            // "<!--<script" would put the browser's script parser into a state
            // that swallows the rest of the page.
            $vars = [
                'ajaxurl' => admin_url('admin-ajax.php'),
                'engagement' => self::engagement_enabled(),
                'consent' => Consent::script_vars(),
                'page' => $page,
            ];
            wp_add_inline_script(
                'analyticswp',
                'var analyticswp_vars = ' . wp_json_encode($vars, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';',
                'before'
            );
        });

        add_action('wp_ajax_analyticswp_send_analytics', [self::class, 'analyticswp_handle_analytics']);
        add_action('wp_ajax_nopriv_analyticswp_send_analytics', [self::class, 'analyticswp_handle_analytics']);
    }

    /**
     * Handle an event sent from the browser.
     *
     * Order as in Pixel Made Simple: origin, then the checks that write
     * nothing, then the rate limit, then the insert. A refused request never
     * counts against the limit.
     *
     * Accepts the request shape of both the cookieless tracker and upstream's
     * analyticswp.js (a cached page may still load the old script for a
     * while). Anything identifying the visitor that the old script sends,
     * its cookie ID included, is ignored.
     *
     * @return void
     */
    public static function analyticswp_handle_analytics(): void
    {
        try {
            if (!RequestGuard::origin_allowed()) {
                wp_send_json_error(['message' => 'Bad origin'], 403);
            }

            $event_type = self::validate_event_type($_POST['event_type'] ?? null);
            if (!$event_type) {
                wp_send_json_error(['message' => 'Invalid event type'], 400);
            }

            $client_data = self::parse_client_data($_POST['analyticsData'] ?? null);
            if (!$client_data) {
                wp_send_json_error(['message' => 'Invalid analytics data'], 400);
            }

            if (Utils::is_current_user_excluded_from_tracking()) {
                wp_send_json_error(['message' => 'User excluded from tracking']);
            }

            if (BotDetection::should_block_current_request($_REQUEST)) {
                wp_send_json_error(['message' => 'Bot detected']);
            }

            if (RequestGuard::rate_limited('event', self::RATE_LIMIT)) {
                wp_send_json_error(['message' => 'Rate limited'], 429);
            }

            if (RequestGuard::globally_limited('event_all', (int)apply_filters('analyticswp_global_rate_limit', self::GLOBAL_RATE_LIMIT))) {
                wp_send_json_error(['message' => 'Rate limited'], 429);
            }

            $event_properties = self::parse_event_properties($_POST['eventProperties'] ?? null);

            if ($event_type === 'engagement') {
                self::record_engagement($event_properties);
                wp_send_json_success();
            }

            // Engagement events the tracker sends by itself stay out when
            // the setting is off.
            if (in_array($event_type, self::ENGAGEMENT_EVENT_TYPES, true) && !self::engagement_enabled()) {
                wp_send_json_error(['message' => 'Engagement tracking is off']);
            }

            // A click on a phone, e-mail or WhatsApp link can count as a
            // conversion. The server decides, from its own setting.
            if ($event_type === 'contact' && (bool)SuperSimpleWP::get_setting('analyticswp', 'contact_clicks_as_conversion')) {
                $type = isset($event_properties['type']) && in_array($event_properties['type'], ['tel', 'mailto', 'whatsapp'], true) ? $event_properties['type'] : 'tel';
                $event_properties = ['type' => $type];
                $client_data['conversion_type'] = 'contact_' . $type;
                // Counted once per visitor, day and kind: a second tap, or a
                // script replaying the request, adds nothing.
                $client_data['unique_event_identifier'] = 'contact_' . $type . '_' . substr(md5(Visitor::key() . '|' . wp_date('Y-m-d')), 0, 20);
            }

            // Ours last, so nothing the browser sent can override them.
            $final_event_properties = array_merge(
                $event_properties,
                $client_data,
                self::utm_from_url($client_data['page_url'])
            );

            $result = Event::track_server_event($event_type, $final_event_properties);

            if (is_array($result) && isset($result['error'])) {
                wp_send_json_error(['message' => $result['error']]);
            }

            wp_send_json_success(['id' => $result]);
        } catch (\Throwable $e) {
            error_log("Error handling analytics event: " . $e->getMessage());
            wp_send_json_error(['message' => 'Internal server error'], 500);
        }
    }

    /**
     * Validate and sanitize the event type: 1-64 characters of letters,
     * digits, "_", "-", ".", ":" and spaces, and not one the server reserves.
     *
     * @param mixed $event_type
     * @return string|null
     */
    private static function validate_event_type($event_type): ?string
    {
        if (!is_string($event_type)) {
            return null;
        }

        // Checked as sent: sanitizing first would turn "a<b>" into "a" and
        // accept it.
        $event_type = trim(wp_unslash($event_type));

        if (!preg_match('/^[A-Za-z0-9_\-.: ]{1,64}$/', $event_type)) {
            return null;
        }

        if (in_array(strtolower($event_type), self::SERVER_ONLY_EVENT_TYPES, true)) {
            return null;
        }

        return $event_type;
    }

    /**
     * Page URL and referrer from the browser. The page must be on this site;
     * device type, user agent and visitor come from the request instead.
     *
     * @param mixed $data
     * @return array{page_url: string, referrer: string|null}|null
     */
    private static function parse_client_data($data): ?array
    {
        if (!is_string($data) || strlen($data) > 8192) {
            return null;
        }

        $decoded = json_decode(wp_unslash($data), true);
        if (!is_array($decoded) || !isset($decoded['pageURL']) || !is_string($decoded['pageURL'])) {
            return null;
        }

        $page_url = esc_url_raw(substr($decoded['pageURL'], 0, self::MAX_URL_LENGTH));
        if ($page_url === '' || !RequestGuard::is_own_url($page_url)) {
            return null;
        }

        $referrer = isset($decoded['referrer']) && is_string($decoded['referrer']) ? esc_url_raw(substr($decoded['referrer'], 0, self::MAX_URL_LENGTH)) : '';

        return [
            'page_url' => $page_url,
            'referrer' => $referrer !== '' ? $referrer : null,
        ];
    }

    /**
     * The utm_* parameters of a URL, read on the server rather than taken
     * from what the browser reports.
     *
     * @return array<string, string|null>
     */
    public static function utm_from_url(string $url): array
    {
        $query = (string)wp_parse_url($url, PHP_URL_QUERY);
        $params = [];
        if ($query !== '') {
            parse_str($query, $params);
        }

        $utm = [];
        foreach (['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'] as $key) {
            $value = isset($params[$key]) && is_scalar($params[$key]) ? sanitize_text_field((string)$params[$key]) : '';
            // Campaign names never need quotes or angle brackets; dropping them
            // keeps a crafted link harmless in any screen that shows it.
            $value = trim(str_replace(['"', "'", '<', '>', '`'], '', $value));
            $utm[$key] = $value !== '' ? mb_substr($value, 0, 255) : null;
        }

        return $utm;
    }

    /**
     * Custom event properties from the browser: at most MAX_PROPERTIES
     * scalar values, none under a reserved key.
     *
     * @param mixed $properties
     * @return array<string, scalar>
     */
    private static function parse_event_properties($properties): array
    {
        if (!is_string($properties) || strlen($properties) > 8192) {
            return [];
        }

        $decoded = json_decode(wp_unslash($properties), true);
        if (!is_array($decoded)) {
            return [];
        }

        $clean = [];
        foreach ($decoded as $key => $value) {
            if (count($clean) >= self::MAX_PROPERTIES) {
                break;
            }

            $key = sanitize_key((string)$key);
            // Keys starting with "_" steer the server (_isolated, _visitor).
            if ($key === '' || $key[0] === '_' || in_array($key, self::RESERVED_PROPERTY_KEYS, true)) {
                continue;
            }

            if ($key === 'search' && is_string($value)) {
                // Site search terms, grouped regardless of case.
                $clean[$key] = mb_substr(mb_strtolower(trim(sanitize_text_field($value))), 0, 100);
            } elseif (is_string($value)) {
                $clean[$key] = mb_substr(sanitize_text_field($value), 0, self::MAX_PROPERTY_LENGTH);
            } elseif (is_int($value) || is_float($value) || is_bool($value)) {
                $clean[$key] = $value;
            }
        }

        return $clean;
    }
}
