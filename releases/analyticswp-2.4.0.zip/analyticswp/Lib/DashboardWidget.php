<?php

namespace AnalyticsWP\Lib;

use AnalyticsWP\Lib\Admin\App;
use AnalyticsWP\Lib\Admin\Format;
use AnalyticsWP\Lib\Admin\Ui;

// psalm-suppress MissingFile - We are in the context of the plugin
if (! defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Widget on the WordPress dashboard: the last seven days at a glance, with
 * a link into the app.
 */
class DashboardWidget
{
    public static function init(): void
    {
        add_action('wp_dashboard_setup', function () {
            if (App::can_view()) {
                wp_add_dashboard_widget('analyticswp_overview_widget', 'Analytics – letzte 7 Tage', [self::class, 'render_widget_content']);
            }
        });
    }

    public static function render_widget_content(): void
    {
        if (!Reports::has_data()) {
            echo '<p>Noch keine Besuche gemessen. Die ersten Zahlen erscheinen nach dem nächsten Besuch deiner Website.</p>';
            return;
        }

        $period = Reports::period('7d');
        $currency = Reports::main_currency($period);
        $totals = Reports::totals($period, [], $currency);
        $channels = Reports::breakdown('channel', $period, [], $currency, 4);

        $tiles = [
            'visitors' => ['Besucher', Format::number($totals['current']['visitors']), true],
            'sessions' => ['Besuche', Format::number($totals['current']['sessions']), true],
            'conversions' => ['Conversions', Format::number($totals['current']['conversions']), true],
            'revenue' => ['Umsatz', Format::money($totals['current']['revenue'], $currency, 0), true],
        ];

        echo '<style>
            .awp-w-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:4px 0 14px}
            .awp-w-tile{padding:10px 12px;border:1px solid #e4e4e1;border-radius:10px}
            .awp-w-label{display:block;color:#50575e;font-size:12px}
            .awp-w-value{display:block;font-size:20px;font-weight:600;line-height:1.3}
            .awp-w-tile .awp-change{font-size:12px;color:#6b6f74}
            .awp-w-tile .awp-change.is-good{color:#0f6e68}
            .awp-w-tile .awp-change.is-bad{color:#8a4a12}
            .awp-w-tile .awp-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(1px,1px,1px,1px)}
            .awp-w-list{margin:0 0 12px}
            .awp-w-list li{display:flex;justify-content:space-between;margin:0;padding:6px 0;border-bottom:1px solid #ececea}
        </style>';

        echo '<div class="awp-w-grid">';
        foreach ($tiles as $key => [$label, $value, $higher_is_better]) {
            echo '<div class="awp-w-tile"><span class="awp-w-label">' . esc_html($label) . '</span><span class="awp-w-value">' . esc_html($value) . '</span>'
                . Ui::change(Format::change($totals['current'][$key], $totals['previous'][$key]), $higher_is_better) . '</div>';
        }
        echo '</div>';

        if (!empty($channels)) {
            echo '<ul class="awp-w-list">';
            foreach ($channels as $row) {
                echo '<li><span>' . esc_html(Ui::dimension_label('channel', $row['value'])) . '</span><span>' . esc_html(Format::number($row['sessions'])) . ' Besuche</span></li>';
            }
            echo '</ul>';
        }

        echo '<p><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=' . App::SLUG . '&range=7d')) . '">Zur Auswertung</a></p>';
    }
}
