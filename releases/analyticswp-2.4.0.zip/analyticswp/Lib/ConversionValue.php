<?php

namespace AnalyticsWP\Lib;

use AnalyticsWP\Lib\Admin\Format;

/**
 * "Was ist eine Anfrage wert?": an estimated value per form submission and
 * per contact click, optionally per form. Lets sites without a shop compare
 * channels by value. Always shown apart from revenue, never added to it.
 *
 * Settings: value_per_form, value_per_contact (decimal strings, '' = none),
 * form_values (array "type|name" => decimal string).
 */
class ConversionValue
{
    /** A decimal amount as stored: digits, optional ".dd". */
    const PATTERN = '/^\d{1,7}(\.\d{1,2})?$/';

    /** Most per-form values kept. */
    const MAX_FORMS = 200;

    /**
     * Normalise user input ("49,90 €") to a stored amount, or '' for none,
     * or null when it is not an amount.
     */
    public static function sanitize(string $input): ?string
    {
        $value = trim(str_replace([',', '€', ' '], ['.', '', ''], $input));
        if ($value === '') {
            return '';
        }

        return preg_match(self::PATTERN, $value) ? $value : null;
    }

    public static function per_form(): float
    {
        return (float)self::stored('value_per_form');
    }

    public static function per_contact(): float
    {
        return (float)self::stored('value_per_contact');
    }

    /**
     * @return array<string, string> "type|name" => amount
     */
    public static function form_values(): array
    {
        $values = SuperSimpleWP::get_setting('analyticswp', 'form_values');
        if (!is_array($values)) {
            return [];
        }

        $out = [];
        foreach ($values as $key => $value) {
            if (is_string($key) && is_scalar($value) && self::sanitize((string)$value) !== null) {
                $out[$key] = (string)$value;
            }
        }

        return $out;
    }

    public static function form_key(string $type, ?string $name): string
    {
        return $type . '|' . (string)$name;
    }

    /**
     * Value of one conversion of this type (and form name): the form's own
     * value, else the general one; purchases have revenue instead (0).
     */
    public static function of(string $type, ?string $name): float
    {
        $kind = Format::conversion_kind($type);
        if ($kind === 'form') {
            $own = self::form_values()[self::form_key($type, $name)] ?? '';
            return $own !== '' ? (float)$own : self::per_form();
        }

        return $kind === 'contact' ? self::per_contact() : 0.0;
    }

    public static function is_set(): bool
    {
        return self::per_form() > 0 || self::per_contact() > 0 || array_filter(self::form_values()) !== [];
    }

    private static function stored(string $setting): string
    {
        $value = SuperSimpleWP::get_setting('analyticswp', $setting);

        return is_string($value) && self::sanitize($value) !== null ? $value : '';
    }
}
