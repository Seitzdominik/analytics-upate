<?php

namespace AnalyticsWP\Lib;

class URLs
{

    /**
     * Builds URLs for any Admin Page thats just a function of a page_key.
     * 
     * @param string $page_key
     * @param bool $return_just_path If true, will just return the path. Otherwise the full URL.
     * @param array<string, mixed> $query_args
     * 
     * @return string
     */
    public static function admin_path($page_key, $return_just_path = false, $query_args = [])
    {
        $path = "admin.php?page={$page_key}";
        if (!empty($query_args)) {
            $path = add_query_arg($query_args, $path);
        }
        return $return_just_path ? $path : get_admin_url(null, $path);
    }


    /** 
     * @param array<string,string> $conditions
     * 
     * @return string|null
     */
    public static function admin_journey_path_for_event_where_condition($conditions)
    {
        $event = Event::find_where($conditions);
        if ($event == null) {
            return null;
        }

        if ($event['id']) {
            return self::admin_path('event_id_journeys', false, ['event_id' => $event['id']]);
        } else {
            return null;
        }
    }

    /**
     * Query parameters that are kept on a stored page URL. Everything else is
     * dropped: query strings carry e-mail addresses, names and tokens often
     * enough (password resets, newsletter links, form prefills), and
     * attribution only needs these.
     */
    const KEPT_QUERY_PARAMS = [
        'utm_source',
        'utm_medium',
        'utm_campaign',
        'utm_term',
        'utm_content',
        'utm_id',
        'gclid',
        'gbraid',
        'wbraid',
        'fbclid',
        'msclkid',
        'ttclid',
        'li_fat_id',
        'ref',
    ];

    /**
     * Path of a URL on this site ("/kontakt/"), without query string and
     * fragment, at most 191 characters (indexable in utf8mb4). URLs of
     * other hosts keep host and path.
     */
    public static function path_of(?string $url): ?string
    {
        if ($url === null || $url === '') {
            return null;
        }

        $url = self::strip_query($url);
        $home = untrailingslashit(home_url());
        if (stripos($url, $home) === 0) {
            $url = substr($url, strlen($home));
            $url = $url === '' ? '/' : $url;
        } else {
            $url = (string)preg_replace('#^https?://#i', '', $url);
        }

        return mb_substr($url, 0, 191);
    }

    /**
     * A URL without its query string and fragment. Used for referrers, whose
     * query belongs to another site.
     */
    public static function strip_query(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        $cut = strcspn($url, '?#');
        return substr($url, 0, $cut);
    }

    /**
     * A URL with only the KEPT_QUERY_PARAMS left in its query string, and no
     * fragment.
     */
    public static function strip_private_query(string $url): string
    {
        $url = trim($url);
        $base = self::strip_query($url);

        $query = (string)wp_parse_url($url, PHP_URL_QUERY);
        if ($query === '') {
            return $base;
        }

        parse_str($query, $params);

        $kept = [];
        foreach (self::KEPT_QUERY_PARAMS as $key) {
            if (isset($params[$key]) && is_scalar($params[$key]) && (string)$params[$key] !== '') {
                $kept[$key] = (string)$params[$key];
            }
        }

        return empty($kept) ? $base : $base . '?' . http_build_query($kept, '', '&', PHP_QUERY_RFC3986);
    }
}
