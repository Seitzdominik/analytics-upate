<?php

namespace AnalyticsWP\Lib;

use AnalyticsWP\Lib\Admin\Format;

/**
 * Automatic findings ("Erkenntnisse") from report rows, with minimums.
 * One place for the rules, so that the overview, the channel and page tabs
 * and the export say the same thing in the same words.
 *
 * Below the minimums a finding is "pending" instead of a guess from three
 * visits: a channel with 2 of 2 visits converting is not the best channel.
 *
 * Pure functions over the arrays Reports returns; the texts are plain
 * (escaped where they are printed).
 *
 * @psalm-type Insight = array{
 *   status: 'ok'|'pending',
 *   key: string,
 *   label: string,
 *   value: string,
 *   detail: string,
 *   channel: string|null,
 *   tab: string
 * }
 */
class Insights
{
    /** Visits in the period before any finding is made. */
    const MIN_VISITS = 100;

    /** Conversions before findings about conversions. */
    const MIN_CONVERSIONS = 3;

    /** Visits behind a rate before it is shown at all ("zu wenig" below). */
    const MIN_RATE_BASE = 10;

    /** A share gap smaller than this is not worth a sentence. */
    const MIN_SHARE_GAP = 0.05;

    /**
     * The channel with the most visits: "Organische Suche · 29 %",
     * "272 Besuche, 219 € Umsatz".
     *
     * @param list<array<string, mixed>> $channel_rows Reports::breakdown('channel', ...)
     * @return Insight
     */
    public static function largest_channel(array $channel_rows, string $currency = ''): array
    {
        $total = self::sum($channel_rows, 'sessions');
        if ($total < self::MIN_VISITS) {
            return self::pending('largest_channel', 'Größter Kanal', 'ab ' . self::MIN_VISITS . ' Besuchen', 'campaigns');
        }

        $top = self::max_by($channel_rows, 'sessions');
        $detail = Format::number((int)$top['sessions']) . ' Besuche';
        if ((float)$top['revenue'] > 0 && $currency !== '') {
            $detail .= ', ' . Format::money((float)$top['revenue'], $currency, 0) . ' Umsatz';
        }

        return self::ok(
            'largest_channel',
            'Größter Kanal',
            Format::channel($top['value']) . ' · ' . Format::percent((int)$top['sessions'] / $total, 0),
            $detail,
            $top['value'],
            'campaigns'
        );
    }

    /**
     * The channel whose visits convert best, among those with enough
     * visits for a rate: "KI-Assistenten · 5,9 %", "3 Conversions aus 51
     * Besuchen".
     *
     * @param list<array<string, mixed>> $channel_rows
     * @return Insight
     */
    public static function best_conversion_rate(array $channel_rows): array
    {
        $visits = self::sum($channel_rows, 'sessions');
        $conversions = self::sum($channel_rows, 'conversions');
        if ($visits < self::MIN_VISITS) {
            return self::pending('best_conversion_rate', 'Beste Conversion-Rate', 'ab ' . self::MIN_VISITS . ' Besuchen', 'campaigns');
        }
        if ($conversions < self::MIN_CONVERSIONS) {
            return self::pending('best_conversion_rate', 'Beste Conversion-Rate', 'ab ' . self::MIN_CONVERSIONS . ' Conversions', 'campaigns');
        }

        $best = null;
        foreach ($channel_rows as $row) {
            if ((int)$row['sessions'] < self::MIN_RATE_BASE || (int)$row['conversions'] === 0) {
                continue;
            }
            if ($best === null || (float)$row['conversion_rate'] > (float)$best['conversion_rate']) {
                $best = $row;
            }
        }

        if ($best === null) {
            return self::pending('best_conversion_rate', 'Beste Conversion-Rate', 'noch kein Kanal mit ' . self::MIN_RATE_BASE . ' Besuchen und einer Conversion', 'campaigns');
        }

        return self::ok(
            'best_conversion_rate',
            'Beste Conversion-Rate',
            Format::channel($best['value']) . ' · ' . Format::percent((float)$best['conversion_rate']),
            Format::number((int)$best['conversions']) . ' ' . ((int)$best['conversions'] === 1 ? 'Conversion' : 'Conversions') . ' aus ' . Format::number((int)$best['sessions']) . ' Besuchen',
            $best['value'],
            'campaigns'
        );
    }

    /**
     * The most frequent conversion, a form by its name: "Kontakt · 14×",
     * "41 % aller Conversions". The kind (purchase, form, contact click)
     * is in 'channel' for the icon.
     *
     * @param list<array<string, mixed>> $type_rows Reports::conversion_types(...)
     * @return Insight
     */
    public static function top_conversion(array $type_rows): array
    {
        $total = self::sum($type_rows, 'conversions');
        if ($total < self::MIN_CONVERSIONS) {
            return self::pending('top_conversion', 'Häufigster Abschluss', 'ab ' . self::MIN_CONVERSIONS . ' Conversions', 'conversions');
        }

        $top = self::max_by($type_rows, 'conversions');
        $name = !empty($top['name']) ? (string)$top['name'] : Format::conversion_type((string)$top['type']);

        $insight = self::ok(
            'top_conversion',
            'Häufigster Abschluss',
            $name . ' · ' . Format::number((int)$top['conversions']) . '×',
            Format::percent((int)$top['conversions'] / $total, 0) . ' aller Conversions',
            null,
            'conversions'
        );
        $insight['kind'] = Format::conversion_kind((string)$top['type']);

        return $insight;
    }

    /**
     * The sentence above everything: what changed against the period
     * before, in plain words, plus the figures behind it.
     *
     * @param array<string, float|int> $current  Reports::totals()['current']
     * @param array<string, float|int> $previous Reports::totals()['previous']
     * @return array{tone: 'good'|'bad'|'neutral', title: string, text: string}
     */
    public static function summary(array $current, array $previous, int $days, string $currency): array
    {
        $before = $days === 1 ? 'am Tag davor' : 'in den ' . $days . ' Tagen davor';

        $visitors = self::trend((float)($current['visitors'] ?? 0), (float)($previous['visitors'] ?? 0));
        $conversions_known = max((int)($current['conversions'] ?? 0), (int)($previous['conversions'] ?? 0)) >= self::MIN_CONVERSIONS;
        $conversions = $conversions_known ? self::trend((float)($current['conversions'] ?? 0), (float)($previous['conversions'] ?? 0)) : null;

        $more = function (string $trend, string $noun, bool $capital): string {
            $words = [
                'big_up' => 'deutlich mehr',
                'up' => 'mehr',
                'down' => 'weniger',
                'big_down' => 'deutlich weniger',
            ];
            $text = $words[$trend] . ' ' . $noun;

            return $capital ? ucfirst($text) : $text;
        };
        $direction = function (?string $trend): int {
            return $trend === null || $trend === 'flat' ? 0 : (strpos($trend, 'up') !== false ? 1 : -1);
        };

        $v = $direction($visitors);
        $c = $direction($conversions);

        if ($conversions === null) {
            $title = $v === 0 ? 'Etwa so viele Besucher wie ' . $before . '.' : $more($visitors, 'Besucher', true) . ' als ' . $before . '.';
        } elseif ($v === 0 && $c === 0) {
            $title = 'Etwa so viele Besucher und Abschlüsse wie ' . $before . '.';
        } elseif ($v === 0) {
            $title = 'Etwa so viele Besucher wie ' . $before . ', aber ' . $more($conversions, 'Abschlüsse', false) . '.';
        } elseif ($c === 0) {
            $title = $more($visitors, 'Besucher', true) . ' als ' . $before . ', Abschlüsse etwa gleich.';
        } elseif ($v === $c) {
            $title = $more($visitors, 'Besucher', true) . ' und ' . $more($conversions, 'Abschlüsse', false) . ' als ' . $before . '.';
        } else {
            $title = $more($visitors, 'Besucher', true) . ', aber ' . $more($conversions, 'Abschlüsse', false) . ' als ' . $before . '.';
        }

        $deciding = $c !== 0 ? $c : $v;
        $tone = $deciding > 0 ? 'good' : ($deciding < 0 ? 'bad' : 'neutral');

        $parts = [Format::number((int)($current['visitors'] ?? 0)) . ' Besucher' . self::signed_in_brackets($current['visitors'] ?? 0, $previous['visitors'] ?? 0)];
        $parts[] = Format::number((int)($current['conversions'] ?? 0)) . ' Conversions' . self::signed_in_brackets($current['conversions'] ?? 0, $previous['conversions'] ?? 0);
        if ((float)($current['revenue'] ?? 0) > 0 || (float)($previous['revenue'] ?? 0) > 0) {
            $parts[] = Format::money((float)($current['revenue'] ?? 0), $currency, 0) . ' Umsatz' . self::signed_in_brackets($current['revenue'] ?? 0, $previous['revenue'] ?? 0);
        }
        $last = array_pop($parts);
        $text = (empty($parts) ? '' : implode(', ', $parts) . ' und ') . $last . '.';

        return ['tone' => $tone, 'title' => $title, 'text' => $text];
    }

    /**
     * Change from $previous to $current as up/down/flat, "big" from 25 %.
     * Under 5 % either way counts as flat.
     *
     * @return 'big_up'|'up'|'flat'|'down'|'big_down'
     */
    public static function trend(float $current, float $previous): string
    {
        if ($previous <= 0) {
            return $current > 0 ? 'big_up' : 'flat';
        }

        $change = ($current - $previous) / $previous;
        if (abs($change) < 0.05) {
            return 'flat';
        }
        if ($change > 0) {
            return $change >= 0.25 ? 'big_up' : 'up';
        }

        return $change <= -0.25 ? 'big_down' : 'down';
    }

    /**
     * "+14,7 %" / "−6,0 %" / "± 0 %", or null without a base to compare.
     *
     * @param int|float $current
     * @param int|float $previous
     */
    public static function signed_change($current, $previous): ?string
    {
        if ((float)$previous <= 0) {
            return null;
        }

        $change = round(((float)$current - (float)$previous) / (float)$previous * 100, 1);
        if ($change == 0.0) {
            return '± 0 %';
        }

        return ($change > 0 ? '+' : '−') . number_format(abs($change), 1, ',', '.') . ' %';
    }

    /**
     * @param int|float $current
     * @param int|float $previous
     */
    private static function signed_in_brackets($current, $previous): string
    {
        $change = self::signed_change($current, $previous);

        return $change === null ? '' : ' (' . $change . ')';
    }

    /** Exits of one page without any conversion before it is worth a warning. */
    const MIN_LEAKY_EXITS = 20;

    /**
     * The page with the most views: "/ · 830 Aufrufe", "387 Besuche
     * beginnen hier".
     *
     * @param list<array{path: string, pageviews: int, entries: int}> $pages
     * @return Insight
     */
    public static function top_page(array $pages): array
    {
        if (empty($pages)) {
            return self::pending('top_page', 'Meistbesucht', 'noch keine Seitenaufrufe', 'pages');
        }

        $top = self::max_by($pages, 'pageviews');

        return self::ok(
            'top_page',
            'Meistbesucht',
            $top['path'] . ' · ' . Format::number((int)$top['pageviews']) . ' Aufrufe',
            Format::number((int)$top['entries']) . ' Besuche beginnen hier',
            null,
            'pages'
        ) + ['path' => (string)$top['path']];
    }

    /**
     * The landing page whose visits convert best: "/blog/…", "4,4 %
     * Conv.-Rate, 256 € Umsatz".
     *
     * @param list<array<string, mixed>> $landing_rows Reports::breakdown('landing', ...)
     * @return Insight
     */
    public static function best_entry(array $landing_rows, string $currency = ''): array
    {
        $visits = self::sum($landing_rows, 'sessions');
        $conversions = self::sum($landing_rows, 'conversions');
        if ($visits < self::MIN_VISITS || $conversions < self::MIN_CONVERSIONS) {
            return self::pending('best_entry', 'Bester Einstieg', $visits < self::MIN_VISITS ? 'ab ' . self::MIN_VISITS . ' Besuchen' : 'ab ' . self::MIN_CONVERSIONS . ' Conversions', 'pages');
        }

        $best = null;
        foreach ($landing_rows as $row) {
            if ($row['value'] === null || (int)$row['sessions'] < self::MIN_RATE_BASE || (int)$row['conversions'] === 0) {
                continue;
            }
            if ($best === null || (float)$row['conversion_rate'] > (float)$best['conversion_rate']) {
                $best = $row;
            }
        }
        if ($best === null) {
            return self::pending('best_entry', 'Bester Einstieg', 'noch keine Einstiegsseite mit ' . self::MIN_RATE_BASE . ' Besuchen und einer Conversion', 'pages');
        }

        $detail = Format::percent((float)$best['conversion_rate']) . ' Conv.-Rate';
        if ((float)$best['revenue'] > 0 && $currency !== '') {
            $detail .= ', ' . Format::money((float)$best['revenue'], $currency, 0) . ' Umsatz';
        }

        return self::ok('best_entry', 'Bester Einstieg', (string)$best['value'], $detail, null, 'pages') + ['path' => (string)$best['value']];
    }

    /** Share of a page's views that end the visit before it counts as a dead end. */
    const MIN_EXIT_RATE = 0.5;

    /**
     * A dead end: a page where at least half of the views end the visit,
     * with no conversion in those visits. Visits that buy end on the thank
     * you page, so "no conversion at the exit" alone would hit every
     * content page; the exit rate is what makes a page stand out. The home
     * page and grouped pages (confirmations) are left out. Null when no
     * page qualifies.
     *
     * @param list<array<string, mixed>> $exit_rows Reports::breakdown('exit', ...), grouped
     * @param list<array<string, mixed>> $pages     Reports::pages(...), grouped
     * @param list<string> $skip Paths never reported (404 pages).
     * @return Insight|null
     */
    public static function leaky_exit(array $exit_rows, array $pages, array $skip = []): ?array
    {
        if (self::sum($exit_rows, 'sessions') < self::MIN_VISITS) {
            return null;
        }

        $views = [];
        foreach ($pages as $page) {
            $views[(string)$page['path']] = (int)$page['pageviews'];
        }

        $found = null;
        $best_rate = self::MIN_EXIT_RATE;
        foreach ($exit_rows as $row) {
            $path = (string)($row['path'] ?? $row['value']);
            if ($path === '' || $path === '/' || strpos($path, '…') !== false || in_array($path, $skip, true)
                || (int)$row['conversions'] > 0 || (int)$row['sessions'] < self::MIN_LEAKY_EXITS || empty($views[$path])) {
                continue;
            }
            $rate = min(1, (int)$row['sessions'] / $views[$path]);
            if ($rate >= $best_rate) {
                $best_rate = $rate;
                $found = [$path, (int)$row['sessions'], $rate];
            }
        }
        if ($found === null) {
            return null;
        }

        return self::ok(
            'leaky_exit',
            'Viele gehen hier ohne Abschluss',
            $found[0] . ' · ' . Format::number($found[1]) . ' Ausstiege',
            Format::percent($found[2], 0) . ' der Aufrufe enden hier, ohne Conversion.',
            null,
            'pages'
        ) + ['path' => $found[0]];
    }

    /**
     * The channel that brings a much larger share of revenue (or
     * conversions) than of visits: "Über KI-Assistenten kommen 5,5 % der
     * Besuche, aber 26,6 % des Umsatzes." Null when nothing stands out or
     * the data is too thin.
     *
     * @param list<array<string, mixed>> $channel_rows
     * @param 'revenue'|'conversions' $basis
     * @return array{channel: string|null, visit_share: float, value_share: float, text: string}|null
     */
    public static function value_gap(array $channel_rows, string $basis = 'revenue'): ?array
    {
        $visits = self::sum($channel_rows, 'sessions');
        $conversions = self::sum($channel_rows, 'conversions');
        $total = self::sum($channel_rows, $basis);
        if ($visits < self::MIN_VISITS || $conversions < self::MIN_CONVERSIONS || $total <= 0) {
            return null;
        }

        $found = null;
        $gap = self::MIN_SHARE_GAP;
        foreach ($channel_rows as $row) {
            if ((int)$row['sessions'] < self::MIN_RATE_BASE) {
                continue;
            }
            $visit_share = (int)$row['sessions'] / $visits;
            $value_share = (float)$row[$basis] / $total;
            if ($value_share - $visit_share > $gap) {
                $gap = $value_share - $visit_share;
                $found = [$row['value'], $visit_share, $value_share];
            }
        }

        if ($found === null) {
            return null;
        }

        [$channel, $visit_share, $value_share] = $found;

        return [
            'channel' => $channel,
            'visit_share' => $visit_share,
            'value_share' => $value_share,
            'text' => 'Über ' . Format::channel($channel) . ' kommen ' . Format::percent($visit_share) . ' der Besuche, aber '
                . Format::percent($value_share) . ($basis === 'revenue' ? ' des Umsatzes.' : ' der Conversions.'),
        ];
    }

    /**
     * Is a rate over $base visits worth showing?
     */
    public static function rate_is_meaningful(int $base): bool
    {
        return $base >= self::MIN_RATE_BASE;
    }

    /**
     * @param list<array<string, mixed>> $rows
     */
    private static function sum(array $rows, string $key): float
    {
        $sum = 0.0;
        foreach ($rows as $row) {
            $sum += (float)($row[$key] ?? 0);
        }

        return $sum;
    }

    /**
     * @param list<array<string, mixed>> $rows
     * @return array<string, mixed>
     */
    private static function max_by(array $rows, string $key): array
    {
        $best = $rows[0];
        foreach ($rows as $row) {
            if ((float)$row[$key] > (float)$best[$key]) {
                $best = $row;
            }
        }

        return $best;
    }

    /**
     * @return Insight
     */
    private static function ok(string $key, string $label, string $value, string $detail, ?string $channel, string $tab): array
    {
        return ['status' => 'ok', 'key' => $key, 'label' => $label, 'value' => $value, 'detail' => $detail, 'channel' => $channel, 'tab' => $tab];
    }

    /**
     * @return Insight
     */
    private static function pending(string $key, string $label, string $why, string $tab): array
    {
        return ['status' => 'pending', 'key' => $key, 'label' => $label, 'value' => 'Ausstehend', 'detail' => $why, 'channel' => null, 'tab' => $tab];
    }
}
