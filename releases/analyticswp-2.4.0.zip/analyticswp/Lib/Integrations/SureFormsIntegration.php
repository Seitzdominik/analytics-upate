<?php

namespace AnalyticsWP\Lib\Integrations;

use AnalyticsWP\Lib\Event;
use AnalyticsWP\Lib\Integrations;

/**
 * SureForms submissions as conversions.
 *
 * Hooks `srfm_form_submit`, which SureForms fires inside the REST request
 * (sureforms/v1/submit-form) the visitor's browser sends, only after the
 * submission passed validation. The conversion therefore lands in the
 * visitor's session and inherits its channel and campaign. A failed or
 * empty submission never reaches the hook.
 *
 * Only which form was sent is recorded. The submitted values (names, e-mail
 * addresses, messages) are not; SureForms keeps them in its own entries.
 *
 * With "GDPR: do not store entries" SureForms fires the hook without an
 * entry ID. The submission still counts, it just cannot be deduplicated or
 * linked to an entry.
 */
class SureFormsIntegration implements IntegrationInterface
{
    const SLUG = 'sureforms';

    const CONVERSION_TYPE = 'sureforms';

    public static function is_available(): bool
    {
        return defined('SRFM_VER');
    }

    public static function get_integration_description()
    {
        return [
            'slug' => self::SLUG,
            'isAvailable' => self::is_available(),
            'name' => 'SureForms',
            'description' => 'Formular-Absendungen als Conversion, zugeordnet zur Session des Besuchers. Formularinhalte werden nicht gespeichert.',
            'category' => 'Forms',
        ];
    }

    public static function add_hooks(): void
    {
        if (!self::is_available() || !Integrations::is_integration_enabled(self::SLUG)) {
            return;
        }

        add_action('srfm_form_submit', [self::class, 'track_form_submit'], 10, 1);
    }

    /**
     * @param mixed $response SureForms' submit response: success, form_id,
     *                        entry_id (absent without stored entries),
     *                        form_name, to_emails, message, data.
     * @return array{error: string}|int|null
     */
    public static function track_form_submit($response)
    {
        try {
            if (!is_array($response) || empty($response['success']) || empty($response['form_id'])) {
                return null;
            }

            $form_id = (int)$response['form_id'];
            $entry_id = isset($response['entry_id']) ? (int)$response['entry_id'] : 0;

            $form_name = isset($response['form_name']) && is_string($response['form_name'])
                ? html_entity_decode($response['form_name'], ENT_QUOTES, 'UTF-8')
                : get_the_title($form_id);

            $properties = [
                'conversion_type' => self::CONVERSION_TYPE,
                'form_id' => $form_id,
                'form_name' => (string)$form_name,
            ];

            if ($entry_id > 0) {
                $properties['conversion_id'] = $entry_id;
                $properties['entry_id'] = $entry_id;
                $properties['unique_event_identifier'] = 'sureforms_entry_' . $entry_id;
            }

            /**
             * Skip a SureForms submission, e.g. a newsletter form that is not
             * meant to count as a conversion.
             *
             * @param bool  $track    Whether to record it.
             * @param int   $form_id  SureForms form (post) ID.
             * @param array $response SureForms' submit response.
             */
            if (!apply_filters('analyticswp_track_sureforms_submission', true, $form_id, $response)) {
                return null;
            }

            return Event::track_server_event('form_submission', $properties);
        } catch (\Throwable $e) {
            error_log('AnalyticsWP: Error tracking SureForms submission - ' . $e->getMessage());
            return ['error' => 'Failed to track SureForms submission: ' . $e->getMessage()];
        }
    }
}
