<?php

namespace AnalyticsWP\Lib\Integrations;

use AnalyticsWP\Lib\Event;
use AnalyticsWP\Lib\Integrations;

/**
 * SureCart purchases as conversions, with revenue.
 *
 * Main path: `surecart/checkout_confirmed`. SureCart fires it inside the REST
 * request with which the customer's browser confirms the checkout, so the
 * conversion lands in the customer's own session and inherits its channel and
 * campaign. (Pixel Made Simple confirmed this live against SureCart 4.9.)
 *
 * Fallback: `surecart/order_updated` with status "paid", which SureCart fires
 * from its webhook queue. That request is not the customer's, so the
 * conversion gets a session of its own (channel "direct"); it only exists so
 * that revenue is not lost when the confirm request never ran. Both paths
 * share one unique_event_identifier per checkout, so an order is counted once.
 *
 * Upstream recorded `checkout_confirmed` with the checkout's UUID as
 * conversion_id. That column is numeric and validated as an int, so every
 * SureCart event was refused and nothing was ever stored. The UUID now lives
 * in the unique_event_identifier and in the properties.
 */
class SureCartIntegration implements IntegrationInterface
{
    const SLUG = 'surecart';

    const CONVERSION_TYPE = 'surecart_checkout';

    /** Checkout statuses that are an order. "processing" covers manual payment methods. */
    const ORDER_STATUSES = ['paid', 'processing', 'complete', 'completed', 'confirmed'];

    /**
     * Currencies without minor units (Stripe's list). SureCart stores amounts
     * in the smallest unit, so 1999 is 19.99 EUR but 1999 JPY.
     */
    const ZERO_DECIMAL_CURRENCIES = ['BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF'];

    public static function is_available(): bool
    {
        return defined('SURECART_PLUGIN_FILE');
    }

    public static function get_integration_description()
    {
        return [
            'slug' => self::SLUG,
            'isAvailable' => self::is_available(),
            'name' => 'SureCart',
            'description' => 'Käufe als Conversion mit Umsatz, zugeordnet zur Session des Käufers.',
            'category' => 'eCommerce',
        ];
    }

    public static function add_hooks(): void
    {
        if (!self::is_available() || !Integrations::is_integration_enabled(self::SLUG)) {
            return;
        }

        add_action('surecart/checkout_confirmed', [self::class, 'track_checkout_confirmed'], 10, 2);
        add_action('surecart/order_updated', [self::class, 'track_paid_order'], 10, 2);
    }

    /**
     * @param object $checkout \SureCart\Models\Checkout
     * @param mixed  $request  \WP_REST_Request
     * @return array{error: string}|int|null
     */
    public static function track_checkout_confirmed($checkout, $request = null)
    {
        try {
            if (!is_object($checkout) || empty($checkout->id)) {
                return null;
            }

            if (!in_array((string)($checkout->status ?? ''), self::ORDER_STATUSES, true)) {
                return null;
            }

            return self::track_checkout($checkout, 'checkout');
        } catch (\Throwable $e) {
            error_log('AnalyticsWP: Error tracking SureCart checkout - ' . $e->getMessage());
            return ['error' => 'Failed to track SureCart checkout: ' . $e->getMessage()];
        }
    }

    /**
     * @param object $order \SureCart\Models\Order
     * @param mixed  $data  Raw webhook data (unused).
     * @return array{error: string}|int|null
     */
    public static function track_paid_order($order, $data = null)
    {
        try {
            if (!is_object($order) || (string)($order->status ?? '') !== 'paid' || empty($order->checkout)) {
                return null;
            }

            $checkout = $order->checkout;
            if (!is_object($checkout) && class_exists('\SureCart\Models\Checkout')) {
                $checkout = \SureCart\Models\Checkout::find((string)$order->checkout);
            }
            if (!is_object($checkout) || is_wp_error($checkout) || empty($checkout->id)) {
                return null;
            }

            // Someone other than the customer is logged in: an admin marking
            // the order paid in the backend. Their request is not the
            // customer's visit; leave it to the webhook.
            if (is_user_logged_in() && !empty($checkout->email) && strcasecmp((string)wp_get_current_user()->user_email, (string)$checkout->email) !== 0) {
                return null;
            }

            return self::track_checkout($checkout, 'webhook');
        } catch (\Throwable $e) {
            error_log('AnalyticsWP: Error tracking SureCart order - ' . $e->getMessage());
            return ['error' => 'Failed to track SureCart order: ' . $e->getMessage()];
        }
    }

    /**
     * @param object $checkout
     * @param 'checkout'|'webhook' $via
     * @return array{error: string}|int|null
     */
    private static function track_checkout($checkout, string $via)
    {
        // Test mode orders are not revenue.
        if (isset($checkout->live_mode) && $checkout->live_mode === false && !apply_filters('analyticswp_track_surecart_test_orders', false)) {
            return null;
        }

        $currency = strtoupper((string)($checkout->currency ?? ''));
        $order = $checkout->order ?? null;

        $properties = [
            'conversion_type' => self::CONVERSION_TYPE,
            'unique_event_identifier' => 'surecart_checkout_' . $checkout->id,
            'revenue' => self::amount($checkout->total_amount ?? 0, $currency),
            'currency' => $currency !== '' ? $currency : null,
            'checkout_id' => (string)$checkout->id,
            'order_id' => is_object($order) ? (string)($order->id ?? '') : (is_string($order) ? $order : null),
            'order_number' => is_object($order) ? (string)($order->number ?? '') : null,
            'status' => (string)($checkout->status ?? ''),
            'subtotal' => self::amount($checkout->subtotal_amount ?? 0, $currency),
            'discount' => self::amount($checkout->discount_amount ?? 0, $currency),
            'tax' => self::amount($checkout->tax_amount ?? 0, $currency),
            'via' => $via,
            '_isolated' => $via === 'webhook',
        ];

        return Event::track_server_event('conversion', array_filter($properties, function ($value) {
            return $value !== null && $value !== '';
        }));
    }

    /**
     * An amount in SureCart's smallest unit as a decimal number.
     *
     * @param mixed $amount
     */
    public static function amount($amount, string $currency): float
    {
        $divisor = in_array($currency, self::ZERO_DECIMAL_CURRENCIES, true) ? 1 : 100;

        return round((float)$amount / $divisor, 4);
    }
}
