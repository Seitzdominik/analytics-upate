<?php

namespace AnalyticsWP\Lib\Integrations;

use AnalyticsWP\Lib\Event;
use AnalyticsWP\Lib\Integrations;
use AnalyticsWP\Lib\OrderOrigin;
use AnalyticsWP\Lib\SuperSimpleWP;
use AnalyticsWP\Lib\Utils;
use AnalyticsWP\Lib\Validators;
use AnalyticsWP\Lib\Visitor;

/**
 * WooCommerce orders as conversions with revenue, and their origin
 * (OrderOrigin) in the order list, on the order screen and in the
 * "Neue Bestellung" e-mail.
 */
class WooCommerceIntegration implements IntegrationInterface
{
    const SLUG = 'woocommerce';

    /**
     * Statuses that make an order a conversion: paid, or placed with a
     * payment method that settles later (bank transfer, cash on delivery).
     * Not "pending", "failed" or the block checkout's "checkout-draft".
     */
    const ORDER_STATUSES = ['processing', 'completed', 'on-hold'];

    /** Order meta: the visitor key from the checkout request, or "excluded". */
    const VISITOR_META = '_analyticswp_visitor';

    public static function is_available(): bool
    {
        return function_exists('WC');
    }

    public static function get_integration_description()
    {
        return [
            'slug' => self::SLUG,
            'isAvailable' => self::is_available(),
            'name' => 'WooCommerce',
            'description' => 'Bestellungen als Conversion mit Umsatz. Herkunft in der Bestellliste, an der Bestellung und in der E-Mail „Neue Bestellung“.',
            'category' => 'eCommerce',
        ];
    }

    public static function add_hooks(): void
    {
        // Check if woocommerce is active on this site
        if (!self::is_available() || !Integrations::is_integration_enabled(self::SLUG)) {
            return;
        }

        // The checkout request is the customer's: remember who they are.
        add_action('woocommerce_checkout_create_order', [self::class, 'remember_visitor'], 10, 1);
        add_action('woocommerce_store_api_checkout_update_order_meta', [self::class, 'remember_visitor'], 10, 1);

        // Count the order once it is placed or paid, in whichever request
        // that happens. Upstream counted it on woocommerce_new_order, which
        // the block checkout fires for its drafts: abandoned checkouts
        // became conversions.
        add_action('woocommerce_order_status_changed', [self::class, 'track_status_change'], 10, 3);
        add_action('woocommerce_thankyou', [self::class, 'track_order'], 10);

        add_action('woocommerce_subscription_renewal_payment_complete', [self::class, 'track_subscription_renewal'], 10, 2);

        add_filter('manage_edit-shop_order_columns', [self::class, 'add_source_column']);
        add_action('manage_shop_order_posts_custom_column', [self::class, 'populate_source_column'], 1000, 2);
        add_filter('woocommerce_shop_order_list_table_columns', [self::class, 'add_source_column']);
        add_action('woocommerce_shop_order_list_table_custom_column', [self::class, 'populate_source_column'], 1000, 2);


        add_filter('woocommerce_email_additional_content_new_order', [self::class, 'custom_additional_content_new_order_email'], 99, 3);

        /**
         * Meta Box on Admin Order page
         */
        add_action('add_meta_boxes', [self::class, 'add_meta_boxes']);

        /**
         * WooCommerce Checkout - Where did you hear about us?
         */
        $how_did_you_hear_field_position = (string)SuperSimpleWP::get_setting('analyticswp', 'how_did_you_hear');
        if (!empty($how_did_you_hear_field_position) && $how_did_you_hear_field_position !== 'disable') {
            // deal with saving the data
            add_action($how_did_you_hear_field_position, [self::class, 'add_custom_checkout_field']);
            add_action('woocommerce_checkout_update_order_meta', [self::class, 'save_custom_checkout_field']);
        }
    }

    /**
     * Origin section in the "Neue Bestellung" e-mail to the shop owner.
     *
     * @param string $message
     * @param mixed  $order \WC_Order
     * @param mixed  $email \WC_Email
     *
     * @return string
     */
    public static function custom_additional_content_new_order_email($message, $order = null, $email = null)
    {
        try {
            if (!(bool)SuperSimpleWP::get_setting('analyticswp', 'enable_woocommerce_order_notification_source_section') || !($order instanceof \WC_Order)) {
                return $message;
            }

            $origin = self::origin_for_order_id($order->get_id());
            $html = OrderOrigin::render($origin, false, true);
            $where = self::get_analyticswp_where_heard_about_us_for_order_id($order->get_id());
            if ($where !== '') {
                $html .= '<br>Angabe an der Kasse: ' . esc_html($where);
            }

            $plain = is_object($email) && method_exists($email, 'get_email_type') && $email->get_email_type() === 'plain';
            if ($plain) {
                $text = (string)preg_replace('/<a href="([^"]*)">[^<]*<\/a>/', 'Journey: $1', $html);
                $text = wp_strip_all_tags(str_replace('<br>', "\n", $text));
                return $message . "\n\nHerkunft\n" . html_entity_decode($text, ENT_QUOTES, 'UTF-8');
            }

            return $message . '<h2>Herkunft</h2><p>' . $html . '</p>';
        } catch (\Throwable $e) {
            return $message;
        }
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function origin_for_order_id(int $order_id): ?array
    {
        return OrderOrigin::find(['woocommerce_order', 'woocommerce_order-subscription-renewal'], (string)$order_id);
    }


    /**
     * Store the visitor key of the checkout request on the order, so that a
     * payment confirmed later in another request is still theirs.
     *
     * @param mixed $order \WC_Order
     */
    public static function remember_visitor($order): void
    {
        try {
            if (!($order instanceof \WC_Order) || wp_doing_cron() || (is_admin() && !wp_doing_ajax())) {
                return;
            }

            $excluded = is_user_logged_in() && Utils::is_current_user_excluded_from_tracking();
            $order->update_meta_data(self::VISITOR_META, $excluded ? 'excluded' : Visitor::key());
            if ($order->get_id() > 0) {
                $order->save_meta_data();
            }
        } catch (\Throwable $e) {
            error_log('AnalyticsWP: remembering the WooCommerce visitor failed - ' . $e->getMessage());
        }
    }

    /**
     * @param int    $order_id
     * @param string $from
     * @param string $to
     */
    public static function track_status_change($order_id, $from = '', $to = ''): void
    {
        if (in_array((string)$to, self::ORDER_STATUSES, true)) {
            self::track_order((int)$order_id);
        }
    }

    /**
     * @param int $order_id
     *
     * @return array{error: string}|int|null
     */
    public static function track_order($order_id)
    {
        if (!$order_id) {
            return;
        }

        $order = \wc_get_order($order_id);
        if (!($order instanceof \WC_Order) || !in_array($order->get_status(), self::ORDER_STATUSES, true)) {
            return;
        }

        $visitor = (string)$order->get_meta(self::VISITOR_META);
        if ($visitor === 'excluded') {
            return;
        }

        ///////////////////////////////////////////////////////////////////////////
        // For now, check if a conversion event was already tracked for this order
        // If it was, don't track it again
        if (count(Event::where([
            'conversion_id' => (string)$order_id,
            'conversion_type' => 'woocommerce_order'
        ])) > 0) {
            return;
        }
        ///////////////////////////////////////////////////////////////////////////


        // Guest or registered, the order is the same conversion. The billing
        // e-mail is not stored; the order holds it.
        $r = Event::track_server_event('conversion', [
            'conversion_id' => $order_id,
            'conversion_type' => 'woocommerce_order',
            // thankyou, new_order and completed can run at the same time.
            'unique_event_identifier' => 'woocommerce_order_' . $order_id,
            'user_id' => $order->get_user_id(),
            'revenue' => (float)$order->get_total(),
            'currency' => $order->get_currency(),
            '_visitor' => $visitor,
        ]);

        return $r;
    }

    /**
     * A subscription renewal: paid by cron, without a visit.
     *
     * @param mixed $_subscription TODO this is a \WC_Subscription, but we don't have the stubs loaded
     * @param \WC_Order $renewal_order
     * @return array{error: string}|int|null
     */
    public static function track_subscription_renewal($_subscription, $renewal_order)
    {
        // get user id and email from the order
        $order = wc_get_order($renewal_order);

        if (!($order instanceof \WC_Order)) {
            return;
        }

        $r = Event::track_server_event('conversion', [
            'conversion_id' => $order->get_id(),
            'conversion_type' => 'woocommerce_order-subscription-renewal',
            'unique_event_identifier' => 'woocommerce_order_' . $order->get_id(),
            'user_id' => $order->get_user_id(),
            'revenue' => (float)$order->get_total(),
            'currency' => $order->get_currency(),
        ]);

        return $r;
    }

    /**
     * Adds a new 'Source' column to the WooCommerce Orders table.
     *
     * @param string[] $columns Current columns on the list screen.
     *
     * @return string[] Updated columns on the list screen.
     */
    public static function add_source_column($columns)
    {
        // Order origin is analytics data: only for roles that may see it.
        if (!\AnalyticsWP\Lib\Admin\App::can_view()) {
            return $columns;
        }
        $columns['order_analyticswp_source'] = 'Herkunft (Analytics)';
        return $columns;
    }


    /**
     * Populates the 'Source' column.
     *
     * @param string $column Name of the current column.
     * @param int|\WC_Order $post_id_or_order_object
     *
     * @return void
     */
    public static function populate_source_column($column, $post_id_or_order_object)
    {
        if ('order_analyticswp_source' === $column) {
            $order_id = ($post_id_or_order_object instanceof \WC_Order) ? $post_id_or_order_object->get_id() : $post_id_or_order_object;
            echo OrderOrigin::render(self::origin_for_order_id((int)$order_id), true);
        }
    }


    /**
     * @return void
     */
    public static function add_meta_boxes()
    {
        if (!\AnalyticsWP\Lib\Admin\App::can_view()) {
            return;
        }
        // WooCommerce Admin > Order > Edit Order
        $callback =
            /**
             * @param \WP_Post|\WC_Order $post
             * @return void
             */
            function ($post) {
                $order_id = $post instanceof \WC_Order ? $post->get_id() : (int)$post->ID;
                echo '<p style="line-height:1.6">' . OrderOrigin::render(self::origin_for_order_id($order_id)) . '</p>';
                $where = self::get_analyticswp_where_heard_about_us_for_order_id($order_id);
                if ($where !== '') {
                    echo '<p>Angabe an der Kasse: ' . esc_html($where) . '</p>';
                }
            };

        $screen = self::get_shop_order_screen();
        add_meta_box('analytics-wp_meta-box_shop-order', 'Herkunft (Analytics)', $callback, $screen, 'side', 'high');
    }

    public static function get_shop_order_screen(): string
    {
        $screen = 'shop_order';

        try {
            /** @psalm-suppress MixedMethodCall - This one is ok. */
            $screen = class_exists('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController') && wc_get_container()->get('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController')->custom_orders_table_usage_is_enabled()
                ? wc_get_page_screen_id('shop-order')
                : 'shop_order';
        } catch (\Exception $e) {
            // Log the exception or handle it as needed
            error_log('Error in getting shop order screen: ' . $e->getMessage());
        }

        return $screen;
    }

    /**
     * @return array<string, string>
     */
    public static function get_wc_field_positions()
    {
        return Validators::array_of_string_keys_and_values(apply_filters('wc_customer_source_checkout_field_actions', array(
            'woocommerce_before_order_notes' => 'Vor den Bestellnotizen',
            'woocommerce_after_order_notes' => 'Nach den Bestellnotizen',
            'woocommerce_before_checkout_billing_form' => 'Vor der Rechnungsadresse',
            'woocommerce_after_checkout_billing_form' => 'Nach der Rechnungsadresse',
            'woocommerce_before_checkout_shipping_form' => 'Vor der Lieferadresse',
            'woocommerce_after_checkout_shipping_form' => 'Nach der Lieferadresse',
        )));
    }

    /**
     * Adds a custom checkout field to the WooCommerce checkout page.
     *
     * This function hooks into the WooCommerce checkout process and adds a text field
     * where customers can specify how they heard about the product.
     *
     * @param \WC_Checkout $checkout The WooCommerce checkout object.
     *
     * @return void
     */
    public static function add_custom_checkout_field($checkout)
    {
        woocommerce_form_field('analyticswp_where_heard_about_us', array(
            'type' => 'text',
            'class' => array(
                'analyticswp-checkout-field form-row-wide'
            ),
            'label' => (string)apply_filters('analyticswp_where_heard_label', 'Wie hast du von uns erfahren?'),
            'required' => false,
            'maxlength' => 200,
        ), $checkout->get_value('analyticswp_where_heard_about_us'));
    }

    /**
     * Saves the custom checkout field data to the order meta.
     *
     * This function checks if the 'Where did you hear about us?' field is set in the POST data
     * and saves its value to the order meta if present.
     *
     * @param int $order_id The ID of the WooCommerce order.
     *
     * @return void
     */
    public static function save_custom_checkout_field($order_id)
    {
        $val = isset($_POST['analyticswp_where_heard_about_us']) && is_string($_POST['analyticswp_where_heard_about_us'])
            ? sanitize_text_field(wp_unslash($_POST['analyticswp_where_heard_about_us']))
            : '';
        $order = $val !== '' ? wc_get_order($order_id) : null;

        // Order meta, not post meta: with HPOS the order is no post.
        if ($order instanceof \WC_Order) {
            $order->update_meta_data('analyticswp_where_heard_about_us', mb_substr($val, 0, 200));
            $order->save_meta_data();
        }
    }

    /**
     * @param int $order_id
     * @return string
     */
    public static function get_analyticswp_where_heard_about_us_for_order_id($order_id): string
    {
        $order = wc_get_order($order_id);

        return $order instanceof \WC_Order ? (string)$order->get_meta('analyticswp_where_heard_about_us') : '';
    }
}
