<?php

namespace AnalyticsWP\Lib\Integrations;

use AnalyticsWP\Lib\Event;
use AnalyticsWP\Lib\Integrations;
use AnalyticsWP\Lib\SuperSimpleWP;

/**
 * AnalyticsWP Integration for Fluent Forms
 * 
 * This integration allows you to track form submissions and conversions from Fluent Forms.
 * 
 * Features:
 * - Automatically tracks all form submissions
 * - Option to track submissions as conversions
 * - Adds form analytics data to the Fluent Forms entry view
 * - Links form entries back to user journeys
 * - Customizable event names and properties
 * 
 * To use this integration:
 * 1. Navigate to Fluent Forms > Forms
 * 2. Edit a form
 * 3. Go to Settings > AnalyticsWP
 * 4. Enable tracking and configure options
 * 
 * The integration will then automatically track all submissions for the configured forms.
 */
class FluentFormsIntegration implements IntegrationInterface
{
    const SLUG = 'fluent-forms';

    public static function is_available(): bool
    {
        return defined('FLUENTFORM');
    }

    public static function get_integration_description()
    {
        return [
            'slug' => self::SLUG,
            'isAvailable' => self::is_available(),
            'name' => 'Fluent Forms',
            'description' => 'Track form submissions and conversions with Fluent Forms',
            'category' => 'Forms',
        ];
    }

    /**
     * Initialize the integration by setting up all necessary hooks
     * 
     * @return void
     */
    public static function add_hooks(): void
    {
        // Check if Fluent Forms is active and this integration is enabled
        if (!self::is_available() || !Integrations::is_integration_enabled(self::SLUG)) {
            return;
        }


        // Track form submissions
        add_action('fluentform/submission_inserted', [self::class, 'track_form_submission'], 10, 3);
    }


    /**
     * Track form submissions in AnalyticsWP
     * 
     * @param int $entryId Entry ID
     * @param array $formData Form submission data
     * @param \FluentForm\App\Models\Form $form Form object
     * @return void
     */
    public static function track_form_submission($entryId, $formData, $form): void
    {
        try {
            // Only which form, never what was entered (upstream copied every
            // field). The entry ID may arrive as a numeric string.
            $entry_id = (int)$entryId;
            $properties = [
                'conversion_type' => 'fluent_forms',
                'form_id' => (string)$form->id,
                'form_name' => (string)$form->title,
            ];
            if ($entry_id > 0) {
                $properties['conversion_id'] = $entry_id;
                $properties['unique_event_identifier'] = 'fluent_forms_submission_' . $entry_id;
            }

            Event::track_server_event('form_submission', $properties);
        } catch (\Throwable $th) {
            error_log('AnalyticsWP Fluent Forms Integration Error: ' . $th->getMessage());
        }
    }

    /**
     * Add analytics card to entry details page
     * 
     * @param array $cards Current cards
     * @param array $entry Entry data
     * @return array Modified cards array
     */
    public static function add_analytics_card($cards, $entry): array
    {
        try {
            $entry_id = $entry->id;

            // Get journey URL from AnalyticsWP
            $journey_path = \AnalyticsWP\Lib\URLs::admin_journey_path_for_event_where_condition([
                'conversion_type' => 'fluent_forms',
                'conversion_id' => $entry_id
            ]);

            if ($journey_path) {
                $cards[] = [
                    'title' => 'AnalyticsWP',
                    'content' => sprintf(
                        '<a href="%s" class="button button-secondary">%s</a>',
                        esc_url($journey_path),
                        esc_html__('View User Journey', 'analyticswp')
                    )
                ];
            }
        } catch (\Throwable $th) {
            error_log('AnalyticsWP Fluent Forms Integration Error: ' . $th->getMessage());
        }

        return $cards;
    }
}
