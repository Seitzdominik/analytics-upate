<?php

namespace AnalyticsWP\Lib\Integrations;

use AnalyticsWP\Lib\Event;
use AnalyticsWP\Lib\Integrations;

/**
 * Elementor: forms of Elementor Pro count as conversions, buttons and
 * calls to action count clicks when switched on in the widget.
 *
 * Clicks need no script of their own: the widget's wrapper gets the
 * data-awp-event attributes the tracker already reads (analyticswp.js),
 * so it works with page caches and without jQuery. Upstream added inline
 * jQuery from elementor/frontend/after_render to wp_enqueue_scripts, a hook
 * that had already run by then: clicks were never counted.
 *
 * Forms: every Elementor Pro form counts, unless "Als Conversion zählen" is
 * switched off in the form. Only the form's name, never what was entered.
 */
class ElementorIntegration implements IntegrationInterface
{
    const SLUG = 'elementor';

    const CONVERSION_TYPE = 'elementor_form';

    /** Widget => section the controls go after. */
    const SECTIONS = [
        'form' => 'section_form_options',
        'button' => 'section_button',
        'call-to-action' => 'section_content',
    ];

    public static function is_available(): bool
    {
        return did_action('elementor/loaded') > 0;
    }

    public static function get_integration_description()
    {
        return [
            'slug' => self::SLUG,
            'isAvailable' => self::is_available(),
            'name' => 'Elementor',
            'description' => 'Form submissions of Elementor Pro as conversions, clicks on buttons and calls to action.',
            'category' => 'Site Builder',
        ];
    }

    public static function add_hooks(): void
    {
        if (!self::is_available() || !Integrations::is_integration_enabled(self::SLUG)) {
            return;
        }

        add_action('elementor/element/after_section_end', [self::class, 'add_tracking_controls'], 999, 2);
        add_action('elementor/frontend/before_render', [self::class, 'mark_widget']);
        add_action('elementor_pro/forms/new_record', [self::class, 'track_form_submission'], 10, 2);
    }

    /**
     * The "Analytics" section in the widget's content tab.
     *
     * @param \Elementor\Controls_Stack $element
     * @param string $section_id
     */
    public static function add_tracking_controls($element, $section_id): void
    {
        try {
            $name = $element->get_name();
            if (!isset(self::SECTIONS[$name]) || $section_id !== self::SECTIONS[$name]) {
                return;
            }

            $element->start_controls_section('analyticswp_tracking_section', [
                'label' => 'Analytics',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]);

            if ($name === 'form') {
                $element->add_control('analyticswp_conversion', [
                    'label' => 'Als Conversion zählen',
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'default' => 'yes',
                    'label_on' => 'Ja',
                    'label_off' => 'Nein',
                    'description' => 'Gezählt wird nur der Name des Formulars, nie was eingegeben wurde.',
                ]);
            } else {
                $element->add_control('enable_tracking', [
                    'label' => 'Klicks zählen',
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'default' => '',
                    'label_on' => 'Ja',
                    'label_off' => 'Nein',
                ]);
                $element->add_control('event_name', [
                    'label' => 'Name des Ereignisses',
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => '',
                    'placeholder' => 'z. B. angebot-angefragt',
                    'condition' => ['enable_tracking' => 'yes'],
                    'description' => 'Erscheint unter Engagement › Eigene Events.',
                ]);
            }

            $element->end_controls_section();
        } catch (\Throwable $th) {
            error_log('AnalyticsWP Elementor: ' . $th->getMessage());
        }
    }

    /**
     * A button or call to action with "Klicks zählen": data-awp-event on
     * its wrapper, so a click anywhere in it counts once.
     *
     * @param \Elementor\Element_Base $element
     */
    public static function mark_widget($element): void
    {
        try {
            $type = $element->get_name();
            if ($type === 'form' || !isset(self::SECTIONS[$type]) || !method_exists($element, 'get_settings_for_display')) {
                return;
            }
            $settings = $element->get_settings_for_display();
            if (($settings['enable_tracking'] ?? '') !== 'yes') {
                return;
            }

            $name = sanitize_key(str_replace(' ', '-', (string)($settings['event_name'] ?? '')));
            $element->add_render_attribute('_wrapper', [
                'data-awp-event' => $name !== '' ? $name : ($type === 'button' ? 'button-klick' : 'cta-klick'),
                'data-awp-prop-element' => $type,
            ]);
        } catch (\Throwable $th) {
            error_log('AnalyticsWP Elementor: ' . $th->getMessage());
        }
    }

    /**
     * An Elementor Pro form was sent and validated.
     *
     * @param \ElementorPro\Modules\Forms\Classes\Form_Record $record
     * @param \ElementorPro\Modules\Forms\Classes\Ajax_Handler $ajax_handler
     */
    public static function track_form_submission($record, $ajax_handler): void
    {
        try {
            $settings = (array)$record->get('form_settings');
            if (($settings['analyticswp_conversion'] ?? 'yes') !== 'yes') {
                return;
            }

            $form_name = (string)($settings['form_name'] ?? '');
            Event::track_server_event('form_submission', [
                'conversion_type' => self::CONVERSION_TYPE,
                'form_id' => (string)($settings['id'] ?? ''),
                'form_name' => $form_name !== '' ? $form_name : 'Elementor-Formular',
            ]);
        } catch (\Throwable $th) {
            error_log('AnalyticsWP Elementor: ' . $th->getMessage());
        }
    }
}
