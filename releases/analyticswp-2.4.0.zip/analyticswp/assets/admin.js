/**
 * AnalyticsWP admin: everything the server-rendered pages cannot do alone.
 * One IIFE, no jQuery, no libraries (as in Pixel Made Simple).
 *
 * 1. Chart: switch the metric from the key figure tiles, show the values
 *    under the pointer.
 * 2. UTM link builder.
 * 3. Live view: reload every N seconds while the tab is visible.
 * 4. Copy buttons.
 * 5. Tooltips for terms (.awp-term, .awp-few, [data-awp-tip]).
 * 6. Hover groups: [data-awp-hover] containers whose [data-awp-key]
 *    elements light up together (a donut segment and its table row).
 * 7. Switches that save on change ([data-awp-autosave]).
 *
 * Everything is progressive: without JS the pages stay readable, terms
 * keep their title, switches post with their form.
 */
(function () {
	'use strict';

	var nf = new Intl.NumberFormat('de-DE', { maximumFractionDigits: 0 });
	var pf = new Intl.NumberFormat('de-DE', { style: 'percent', maximumFractionDigits: 1 });

	function format(value, kind, currency) {
		if (kind === 'percent') {
			return pf.format(value);
		}
		if (kind === 'money') {
			try {
				return new Intl.NumberFormat('de-DE', { style: 'currency', currency: currency || 'EUR', maximumFractionDigits: 0 }).format(value);
			} catch (e) {
				return nf.format(value) + ' ' + currency;
			}
		}
		if (kind === 'duration') {
			var s = Math.round(value || 0);
			return s < 60 ? s + ' Sek.' : Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2) + ' Min.';
		}
		return nf.format(value);
	}

	function el(tag, className, text) {
		var node = document.createElement(tag);
		if (className) {
			node.className = className;
		}
		if (text !== undefined) {
			node.textContent = text;
		}
		return node;
	}

	// 1. Chart ---------------------------------------------------------------

	function initChart(chart) {
		var data;
		try {
			data = JSON.parse(chart.getAttribute('data-awp-chart'));
		} catch (e) {
			return;
		}

		var card = chart.closest('.awp-card') || document;
		var tiles = card.querySelectorAll('[data-awp-metric]');
		var active = chart.getAttribute('data-awp-active');
		var plot = chart.querySelector('.awp-chart-plot');

		var strip = chart.querySelector('.awp-chart-strip');
		var stripLegend = chart.querySelector('[data-awp-strip-legend]');
		var stripOff = strip ? (strip.getAttribute('data-awp-strip-off') || '').split(' ') : [];
		var title = chart.querySelector('[data-awp-chart-title]');

		function select(metric, focus) {
			if (!data.metrics[metric]) {
				return;
			}
			active = metric;
			chart.querySelectorAll('[data-awp-series]').forEach(function (node) {
				// The attribute, not .hidden: SVG groups have no such property.
				node.toggleAttribute('hidden', node.getAttribute('data-awp-series') !== metric);
			});
			tiles.forEach(function (tile) {
				var on = tile.getAttribute('data-awp-metric') === metric;
				tile.setAttribute('aria-selected', on ? 'true' : 'false');
				tile.tabIndex = on ? 0 : -1;
				if (on && focus) {
					tile.focus();
				}
			});
			// The conversion strip says nothing next to conversions or revenue.
			var noStrip = stripOff.indexOf(metric) !== -1;
			if (strip) {
				strip.toggleAttribute('hidden', noStrip);
			}
			if (stripLegend) {
				stripLegend.hidden = noStrip;
			}
			if (title) {
				title.textContent = data.metrics[metric].title || data.metrics[metric].label;
			}
			var svg = chart.querySelector('svg');
			if (svg) {
				svg.setAttribute('aria-label', 'Verlauf ' + (data.metrics[metric].title || data.metrics[metric].label));
			}
			// Keep the choice in the URL, so a reload or a shared link shows it.
			try {
				var url = new URL(window.location.href);
				url.searchParams.set('metric', metric);
				window.history.replaceState(null, '', url.toString());
			} catch (e) {}
		}

		tiles.forEach(function (tile, index) {
			tile.tabIndex = tile.getAttribute('aria-selected') === 'true' ? 0 : -1;
			tile.addEventListener('click', function () {
				select(tile.getAttribute('data-awp-metric'), false);
			});
			tile.addEventListener('keydown', function (e) {
				var next = null;
				if (e.key === 'ArrowRight') {
					next = tiles[(index + 1) % tiles.length];
				} else if (e.key === 'ArrowLeft') {
					next = tiles[(index - 1 + tiles.length) % tiles.length];
				}
				if (next) {
					e.preventDefault();
					select(next.getAttribute('data-awp-metric'), true);
				}
			});
		});

		// Tooltip under the pointer: date, value, the period before with the
		// change (coloured by better/worse, not by up/down), conversions and
		// revenue of that bucket.
		var guide = el('div', 'awp-chart-guide');
		var dot = el('div', 'awp-chart-dot');
		var tip = el('div', 'awp-chart-tip');
		guide.hidden = dot.hidden = tip.hidden = true;
		plot.appendChild(guide);
		plot.appendChild(dot);
		plot.appendChild(tip);

		function markStrip(i) {
			if (!strip) {
				return;
			}
			strip.querySelectorAll('[data-i]').forEach(function (bar) {
				bar.classList.toggle('is-hover', bar.getAttribute('data-i') === String(i));
			});
		}

		function hide() {
			guide.hidden = dot.hidden = tip.hidden = true;
			markStrip(-1);
		}

		function row(label, value, className, swatch) {
			var line = el('div', 'awp-chart-tip-row' + (className ? ' ' + className : ''));
			var name = el('span');
			if (swatch) {
				name.appendChild(el('i', swatch));
			}
			name.appendChild(document.createTextNode(label));
			line.appendChild(name);
			line.appendChild(el('span', 'awp-chart-tip-value', value));
			return line;
		}

		plot.addEventListener('mousemove', function (e) {
			var series = data.metrics[active];
			var count = data.labels.length;
			if (!series || !count) {
				return;
			}
			var rect = plot.getBoundingClientRect();
			var x = Math.min(Math.max(e.clientX - rect.left, 0), rect.width);
			var i = count > 1 ? Math.round(x / rect.width * (count - 1)) : 0;
			var left = count > 1 ? i / (count - 1) * rect.width : rect.width / 2;
			var before = i < data.start;
			var after = i > data.end;
			var value = series.values[i] || 0;
			var max = series.max || 1;
			var top = rect.height - Math.min(value, max) / max * (rect.height * 220 / 240);

			guide.style.left = left + 'px';
			dot.style.left = left + 'px';
			dot.style.top = top + 'px';
			dot.hidden = before || after;
			guide.hidden = false;
			markStrip(before || after ? -1 : i);

			tip.textContent = '';
			var isLast = data.open && i === data.end;
			tip.appendChild(el('div', 'awp-chart-tip-date', data.labels[i] + (isLast ? ' (läuft noch)' : '')));

			if (before) {
				tip.appendChild(el('div', 'is-muted', 'Vor Messbeginn, keine Daten.'));
			} else if (after) {
				tip.appendChild(el('div', 'is-muted', 'Noch nicht erreicht.'));
			} else {
				tip.appendChild(row(series.label, format(value, series.format, data.currency), '', 'is-line'));
				if (data.compare && series.previous && series.previous.length > i) {
					var prev = series.previous[i] || 0;
					tip.appendChild(row('Zeitraum davor', format(prev, series.format, data.currency), 'is-muted', 'is-prev'));
					// A running bucket against a whole one would always look worse.
					if (prev > 0 && !isLast) {
						var change = (value - prev) / prev;
						var good = change === 0 ? null : ((change > 0) === !!series.better);
						var text = (change > 0 ? '+' : (change < 0 ? '−' : '± ')) + Math.abs(change * 100).toLocaleString('de-DE', { maximumFractionDigits: 0 }) + ' % zum Zeitraum davor';
						tip.appendChild(el('div', 'awp-chart-tip-delta' + (good === null ? '' : (good ? ' is-good' : ' is-bad')), text));
					}
				}
				tip.appendChild(el('div', 'awp-chart-tip-sep'));
				var extras = data.extras || {};
				if (active !== 'conversions' && extras.conversions) {
					tip.appendChild(row('Conversions', format(extras.conversions[i] || 0, 'number')));
				}
				if (active === 'conversions' || active === 'revenue') {
					tip.appendChild(row('Besucher', format((extras.visitors || [])[i] || 0, 'number')));
				}
				if (active !== 'revenue' && extras.revenue) {
					tip.appendChild(row('Umsatz', format(extras.revenue[i] || 0, 'money', data.currency)));
				}
				if (isLast) {
					tip.appendChild(el('div', 'awp-chart-tip-note', 'Zahlen kommen noch dazu.'));
				}
			}
			tip.hidden = false;

			var tipWidth = tip.offsetWidth;
			var tipLeft = left + 14;
			if (tipLeft + tipWidth > rect.width) {
				tipLeft = left - tipWidth - 14;
			}
			tip.style.left = Math.max(0, tipLeft) + 'px';
			tip.style.top = '4px';
		});
		plot.addEventListener('mouseleave', hide);
	}

	// Donut: the centre shows the hovered channel (hover group does the rest).
	function initDonut(donut) {
		var group = donut.closest('[data-awp-hover]');
		var value = donut.querySelector('.awp-donut-value');
		var label = donut.querySelector('.awp-donut-label');
		if (!group || !value || !label) {
			return;
		}
		function update() {
			var seg = donut.querySelector('.awp-donut-seg.is-hover');
			value.textContent = seg ? seg.getAttribute('data-share') : value.getAttribute('data-default');
			label.textContent = seg ? seg.getAttribute('data-name') : label.getAttribute('data-default');
		}
		group.addEventListener('mouseover', update);
		group.addEventListener('mouseleave', update);
		group.addEventListener('focusin', update);
	}

	// 2. UTM link builder ----------------------------------------------------

	function initUtm(box) {
		var fields = {};
		box.querySelectorAll('[data-awp-utm-field]').forEach(function (field) {
			fields[field.getAttribute('data-awp-utm-field')] = field;
		});
		var out = box.querySelector('[data-awp-utm-out]');
		var presets = box.querySelectorAll('[data-awp-utm-preset]');
		var copy = box.querySelector('[data-awp-copy-utm]');
		var full = '';

		// Lower case, no spaces: the report groups equal names.
		function clean(value) {
			return (value || '').toLowerCase().trim().replace(/\s+/g, '-');
		}

		function build() {
			var base = (fields.url ? fields.url.value : '').trim();
			var hash = '';
			var at = base.indexOf('#');
			if (at !== -1) {
				hash = base.slice(at);
				base = base.slice(0, at);
			}
			var params = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content'].map(function (key) {
				return [key, fields[key] ? clean(fields[key].value) : ''];
			}).filter(function (pair) {
				return pair[1] !== '';
			});
			var sep = base.indexOf('?') === -1 ? '?' : '&';

			out.textContent = '';
			out.appendChild(el('span', 'awp-utm-base', base));
			params.forEach(function (pair, i) {
				out.appendChild(el('span', 'awp-utm-key', (i === 0 ? sep : '&') + pair[0] + '='));
				out.appendChild(el('span', 'awp-utm-value', pair[1]));
			});
			if (hash) {
				out.appendChild(el('span', 'awp-utm-base', hash));
			}
			full = base + params.map(function (pair, i) {
				return (i === 0 ? sep : '&') + pair[0] + '=' + encodeURIComponent(pair[1]);
			}).join('') + hash;
		}

		Object.keys(fields).forEach(function (key) {
			fields[key].addEventListener('input', function () {
				if (key === 'utm_source' || key === 'utm_medium') {
					presets.forEach(function (preset) {
						preset.setAttribute('aria-pressed', 'false');
					});
				}
				build();
			});
		});

		presets.forEach(function (preset) {
			preset.addEventListener('click', function () {
				presets.forEach(function (other) {
					other.setAttribute('aria-pressed', other === preset ? 'true' : 'false');
				});
				if (fields.utm_source) {
					fields.utm_source.value = preset.getAttribute('data-source');
				}
				if (fields.utm_medium) {
					fields.utm_medium.value = preset.getAttribute('data-medium');
				}
				build();
			});
		});

		if (copy) {
			var label = copy.querySelector('span');
			copy.addEventListener('click', function () {
				if (!navigator.clipboard || !navigator.clipboard.writeText) {
					return;
				}
				navigator.clipboard.writeText(full).then(function () {
					var text = label.textContent;
					label.textContent = 'Kopiert';
					setTimeout(function () {
						label.textContent = text;
					}, 1500);
				}, function () {});
			});
		}

		build();
	}

	// Bar chart (conversions): tiles switch the metric, the tooltip splits
	// a bucket into purchases, forms and contact clicks.
	function initBars(chart) {
		var data;
		try {
			data = JSON.parse(chart.getAttribute('data-awp-bars'));
		} catch (e) {
			return;
		}
		var card = chart.closest('.awp-card') || document;
		var tiles = card.querySelectorAll('[data-awp-metric]');
		var active = chart.getAttribute('data-awp-active');
		var plot = chart.querySelector('.awp-bars-plot');
		var title = chart.querySelector('[data-awp-chart-title]');
		var tip = el('div', 'awp-chart-tip');
		tip.hidden = true;
		plot.appendChild(tip);

		function select(metric, focus) {
			if (!data.metrics[metric]) {
				return;
			}
			active = metric;
			chart.querySelectorAll('[data-awp-series]').forEach(function (node) {
				// The attribute, not .hidden: SVG groups have no such property.
				node.toggleAttribute('hidden', node.getAttribute('data-awp-series') !== metric);
			});
			tiles.forEach(function (tile) {
				var on = tile.getAttribute('data-awp-metric') === metric;
				tile.setAttribute('aria-selected', on ? 'true' : 'false');
				tile.tabIndex = on ? 0 : -1;
				if (on && focus) {
					tile.focus();
				}
			});
			if (title) {
				title.textContent = data.metrics[metric].title;
			}
			try {
				var url = new URL(window.location.href);
				url.searchParams.set('metric', metric);
				window.history.replaceState(null, '', url.toString());
			} catch (e) {}
		}

		tiles.forEach(function (tile, index) {
			tile.tabIndex = tile.getAttribute('aria-selected') === 'true' ? 0 : -1;
			tile.addEventListener('click', function () {
				select(tile.getAttribute('data-awp-metric'), false);
			});
			tile.addEventListener('keydown', function (e) {
				var next = e.key === 'ArrowRight' ? tiles[(index + 1) % tiles.length] : (e.key === 'ArrowLeft' ? tiles[(index - 1 + tiles.length) % tiles.length] : null);
				if (next) {
					e.preventDefault();
					select(next.getAttribute('data-awp-metric'), true);
				}
			});
		});

		function mark(i) {
			chart.querySelectorAll('.awp-bars-set span').forEach(function (bar) {
				bar.classList.toggle('is-hover', bar.getAttribute('data-i') === String(i));
			});
		}

		function row(label, value, icon) {
			var line = el('div', 'awp-chart-tip-row');
			line.appendChild(el('span', '', label));
			line.appendChild(el('span', 'awp-chart-tip-value', value));
			return line;
		}

		plot.addEventListener('mousemove', function (e) {
			var series = data.metrics[active];
			var count = data.labels.length;
			if (!series || !count) {
				return;
			}
			var rect = plot.getBoundingClientRect();
			var i = Math.min(count - 1, Math.max(0, Math.floor((e.clientX - rect.left) / rect.width * count)));
			mark(i);

			tip.textContent = '';
			var isLast = data.open && i === data.end;
			tip.appendChild(el('div', 'awp-chart-tip-date', data.labels[i] + (isLast ? ' (läuft noch)' : '')));
			if (i > data.end) {
				tip.appendChild(el('div', 'is-muted', 'Noch nicht erreicht.'));
			} else {
				var value = series.values[i];
				tip.appendChild(row(series.label, value === null || value === undefined ? '–' : format(value, series.format, data.currency)));
				var parts = data.parts || {};
				if (parts.purchase) {
					tip.appendChild(el('div', 'awp-chart-tip-sep'));
					var bought = parts.purchase[i] || 0;
					tip.appendChild(row('Käufe', bought + (parts.revenue && parts.revenue[i] ? ' · ' + format(parts.revenue[i], 'money', data.currency) : '')));
					tip.appendChild(row('Formulare', String(parts.form ? parts.form[i] || 0 : 0)));
					tip.appendChild(row('Kontakt-Klicks', String(parts.contact ? parts.contact[i] || 0 : 0)));
					if (parts.other && parts.other[i]) {
						tip.appendChild(row('Sonstige', String(parts.other[i])));
					}
				}
				if (isLast) {
					tip.appendChild(el('div', 'awp-chart-tip-note', 'Heute läuft noch.'));
				}
			}
			tip.hidden = false;
			var left = (i + 0.5) / count * rect.width;
			var tipLeft = left + 14;
			if (tipLeft + tip.offsetWidth > rect.width) {
				tipLeft = left - tip.offsetWidth - 14;
			}
			tip.style.left = Math.max(0, tipLeft) + 'px';
			tip.style.top = '4px';
		});
		plot.addEventListener('mouseleave', function () {
			tip.hidden = true;
			mark(-1);
		});
	}

	// Journeys mosaic: hover previews a visit, a click pins it; a bar of the
	// timeline marks its visits; the colour switches between result and
	// channel. The preview is static (fixed height), so nothing jumps.
	function initMosaic(mosaic) {
		var visits;
		try {
			visits = JSON.parse(mosaic.querySelector('.awp-mosaic-data').textContent);
		} catch (e) {
			return;
		}
		var card = mosaic.closest('.awp-card') || mosaic;
		var squares = mosaic.querySelectorAll('.awp-sq');
		var bins = mosaic.querySelectorAll('.awp-bin');
		var binTip = mosaic.querySelector('.awp-bin-tip');
		var empty = mosaic.querySelector('.awp-preview-empty');
		var preview = mosaic.querySelector('.awp-preview-card');
		var sprite = mosaic.querySelector('[data-awp-icon-sprite]');
		var unpin = mosaic.querySelector('[data-awp-unpin]');
		var pinned = null;
		var slot = function (name) {
			return preview.querySelector('[data-slot="' + name + '"]');
		};

		function icon(name) {
			var source = sprite ? sprite.querySelector('[data-name="' + name + '"] svg') : null;
			return source ? source.cloneNode(true) : document.createTextNode('');
		}

		function markBin(b) {
			bins.forEach(function (bin) {
				bin.classList.toggle('is-marked', bin.getAttribute('data-b') === String(b));
			});
		}

		function show(i) {
			var v = visits[i];
			if (!v) {
				empty.hidden = false;
				preview.hidden = true;
				markBin(-1);
				squares.forEach(function (sq) {
					sq.classList.remove('is-active');
				});
				return;
			}
			squares.forEach(function (sq) {
				sq.classList.toggle('is-active', sq.getAttribute('data-i') === String(i));
			});
			markBin(v.b);

			var tile = slot('icon');
			tile.textContent = '';
			tile.appendChild(icon(visitIcon(v.k)));
			var swatch = el('span', 'awp-swatch');
			swatch.style.background = 'var(--awp-ch-' + v.k.replace(/_/g, '-') + ')';
			tile.appendChild(swatch);
			slot('channel').textContent = v.n;
			slot('detail').textContent = v.d;
			var device = slot('device-icon');
			device.textContent = '';
			device.appendChild(icon(v.di));
			slot('when').textContent = v.dv + ' · ' + v.w;
			var dots = slot('dots');
			dots.textContent = '';
			v.x.forEach(function (dot, n) {
				dots.appendChild(el('i', dot === 'c' ? 'is-conv' : (n === 0 ? 'is-first' : '')));
			});
			slot('entry').textContent = v.e;
			slot('summary').textContent = v.p === 1 ? 'Nur diese eine Seite' : v.p + ' Seiten' + (v.t !== '–' ? ' in ' + v.t : '');
			var result = slot('result');
			result.textContent = '';
			if (v.s === 'conv') {
				result.appendChild(el('span', 'awp-pill-conv', (v.c === 1 ? '1 Conversion' : v.c + ' Conversions') + (v.r ? ' · ' + v.r : '')));
			} else {
				result.appendChild(el('span', 'awp-none', v.s === 'multi' ? 'Keine Conversion' : 'Abgesprungen'));
			}
			var open = slot('open');
			open.setAttribute('data-i', String(i));
			open.href = journeyUrl(v);
			unpin.hidden = pinned !== i;
			empty.hidden = true;
			preview.hidden = false;
		}

		var channelIcons = {};
		if (sprite) {
			try {
				channelIcons = JSON.parse(mosaic.getAttribute('data-awp-channel-icons') || '{}');
			} catch (e) {}
		}
		function visitIcon(channel) {
			return channelIcons[channel] || 'dots-three';
		}

		function journeyUrl(v) {
			try {
				var url = new URL(window.location.href);
				['only', 'empty', 'p', 'sel', 'q'].forEach(function (key) {
					url.searchParams.delete(key);
				});
				url.searchParams.set(v.u ? 'user' : 'visitor', v.u ? String(v.u) : v.v);
				url.hash = '';
				return url.toString();
			} catch (e) {
				return '#';
			}
		}

		squares.forEach(function (sq) {
			var i = parseInt(sq.getAttribute('data-i'), 10);
			sq.addEventListener('mouseenter', function () {
				show(i);
			});
			sq.addEventListener('focus', function () {
				show(i);
			});
			sq.addEventListener('click', function () {
				pinned = pinned === i ? null : i;
				squares.forEach(function (other) {
					other.setAttribute('aria-pressed', other === sq && pinned === i ? 'true' : 'false');
				});
				show(pinned === null ? i : pinned);
			});
		});
		mosaic.querySelector('.awp-sq-grid').addEventListener('mouseleave', function () {
			show(pinned === null ? -1 : pinned);
		});
		if (unpin) {
			unpin.addEventListener('click', function () {
				pinned = null;
				squares.forEach(function (sq) {
					sq.setAttribute('aria-pressed', 'false');
				});
				show(-1);
			});
		}

		// "Ganze Journey": the row in the list below when it is there.
		slot('open').addEventListener('click', function (e) {
			var v = visits[parseInt(this.getAttribute('data-i'), 10)];
			var row = v ? document.getElementById('awp-visit-' + v.id) : null;
			if (row) {
				e.preventDefault();
				row.open = true;
				row.classList.add('is-highlighted');
				row.scrollIntoView({ behavior: 'smooth', block: 'center' });
			}
		});

		bins.forEach(function (bin) {
			bin.addEventListener('mouseenter', function () {
				var b = bin.getAttribute('data-b');
				mosaic.classList.add('is-bin');
				squares.forEach(function (sq) {
					var v = visits[parseInt(sq.getAttribute('data-i'), 10)];
					sq.classList.toggle('is-dim', !v || String(v.b) !== b);
				});
				bins.forEach(function (other) {
					other.classList.toggle('is-dim', other !== bin);
				});
				binTip.textContent = '';
				binTip.appendChild(el('strong', '', bin.getAttribute('data-title')));
				binTip.appendChild(el('span', '', bin.getAttribute('data-text') + ' · im Mosaik markiert'));
				binTip.hidden = false;
				var wrap = binTip.parentNode.getBoundingClientRect();
				var rect = bin.getBoundingClientRect();
				var left = rect.left - wrap.left + rect.width / 2 - binTip.offsetWidth / 2;
				binTip.style.left = Math.max(0, Math.min(left, wrap.width - binTip.offsetWidth)) + 'px';
			});
		});
		mosaic.querySelector('.awp-bins').addEventListener('mouseleave', function () {
			mosaic.classList.remove('is-bin');
			squares.forEach(function (sq) {
				sq.classList.remove('is-dim');
			});
			bins.forEach(function (bin) {
				bin.classList.remove('is-dim');
			});
			binTip.hidden = true;
		});

		card.querySelectorAll('[data-awp-mosaic-mode]').forEach(function (button) {
			button.addEventListener('click', function () {
				var byChannel = button.getAttribute('data-awp-mosaic-mode') === 'channel';
				card.classList.toggle('is-by-channel', byChannel);
				card.querySelectorAll('[data-awp-mosaic-mode]').forEach(function (other) {
					var on = other === button;
					other.classList.toggle('is-active', on);
					other.setAttribute('aria-pressed', on ? 'true' : 'false');
				});
			});
		});
	}

	// 3. Live refresh --------------------------------------------------------

	var refreshTimer = null;

	function initRefresh(el) {
		var seconds = parseInt(el.getAttribute('data-awp-refresh'), 10) || 30;
		clearInterval(refreshTimer);
		refreshTimer = setInterval(function () {
			if (document.visibilityState !== 'visible') {
				return;
			}
			// In place where possible: no flash, scroll position kept.
			if (navigate) {
				navigate(window.location.href, { push: false, keepScroll: true, quiet: true });
			} else {
				window.location.reload();
			}
		}, seconds * 1000);
	}

	// 4. Copy buttons ----------------------------------------------------------

	function initCopy(button) {
		button.addEventListener('click', function () {
			var target = document.querySelector(button.getAttribute('data-awp-copy'));
			if (!target || !navigator.clipboard || !navigator.clipboard.writeText) {
				return;
			}
			var label = button.textContent;
			navigator.clipboard.writeText(target.value !== undefined ? target.value : target.textContent).then(function () {
				button.textContent = 'Kopiert';
				setTimeout(function () {
					button.textContent = label;
				}, 1500);
			}, function () {});
		});
	}

	// 5. Tooltips ---------------------------------------------------------------

	var tip = null;
	var tipOwner = null;

	function tipElement() {
		if (!tip) {
			tip = document.createElement('div');
			tip.className = 'awp-tip';
			tip.id = 'awp-tip';
			tip.setAttribute('role', 'tooltip');
			tip.hidden = true;
			document.body.appendChild(tip);
		}
		return tip;
	}

	/**
	 * Show text (or a DOM node) next to an element: above it, or below when
	 * there is no room. Shared by term tooltips and later chart tooltips.
	 */
	function showTip(owner, content) {
		var el = tipElement();
		el.textContent = '';
		if (typeof content === 'string') {
			el.textContent = content;
		} else {
			el.appendChild(content);
		}
		el.hidden = false;
		tipOwner = owner;
		owner.setAttribute('aria-describedby', 'awp-tip');

		var r = owner.getBoundingClientRect();
		var w = el.offsetWidth;
		var h = el.offsetHeight;
		var left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), window.innerWidth - w - 8);
		var top = r.top - h - 8;
		if (top < 8) {
			top = r.bottom + 8;
		}
		el.style.left = left + 'px';
		el.style.top = top + 'px';
	}

	function hideTip() {
		if (tip) {
			tip.hidden = true;
		}
		if (tipOwner) {
			tipOwner.removeAttribute('aria-describedby');
			tipOwner = null;
		}
	}

	function initTip(node) {
		// The title stays as the no-JS fallback; with JS it moves into the
		// bubble, so the browser does not show a second tooltip.
		var text = node.getAttribute('data-awp-tip') || node.getAttribute('title') || '';
		if (!text) {
			return;
		}
		var heading = node.getAttribute('data-awp-tip-title');
		node.setAttribute('data-awp-tip', text);
		node.removeAttribute('title');
		if (!node.hasAttribute('tabindex') && !node.querySelector('a, button, input')) {
			node.setAttribute('tabindex', '0');
		}

		var show = function () {
			if (heading) {
				var box = document.createElement('div');
				box.appendChild(el('strong', 'awp-tip-title', heading));
				box.appendChild(el('span', '', text));
				showTip(node, box);
			} else {
				showTip(node, text);
			}
		};
		node.addEventListener('mouseenter', show);
		node.addEventListener('focusin', show);
		node.addEventListener('mouseleave', hideTip);
		node.addEventListener('focusout', hideTip);
	}

	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape') {
			hideTip();
		}
	});
	window.addEventListener('scroll', hideTip, { passive: true });

	// 6. Hover groups -----------------------------------------------------------

	function initHoverGroup(group) {
		var current = null;

		function set(key) {
			if (key === current) {
				return;
			}
			current = key;
			group.classList.toggle('is-hovering', key !== null);
			group.querySelectorAll('[data-awp-key]').forEach(function (el) {
				el.classList.toggle('is-hover', key !== null && el.getAttribute('data-awp-key') === key);
			});
		}

		function keyOf(target) {
			var el = target && target.closest ? target.closest('[data-awp-key]') : null;
			return el && group.contains(el) ? el.getAttribute('data-awp-key') : null;
		}

		group.addEventListener('mouseover', function (e) {
			set(keyOf(e.target));
		});
		group.addEventListener('mouseleave', function () {
			set(null);
		});
		group.addEventListener('focusin', function (e) {
			set(keyOf(e.target));
		});
		group.addEventListener('focusout', function (e) {
			if (!group.contains(e.relatedTarget)) {
				set(null);
			}
		});
	}

	// 7. Autosave -----------------------------------------------------------------

	var statusTimer = null;

	function saveStatus(text, isError) {
		var head = document.querySelector('.awp-page-head');
		if (!head) {
			return;
		}
		var el = head.querySelector('.awp-save-status');
		if (!el) {
			el = document.createElement('span');
			el.className = 'awp-save-status';
			el.setAttribute('role', 'status');
			head.appendChild(el);
		}
		el.textContent = text;
		el.classList.toggle('is-error', !!isError);
		el.hidden = false;
		clearTimeout(statusTimer);
		if (!isError) {
			statusTimer = setTimeout(function () {
				el.hidden = true;
			}, 2500);
		}
	}

	// The privacy text after a change: preview paragraphs and the copy text.
	function updatePolicy(text) {
		var preview = document.getElementById('awp-policy');
		var copySource = document.getElementById('awp-policy-text');
		if (copySource) {
			copySource.value = text;
		}
		if (!preview) {
			return;
		}
		preview.textContent = '';
		text.split(/\n\n+/).forEach(function (paragraph, i) {
			preview.appendChild(el('p', i === 0 ? 'awp-policy-title' : '', paragraph));
		});
	}

	// "Bei 16 Anfragen … wären das zusätzlich 800 € Wert."
	function updateValueHint() {
		var box = document.querySelector('[data-awp-value-hint]');
		if (!box) {
			return;
		}
		var forms = parseInt(box.getAttribute('data-forms'), 10) || 0;
		var clicks = parseInt(box.getAttribute('data-clicks'), 10) || 0;
		var amount = function (setting) {
			var input = box.querySelector('[data-awp-autosave="' + setting + '"]');
			return input ? parseFloat(String(input.value).replace(',', '.')) || 0 : 0;
		};
		var hint = box.querySelector('.awp-value-hint');
		if (!hint || (forms === 0 && clicks === 0)) {
			return;
		}
		var parts = [];
		if (forms) {
			parts.push(nf.format(forms) + (forms === 1 ? ' Anfrage' : ' Anfragen'));
		}
		if (clicks) {
			parts.push(nf.format(clicks) + (clicks === 1 ? ' Kontakt-Klick' : ' Kontakt-Klicks'));
		}
		var total = forms * amount('value_per_form') + clicks * amount('value_per_contact');
		hint.textContent = 'Bei ' + parts.join(' und ') + ' in den letzten 30 Tagen wären das zusätzlich ' + nf.format(total) + ' € Wert. Er wird getrennt vom Umsatz gezeigt.';
	}

	function initAutosave(control) {
		var cfg = window.analyticswpAdmin || {};
		if (!cfg.ajaxurl || !cfg.nonce || !window.fetch) {
			return;
		}
		var isCheck = control.type === 'checkbox';
		var isRadio = control.type === 'radio';
		var isText = control.type === 'text' || control.type === 'number';
		var lastValue = isCheck ? (control.checked ? '1' : '') : control.value;

		if (isText) {
			control.addEventListener('input', updateValueHint);
		}

		control.addEventListener('change', function () {
			if (isRadio && !control.checked) {
				return;
			}
			var value = isCheck ? (control.checked ? '1' : '') : control.value;

			// The amber line belongs to the decision: show it while on.
			if (isCheck) {
				var field = control.closest('.awp-field');
				if (field) {
					field.querySelectorAll('[data-awp-when-on]').forEach(function (line) {
						line.hidden = !control.checked;
					});
				}
			}

			var body = new FormData();
			body.append('action', 'analyticswp_save_setting');
			body.append('nonce', cfg.nonce);
			body.append('setting', control.getAttribute('data-awp-autosave'));
			body.append('value', value);
			if (control.hasAttribute('data-awp-autosave-key')) {
				body.append('key', control.getAttribute('data-awp-autosave-key'));
			}

			control.classList.add('is-saving');
			fetch(cfg.ajaxurl, { method: 'POST', body: body, credentials: 'same-origin' })
				.then(function (r) {
					return r.json();
				})
				.then(function (res) {
					control.classList.remove('is-saving');
					if (!res || !res.success) {
						throw new Error(res && res.data && res.data.message ? res.data.message : 'Nicht gespeichert');
					}
					lastValue = value;
					saveStatus('✓ Gespeichert');
					if (res.data && typeof res.data.policy === 'string') {
						updatePolicy(res.data.policy);
					}
				})
				.catch(function (err) {
					control.classList.remove('is-saving');
					if (isCheck) {
						control.checked = !control.checked;
					} else if (isText) {
						control.value = lastValue;
						updateValueHint();
					}
					saveStatus(err && err.message ? err.message : 'Nicht gespeichert', true);
				});
		});
	}

	// "Administrator ausschließen": ticks a chip, which saves itself.
	function initCheckButton(button) {
		button.addEventListener('click', function () {
			var target = document.querySelector(button.getAttribute('data-awp-check'));
			if (!target || target.checked) {
				return;
			}
			target.checked = true;
			target.dispatchEvent(new Event('change'));
			var line = button.closest('.awp-tipline');
			if (line) {
				line.hidden = true;
			}
		});
	}

	// Integration switches: the form posts in the background.
	function initFormAutosave(form) {
		var toggle = form.querySelector('.awp-switch');
		var state = form.querySelector('[data-awp-switch-state]');
		if (!toggle || !window.fetch) {
			return;
		}
		toggle.addEventListener('change', function () {
			if (state) {
				state.textContent = toggle.checked ? 'An' : 'Aus';
			}
			toggle.classList.add('is-saving');
			// getAttribute: the hidden field named "action" shadows form.action.
			fetch(form.getAttribute('action'), { method: 'POST', body: new FormData(form), credentials: 'same-origin' })
				.then(function (r) {
					toggle.classList.remove('is-saving');
					if (!r.ok) {
						throw new Error('Nicht gespeichert');
					}
					saveStatus('✓ Gespeichert');
				})
				.catch(function (err) {
					toggle.classList.remove('is-saving');
					toggle.checked = !toggle.checked;
					if (state) {
						state.textContent = toggle.checked ? 'An' : 'Aus';
					}
					saveStatus(err.message || 'Nicht gespeichert', true);
				});
		});
	}

	// KI & Export: the preview follows range, parts and format; the state
	// goes into the URL, so a reload shows the same export.
	function initExport(form) {
		var nonce = form.getAttribute('data-awp-export');
		var pre = form.querySelector('#awp-export-preview');
		var size = form.querySelector('[data-awp-export-size]');
		var dates = form.querySelector('[data-awp-export-dates]');
		var copy = form.querySelector('[data-awp-export-copy]');
		var download = form.querySelector('[data-awp-export-download] span');
		var refresh = form.querySelector('.awp-export-refresh');
		if (!pre || !window.fetch || !window.FormData) {
			return;
		}
		if (refresh) {
			refresh.hidden = true;
		}
		var timer = null;
		var counter = 0;

		function update() {
			var data = new FormData(form);
			var query = new URLSearchParams();
			data.forEach(function (value, key) {
				query.append(key, value);
			});
			history.replaceState(null, '', form.getAttribute('action') + '?' + query.toString());

			data.append('action', 'analyticswp_export_preview');
			data.append('nonce', nonce);
			var mine = ++counter;
			pre.setAttribute('aria-busy', 'true');
			fetch(analyticswpAdmin.ajaxurl, { method: 'POST', body: data, credentials: 'same-origin' })
				.then(function (r) {
					return r.json();
				})
				.then(function (json) {
					if (mine !== counter) {
						return;
					}
					pre.removeAttribute('aria-busy');
					if (!json || !json.success) {
						throw new Error(json && json.data && json.data.message ? json.data.message : 'Vorschau nicht geladen');
					}
					pre.textContent = json.data.text;
					size.textContent = json.data.size;
					dates.textContent = json.data.dates;
					copy.textContent = json.data.copy;
					download.textContent = json.data.download;
				})
				.catch(function (err) {
					if (mine === counter) {
						pre.removeAttribute('aria-busy');
						size.textContent = err.message;
					}
				});
		}

		form.addEventListener('change', function () {
			clearTimeout(timer);
			timer = setTimeout(update, 150);
		});
	}

	// "In deiner KI eintragen": one help text at a time.
	function initAssistants(group) {
		var buttons = group.querySelectorAll('[data-awp-assistant]');
		var panels = document.querySelectorAll('[data-awp-assistant-help]');

		function show(key) {
			buttons.forEach(function (button) {
				button.setAttribute('aria-pressed', button.getAttribute('data-awp-assistant') === key ? 'true' : 'false');
			});
			panels.forEach(function (panel) {
				panel.hidden = panel.getAttribute('data-awp-assistant-help') !== key;
			});
		}

		buttons.forEach(function (button) {
			button.addEventListener('click', function () {
				show(button.getAttribute('data-awp-assistant'));
			});
		});
		group.classList.add('is-ready');
		show('claude');
	}

	// Live: "Aktualisiert vor x Sek." instead of the clock time.
	function initUpdated(el) {
		var at = parseInt(el.getAttribute('data-awp-updated'), 10) * 1000;
		var start = Date.now();
		function tick() {
			// Server time plus the time this page is open: no clock skew.
			var seconds = Math.max(0, Math.round((Date.now() - start) / 1000));
			el.textContent = seconds < 60 ? 'Aktualisiert vor ' + seconds + ' Sek.' : 'Aktualisiert vor ' + Math.floor(seconds / 60) + ' Min.';
		}
		if (at) {
			tick();
			setInterval(tick, 1000);
		}
	}

	// Table rows with exactly one filter or detail link: a click anywhere in
	// the row follows it. The link stays the keyboard target.
	function initRowLink(row) {
		var links = row.querySelectorAll('.awp-filter-link');
		if (links.length !== 1) {
			return;
		}
		row.classList.add('is-row-link');
		row.addEventListener('click', function (e) {
			if (e.target.closest('a, button, input, summary') || (window.getSelection && String(window.getSelection()) !== '')) {
				return;
			}
			links[0].click();
		});
	}

	// Navigation inside the app -------------------------------------------
	//
	// Links and GET forms that stay in the app load only the app
	// (admin-ajax "analyticswp_view", same HTML as the page) and swap it in:
	// no reload of the WordPress admin around it, scroll position kept
	// within a tab. Pointing at a link for a moment loads it ahead, so the
	// click often shows at once. Anything else is a normal page load.

	var navigate = null;

	function initNav() {
		if (!window.fetch || !window.history || !history.pushState || !window.DOMParser || !document.querySelector('.awp-app')) {
			return;
		}
		var cache = {};
		var hoverTimer = null;
		var loadingTimer = null;
		var counter = 0;

		function appUrl(href) {
			try {
				var url = new URL(href, window.location.href);
				if (url.origin !== window.location.origin || url.pathname.slice(-19) !== '/wp-admin/admin.php' || url.searchParams.get('page') !== 'analyticswp') {
					return null;
				}
				url.hash = '';
				return url.toString();
			} catch (e) {
				return null;
			}
		}

		function load(url) {
			if (!cache[url]) {
				var fragment = new URL(analyticswpAdmin.ajaxurl, window.location.href);
				new URL(url).searchParams.forEach(function (value, key) {
					fragment.searchParams.append(key, value);
				});
				fragment.searchParams.set('action', 'analyticswp_view');
				var request = fetch(fragment.toString(), { credentials: 'same-origin' }).then(function (r) {
					if (!r.ok) {
						throw new Error(String(r.status));
					}
					return r.text();
				});
				cache[url] = request;
				// A failed load is not kept; a successful one only shortly.
				request.catch(function () {
					if (cache[url] === request) {
						delete cache[url];
					}
				});
				setTimeout(function () {
					if (cache[url] === request) {
						delete cache[url];
					}
				}, 20000);
			}
			return cache[url];
		}

		function tabOf(url) {
			return new URL(url).searchParams.get('tab') || 'overview';
		}

		function swap(html, url, options) {
			var doc = new DOMParser().parseFromString(html, 'text/html');
			var fresh = doc.querySelector('.awp-app');
			var current = document.querySelector('.awp-app');
			if (!fresh || !current) {
				throw new Error('no app');
			}
			var sameTab = tabOf(url) === tabOf(window.location.href);
			var scroll = window.scrollY;

			hideTip();
			current.replaceWith(document.importNode(fresh, true));
			var sprite = doc.querySelector('svg.awp-sprite');
			var oldSprite = document.querySelector('svg.awp-sprite');
			if (sprite && oldSprite) {
				oldSprite.replaceWith(document.importNode(sprite, true));
			}

			if (options.push) {
				history.pushState({ awp: 1 }, '', url);
			}
			cache = {};
			init();

			if (options.keepScroll || sameTab) {
				window.scrollTo(0, scroll);
			} else {
				window.scrollTo(0, 0);
				var title = document.querySelector('.awp-title');
				if (title) {
					title.setAttribute('tabindex', '-1');
					title.focus({ preventScroll: true });
				}
			}
		}

		function setLoading(on) {
			clearTimeout(loadingTimer);
			if (!on) {
				document.documentElement.classList.remove('awp-is-loading');
				return;
			}
			// Only when it takes a moment: no flicker on a preloaded view.
			loadingTimer = setTimeout(function () {
				document.documentElement.classList.add('awp-is-loading');
			}, 120);
		}

		navigate = function (href, options) {
			var url = appUrl(href);
			if (!url) {
				window.location.href = href;
				return;
			}
			options = options || {};
			var mine = ++counter;
			if (!options.quiet) {
				setLoading(true);
			}
			load(url).then(function (html) {
				if (mine !== counter) {
					return;
				}
				setLoading(false);
				swap(html, url, options);
			}).catch(function () {
				if (mine !== counter) {
					return;
				}
				setLoading(false);
				if (!options.quiet) {
					window.location.href = href;
				}
			});
		};

		function eligible(a) {
			return !!a && !!a.href && !a.target && !a.hasAttribute('download') && a.getAttribute('href').charAt(0) !== '#'
				&& !!a.closest('.awp-app') && appUrl(a.href) !== null;
		}

		document.addEventListener('click', function (e) {
			if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
				return;
			}
			var a = e.target.closest ? e.target.closest('a') : null;
			if (!eligible(a)) {
				return;
			}
			e.preventDefault();
			navigate(a.href, { push: true });
		});

		document.addEventListener('submit', function (e) {
			var form = e.target;
			var submitter = e.submitter || null;
			if (e.defaultPrevented || !form.closest('.awp-app') || form.hasAttribute('data-awp-export')) {
				return;
			}
			var method = (submitter && submitter.getAttribute('formmethod')) || form.getAttribute('method') || 'get';
			var action = (submitter && submitter.getAttribute('formaction')) || form.getAttribute('action') || window.location.href;
			if (method.toLowerCase() !== 'get' || !appUrl(action)) {
				return;
			}
			var url = new URL(action, window.location.href);
			url.search = new URLSearchParams(new FormData(form, submitter)).toString();
			if (!appUrl(url.toString())) {
				return;
			}
			e.preventDefault();
			navigate(url.toString(), { push: true });
		});

		function prefetchLater(e) {
			var a = e.target.closest ? e.target.closest('a') : null;
			if (!eligible(a)) {
				return;
			}
			clearTimeout(hoverTimer);
			hoverTimer = setTimeout(function () {
				load(appUrl(a.href));
			}, 80);
		}
		document.addEventListener('mouseover', prefetchLater);
		document.addEventListener('focusin', prefetchLater);
		document.addEventListener('mouseout', function () {
			clearTimeout(hoverTimer);
		});

		history.replaceState({ awp: 1 }, '', window.location.href);
		window.addEventListener('popstate', function () {
			navigate(window.location.href, { push: false, keepScroll: true });
		});
	}

	function init() {
		document.querySelectorAll('[data-awp-chart]').forEach(initChart);
		document.querySelectorAll('.awp-table tbody tr').forEach(initRowLink);
		document.querySelectorAll('[data-awp-updated]').forEach(initUpdated);
		document.querySelectorAll('[data-awp-export]').forEach(initExport);
		document.querySelectorAll('[data-awp-assistants]').forEach(initAssistants);
		document.querySelectorAll('[data-awp-copy]').forEach(initCopy);
		document.querySelectorAll('.awp-term, .awp-few, [data-awp-tip]').forEach(initTip);
		document.querySelectorAll('[data-awp-hover]').forEach(initHoverGroup);
		document.querySelectorAll('[data-awp-donut]').forEach(initDonut);
		document.querySelectorAll('[data-awp-bars]').forEach(initBars);
		document.querySelectorAll('[data-awp-mosaic]').forEach(initMosaic);
		document.querySelectorAll('[data-awp-autosave]').forEach(initAutosave);
		document.querySelectorAll('[data-awp-check]').forEach(initCheckButton);
		document.querySelectorAll('[data-awp-form-autosave]').forEach(initFormAutosave);
		document.querySelectorAll('[data-awp-utm]').forEach(initUtm);
		var refresh = document.querySelector('[data-awp-refresh]');
		clearInterval(refreshTimer);
		if (refresh) {
			initRefresh(refresh);
		}
	}

	function boot() {
		init();
		initNav();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
