<?php
/**
 * Plugin Name: Analytics – schneller Messpunkt
 * Description: Lädt für die Messanfragen von Analytics nur Analytics (und Must-Have Cookie) statt aller Plugins. Wird von Analytics angelegt, aktualisiert und entfernt.
 * Version: {{VERSION}}
 *
 * analyticswp-fast-endpoint (managed by the plugin, overwritten on update)
 *
 * Every page view sends one request to admin-ajax.php (action
 * analyticswp_send_analytics). WordPress would load every active plugin for
 * it; the endpoint needs none of them but Analytics and, for the consent
 * cookie, Must-Have Cookie. Only that request is changed: the list of
 * active plugins it sees is cut down. Themes, drop-ins (object cache) and
 * wp-config.php load as always. Without Analytics in the list, nothing
 * changes.
 *
 * More plugins to keep, e.g. one that filters the endpoint:
 *   define('ANALYTICSWP_FAST_ENDPOINT_KEEP', 'my-plugin/my-plugin.php');
 * Off for a request: define('ANALYTICSWP_FULL_LOAD', true);
 */

defined('ABSPATH') || exit;

if (
	defined('DOING_AJAX') && DOING_AJAX
	&& isset($_POST['action']) && $_POST['action'] === 'analyticswp_send_analytics'
	&& !(defined('ANALYTICSWP_FULL_LOAD') && ANALYTICSWP_FULL_LOAD)
) {
	$analyticswp_keep = function ($file) {
		if (!is_string($file)) {
			return false;
		}
		if ($file === '{{BASENAME}}' || strpos($file, 'must-have-cookie/') === 0) {
			return true;
		}
		$extra = defined('ANALYTICSWP_FAST_ENDPOINT_KEEP') ? array_map('trim', explode(',', (string)ANALYTICSWP_FAST_ENDPOINT_KEEP)) : [];

		return in_array($file, $extra, true);
	};

	// Per site: a list of plugin files.
	add_filter('option_active_plugins', function ($plugins) use ($analyticswp_keep) {
		if (!is_array($plugins) || !in_array('{{BASENAME}}', $plugins, true)) {
			return $plugins;
		}

		return array_values(array_filter($plugins, $analyticswp_keep));
	}, PHP_INT_MAX);

	// Network-wide (multisite): plugin file => activation time.
	add_filter('site_option_active_sitewide_plugins', function ($plugins) use ($analyticswp_keep) {
		if (!is_array($plugins)) {
			return $plugins;
		}
		$own = isset($plugins['{{BASENAME}}']);
		$site = get_option('active_plugins');
		if (!$own && !(is_array($site) && in_array('{{BASENAME}}', $site, true))) {
			return $plugins;
		}

		return array_filter($plugins, $analyticswp_keep, ARRAY_FILTER_USE_KEY);
	}, PHP_INT_MAX);
}
